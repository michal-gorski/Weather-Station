---
name: resolution-notes-skill
description: "Generate AMS resolution notes for ticket closure. Supports two modes: full notes when Build and Release notes are not available, and a condensed mode when Build and Release notes exist."
argument-hint: "Provide ticket context, or say start to be guided"
---

# Resolution Notes Skill

This skill generates resolution notes in a standard AMS format for ticket updates and closure comments.

## Output Fields

- Requirement Summary:
- Release Approved By:
- Target Environment:
- Date and Time Implemented:
- Implementation Steps:
- Testing Performed:
- Rollback Instructions:
- Build and Release Notes Attached (Yes, No, N/A):

## Modes

### Mode A: Build and Release notes exist

Use this mode when a Build and Release note has already been created.

Populate these fields with specific values:

- Requirement Summary:
- Release Approved By:
- Target Environment:
- Date and Time Implemented:

For all remaining fields, set the value exactly to:

Please see Build and Release notes.

Set:

- Build and Release Notes Attached (Yes, No, N/A): Yes

### Mode B: Build and Release notes do not exist

Use this mode when no Build and Release note is available.

Populate all fields with full detail.

Set:

- Build and Release Notes Attached (Yes, No, N/A): No (or N/A if not applicable)

## Prompting Flow

If Build and Release note availability is unclear, ask first:

1. Do you already have a Build and Release note document for this ticket?

Then continue with the minimum required questions for the selected mode.

Attachment field rule:

- If Mode A, set Build and Release Notes Attached to Yes by default
- If Mode B, set Build and Release Notes Attached to No (or N/A if not applicable)
- Only ask a follow-up about attachment status if the user explicitly says the document exists but is not attached yet

### Required inputs for Mode A

1. Requirement Summary
2. Release Approved By
3. Target Environment
4. Date and Time Implemented

### Required inputs for Mode B

1. Requirement Summary
2. Release Approved By
3. Target Environment
4. Date and Time Implemented
5. Implementation Steps
6. Testing Performed
7. Rollback Instructions

## Formatting Rules

- Use UK English spelling by default
- Keep wording concise and customer-safe
- Do not invent approvals, dates, or testing outcomes
- If a field is unknown, ask instead of assuming

## Output Template

Requirement Summary:
<value>

Release Approved By:
<value>

Target Environment:
<value>

Date and Time Implemented:
<value>

Implementation Steps:
<value>

Testing Performed:
<value>

Rollback Instructions:
<value>

Build and Release Notes Attached (Yes, No, N/A):
<value>

## Example (Mode A)

Requirement Summary:
Confirmation logic updated to send Dokapi confirmation when invoiceWID is returned in regular listener flow.

Release Approved By:
Securex / Kris Laenens

Target Environment:
Production

Date and Time Implemented:
16/06/2026 14:17 BST

Implementation Steps:
Please see Build and Release notes.

Testing Performed:
Please see Build and Release notes.

Rollback Instructions:
Please see Build and Release notes.

Build and Release Notes Attached (Yes, No, N/A):
Yes

## Example (Mode B)

Requirement Summary:
Fix missing confirmation message in regular INTF074 processing.

Release Approved By:
Securex / Kris Laenens

Target Environment:
Sandbox

Date and Time Implemented:
15/06/2026 10:43 BST

Implementation Steps:
Updated CallConfirmUBLFile execute condition in assembly.xml to check invoiceWID instead of an unpopulated property.

Testing Performed:
Validated listener flow with UBL input and confirmed confirmation path is triggered when invoiceWID is present.

Rollback Instructions:
Revert execute condition to previous value and redeploy the integration package.

Build and Release Notes Attached (Yes, No, N/A):
No
