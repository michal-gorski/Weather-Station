---
name: unit-test-skill
description: "Populate the Kainos unit test Excel template with test cases from the current conversation. Use when the user asks to generate, export, or create a unit test document, test spec, or test spreadsheet for an integration. Captures test cases discussed or generated during the session and writes them to the standard template."
argument-hint: "Say 'start' to be walked through, or paste/describe your test cases"
---

# Unit Test Specification — Workflow Skill

This skill populates the Kainos AMS unit test Excel template with test cases from the current conversation. It captures test scenarios the user has discussed, generated, or reviewed during the chat and writes them into the standard branded template.

## When to Use

- The user has generated or discussed test cases for an integration and wants to capture them
- User asks to "create unit tests", "export test cases", "generate a test spec", or similar
- Post-build documentation where test scenarios need recording before handover

## Procedure

### Step 1 — Collect or Generate Test Cases

Scan the current conversation for test cases. Test cases typically appear as:

- Numbered lists of test scenarios with expected results
- Markdown tables with test/expected-result columns
- Bullet points describing what to test and what should happen
- Pass/fail results from test execution discussion

**If no test cases exist in the conversation**, offer to generate them. Based on the integration changes discussed (code, assembly, XSLT, mediations), propose test cases covering:

- Happy path (expected inputs producing expected outputs)
- Error/exception scenarios (malformed data, missing fields, empty payloads)
- Boundary conditions (empty files, single records, large volumes where relevant)
- Configuration variations (launch parameters, integration attributes)

Present proposed cases to the user for review and refinement before proceeding. The consultant decides what to test — do not finalise without their agreement.

Extract each test case into this structure:

| Field | Source | Required |
|---|---|---|
| **Test** | Test description / scenario name | Yes |
| **Expected Result** | What should happen when the test passes | Yes |
| **Outcome** | Pass / Fail / Not Run | No — default: `Not Run` |
| **Comments** | Additional notes, failure details, observations | No |

If the conversation contains pass/fail results (e.g. the user confirmed "all passed" or marked specific tests), populate the Outcome column accordingly. Otherwise default to `Not Run`.

### Step 2 — Gather Missing Information

Use `vscode_askQuestions` to collect anything not already known from context. Ask only for what is missing.

| # | Question | Notes |
|---|----------|-------|
| 1 | What is the **integration name**? | Used in the document title and filename. e.g. `INT001 Worker Outbound to SAP` |
| 2 | What is the **ServiceNow ticket ID**? (AMS only) | Used in the filename. e.g. `CS0066361`. Skip if already known or not AMS |
| 3 | What is the **customer / organisation name**? | Used in the filename. e.g. `Securex` |
| 4 | Are the test cases I found correct? | Show the extracted test cases as a numbered summary and ask the user to confirm, add, remove, or edit |

### Step 3 — Confirm Test Cases

Before generating the file, present the extracted test cases to the user in a clear summary:

```
I found N test cases in our conversation:

1. [Test description] → Expected: [expected result]
2. [Test description] → Expected: [expected result]
...

Outcome will default to "Not Run" unless results were discussed.
```

Ask the user to confirm or request changes. Once confirmed, proceed to generation.

### Step 4 — Generate the Excel File

Use the [Excel Fill Procedure](#excel-fill-procedure) below to populate the template and save it.

**Output filename convention:**

- AMS: `[Customer Name] [Case No] Unit Tests.xlsx`
  - Example: `Securex CS0101046 Unit Tests.xlsx`
- Implementation / other: `[Integration Name] Unit Tests.xlsx`
  - Example: `INT001 Worker Outbound Unit Tests.xlsx`

Default output location: the workspace root or a path the user specifies.

---

## Template Structure

The template (`references/templates/Unit_Test_Template.xlsx`) contains a single sheet named ` Unit Tests` (note the leading space) with:

| Area | Content |
|------|---------|
| **A1** | Title: "Integration - Unit Test Specification" — Segoe UI 20pt bold |
| **Row 2** | Empty spacer row |
| **Row 3** | Column headers (bold, coloured backgrounds): Test ID (amber), Test (amber), Expected Result (green), Outcome (green), Comments (blue) |
| **Column F** | Empty spacer column |
| **G3:H3** | Summary headers: "Test Result Analysis" / "Total" (yellow) |
| **Rows 4–37** | Pre-built data rows with sequential test IDs (001–035) |
| **G4:H6** | Summary formulas: COUNTIF for Pass/Fail/Not Run counts |
| **D4:D37** | Data validation: dropdown list → Pass / Fail / Not Run |

### Key Formatting

- Font: Segoe UI 10pt throughout data rows
- Headers: Segoe UI 10pt bold, centred, with wrap text
- Column D data validation sourced from G4:G6
- All data cells have `wrapText=True`

---

## Excel Fill Procedure

Use Python with `openpyxl` to populate the template. **Never use PowerShell COM automation** (hangs in headless terminals) and **never use ImportExcel** (unreliable on consultant laptops).

### Approach

1. Copy the template to the output location with the correct filename
2. Load the copy with `openpyxl` (without `data_only=True` to preserve formulas)
3. Optionally update the title in A1 to include the integration name
4. Clear existing data rows (rows 4 onwards, columns A–E only — preserve G4:H6 summary)
5. Write test case data to rows 4 onwards
6. Remove unused rows beyond the last test case
7. Update the data validation range on column D to match the actual data rows
8. Update the COUNTIF formula range in H4:H6 to cover all data rows
9. Save the workbook

### Fill Script

Adapt this script per invocation. Replace the test case data with gathered content.

```python
import openpyxl
import shutil
import os
from copy import copy
from openpyxl.worksheet.datavalidation import DataValidation

# --- Parameters (substitute from gathered data) ---
template_path = r'TEMPLATE_PATH'
output_path = r'OUTPUT_PATH'
integration_name = 'INTEGRATION_NAME'

# Each test case: (test_description, expected_result, outcome, comments)
# outcome must be one of: 'Pass', 'Fail', 'Not Run'
test_cases = [
    # ('Verify worker hire event triggers outbound', 'File generated with hire data', 'Not Run', ''),
]

# --- Copy template ---
shutil.copy2(template_path, output_path)

# --- Load workbook ---
wb = openpyxl.load_workbook(output_path)
ws = wb[' Unit Tests']

# --- Update title ---
if integration_name:
    ws['A1'].value = f'{integration_name} - Unit Test Specification'

# --- Capture formatting from row 4 (template data row) ---
style_row = 4
style_cells = {}
for col_letter in ['A', 'B', 'C', 'D', 'E']:
    src = ws[f'{col_letter}{style_row}']
    style_cells[col_letter] = {
        'font': copy(src.font),
        'fill': copy(src.fill),
        'border': copy(src.border),
        'alignment': copy(src.alignment),
        'number_format': src.number_format,
    }

# --- Clear existing data rows (columns A-E only, preserve G:H summary) ---
for row_num in range(4, ws.max_row + 1):
    for col_letter in ['A', 'B', 'C', 'D', 'E']:
        ws[f'{col_letter}{row_num}'].value = None

# --- Write test cases ---
num_tests = len(test_cases)
last_data_row = 3 + num_tests

for i, (test_desc, expected, outcome, comments) in enumerate(test_cases):
    row = 4 + i
    test_id = f'{i + 1:03d}'

    ws[f'A{row}'].value = test_id
    ws[f'B{row}'].value = test_desc
    ws[f'C{row}'].value = expected
    ws[f'D{row}'].value = outcome if outcome in ('Pass', 'Fail', 'Not Run') else 'Not Run'
    ws[f'E{row}'].value = comments if comments else None

    # Apply formatting
    for col_letter in ['A', 'B', 'C', 'D', 'E']:
        cell = ws[f'{col_letter}{row}']
        styles = style_cells[col_letter]
        cell.font = copy(styles['font'])
        cell.fill = copy(styles['fill'])
        cell.border = copy(styles['border'])
        cell.alignment = copy(styles['alignment'])
        cell.number_format = styles['number_format']

# --- Remove unused rows beyond test data (but keep rows with G:H summary) ---
# Only delete rows past both test data AND the summary area (row 6)
delete_from = max(last_data_row + 1, 7)  # Never delete rows 4-6 (summary area in G:H)
if delete_from <= ws.max_row:
    ws.delete_rows(delete_from, ws.max_row - delete_from + 1)

# Also clear columns A-E in rows between test data end and row 6 (if test data is shorter)
for row_num in range(last_data_row + 1, min(7, ws.max_row + 1)):
    for col_letter in ['A', 'B', 'C', 'D', 'E']:
        ws[f'{col_letter}{row_num}'].value = None

# --- Remove existing data validations on column D ---
ws.data_validations.dataValidation = [
    dv for dv in ws.data_validations.dataValidation
    if str(dv.sqref) != f'D4:D{ws.max_row + 50}'  # clear old range
]
# Remove all DV that covers column D at all
ws.data_validations.dataValidation = [
    dv for dv in ws.data_validations.dataValidation
    if 'D' not in str(dv.sqref).split(':')[0]
]

# --- Add data validation for Outcome column ---
if num_tests > 0:
    dv = DataValidation(type='list', formula1='$G$4:$G$6', allow_blank=True)
    dv.error = 'Please select Pass, Fail, or Not Run'
    dv.errorTitle = 'Invalid outcome'
    dv.sqref = f'D4:D{last_data_row}'
    ws.add_data_validation(dv)

# --- Update COUNTIF formulas in summary area ---
count_range = f'D4:D{max(last_data_row, 4)}'
ws['H4'].value = f'=COUNTIF({count_range},G4)'
ws['H5'].value = f'=COUNTIF({count_range},G5)'
ws['H6'].value = f'=COUNTIF({count_range},G6)'

# --- Save ---
wb.save(output_path)
wb.close()

print(f'Unit test document generated: {output_path}')
```

### Script Parameters

| Parameter | Source | Example |
|---|---|---|
| `template_path` | Skill template location | `references/templates/Unit_Test_Template.xlsx` |
| `output_path` | Workspace root + filename convention | `Securex CS0101046 Unit Tests.xlsx` |
| `integration_name` | Gathered from user in Step 2 | `INT001 Worker Outbound to SAP` |
| `test_cases` | Extracted from conversation in Step 1 | List of tuples: `(test, expected, outcome, comments)` |

### Key Rules

- **Always use `openpyxl`** — install with `py -m pip install openpyxl` if not present
- **Never use `data_only=True`** when loading — this strips formulas and replaces them with cached values
- **Write the script as a `.py` file, not inline in PowerShell** — the `$` characters in Excel formulas (`$G$4:$G$6`) cause PowerShell variable interpolation errors. Save the script to a temporary `.py` file and run with `py script.py`
- **Preserve G4:H6 summary area** — do not clear or overwrite the Test Result Analysis cells (G4:G6) or the COUNTIF formulas (H4:H6)
- **Copy formatting from row 4** — use `copy()` from `copy` module to clone font, fill, border, and alignment from the template row so new rows match the style
- **Outcome must be one of three values** — `Pass`, `Fail`, or `Not Run`. Default to `Not Run` if not specified
- **Test IDs are zero-padded** — format as `001`, `002`, `003`, etc.
- **Update data validation range** — when the number of test cases differs from the template, rebuild the data validation on column D
- **Update COUNTIF range** — set H4:H6 formulas to reference the actual data range, not the original D4:D296

---

## Platform Compatibility

| Platform | Support |
|---|---|
| Windows + Python 3 | Full support — primary path |
| macOS / Linux + Python 3 | Full support |
| No Python available | Fallback to paste map (see below) |

### Fallback: Paste Map

If Python is not available, output the test cases as a formatted paste map the user can manually enter into the template:

```
=== UNIT TEST PASTE MAP ===

Title: [Integration Name] - Unit Test Specification

| Test ID | Test | Expected Result | Outcome | Comments |
|---------|------|-----------------|---------|----------|
| 001 | [description] | [expected] | Not Run | |
| 002 | [description] | [expected] | Not Run | |
...

Copy each row into the corresponding Excel row starting at row 4.
```

---

## Common Patterns

### Test cases from a bullet list in chat

The user may have generated test cases as:
```
- Test that a hire event produces an output file
- Test that a termination event is excluded
- Test that special characters in names are handled
```

In this case, infer reasonable expected results from the test description, present for confirmation, and default outcome to `Not Run`.

### Test cases from a markdown table

The user may have a table like:
```
| Test | Expected Result |
|------|-----------------|
| Hire event | File generated with hire data |
| Termination | No output file produced |
```

Map columns directly to the template fields.

### Test cases with results

If the user discussed test execution and noted outcomes:
```
- Hire event → PASS
- Termination exclusion → PASS  
- Special characters → FAIL (unicode stripped)
```

Populate the Outcome column with the stated results and add failure details to Comments.
