---
name: integration-review-skill
description: "Review Workday integrations against AMS-AI-Config standards and produce Markdown READMEs (optionally HTML and an executive summary). Use when reviewing an entire customer portfolio of integrations or a single integration. Covers Studio, EIB, Document Transformation, and Payroll (PECI/PICOF/WECI). Source-only review against repo files (assembly.xml, XSL, Java) — does not require tenant exports."
argument-hint: "Customer name and repo path, or 'start' to be walked through the questions"
---

# Integration Review — Workflow Skill

This skill performs a structured review of Workday integrations against AMS-AI-Config standards and produces consistent Markdown deliverables. It supports two modes: **portfolio** (all integrations in a customer repo or repo set) and **single integration**. v1 is source-only — it reads `assembly.xml`, XSL stylesheets, and Java beans from the target repo. It does not consume tenant config exports, run logs, or DART output (see Further Considerations in `references/process-guide.md`).

## When to Use

- A customer onboards to AMS and we need a baseline portfolio review
- Periodic health review of a customer's integrations
- Pre-handover review when an integration is being inherited by AMS from implementation
- Spot-review of a single integration for risk before a planned change
- The user says "review this integration", "review these integrations", "tenant review", "integration portfolio review", "post deployment review", or similar

## Procedure

### Step 1 — Gather Information

Ask the user the following. Only ask for what is not already known from context.

| # | Question | Notes |
|---|----------|-------|
| 1 | What is the **customer name**? | e.g. `Reed`, `Securex`, `GEA` |
| 2 | What is the **target repo path** (or paths)? | Absolute path(s) on disk |
| 3 | **Mode**: portfolio (all integrations) or single integration? | Default: portfolio |
| 4 | If single — which **integration**? | Folder name or assembly.xml path |
| 5 | Is this work tied to an **AMS ticket** (CS-prefixed) or implementation? | Drives commit-message style |
| 6 | **Output location** | Default: per-integration READMEs under `docs/`, portfolio README at repo root |
| 7 | **Prior artefacts** to align style with? | Optional — path to existing review docs or HTML |

### Step 2 — Branch Check

Check the target repo's current branch.

- If on a non-`main`/`master` branch — proceed.
- If on `main` or `master` — warn the user and only continue after they explicitly confirm.

This mirrors the global branching rule in `.github/copilot-instructions.md`.

### Step 3 — Build the Inventory

Discover integrations in the target repo. Treat each of the following as a separate integration:

- Each folder containing a `ws/WSAR-INF/assembly.xml` (Workday Studio).
- Each EIB / DT export folder (typically XML + XSL pairs without an assembly).
- Each top-level Payroll integration (PECI/PICOF/WECI) — usually a Studio repo with payroll attributes.
- Shared component assemblies referenced by other integrations.

Produce a flat list of integrations with name, type, and source path. Confirm the list with the user before reviewing — large portfolios can run long, so a preview lets them prune.

### Step 4 — Per-Integration Review

For each integration:

1. Identify the integration type (Studio / EIB / DT / Payroll / Shared).
2. Apply the matching checklist(s) from `references/`:
   - Studio → [checklist-studio.md](./references/checklist-studio.md)
   - EIB / DT → [checklist-eib-dt.md](./references/checklist-eib-dt.md)
   - Payroll → [checklist-payroll.md](./references/checklist-payroll.md) **plus** the Studio checklist
   - Shared / utility → Studio checklist
3. Score every finding using [review-rubric.md](./references/review-rubric.md). Use the rubric's default severity; if you judge it differently, record a one-line **Override justification** on the finding.
4. Generate a per-integration Markdown file using [per-integration-template.md](./references/per-integration-template.md). Filename and location follow [output-conventions.md](./references/output-conventions.md).
5. Cite the AMS-AI-Config rule each finding violates by file and section heading (e.g. `assembly-patterns.instructions.md § Error Handling`). Do not duplicate rule text — link to it.
6. Apply Epistemic Humility — when the source alone cannot confirm a finding (security domains, tenant config, schedules), record it under **Uncertainties / Tenant Verification Required** rather than asserting it.

### Step 5 — Portfolio Aggregation (portfolio mode only)

Aggregate findings into a portfolio README at the repo root using [portfolio-template.md](./references/portfolio-template.md):

- Risk Summary table — counts of Critical / High / Medium / Low per integration.
- Top Recurring Issues — issues that appear across multiple integrations, ranked by frequency × severity.
- Per-Integration Index — name, risk badge, link to detail README.
- Priority Actions — flat list of recommended fixes in priority order.
- Tenant Verification Notes — consolidated list of items the source review could not confirm.

### Step 6 — Optional Deliverables

After Markdown output is produced, ask:

1. **HTML output?** If yes, produce an HTML version of the portfolio README (and per-integration READMEs if requested) following the formatting in [output-conventions.md](./references/output-conventions.md).
2. **Executive summary?** If yes, produce a short customer-facing summary — one page or less, no code, no jargon — saved as `EXECUTIVE_SUMMARY.md` at the repo root.

Do not produce HTML or executive summary by default.

### Step 7 — Commit and Hand Off

- Commit messages: prefix with the AMS ticket ID if one was supplied (e.g. `CS0091777: integration portfolio review`). Otherwise use a descriptive message (e.g. `Integration review — Reed portfolio`).
- Do not push — leave that for the user.
- Append the standard accountability reminder (see below).

## Constraints

- **Read-only against integration code.** Never modify `assembly.xml`, `.xsl`, `.java`, or any tenant artefact during a review.
- **No PII.** Strip or redact any personal data encountered in test files before quoting in a finding.
- **No invented findings.** If the source does not show a defect, do not invent one to balance severity counts.
- **Cite, do not duplicate.** Reference AMS-AI-Config rules; do not copy them into the output.
- **Flag uncertainty.** Anything that cannot be confirmed from source goes under tenant verification.

## Post-Run Reminder

After producing the deliverables, append this reminder verbatim:

> **Before you send this:** Read through the review with healthy scepticism, not blind trust. AI output is always wrong until you have proven it right. Cross-check the findings against the integration in Studio and the tenant before sharing with the customer.

## Quick Reference — Output Layout

```
<repo-root>/
├── README.md                       # portfolio summary (portfolio mode)
├── EXECUTIVE_SUMMARY.md            # optional, customer-facing
└── docs/
    ├── <IntegrationA>.md           # per-integration detail
    ├── <IntegrationB>.md
    └── …
```

## References

- [Review Rubric](./references/review-rubric.md) — severity definitions and default-severity-per-rule
- [Per-Integration Template](./references/per-integration-template.md) — README template for one integration
- [Portfolio Template](./references/portfolio-template.md) — repo-root README template
- [Studio Checklist](./references/checklist-studio.md) — assembly, MVEL, XSLT, paging, error handling
- [EIB / DT Checklist](./references/checklist-eib-dt.md) — EIB and Document Transformation specifics
- [Payroll Checklist](./references/checklist-payroll.md) — PECI/PICOF/WECI specifics
- [Process Guide](./references/process-guide.md) — review process derived from internal Post Deployment guide
- [Output Conventions](./references/output-conventions.md) — file naming, locations, commit format
