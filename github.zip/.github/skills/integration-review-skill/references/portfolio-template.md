# Portfolio README Template

Use this template for the repo-root `README.md` in portfolio mode. Filename and location are defined in `output-conventions.md`.

---

```markdown
# <Customer> — Integration Portfolio Review

<One paragraph: scope of review (which integrations, which repo), date, reviewer, source standards applied. Link to AMS-AI-Config copilot-instructions.md if appropriate (note: relative link only resolves locally).>

## Risk Summary

| Integration | 🔴 Critical | 🟠 High | 🟡 Medium | 🟢 Low | Detail |
|-------------|------------|---------|-----------|--------|--------|
| <IntegrationA> | 1 | 3 | 5 | 2 | [details](docs/<IntegrationA>.md) |
| <IntegrationB> | 0 | 1 | 4 | 0 | [details](docs/<IntegrationB>.md) |
| **Totals** | <sum> | <sum> | <sum> | <sum> | |

## Top Recurring Issues

Issues that appear across multiple integrations, ranked by frequency × severity.

| # | Issue | Affected | Default Severity | Rule Source |
|---|-------|----------|------------------|-------------|
| 1 | <short title> | <N integrations> | 🟠 High | `assembly-patterns.instructions.md § Error Handling` |
| 2 | <short title> | <N integrations> | 🟡 Medium | `assembly-patterns.instructions.md § MVEL Best Practices` |

## Integration Index

| Integration | Type | Overall Risk | Detail |
|-------------|------|--------------|--------|
| <IntegrationA> | Studio | 🟠 High | [docs/<IntegrationA>.md](docs/<IntegrationA>.md) |
| <IntegrationB> | EIB | 🟡 Medium | [docs/<IntegrationB>.md](docs/<IntegrationB>.md) |

Overall risk is the highest severity present on the integration.

## Priority Actions

Listed in recommended order. Each action references the integration(s) and finding(s) that drove it.

1. **<Action>** — affects <IntegrationA>, <IntegrationB>. See <findings>.
2. **<Action>** — affects <IntegrationC>. See <findings>.

## Tenant Verification Required

Consolidated list of items the source review could not confirm. The customer or AMS lead should verify these in-tenant before treating the review as complete.

- <item> — relevant to <IntegrationA>
- <item> — relevant to <IntegrationB>, <IntegrationC>

## Review Scope and Limitations

- **Source-only review.** Findings are based on repo files (`assembly.xml`, `.xsl`, `.java`). Tenant config, integration system attributes, security group memberships, schedules, and previous run outcomes were not consulted.
- **Standards applied.** AMS-AI-Config rules in effect at review date — see `.github/instructions/` and `.github/copilot-instructions.md` in the AMS-AI-Config repo.
- **DART / SOFI not run.** Recommend running these in-tenant for a complete picture.

## Reviewer Notes

<Free-text section for anything that does not fit the structured tables — e.g. recurring patterns across the portfolio, history context, customer-specific constraints discovered during review.>
```

---

## Authoring Rules

1. **Risk Summary table** — every integration in scope must appear, even if all counts are zero. Totals row is mandatory.
2. **Top Recurring Issues** — minimum threshold: appears on 2+ integrations. List a maximum of 10. If fewer than 2 recurring issues exist, write "No recurring issues identified across the portfolio." and skip the table.
3. **Overall Risk** in the Integration Index = highest severity present on the integration (Critical > High > Medium > Low). If zero findings, use 🟢 Low.
4. **Priority Actions** — order by: Critical first, then High, then by number of integrations affected. Aim for 5–10; do not pad.
5. **Tenant Verification Required** — must include the items from every per-integration README's Uncertainties section, deduplicated.
6. **Cross-repo links** — if linking to AMS-AI-Config from inside a customer repo, note that the link only resolves locally with sibling checkouts. Do not invent a URL.

## Gold Sample for Style Reference

`AMS-Reed/README.md` is the gold reference for tone, table density, and risk-badge usage.
