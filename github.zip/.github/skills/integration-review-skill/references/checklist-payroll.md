# Payroll Integration Checklist (PECI / PICOF / WECI)

Use this checklist for payroll integrations **in addition to** the Studio checklist (or the EIB/DT checklist for PICOF DT-mode). It covers payroll-specific rules from `payroll-integrations.instructions.md`, `peci-reference.md`, `picof-reference.md`.

## How to Identify

- **PECI** — Payroll Effective Change Interface. Full-stack effective-dated. Typically Studio with PECI service.
- **PICOF** — Payroll Interface Connector / Outbound Files. Top-of-stack delta or full. Studio or DT.
- **WECI** — Workday External Connector Interface. HCM data for non-payroll vendor; supports contingent workers.
- **DCoD** — Data Cloud on Demand. API pull pattern.
- **Event-Driven Integration** — real-time hire/term to vendor via PECI service.

Pay group, pay period schedule, and change-detection mode are mandatory checks for all of the above.

---

## 1. Connector Selection

| Check | Source | Notes |
|-------|--------|-------|
| Connector chosen matches requirement (see selection matrix) | `payroll-integrations.instructions.md` | |
| Full-stack + effective-dated history → PECI | `payroll-integration-guide.md` | |
| Top-of-stack delta/full → PICOF | `payroll-integration-guide.md` | |
| Non-payroll HCM with contingent workers → WECI | `payroll-integration-guide.md` | |
| On-demand API pull → DCoD | `payroll-integration-guide.md` | |
| Real-time event-driven → Event-Driven Integration (PECI service) | `payroll-integration-guide.md` | |

## 2. Pay Group and Pay Period Schedule

| Check | Source | Notes |
|-------|--------|-------|
| Pay group(s) in scope documented in README or integration attributes | `payroll-integrations.instructions.md` | |
| Pay period schedule documented (frequency, period start/end logic) | `payroll-integrations.instructions.md` | |
| Pay period calendar maintenance policy noted | `process-guide.md § Maintenance Tasks` | |

## 3. Change Detection (LSRD)

| Check | Source | Notes |
|-------|--------|-------|
| Last Successful Run Date (LSRD) handling correct | `peci-reference.md` | High — broken change detection = wrong data |
| Change detection mode appropriate (Effective Date Range vs Entry Moment) | `peci-reference.md` | |
| Full extract attribute available for re-baseline runs | `peci-reference.md` | |
| First-run / catch-up behaviour documented | `peci-reference.md` | |

## 4. Field Overrides

| Check | Source | Notes |
|-------|--------|-------|
| Overrides configured in tenant where Workday supports it (not hardcoded in XSL) | `payroll-integrations.instructions.md` | |
| Where XSL override is unavoidable, justification documented in stylesheet header | `payroll-integrations.instructions.md` | |
| Override naming follows convention | `naming-conventions.instructions.md` | |

## 5. Earnings, Deductions, and Currency

| Check | Source | Notes |
|-------|--------|-------|
| External earnings / deductions mapped via tenant config, not XSL `<xsl:choose>` | `payroll-integrations.instructions.md` | |
| Currency conversion applied where source is multi-currency | `payroll-integrations.instructions.md` | |
| Conversion source (rate type, rate date) is correct for payroll period | `payroll-integrations.instructions.md` | |

## 6. Scheduling

| Check | Source | Notes |
|-------|--------|-------|
| Schedule frequency matches vendor ingest capacity | `process-guide.md § Schedule Policy` | |
| Schedule does not overlap with previous run (no concurrent executions) | `process-guide.md § Schedule Policy` | |
| Schedule expiration handling considered | `process-guide.md § Schedule Policy` | |
| Environment restriction prevents prod schedule firing in sandbox | `process-guide.md § Delivery / Retrieval Restrictions` | |

## 7. PECI-Specific

| Check | Source | Notes |
|-------|--------|-------|
| Sub-process collections present where required | `peci-reference.md` | |
| Data section filters applied (e.g. Cost Center, Position) | `peci-reference.md` | |
| `isAdded` / `isUpdated` / `isDeleted` flags read correctly per data section | `peci-reference.md` | |
| Hire / termination / change events handled distinctly | `peci-reference.md` | |
| Standalone calls separated from in-payload data sections (avoids duplicate emission — see Liantis CS0082253 pattern) | `peci-reference.md` | |

## 8. PICOF-Specific

| Check | Source | Notes |
|-------|--------|-------|
| Delta vs full extract mode appropriate | `picof-reference.md` | |
| Output format matches vendor requirement (CSV / XML / fixed-width) | `picof-reference.md` | |
| File header / trailer record correct | `picof-reference.md` | |

## 9. WECI-Specific

| Check | Source | Notes |
|-------|--------|-------|
| Contingent worker inclusion configured if vendor requires | `payroll-integration-guide.md` | |
| Non-payroll data only — sensitive payroll data not leaking to non-payroll vendor | `payroll-integration-guide.md` | |

## 10. Things to Flag for Tenant Verification

- ISU permissions on payroll domains (Process Payroll, View Payroll)
- Pay group membership and population
- Pay period calendar current and projected
- Attribute values (LSRD, full extract flag, vendor endpoint)
- Map values for earnings / deductions / pay components
- Notification recipients on payroll failures
- Recent run history (was last run successful, what errors occurred)
- Schedule active and not paused
