# Review Process Guide

This guide adapts the internal Kainos Post Deployment Services review framework (originally drafted 2017) to v1 of the Integration Review skill. v1 is **source-only** — it does not consume tenant exports, run logs, DART output, or SOFI output. Items requiring tenant access are listed for the user to verify out-of-band and to capture under each per-integration README's "Uncertainties / Tenant Verification Required" section.

The categories below mirror the original framework so an experienced reviewer can map skill output back to the legacy template.

---

## 1. Documentation (Section 2.1 of legacy guide)

### Design Documents

Source-only checks the skill can perform:

- Does the repo contain a design document or README that describes purpose, flow, integration system IDs, types, users, launch parameters, attributes/maps, field overrides, web services, scheduling, security, and mappings?
- If yes, is it consistent with the assembly / XSL? Flag drift.
- If no, list this as a gap.

The skill cannot verify design vs production tenant — flag for tenant verification.

### Run Books

- Is there a run book or operations note describing how to launch the integration, expected parameters, and where to view output? Flag absence.

### Naming Conventions

- Check integration system IDs, ISUs, calculated fields, custom reports, stylesheets against `naming-conventions.instructions.md`.
- Source-only: stylesheet filenames, project / assembly names, sub-assembly names, property prefixes.
- Tenant-only: integration system names, ISU names, security group names, calculated field / custom report names → flag for verification.

### Permissions and Notifications

The skill cannot verify in-tenant. Always list under Uncertainties:

- Who is authorised to run this integration
- Who is authorised to view output
- Who should be notified on success / on error
- Whether "no file retrieved" notifications are suppressed when appropriate

---

## 2. Previous Integration Runs (Section 2.2)

Not available in source-only review. Always flag for tenant verification:

- Prevalence of warnings and errors in recent runs
- Whether errors logged are truly errors or should be downgraded to warnings
- Whether the customer is being bombarded with false-positive errors

---

## 3. Security (Section 2.3)

Source-only checks:

- No hardcoded secrets in assembly.xml (Critical finding if present)
- ISU referenced via integration attributes, not implementer account names visible in code
- SOAP / REST calls reference appropriate domains via configuration, not hardcoded URLs

Tenant-only — always flag for verification:

- Security groups grant only what is needed
- Terminated employee accounts deactivated
- Integrations assigned ISUs (not implementer accounts)
- Launch and view-output permissions correct
- SOFI tool output reviewed: https://community.workday.com/node/562544

---

## 4. Custom Reports and Calculated Fields (Section 2.4)

Source-only:

- If repo contains report definitions, check ISU ownership and naming.

Tenant-only — always flag for verification:

- Reports / integrations owned by ISUs (not implementer accounts)
- Naming conventions followed for reports and calculated fields
- Shared calculated fields used where appropriate
- Data source choice (indexed vs standard) appropriate for performance

See `custom-reports-and-calculated-fields.md` in AMS-AI-Config for the rule set.

---

## 5. Automated Analysis (Section 2.5)

DART (Delivery Assurance Review Tool) and SOFI are **not consumed by v1** of the skill. If DART has been run separately, the user can paste findings into the review or flag them in the customer hand-off. v2 may ingest DART spreadsheets directly — see Further Considerations below.

DART checks for:

- Business Processes, Calculated Fields, External Deductions, Document Field Overrides, Data Initialization Service, Documents, Security Domains, Document Transformation, External Earnings, EIB, Integration Events, Cloud Collections, Integration Tenant Setup, Integration System, Integration System User, Constrained / Unconstrained Integration System Security Groups, Packaged Integration Systems, Scheduled Integration Processes, Custom Reports, Studio Integrations, System Tenant Setup, XSL.

DART: https://community.workday.com/node/219325

---

## 6. Delivery / Retrieval / Schedule Restrictions (Section 2.6)

Source-only:

- Assembly uses Workday delivery service where possible (not bespoke Studio transport).
- Filename convention includes integration ID and timestamp.

Tenant-only — flag for verification:

- Environment restrictions configured so prod-only services don't fire in sandbox / implementation tenants
- Test environment enabled where needed

---

## 7. Maps and Attributes (Section 2.7)

Source-only:

- Maps reference Workday fields, not free text (so renames don't break the integration).
- Map definitions exist for tunable code translations rather than hardcoded `<xsl:choose>` blocks.

Tenant-only — flag for verification:

- Map values populated and current
- Integration attributes set to expected values

---

## 8. Integration-Type Specifics (Section 3)

Maps directly to:

- **Core Connector Worker** → general guidance; transaction log used where possible. Flag absence.
- **Payroll Interface** → `checklist-payroll.md`.
- **Workday Studio** → `checklist-studio.md`. Scaling, errors/warnings setup, splitter-XSLT pattern, Workday delivery service preference.
- **Document Transformation** → `checklist-eib-dt.md`. XSLT best practices.
- **Single Sign On** → tenant-only; flag for verification (documentation of current SSO process).

---

## 9. Maintenance Tasks (Section 5)

Tenant-only — list under Uncertainties / verification, do not score:

- WD update test plan exists
- ISUs / queue users / report owners exempt from password expiry where appropriate
- Two-factor / step-up auth configured for sensitive activities
- Password policy (length, complexity, rotation, lockout, timeout)
- Email notifications for sensitive BP events
- Restriction on who can modify business processes / disable alerts
- Schedule expiration handling
- Pay period calendar update policy

---

## 10. Further Considerations (post-v1)

- **DART ingest** — accept the DART output spreadsheet and merge findings into the report.
- **SOFI ingest** — surface security findings from SOFI.
- **Tenant config ingest** — accept exports of integration systems, attributes, maps, schedules, security groups.
- **Previous-run analysis** — accept a recent run log / consolidated report and produce warning-noise metrics.
- **HTML report** — produce a single HTML deliverable matching the legacy CCS Tenant Review style for customer hand-off.

These are listed in `SKILL.md` Step 6 as optional, but only HTML is supported in v1; the others are scoped for v2.
