# Studio Integration Checklist

Run this checklist against every Workday Studio integration (anything with `ws/WSAR-INF/assembly.xml`). Each item cites the AMS-AI-Config rule it tests; severities are in `review-rubric.md`.

## How to Use

1. Read `assembly.xml` end to end before running the checklist.
2. For each item, record either "OK" or a finding. Findings go into the per-integration README under the matching severity table.
3. Cite the rule source on every finding.

---

## 1. Assembly Header

| Check | Source | Notes |
|-------|--------|-------|
| Assembly version is 2025.21 (or current standard) | `assembly-patterns.instructions.md § Assembly Version` | Older versions: see rubric thresholds |
| All projects in the collection share the same assembly version | `assembly-patterns.instructions.md § Assembly Version` | |
| `use-global-error-handlers="true"` set on `cc:assembly` | `assembly-patterns.instructions.md § Error Handling` | |

## 2. Global Error Handling

| Check | Source | Notes |
|-------|--------|-------|
| `cc:global-error-handler` element present | `assembly-patterns.instructions.md § Error Handling` | |
| Global handler routes to `PutIntegrationMessage` with severity `CRITICAL` | `assembly-patterns.instructions.md § Required Patterns` | |
| Global handler extracts `context.errorMessage` via `util.cleanString()` | `assembly-patterns.instructions.md § Required Patterns` | |
| Global handler sets `Propagate Abort = true` after `setAbort` | `assembly-patterns.instructions.md § Terminating Processing` | |

## 3. Per-Mediation Error Handling

For every `cc:mediation` (sync and async):

| Check | Source | Notes |
|-------|--------|-------|
| Mediation has at least one `cc:error-handler` defined | `assembly-patterns.instructions.md § Required Patterns` | |
| Error handler captures error context (does not just rethrow) | `assembly-patterns.instructions.md § Required Patterns` | |
| Async mediations propagate errors upstream where appropriate | `assembly-patterns.instructions.md` | |
| Integration is not "all or nothing" — single bad transaction does not kill the batch | `assembly-patterns.instructions.md § Required Patterns` | |

## 4. Secrets and Credentials

| Check | Source | Notes |
|-------|--------|-------|
| No hardcoded passwords, secrets, tokens, client IDs, or client secrets in assembly.xml | `copilot-instructions.md § Integration Lifecycle` | Critical finding |
| Sensitive values come from Integration System attributes (`intsys.getAttribute*`) | `assembly-patterns.instructions.md § Accessing Integration Attributes` | |
| OAuth refresh tokens not in source — configured in tenant | `assembly-element-catalog.md § OAuth` | |

## 5. MVEL Hygiene

For every `cc:eval`, template-capable property, and inline expression:

| Check | Source | Notes |
|-------|--------|-------|
| String concatenation uses `#` not `+` | `mvel-reference.md § Operators` | |
| `//` is not used as a comment (MVEL treats it as modulo) | `mvel-reference.md` | Critical — runtime error |
| Properties typed with literal values not strings (`= 0` not `= '0'`) | `assembly-patterns.instructions.md § Property Assignment Rules` | |
| Booleans use `true` / `false` literals not `'true'` / `'false'` | `assembly-patterns.instructions.md § Property Assignment Rules` | |
| `intsys.getAttributeAsBoolean()` / `getAttributeAsInt()` used for typed attributes | `assembly-patterns.instructions.md § Property Assignment Rules` | |
| `empty` literal used to check for null/0-length/whitespace | `mvel-reference.md § Operators` | |
| No `xpath` / `xpathB` inside template `@if` conditions | `mvel-reference.md § Performance` | |
| No `xpathF` or `parts[0].text` on potentially large message (>1M chars) | `mvel-reference.md § Performance` | |
| Template-capable properties wrap expressions in `@{}` | `mvel-reference.md` | Critical when wrong |
| Expression-capable properties do not wrap in `@{}` | `mvel-reference.md` | Critical when wrong |
| No data transformation in MVEL — XSLT used instead | `mvel-reference.md` | |
| MVEL 1.3 syntax only (no MVEL 2.x lambdas, `def`, etc.) | `mvel-reference.md` | |

## 6. Paging and Volume

| Check | Source | Notes |
|-------|--------|-------|
| Paged sources use `vm://wcc/PagedGet` (not direct SOAP get with Page=1, Count=999) | `assembly-patterns.instructions.md § PagedGet Selection Matrix` | |
| `PagedGet` configured with correct aggregate XPaths | `assembly-element-catalog.md § PagedGet` | |
| Minimal Safe Defaults followed for `PagedGet` | `assembly-patterns.instructions.md § Minimal Safe Defaults` | |
| Splitter consumes paged stream, not full document in MVEL | `assembly-patterns.instructions.md` | |

## 7. XSLT in Studio

| Check | Source | Notes |
|-------|--------|-------|
| XSLT 3.0 with XSLT+ component used (not legacy XSLT step) — unless EIB/DT compatibility required | `xsl-standards.instructions.md` | |
| No XSLT 1.0 anywhere | `xsl-standards.instructions.md § Version Selection` | |
| Stylesheets have standard header comment block | `xsl-standards.instructions.md` | |
| XSLT applied inside splitter, not against entire document | `xsl-standards.instructions.md` | Performance |
| ETV / XTT attributes present for tenant-tunable values | `xsl-standards.instructions.md` | |
| Code translation uses integration maps (`etv:map`/`xtt:map`), not hardcoded `<xsl:choose>` | `xsl-standards.instructions.md` | |

## 8. Routing and Termination

| Check | Source | Notes |
|-------|--------|-------|
| `setAbort(true)` always paired with `Propagate Abort = true` on subsequent local-out | `assembly-patterns.instructions.md § Terminating Processing` | |
| No write-steps performing data transformation — XSLT used instead | `mvel-reference.md` | Write steps only for small static payloads |
| Delivery uses Workday delivery service where possible (not Studio component) | `process-guide.md § Delivery / Retrieval` | |

## 9. Custom Beans (when present)

For each `.java` file under `src/main/java/`:

| Check | Source | Notes |
|-------|--------|-------|
| Bean has `@AssemblyComponent` and required annotations | `java-beans.instructions.md` | Critical when missing |
| Bean does not swallow exceptions silently | `java-beans.instructions.md` | |
| Bean uses current `MediationContext` API (no deprecated calls) | `java-beans.instructions.md` | |
| Third-party JAR shipped with licence note | `java-beans.instructions.md` | |
| Bean exists for a valid reason — built-in component is insufficient | `java-beans.instructions.md` | |

## 10. SSK (Studio Starter Kit) — Existing Integrations Only

If the integration uses SSK:

| Check | Source | Notes |
|-------|--------|-------|
| Flag SSK use in README — discourage extending; do not refactor without ticket | `ssk-reference.instructions.md` | |
| Cloud log and RaaS HashMap patterns extracted à la carte are fine; full SSK framework is not | `copilot-instructions.md § Skills & References` | |

## 11. Naming Conventions

| Check | Source | Notes |
|-------|--------|-------|
| Component names follow tenant naming convention | `naming-conventions.instructions.md` | |
| Property names use the documented prefixes (`p.`, `pi.`, `ia.`, `lp.`, etc.) | `naming-conventions.instructions.md` | |
| Sub-assembly local-in/local-out names descriptive | `naming-conventions.instructions.md` | |

## 12. Logging and Observability

Error *handling* is covered in sections 2–3. This section covers proactive logging — the messages the integration emits during normal and degraded operation, so the customer can diagnose without raising a ticket.

| Check | Source | Notes |
|-------|--------|-------|
| `PutIntegrationMessage` emitted at meaningful checkpoints — run start, end of each phase, record counts, paging round-trips | `assembly-patterns.instructions.md § Error Handling` | High when a complex multi-step integration has zero INFO messages |
| Warnings emitted (severity `WARNING`) for skipped records, partial failures, vendor non-2xx responses, retries | `assembly-patterns.instructions.md § Error Handling` | |
| Severity used correctly — `CRITICAL` only for run-failing errors, `WARNING` for per-record issues, `INFO` for status | `assembly-patterns.instructions.md § Error Handling` | |
| Run identifier (e.g. event ID, timestamp, GUID) emitted at start and referenced in every error / warning message for traceability | `assembly-patterns.instructions.md` | |
| HTTP-out vendor response codes captured and logged on non-2xx (not just on connection failure) | `assembly-element-catalog.md § HTTP` | |
| Record counts logged at each major transformation boundary (input read, post-split, post-XSLT, sent) | `assembly-patterns.instructions.md` | Helps diagnose silent data loss |
| Cloud Log component used where customer has adopted the pattern (SSK à la carte) | `ssk-reference.instructions.md`, `copilot-instructions.md § Skills & References` | Medium when absent on integrations the customer needs to self-diagnose |
| Custom beans use slf4j / log4j at INFO / WARN / ERROR (no `System.out.println`) | `java-beans.instructions.md` | |
| No PII in log messages — worker names, NI numbers, emails, national IDs redacted | `copilot-instructions.md § General Principles` | Critical when PII present |
| No secrets in log messages — tokens, passwords, client secrets never logged even on error | `copilot-instructions.md § Integration Lifecycle` | Critical when present |
| `util.cleanString()` applied to any user / vendor data before emission to `PutIntegrationMessage` | `assembly-patterns.instructions.md § Required Patterns` | Prevents "invalid Rich Text" failures |
| Excessive logging avoided — no per-record INFO on high-volume runs (use counts/summaries instead) | `assembly-patterns.instructions.md` | Performance and Process Monitor noise |

## 13. Things to Flag for Tenant Verification

Items the source alone cannot confirm. Always list these in the per-integration README's Uncertainties section:

- Integration System User assigned and active
- Security group memberships for Launch, Deploy, View Output
- Schedule frequency and next-run time
- Integration attributes' actual values in tenant
- Map values populated in tenant
- Recent run outcomes and prevalence of warnings/errors
- Notification recipients
- Delivery / retrieval environment restrictions
- Process Monitor / Cloud Log retention period
- Whether prior runs' warnings have actually been triaged or are being ignored as noise
