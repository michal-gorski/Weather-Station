# Output Conventions

File naming, locations, and commit-message rules for the Integration Review skill.

---

## File Layout

```
<target-repo-root>/
├── README.md                       # portfolio summary (portfolio mode only)
├── EXECUTIVE_SUMMARY.md            # optional, customer-facing (Step 6)
├── README.html                     # optional HTML export of portfolio README (Step 6)
└── docs/
    ├── <IntegrationName>.md        # per-integration detail
    └── <IntegrationName>.html      # optional HTML per-integration
```

## Per-Integration File Naming

| Source | Filename pattern |
|--------|------------------|
| Studio integration (folder containing `ws/WSAR-INF/assembly.xml`) | `docs/<FolderName>.md` |
| EIB | `docs/<EIB Object Name with spaces replaced by underscores>.md` |
| Document Transformation | `docs/<DT Name>.md` |
| Payroll integration (Studio) | `docs/<FolderName>.md` |
| Shared component assembly | `docs/SharedComponents.md` or `docs/<ComponentName>.md` |

- Use the folder name unless the integration has an explicit ID in `WorkdayManifest.xml` — prefer the explicit ID.
- Replace spaces with underscores. Do not abbreviate.
- Do not include the customer name in the filename — the parent repo carries that.

## Portfolio README Location

- **Portfolio mode** — write to `<repo-root>/README.md`. If an existing README already exists and is the previous review, overwrite it. If the existing README is non-review content (e.g. a build instructions README), **do not overwrite** — ask the user whether to rename the existing file or place the review at `REVIEW.md`.

## Optional HTML Output

When the user opts in to HTML (Step 6 of `SKILL.md`):

- Filename mirrors the Markdown filename with `.html` extension.
- Use a single-file self-contained HTML (no external CSS / JS / image dependencies) so it can be emailed as an attachment.
- Render Markdown headings, tables, badges (Critical/High/Medium/Low) using inline CSS.
- Apply the badge colours: Critical `#d73a49`, High `#e36209`, Medium `#dbab09`, Low `#28a745`.
- Top of file: customer name, review date, scope summary.

## Optional Executive Summary

When the user opts in to an executive summary (Step 6):

- File: `<repo-root>/EXECUTIVE_SUMMARY.md`
- One page or less. No code blocks. No assembly version numbers. No rule citations.
- Structure:
  1. One-paragraph overview ("This review covered N integrations across…").
  2. Top 3 risks in plain language.
  3. Recommended next steps (3–5 bullets).
  4. Items requiring customer / tenant input.
- Suitable for the AMS lead to email to the customer.

## Commit Messages

| Context | Commit message pattern |
|---------|------------------------|
| AMS support with ticket | `<CS-ID>: integration review — <customer> <mode>` e.g. `CS0091777: integration review — Reed portfolio` |
| AMS support without ticket | Ask the user for a ticket; do not invent one |
| Implementation | `Integration review — <customer> <mode>` |
| Single integration | Append `(<IntegrationName>)` to either form above |

Commit only the review artefacts. Do not commit any integration code changes from a review run — the skill is read-only against integration source.

## Branch Handling

- Default expectation: target repo is on a non-`main` branch named after the review (e.g. `review/<customer>-<YYYY-MM>`).
- If on `main`, warn the user once, list the impact (review files will land directly on the default branch), and proceed only after explicit confirmation.
- Do not run `git push` — leave that for the user.

## PII

- Never include personal data in any output file.
- If quoting code, redact any embedded names, email addresses, employee IDs, or national identifiers with `<redacted>`.
- If the source contains PII (test data committed by mistake), flag it as a Critical finding in the per-integration README under "Security" with rule source `copilot-instructions.md § General Principles`.
