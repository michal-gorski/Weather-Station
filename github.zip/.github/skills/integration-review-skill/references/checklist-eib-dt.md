# EIB and Document Transformation Checklist

Run this checklist against EIB exports and Document Transformation (DT) artefacts in the target repo. DT and EIB share most rules, with EIB-specific items called out.

## How to Identify

- **EIB**: XML export of an EIB definition (typically named like the EIB), often paired with one or more XSLTs.
- **Document Transformation (DT)**: connector-driven (PICOF / PECI / Core Connector / Custom Reports) with a single-step XSLT reshape to CSV / fixed-width / EDI.
- **MDT (Multi-Document Transformation)**: variant of DT supporting multiple inputs/outputs and dynamic file naming.

If the artefact has an `assembly.xml`, it is Studio — use `checklist-studio.md` instead.

---

## 1. XSLT Version

| Check | Source | Notes |
|-------|--------|-------|
| XSLT 2.0 used (EIB / DT) | `xsl-standards.instructions.md § Version Selection` | |
| No XSLT 1.0 anywhere | `xsl-standards.instructions.md § Version Selection` | Forbidden |
| XSLT 3.0 not used for EIB/DT unless explicit reason | `xsl-standards.instructions.md § Version Selection` | |

## 2. Header and Structure

| Check | Source | Notes |
|-------|--------|-------|
| Stylesheet has standard header comment (purpose, owner, change log) | `xsl-standards.instructions.md` | |
| Output format declared correctly (`xsl:output`) | `xsl-standards.instructions.md` | |
| Logical templates / modes named, not anonymous match-all | `xsl-standards.instructions.md` | |
| No PII in stylesheet comments or test data | `copilot-instructions.md § General Principles` | |

## 3. Performance

| Check | Source | Notes |
|-------|--------|-------|
| Streaming applied where the input may be large | `xsl-standards.instructions.md` | |
| No repeated `//descendant::` style XPath on large docs | `xsl-standards.instructions.md` | |
| Keys (`xsl:key`) used for repeated lookups | `xsl-standards.instructions.md` | |

## 4. ETV / XTT and Maps

| Check | Source | Notes |
|-------|--------|-------|
| ETV / XTT attributes present on tunable values | `xsl-standards.instructions.md` | |
| Code translation uses `etv:map` / `xtt:map` integration maps | `xsl-standards.instructions.md § Document Transformation Connector` | |
| No hardcoded translation tables in `<xsl:choose>` for vendor codes | `xsl-standards.instructions.md` | High when vendor codes change frequently |
| Maps reference Workday fields, not free text | `process-guide.md § Maps and Attributes` | |

## 5. EIB-Specific

| Check | Source | Notes |
|-------|--------|-------|
| EIB is the right tool — not a Studio job in disguise | `integration-design-skill` | |
| Source: custom report or Workday web service appropriate | `custom-reports-and-calculated-fields.md` | |
| Source report uses indexed data source where available | `custom-reports-and-calculated-fields.md` | |
| Calculated fields shared rather than duplicated | `custom-reports-and-calculated-fields.md` | |
| Delivery type (SFTP, email, attachment) appropriate | `process-guide.md § Delivery / Retrieval` | |
| Inbound EIB has spreadsheet template versioned in repo | `xsl-standards.instructions.md` | |

## 6. DT-Specific

| Check | Source | Notes |
|-------|--------|-------|
| DT is preferred over Studio when source is a Connector and transformation is single-step | `xsl-standards.instructions.md § Version Selection` | |
| MDT considered if multiple inputs / outputs / dynamic filenames needed | `xsl-standards.instructions.md § Version Selection` | |
| Field overrides handled via tenant configuration, not hardcoded in XSL | `payroll-integrations.instructions.md` | |

## 7. Naming Conventions

| Check | Source | Notes |
|-------|--------|-------|
| XSLT filename follows naming convention | `naming-conventions.instructions.md` | |
| EIB / DT object names follow naming convention | `naming-conventions.instructions.md` | |
| Custom report and calculated field names follow convention | `naming-conventions.instructions.md` | Flag for tenant verification |

## 8. Delivery and Retrieval

| Check | Source | Notes |
|-------|--------|-------|
| Delivery uses Workday delivery service (not bespoke transport) | `process-guide.md § Delivery / Retrieval` | |
| Environment restriction in place so prod-only services don't fire in sandbox | `process-guide.md § Delivery / Retrieval Restrictions` | |
| Encryption (PGP / GPG) configured where vendor requires | `xsl-standards.instructions.md` | |
| Filename convention includes integration ID and timestamp | `naming-conventions.instructions.md` | |

## 9. Error Handling and Notifications

| Check | Source | Notes |
|-------|--------|-------|
| Validation messages on critical mapping rules | `xsl-standards.instructions.md` | |
| Notification block suppressed when "no file retrieved" if appropriate | `process-guide.md § Notifications` | Avoids false alarms |
| Notification recipients documented | Flag for tenant verification | |

## 10. Logging and Observability

EIB and DT have less logging surface than Studio, but the same diagnostic principles apply.

| Check | Source | Notes |
|-------|--------|-------|
| Validation messages (`xsl:message`) emitted at appropriate severity for skipped / rejected records | `xsl-standards.instructions.md` | |
| Validation message text identifies the record (by an external ID, not by PII) | `copilot-instructions.md § General Principles` | |
| No PII in validation messages — worker names, NI numbers, emails, national IDs redacted | `copilot-instructions.md § General Principles` | Critical when PII present |
| Record counts visible in the EIB / DT output (header / trailer record where format supports it) | `xsl-standards.instructions.md` | Helps detect silent truncation |
| Vendor delivery success / failure surfaced to the integration event (not silently swallowed by the delivery service) | `process-guide.md § Delivery / Retrieval` | Flag for tenant verification |
| Run identifier in output filename (timestamp, sequence) | `naming-conventions.instructions.md` | Enables cross-referencing to Process Monitor |

## 11. Things to Flag for Tenant Verification

- Schedule frequency and next-run time
- Integration system user and security group memberships
- Calculated fields used by the source report (existence, correctness, sharing)
- Custom report data source choice (indexed vs standard)
- Notification recipients and "no file retrieved" behaviour
- Vendor delivery endpoint and credentials
- Map values populated in tenant
- Whether prior runs' validation warnings are triaged or ignored as noise
