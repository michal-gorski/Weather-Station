# Review Rubric — Severity Definitions and Default Severity Per Rule

Severity drives the README issue tables and the portfolio risk summary. Use the defaults below. If you judge a finding differently in context (e.g. a Medium-default issue that has caused repeated production incidents), override it and record a one-line **Override justification** on the finding.

## Severity Levels

| Level | Badge | Definition |
|-------|-------|------------|
| **Critical** | 🔴 | Currently causing or imminently certain to cause production failure, data loss, security exposure, or compliance breach. Customer impact is active or unavoidable. Fix immediately. |
| **High** | 🟠 | Will fail under realistic conditions (load, edge data, error path). No active impact yet but the integration is fragile or insecure. Fix in the next planned window. |
| **Medium** | 🟡 | Best-practice violation with a credible failure mode but no near-term incident expected. Reduces maintainability or hides errors. Address opportunistically. |
| **Low** | 🟢 | Cosmetic, naming, or style deviation. No functional risk. Address during the next touch on the integration. |

## How to Apply

1. Locate the matching rule in the checklist references — each rule has a default severity.
2. Use the default unless the integration's context makes it clearly wrong.
3. If overriding, write `**Override justification:** <reason>` on a new line under the finding.
4. Never invent a severity — if no rule matches, find the nearest rule, cite it, and explain the analogy.

## Default Severity Per Rule

The tables below map each AMS-AI-Config rule to a default severity. Where a rule cites a source file, the citation is the canonical owner of the rule — the rubric does not duplicate the rule text.

### Studio — Assembly & Error Handling
*(source: `assembly-patterns.instructions.md`, `assembly-element-catalog.md`)*

| Rule | Default | Notes |
|------|---------|-------|
| Hardcoded secrets in assembly.xml (clientId, secret, password, token) | Critical | Security exposure even in private repos |
| No global error handler defined | High | Single bad transaction halts the run silently |
| Mediation without error handler on async/sync flows | High | Errors lost or rethrown without context |
| Error message extracted without `util.cleanString()` | Medium | Risk of "invalid Rich Text" failure in `PutIntegrationMessage` |
| `setAbort(true)` without `Propagate Abort = true` on subsequent `local-out` | High | Abort silently swallowed |
| All-or-nothing batch design (one failure kills the run) | High | Fix only if loop processes >1 transaction |
| Assembly version older than 2025.21 | Medium | Critical if older than 2022 |
| Assembly version older than 2020 | Critical | Likely deprecated APIs and runtime |

### Studio — MVEL
*(source: `mvel-reference.md`, `assembly-patterns.instructions.md § Property Assignment Rules`)*

| Rule | Default | Notes |
|------|---------|-------|
| String concatenation with `+` instead of `#` | Medium | High if any operand could be numeric |
| MVEL 2.x syntax (e.g. `def`, lambdas) used where MVEL 1.3 required | Critical | Will not parse at runtime |
| `//` used as comment (it is modulo in MVEL) | Medium | Causes division-by-zero at runtime |
| `xpath` / `xpathB` in MVEL template `@if` conditions | High | Severe performance overhead on large docs |
| `xpathF` or `parts[0].text` on potentially large message (>1M chars) | High | Hard runtime limit |
| Untyped property assignment (`props['x'] = '0'` instead of `props['x'] = 0`) | Medium | Causes downstream type confusion |
| Complex transformation done in MVEL/XPath property chains instead of XSLT | High | Maintainability and performance |
| Template-capable property missing `@{}` wrapper | Critical | Expression evaluated as literal string |
| Expression-capable property wrapped in `@{}` | Critical | Expression treated as text |
| Empty string `''` used instead of `null` literal for empty values | Low | |

### Studio — Routing & Paging
*(source: `assembly-patterns.instructions.md`, `assembly-element-catalog.md` § PagedGet)*

| Rule | Default | Notes |
|------|---------|-------|
| Direct SOAP get for paged dataset (no `PagedGet`) — Page=1, Count=999 hardcoded | High | Silent data loss above the page limit |
| `PagedGet` configured but aggregate XPaths missing | High | Pages fetched but not merged |
| Splitter consuming entire document in MVEL before XSLT | High | Memory/perf risk on large datasets |
| `Propagate Abort = true` missing on local-out after `setAbort` | High | See assembly checklist |

### Studio — XSLT in Studio
*(source: `xsl-standards.instructions.md`)*

| Rule | Default | Notes |
|------|---------|-------|
| XSLT 1.0 used anywhere | High | Forbidden by standard |
| Studio integration using legacy XSLT step instead of XSLT+ component (no DT/EIB compatibility need) | Medium | |
| XSLT applied to full document instead of splitter+template | High | Performance |
| Missing standard header comment block | Low | Maintainability |
| ETV / XTT attributes missing for tenant-tunable values | Medium | |
| Hardcoded code translation instead of integration map | Medium | High if codes change frequently |

### Studio — Logging and Observability
*(source: `assembly-patterns.instructions.md`, `ssk-reference.instructions.md`, `java-beans.instructions.md`)*

| Rule | Default | Notes |
|------|---------|-------|
| PII present in log messages (`PutIntegrationMessage`, Cloud Log, server log) | Critical | Compliance exposure |
| Secrets (token, password, client secret) emitted to any log channel | Critical | Security exposure |
| Complex multi-step integration emits zero INFO messages — no checkpoints, no counts | High | Customer cannot self-diagnose |
| HTTP-out non-2xx response not logged (only connection failures captured) | High | Hides vendor-side rejections |
| No record counts at transformation boundaries on a data-moving integration | Medium | Allows silent data loss |
| Severities used incorrectly (e.g. CRITICAL for per-record skip, INFO for run failure) | Medium | Train customer to ignore real errors |
| No run identifier emitted for cross-message correlation | Medium | |
| Cloud Log pattern absent where adopted elsewhere in the customer portfolio | Medium | Consistency |
| Custom bean uses `System.out.println` instead of slf4j / log4j | Medium | |
| `util.cleanString()` missing on data passed to `PutIntegrationMessage` | Medium | "invalid Rich Text" risk |
| Per-record INFO logging on high-volume run | Medium | Performance + Process Monitor noise |

### EIB / Document Transformation
*(source: `xsl-standards.instructions.md` § DT, `payroll-integrations.instructions.md` where applicable)*

| Rule | Default | Notes |
|------|---------|-------|
| XSLT version other than 2.0 used in EIB/DT | High | |
| Code translation hardcoded in `<xsl:choose>` instead of `etv:map`/`xtt:map` | Medium | High if codes change frequently |
| No header comment on stylesheet | Low | |
| Naming convention violation on XSLT file | Low | |
| Delivery configured in Studio instead of using Workday delivery service | Medium | Per § Delivery / Retrieval in process guide |

### Payroll (PECI / PICOF / WECI)
*(source: `payroll-integrations.instructions.md`, `peci-reference.md`, `picof-reference.md`)*

| Rule | Default | Notes |
|------|---------|-------|
| Wrong connector chosen for requirement (e.g. WECI for full-stack payroll) | High | Redesign needed |
| Field overrides hardcoded in XSL that should be configured in tenant | Medium | |
| Pay group / pay period schedule not documented | Medium | |
| LSRD (Last Successful Run Date) handling absent or incorrect | High | Change detection broken |
| Currency conversion not applied where source is multi-currency | High | Data correctness |
| Schedule fires more frequently than vendor can ingest | Medium | |

### Naming Conventions
*(source: `naming-conventions.instructions.md`)*

| Rule | Default | Notes |
|------|---------|-------|
| Integration system name does not match convention | Low | |
| XSLT stylesheet name does not match convention | Low | |
| Calculated field / custom report name does not match convention | Low | Out of scope for source-only review — flag for tenant verification |

### Custom Beans (Java)
*(source: `java-beans.instructions.md`)*

| Rule | Default | Notes |
|------|---------|-------|
| Bean missing `@AssemblyComponent` or required annotations | Critical | Will not load |
| Bean swallowing exceptions silently | High | |
| Bean using deprecated MediationContext APIs | Medium | |
| Bean shipping third-party JAR without licence note | Medium | |

## Worked Examples

### Example 1 — Default applied

> **Finding:** Property `props['p.count']` assigned as `'0'` (string).
> **Severity:** 🟡 Medium *(default — `assembly-patterns.instructions.md` § Property Assignment)*
> **Recommendation:** Replace with `props['p.count'] = 0` so downstream arithmetic does not coerce silently.

### Example 2 — Override applied

> **Finding:** No global error handler defined.
> **Severity:** 🔴 Critical *(default High — overridden)*
> **Override justification:** Integration is the customer's sole payroll feed; a silent failure has already caused a missed pay run (CS0099123). Promote to Critical to match active business impact.
> **Recommendation:** Add `cc:global-error-handler` linked to `PutIntegrationMessage` with severity CRITICAL.

### Example 3 — No matching rule

> **Finding:** Splitter emits one message per worker; downstream HTTP-out has no concurrency limit configured.
> **Severity:** 🟠 High *(no exact rule; closest analogy — `assembly-patterns.instructions.md` § Error Handling, "do not build all-or-nothing integrations")*
> **Override justification:** Vendor rate-limit at 5 req/s; uncapped concurrency has triggered 429s in similar Reed integrations. Treat as High by analogy.
