# Per-Integration README Template

Use this template for every integration reviewed. The file lives under `docs/<IntegrationName>.md` (see `output-conventions.md`).

The output must match this structure exactly so portfolio aggregation can parse it. Tables with no rows should be omitted, not left empty.

---

```markdown
# <IntegrationName>

## Summary

<One paragraph: purpose, source, target, frequency. No marketing text. Plain English.>

## Overall Flow

<ASCII flow block — root entry point top, branches indented. Match the existing AMS-Reed docs style.>

```
EntryStep (workday-in)
  → StepA
  → Loop
    → StepB
    → StepC
  → ResultStep
```

## Assembly Version

**<version>** — <state> (current standard: 2025.21)

State values: `up to date`, `slightly outdated`, `outdated`, `critically outdated`. See `review-rubric.md` for thresholds.

## Issues Found

### Critical

| # | Issue | Details |
|---|-------|---------|
| 1 | **<short title>** | <one or two sentences; cite rule source> |

### High

| # | Issue | Details |
|---|-------|---------|
| 1 | **<short title>** | <one or two sentences; cite rule source> |

### Medium

| # | Issue | Details |
|---|-------|---------|
| 1 | **<short title>** | <one or two sentences; cite rule source> |

### Low

| # | Issue | Details |
|---|-------|---------|
| 1 | **<short title>** | <one or two sentences; cite rule source> |

## What Works Well

- <positive observation 1>
- <positive observation 2>

## Recommendations

1. <action>
2. <action>

## Uncertainties / Tenant Verification Required

- <item that cannot be confirmed from source alone>
- <item that cannot be confirmed from source alone>
```

---

## Authoring Rules

1. **Severity tables** — omit the entire section if there are no findings at that severity. Do not output an empty table.
2. **Issue title** — bold short phrase, no punctuation at the end. Title should read like a tag.
3. **Details** — one or two sentences. Cite the rule source inline using the form `assembly-patterns.instructions.md § Error Handling`.
4. **Override justifications** — when overriding the rubric default, add a line `**Override justification:** <reason>` under the Details cell.
5. **Recommendations** — concrete, actionable. Reference the file or component that needs to change.
6. **Uncertainties** — anything the source cannot prove (security group membership, tenant attribute values, actual schedule, prior run outcomes). Be explicit; the customer needs this list to verify in-tenant.
7. **No PII** — strip personal data from any quoted code or sample.
8. **What Works Well must not be empty.** If nothing positive exists, write "Integration is fundamentally broken — see Critical findings; no positives identified." Do not pad with platitudes.

## Gold Sample for Style Reference

`AMS-Reed/docs/INT2003_Archive_Files.md` and `AMS-Reed/docs/SharedComponents.md` are the gold references. Match their tone (terse, factual) and table density.
