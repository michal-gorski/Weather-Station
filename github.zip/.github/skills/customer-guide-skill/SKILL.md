---
name: customer-guide-skill
description: "Generate a branded customer-facing guide document. Use when the user asks to write, create, draft, or generate a customer guide, how-to guide, step-by-step guide, runbook, or handover document. Populates the Kainos branded Word template with gathered content — cover page, introduction, prerequisites, and task/step sections."
argument-hint: "Describe the guide topic, or say 'start' to be walked through the questions"
---

# Customer Guide — Workflow Skill

This skill produces customer-facing guide documents using the Kainos branded Word template. Guides are step-by-step instructional documents that walk the reader through a set of tasks. They are used for handovers, configuration guides, operational runbooks, and any customer-facing documentation that needs Kainos branding.

## When to Use

- User asks to create a customer guide, how-to document, or step-by-step guide
- Post-workshop handover documentation is needed
- Creating a configuration or operational runbook for a customer
- Any customer-facing document that should use the Kainos branded template

## Procedure

### Step 1 — Gather Information

Ask the user the following questions. They can answer all at once or interactively. Only ask for what you do not already know from context.

| # | Question | Notes |
|---|----------|-------|
| 1 | What is the **guide title**? | e.g. `Removing Integration Systems from the Tenant` |
| 2 | What is the **customer / organisation name**? | e.g. `Securex` |
| 3 | Who is the **author** (consultant name)? | e.g. `Andrew Hylands` |
| 4 | What is the **introduction**? | Purpose, context, and expected outcome. Can be 1–3 paragraphs. Should cover: what the guide does, why it exists, what the reader will achieve by the end |
| 5 | What are the **prerequisites**? | Security requirements, roles needed, tasks that must be complete before starting |
| 6 | What are the **tasks and steps**? | The main guide content. Provide as a structured outline, a description, or answer task-by-task interactively. See [Content Format](#content-format) below |
| 7 | **Document subtitle** (optional) | Default: `Workday Integrations Guide`. Change if the guide is not integration-related |
| 8 | **Document revision** (optional) | Default: `0.1` |

### Content Format

The user can provide task/step content in any of these ways:

1. **Structured outline** — markdown-style with headings and bullets:
   ```
   ## Configure the Integration System
   - Navigate to the Integration System page
   - Update the connection settings to the new endpoint
   
   ## Test the Integration
   - Run a test launch with sample data
   - Verify the output file is generated
   ```

2. **Free-form description** — describe what the guide should cover and let the AI structure it into tasks and steps

3. **Interactive** — answer task-by-task when prompted: "What is the first task?", "What steps does it involve?", etc.

In all cases, the AI organises the content into **Tasks** (major activities, Heading 1) and **Steps** (sub-steps within each task, Heading 2). Each step has a description paragraph.

### Step 2 — Draft Content

Before generating the Word document, produce the full guide content as text for review. Use this format:

```
=== GUIDE DRAFT ===

Title: [Guide Title]
Customer: [Customer Name]
Author: [Author]
Subtitle: [Document Subtitle]
Revision: [Revision]

--- INTRODUCTION ---
[Introduction paragraphs]

--- PREREQUISITES ---
[Prerequisite items]

--- TASKS ---

Task 1: [Task Title]
  Step 1.1: [Step Title]
    [Step description]
  Step 1.2: [Step Title]
    [Step description]

Task 2: [Task Title]
  Step 2.1: [Step Title]
    [Step description]
  ...
```

Apply these rules when drafting:

- **Screenshots cannot be inserted by the AI.** Add the note `[Add screenshot]` at the end of each step description to remind the user to insert screenshots in Word after generation
- **Content accuracy is the consultant's responsibility.** The AI can structure and format content, but specific navigation paths, configuration values, and customer-specific details must be verified
- **Keep step descriptions concise.** One to three sentences per step. The screenshot conveys the visual detail
- **Use UK English spelling** (behaviour, organisation, prioritise) unless the customer uses US English
- **Task titles should be action-oriented.** Use imperative verbs: "Configure…", "Test…", "Verify…", "Remove…"

### Step 3 — Produce Output

After user confirmation or requested edits, produce the filled `.docx` file. Use the [Word Fill Procedure](#word-fill-procedure) below.

Output filename convention:
- `[Customer Name] - [Guide Title].docx`
- Example: `Securex - Removing Integration Systems from the Tenant.docx`

Default output behaviour:
- Show the full draft text first so the user can review content before file generation
- After approval, generate the `.docx` file using the approved text
- If the user explicitly asks to generate immediately, skip the review step

After generating the document, remind the user:
1. Open the document in Word
2. Right-click the Table of Contents → **Update Field** → **Update entire table**
3. Add screenshots to each step as needed
4. Review the Circulation List table and fill in contact details
5. Save and distribute

---

## Word Fill Procedure

When producing Word output, fill the Kainos branded template stored at `references/templates/Kainos_Integration_Guide_Template.docx` using PowerShell XML DOM manipulation. **Never use Word COM automation** and **never use string replacement** on docx XML.

### Template Structure

The template contains the following elements (by body child index):

| Index | Type | Style | Content |
|---|---|---|---|
| 0 | Paragraph | Title | Cover page — contains textbox drawings with guide title, customer name, revision, and subtitle |
| 1–2 | Paragraphs | Heading1/2 | Document Properties / Revision History heading |
| 3 | Table | — | Revision History (4 cols: Revision, Date, Author, Description) |
| 4–6 | Paragraphs | — | Spacers |
| 7 | Paragraph | Heading2 | Circulation List heading |
| 8 | Table | — | Circulation List (4 cols: Name, Role, Organization, Email Address) |
| 9–24 | Paragraphs | TOC/spacers | Table of contents and spacing |
| 25 | Paragraph | Heading1 | **Introduction** |
| 26–28 | Paragraphs | (none) | Introduction placeholder text (3 paragraphs) |
| 29 | Paragraph | (none) | Empty separator |
| 30 | Paragraph | Heading1 | **Prerequisites** |
| 31–32 | Paragraphs | (none) | Prerequisites placeholder text (2 paragraphs) |
| 33 | Paragraph | (none) | Empty separator |
| 34 | Paragraph | Heading1 | **Task1** (first task heading) |
| 35–38 | Paragraphs | Heading2/(none) | Steps and descriptions for Task1 |
| 39 | Paragraph | (none) | Empty separator |
| 40–46 | Paragraphs | Heading1/2/(none) | Task2 with steps |
| 47–49 | Paragraphs | Heading1/(none) | Empty trailing headings and spacers |
| 50 | sectPr | — | Section properties |

### Cover Page Textboxes

The cover page (Title paragraph, body child 0) contains two textboxes rendered in dual format (`wps:txbx` for modern Word and `v:textbox` for VML fallback). Both copies must be updated.

**Textbox 0 — Guide details:**
Contains `w:t` elements in this order: `"Guide name "` → `[guide title]` → `"Organization"` → `""` → `[customer name]` → `"Document Revision"` → `""` → `[revision]`

**Textbox 1 — Document subtitle:**
Contains fragmented `w:t` elements: `"Workday Integration"` + `"s"` + `"Guide"` = `"Workday Integrations Guide"`

### Fill Script

Adapt this script per guide. Replace the content variables with gathered interview data.

```powershell
param(
    [string]$TemplatePath,          # Path to Kainos_Integration_Guide_Template.docx
    [string]$OutputPath,            # Output file path
    [string]$GuideTitle,            # e.g. 'Removing Integration Systems from the Tenant'
    [string]$CustomerName,          # e.g. 'Securex'
    [string]$Author,                # e.g. 'Andrew Hylands'
    [string]$Revision = '0.1',     # Document revision
    [string]$Subtitle,              # Optional — default keeps 'Workday Integrations Guide'
    [string[]]$IntroductionItems,   # Array of introduction paragraphs
    [string[]]$PrerequisiteItems,   # Array of prerequisite items
    [string]$TasksJson              # JSON: [{"title":"...","steps":[{"title":"...","description":"..."}]}]
)

$Tasks = $TasksJson | ConvertFrom-Json

Copy-Item -Path $TemplatePath -Destination $OutputPath -Force

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$zip = [System.IO.Compression.ZipFile]::Open($OutputPath, [System.IO.Compression.ZipArchiveMode]::Update)
try {
    $entry = $zip.GetEntry('word/document.xml')
    $stream = $entry.Open()
    $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
    $xmlText = $reader.ReadToEnd()
    $reader.Close()
    $stream.Close()

    $doc = New-Object System.Xml.XmlDocument
    $doc.PreserveWhitespace = $true
    $doc.LoadXml($xmlText)

    $ns = New-Object System.Xml.XmlNamespaceManager($doc.NameTable)
    $ns.AddNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main')

    $wNs = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    $xmlNs = 'http://www.w3.org/XML/1998/namespace'
    $body = $doc.SelectSingleNode('//w:body', $ns)

    # ── Helper functions ──

    function Get-ParagraphText([System.Xml.XmlNode]$para, [System.Xml.XmlNamespaceManager]$nsMgr) {
        $texts = $para.SelectNodes('.//w:t', $nsMgr)
        $parts = @()
        foreach ($t in $texts) { $parts += $t.InnerText }
        return ($parts -join '')
    }

    function New-StyledParagraph {
        param(
            [System.Xml.XmlDocument]$docObj,
            [System.Xml.XmlNamespaceManager]$nsMgr,
            [string]$text,
            $pPrTemplate,
            $rPrTemplate
        )
        $p = $docObj.CreateElement('w', 'p', $wNs)
        if ($pPrTemplate) {
            [void]$p.AppendChild($pPrTemplate.CloneNode($true))
        }
        if ($text -ne '' -and $text -ne $null) {
            $r = $docObj.CreateElement('w', 'r', $wNs)
            if ($rPrTemplate) {
                [void]$r.AppendChild($rPrTemplate.CloneNode($true))
            }
            $t = $docObj.CreateElement('w', 't', $wNs)
            $spaceAttr = $docObj.CreateAttribute('xml', 'space', $xmlNs)
            $spaceAttr.Value = 'preserve'
            [void]$t.Attributes.Append($spaceAttr)
            $t.InnerText = $text
            [void]$r.AppendChild($t)
            [void]$p.AppendChild($r)
        }
        return $p
    }

    # ── 1. Cover page textboxes ──
    # The Title paragraph (body child 0) contains all cover page text in textbox drawings.
    # Text appears in both wps:txbx and v:textbox — replacing all matching w:t elements
    # updates both copies.

    $titlePara = $body.FirstChild
    $allCoverTexts = @($titlePara.SelectNodes('.//w:t', $ns))
    $coverState = 'idle'
    $subtitleState = 'idle'

    foreach ($t in $allCoverTexts) {
        $val = $t.InnerText

        # Details textbox: guide title, customer name, revision
        if ($val -match '^Guide name') {
            $coverState = 'expect_title'
            continue
        }
        if ($coverState -eq 'expect_title' -and $val.Trim() -ne '') {
            $t.InnerText = $GuideTitle
            $coverState = 'idle'
            continue
        }
        if ($val -eq 'Customer Name') {
            $t.InnerText = $CustomerName
            continue
        }
        if ($val -match '^Document Revision') {
            $coverState = 'expect_revision'
            continue
        }
        if ($coverState -eq 'expect_revision' -and $val.Trim() -ne '') {
            $t.InnerText = $Revision
            $coverState = 'idle'
            continue
        }

        # Subtitle textbox (optional): "Workday Integration" + "s" + "Guide"
        if ($Subtitle -and $val -eq 'Workday Integration') {
            $t.InnerText = $Subtitle
            $subtitleState = 'clearing'
            continue
        }
        if ($subtitleState -eq 'clearing') {
            $t.InnerText = ''
            if ($val -eq 'Guide') { $subtitleState = 'idle' }
            continue
        }
    }

    # ── 2. Revision History table ──
    # Table 0: row 1 cells = Revision, Date, Author, Description

    $tables = $doc.SelectNodes('//w:tbl', $ns)
    if ($tables.Count -ge 1) {
        $revTbl = $tables.Item(0)
        $revRows = $revTbl.SelectNodes('./w:tr', $ns)
        if ($revRows.Count -ge 2) {
            $cells = $revRows.Item(1).SelectNodes('./w:tc', $ns)
            if ($cells.Count -ge 4) {
                foreach ($idx in 0..3) {
                    $cell = $cells.Item($idx)
                    $existingP = $cell.SelectSingleNode('./w:p[1]', $ns)
                    $rPrClone = $null
                    if ($existingP) {
                        $rPr = $existingP.SelectSingleNode('.//w:rPr', $ns)
                        if ($rPr) { $rPrClone = $rPr.CloneNode($true) }
                    }
                    # Clear existing paragraphs
                    $pNodes = @($cell.SelectNodes('./w:p', $ns))
                    foreach ($pn in $pNodes) { [void]$cell.RemoveChild($pn) }

                    $values = @($Revision, (Get-Date -Format 'dd/MM/yyyy'), $Author, 'Initial draft')
                    $p = $doc.CreateElement('w', 'p', $wNs)
                    $r = $doc.CreateElement('w', 'r', $wNs)
                    if ($rPrClone) { [void]$r.AppendChild($rPrClone) }
                    $tEl = $doc.CreateElement('w', 't', $wNs)
                    $sp = $doc.CreateAttribute('xml', 'space', $xmlNs)
                    $sp.Value = 'preserve'
                    [void]$tEl.Attributes.Append($sp)
                    $tEl.InnerText = $values[$idx]
                    [void]$r.AppendChild($tEl)
                    [void]$p.AppendChild($r)
                    [void]$cell.AppendChild($p)
                }
            }
        }
    }

    # ── 3. Clone style templates from existing headings ──
    # Grab w:pPr and w:rPr from Introduction (Heading1), first Step (Heading2),
    # and first body paragraph — these are used to create new styled paragraphs.

    $heading1PPr = $null; $heading1RPr = $null
    $heading2PPr = $null; $heading2RPr = $null
    $bodyPPr = $null; $bodyRPr = $null
    $introNode = $null; $prereqNode = $null; $firstTaskNode = $null

    $bodyChildren = @($body.ChildNodes)
    $foundPrereq = $false

    for ($i = 0; $i -lt $bodyChildren.Count; $i++) {
        $ch = $bodyChildren[$i]
        if ($ch.LocalName -ne 'p') { continue }
        $style = $ch.SelectSingleNode('./w:pPr/w:pStyle/@w:val', $ns)
        if (-not $style) { continue }
        $txt = (Get-ParagraphText $ch $ns).Trim()

        if ($style.Value -eq 'Heading1' -and $txt -eq 'Introduction') {
            $introNode = $ch
            $ppr = $ch.SelectSingleNode('./w:pPr', $ns)
            if ($ppr) { $heading1PPr = $ppr.CloneNode($true) }
            $rpr = $ch.SelectSingleNode('./w:r[1]/w:rPr', $ns)
            if ($rpr) { $heading1RPr = $rpr.CloneNode($true) }
        }
        if ($style.Value -eq 'Heading1' -and $txt -like 'Prerequisites*') {
            $prereqNode = $ch
            $foundPrereq = $true
        }
        if ($style.Value -eq 'Heading1' -and $foundPrereq -and $firstTaskNode -eq $null -and $txt -ne '' -and $txt -notlike 'Prerequisites*' -and $txt -ne 'Introduction') {
            $firstTaskNode = $ch
        }
        if ($style.Value -eq 'Heading2' -and $heading2PPr -eq $null) {
            $ppr = $ch.SelectSingleNode('./w:pPr', $ns)
            if ($ppr) { $heading2PPr = $ppr.CloneNode($true) }
            $rpr = $ch.SelectSingleNode('./w:r[1]/w:rPr', $ns)
            if ($rpr) { $heading2RPr = $rpr.CloneNode($true) }
        }
    }

    # Grab body paragraph style from first paragraph after Introduction heading
    if ($introNode) {
        $nextSib = $introNode.NextSibling
        if ($nextSib -and $nextSib.LocalName -eq 'p') {
            $ppr = $nextSib.SelectSingleNode('./w:pPr', $ns)
            if ($ppr) { $bodyPPr = $ppr.CloneNode($true) }
            $rpr = $nextSib.SelectSingleNode('./w:r[1]/w:rPr', $ns)
            if ($rpr) { $bodyRPr = $rpr.CloneNode($true) }
        }
    }

    # ── 4. Replace Introduction content ──

    if ($introNode) {
        # Remove all non-heading paragraphs after Introduction heading
        $next = $introNode.NextSibling
        while ($next -ne $null -and $next.LocalName -eq 'p') {
            $s = $next.SelectSingleNode('./w:pPr/w:pStyle/@w:val', $ns)
            if ($s -and $s.Value -match '^Heading') { break }
            $toRemove = $next
            $next = $next.NextSibling
            [void]$body.RemoveChild($toRemove)
        }
        # Insert new introduction paragraphs (before the next heading)
        $insertBefore = $next
        foreach ($item in $IntroductionItems) {
            $p = New-StyledParagraph $doc $ns $item $bodyPPr $bodyRPr
            [void]$body.InsertBefore($p, $insertBefore)
        }
        # Add empty separator
        $sep = New-StyledParagraph $doc $ns '' $null $null
        [void]$body.InsertBefore($sep, $insertBefore)
    }

    # ── 5. Replace Prerequisites content ──

    if ($prereqNode) {
        $next = $prereqNode.NextSibling
        while ($next -ne $null -and $next.LocalName -eq 'p') {
            $s = $next.SelectSingleNode('./w:pPr/w:pStyle/@w:val', $ns)
            if ($s -and $s.Value -match '^Heading') { break }
            $toRemove = $next
            $next = $next.NextSibling
            [void]$body.RemoveChild($toRemove)
        }
        $insertBefore = $next
        foreach ($item in $PrerequisiteItems) {
            $p = New-StyledParagraph $doc $ns $item $bodyPPr $bodyRPr
            [void]$body.InsertBefore($p, $insertBefore)
        }
        $sep = New-StyledParagraph $doc $ns '' $null $null
        [void]$body.InsertBefore($sep, $insertBefore)
    }

    # ── 6. Replace Tasks and Steps ──
    # Remove everything from the first task heading to just before sectPr,
    # then insert new task/step paragraphs.

    if ($firstTaskNode) {
        $sectPr = $body.SelectSingleNode('./w:sectPr', $ns)

        # Remove all body children from firstTaskNode to end (before sectPr)
        $current = $firstTaskNode
        $nodesToRemove = @()
        while ($current -ne $null -and $current.LocalName -ne 'sectPr') {
            $nodesToRemove += $current
            $current = $current.NextSibling
        }
        foreach ($n in $nodesToRemove) {
            [void]$body.RemoveChild($n)
        }

        # Insert new task/step paragraphs before sectPr
        $taskNum = 0
        foreach ($task in $Tasks) {
            $taskNum++
            # Task heading (Heading1)
            $h1 = New-StyledParagraph $doc $ns $task.title $heading1PPr $heading1RPr
            [void]$body.InsertBefore($h1, $sectPr)

            $stepNum = 0
            foreach ($step in $task.steps) {
                $stepNum++
                # Step heading (Heading2)
                $h2 = New-StyledParagraph $doc $ns $step.title $heading2PPr $heading2RPr
                [void]$body.InsertBefore($h2, $sectPr)

                # Step description — split on newlines for multiple paragraphs
                $descLines = @($step.description -split "`n" | Where-Object { $_.Trim() -ne '' })
                foreach ($line in $descLines) {
                    $bp = New-StyledParagraph $doc $ns $line.Trim() $bodyPPr $bodyRPr
                    [void]$body.InsertBefore($bp, $sectPr)
                }
            }

            # Empty separator between tasks (not after last)
            if ($taskNum -lt $Tasks.Count) {
                $sep = New-StyledParagraph $doc $ns '' $null $null
                [void]$body.InsertBefore($sep, $sectPr)
            }
        }
    }

    # ── 7. Write back document.xml ──

    $stream2 = $entry.Open()
    $stream2.SetLength(0)
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    $bytes = $utf8NoBom.GetBytes($doc.OuterXml)
    $stream2.Write($bytes, 0, $bytes.Length)
    $stream2.Close()

    # ── 8. Update header copyright year ──

    $headerEntry = $zip.GetEntry('word/header2.xml')
    if ($headerEntry) {
        $hdrStream = $headerEntry.Open()
        $hdrReader = New-Object System.IO.StreamReader($hdrStream, [System.Text.Encoding]::UTF8)
        $hdrXml = $hdrReader.ReadToEnd()
        $hdrReader.Close()
        $hdrStream.Close()

        $hdrDoc = New-Object System.Xml.XmlDocument
        $hdrDoc.PreserveWhitespace = $true
        $hdrDoc.LoadXml($hdrXml)

        $hdrTexts = $hdrDoc.SelectNodes('//w:t', $ns)
        foreach ($ht in $hdrTexts) {
            if ($ht.InnerText -match ([regex]::Escape('©') + '\s*Kainos\s*\d{4}')) {
                $ht.InnerText = [char]0x00A9 + ' Kainos ' + (Get-Date).Year.ToString()
            }
        }

        $hdrStream2 = $headerEntry.Open()
        $hdrStream2.SetLength(0)
        $hdrBytes = $utf8NoBom.GetBytes($hdrDoc.OuterXml)
        $hdrStream2.Write($hdrBytes, 0, $hdrBytes.Length)
        $hdrStream2.Close()
    }
}
finally {
    $zip.Dispose()
}

Write-Host "Guide generated: $OutputPath"
```

### Section-to-Element Mapping

| Guide Section | Element Type | How Identified | Fill Method |
|---|---|---|---|
| Cover — Guide title | Textbox `w:t` | Text after `"Guide name "` label | Replace `InnerText` (both wps and VML copies) |
| Cover — Customer name | Textbox `w:t` | Text `"Customer Name"` | Replace `InnerText` |
| Cover — Revision | Textbox `w:t` | Text after `"Document Revision"` label | Replace `InnerText` |
| Cover — Subtitle | Textbox `w:t` | Text `"Workday Integration"` + `"s"` + `"Guide"` | Replace first, clear fragments |
| Revision History | Table 0, row 1 | First `w:tbl` in document | DOM cell replacement |
| Introduction | Body paragraphs | After `Heading1` with text `"Introduction"` | Remove + insert styled paragraphs |
| Prerequisites | Body paragraphs | After `Heading1` with text `"Prerequisites"` | Remove + insert styled paragraphs |
| Tasks / Steps | Body paragraphs | First `Heading1` after Prerequisites to `sectPr` | Remove all, insert new `Heading1` / `Heading2` / body paragraphs |
| Header copyright | `word/header2.xml` | `w:t` matching `© Kainos YYYY` | Replace year with current year |

---

## Key Rules

These rules match the build-release-note-skill conventions and apply equally here:

- **Never use string replacement** on `.docx` XML — Word fragments text across multiple `<w:r>` and `<w:t>` elements. Always use XmlDocument DOM operations.
- **Never use Word COM automation** — hangs in headless terminals.
- **Preserve `w:tcPr`** (table cell properties) — only remove/replace `w:p` paragraph children, never the cell properties node.
- **Add `xml:space="preserve"`** on all `w:t` elements to prevent Word from stripping whitespace.
- **Clone `w:pPr` and `w:rPr`** from existing template paragraphs to preserve font, size, and list numbering on inserted text.
- **Never delete+recreate ZIP entries** — open the existing entry's stream, truncate with `SetLength(0)`, and write modified XML as raw UTF-8 bytes (no BOM).
- **Use `$doc.OuterXml` for write-back** — `XmlWriter` can alter namespace declarations.
- **Update both textbox formats** — the cover page uses `mc:AlternateContent` with `wps:txbx` (modern) and `v:textbox` (VML fallback). Searching all `w:t` descendants of the Title paragraph updates both copies automatically.
- **Heading auto-numbering is style-based** — cloning `w:pPr` from an existing `Heading1` paragraph preserves the `w:numPr` reference, so new headings auto-number in sequence.
- **TOC requires manual update** — Word will not auto-refresh the Table of Contents. Remind the user to right-click → Update Field → Update entire table after opening.
- **Screenshots must be added manually** — the AI cannot insert images. Mark insertion points with `[Add screenshot]` in the draft.

---

## Word Template Compatibility

| Platform | Support |
|---|---|
| Windows + PowerShell 5.1+ | Full support — primary path |
| Windows + PowerShell 7 | Full support |
| macOS / Linux | Not supported |
| VS Code terminal disabled | Fallback to plain text paste map (see below) |

### Fallback: Plain Text Paste Map

If the terminal is unavailable or the user is not on Windows, output the guide content as plain text with a **paste map** showing exactly which text goes where:

```
=== PASTE MAP (for manual Word template fill) ===

[Cover Page — Details textbox]
  Guide title:   <value>
  Customer name: <value>
  Revision:      <value>

[Cover Page — Subtitle textbox]
  Subtitle: <value>

[Revision History — Row 1]
  Revision:    <value>
  Date:        <value>
  Author:      <value>
  Description: Initial draft

[Introduction]
  Paragraph 1: <text>
  Paragraph 2: <text>
  ...

[Prerequisites]
  Item 1: <text>
  Item 2: <text>
  ...

[Tasks]
  Task 1: <title>
    Step 1.1: <title>
      <description>
    Step 1.2: <title>
      <description>
  Task 2: <title>
    Step 2.1: <title>
      <description>
  ...
```

### Template Customisation

The fill script identifies sections by heading text content and table position, not by fixed body child index. If the template is updated with additional sections or reordered tables, the script will still work as long as:
- The Title paragraph remains the first body child
- Headings use `Heading1` and `Heading2` styles
- The `Introduction` and `Prerequisites` heading text is preserved
- The Revision History table remains the first `w:tbl` in the document
