---
name: create-studio-skill
description: "Workday Studio assembly.xml creation and modification reference. Use when creating a new Studio integration from scratch, adding or removing components in assembly.xml, modifying routing between components, configuring integration attributes or report services, adding error handlers to mediations, building sub-assembly patterns with local-in/local-out, configuring HTTP-out or Workday-out transports, or updating assembly-diagram.xml after structural changes."
argument-hint: "Describe the Studio integration you want to create or the assembly.xml change you need to make"
---

# Create & Modify Workday Studio Integrations

This skill provides the exact XML syntax and structural patterns needed to create or modify Workday Studio `assembly.xml` and `assembly-diagram.xml` files accurately.

## When to Use

- Creating a new Studio integration project from scratch
- **Automatic handoff from `/integration-design-skill`** — when the design skill determines a Studio integration is needed, it will invoke this skill and pass forward all discovery context (integration name, data source, target system, file layout, field mapping, processing model, error handling, attributes). Accept this context and skip re-asking questions that are already answered
- Adding components (mediations, transports, eval steps) to an existing assembly
- Modifying routing between components (`routes-to`, `routes-response-to`)
- Configuring integration attributes, report services, or launch parameters
- Adding error handlers to mediations
- Building sub-assembly patterns with `local-in` / `local-out`
- Updating `assembly-diagram.xml` after adding or removing components

## Procedure

1. **Gate: If the user mentions SSK or requests full SSK scaffolding** — refuse. SSK is not used for new integrations (hard to maintain, hard to debug, bloats the repo, slows AI tooling). Explain the reasons and proceed with the lean component-only approach this skill provides. Do not offer an override — this is a hard rule
2. **Ask the user which assembly version to target** — default is `2025.21` if not specified
3. **Identify the functional domain** (HCM, Payroll, Financials, etc.)
4. Consult the [Assembly Element Catalog](./references/assembly-element-catalog.md) for the exact XML syntax of each component type
4. Use the [Annotated Stub Template](./references/stub-assembly-annotated.md) as a structural reference for how components fit together
5. When adding or removing components, follow the [Assembly Diagram Guide](./references/assembly-diagram-guide.md) to update `assembly-diagram.xml`
6. Apply the rules from the `assembly-patterns.instructions.md` and `copilot-instructions.md` for error handling, naming, and property conventions

## Key Principles

- **SSK framework is blocked for new integrations** — always build lean, purpose-built assemblies. Individual SSK patterns (cloud log, RaaS HashMap) can be adopted à la carte without the full framework
- **Never guess XML syntax** — always reference the element catalog for exact attribute names and structure
- **Processing mediations need an error handler** — add `cc:send-error` as the last child of every processing `cc:async-mediation` and `cc:sync-mediation`
- **Catch/error-handler mediations do NOT get `cc:send-error`** — they are terminal; the global error handler catches failures in them
- **Every new component needs a diagram entry** — `visualProperties`, `connections`, and `swimlanes` in `assembly-diagram.xml`
- **Component IDs must be descriptive** — no numeric suffixes, no generic names
- **Use sub-assemblies** — `local-in` / `local-out` pairs to isolate functional areas

## Quick Reference — Component Types

| Element | Purpose |
|---------|---------|
| `cc:workday-in` | Entry point, contains integration system config |
| `cc:async-mediation` | Asynchronous processing block with steps |
| `cc:sync-mediation` | Synchronous processing block with steps |
| `cc:local-in` / `cc:local-out` | Sub-assembly entry/exit points |
| `cc:workday-out-soap` | SOAP call to Workday API (NOT `cc:workday-out` — that is invalid) |
| `cc:workday-out-rest` | REST call to Workday API |
| `cc:http-out` | HTTP call to external system |
| `cc:send-error` | Error handler routing within mediation |
| `cc:eval` | MVEL expression evaluation |
| `cc:cloud-log` | Write to CloudLog document |
| `cc:store` | Store document to Integration Event |
| `cc:set-headers` | Set/remove HTTP headers |
| `cc:xslt` | XSLT transformation |
| `cc:splitter` | Split message into parts |
| `cc:route` | Conditional routing based on MVEL expressions |
| `cc:write` | Construct message body (JSON, form-encoded) |
| `cc:json-to-xml` | Convert JSON response to XML for XPath |
| `cc:copy` | Copy/restore message to/from variables |

## References

- [Assembly Element Catalog](./references/assembly-element-catalog.md) — exact XML syntax for every component type
- [Annotated Stub Template](./references/stub-assembly-annotated.md) — golden reference assembly with inline explanations
- [Assembly Diagram Guide](./references/assembly-diagram-guide.md) — how to maintain assembly-diagram.xml
- [OAuth 2.0 & REST API Patterns](./references/oauth-rest-patterns.md) — OAuth token flow, Bearer auth, JSON handling, splitter loops, conditional routing
