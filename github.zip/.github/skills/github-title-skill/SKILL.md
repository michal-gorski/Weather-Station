---
name: github-title-skill
description: "Generate concise GitHub title and commit text for Workday integration changes in an ASCII-safe format to avoid character loss. Use when the user asks for PR title, commit subject, commit description/body, or a ready-to-run git commit command."
argument-hint: "Paste the ticket ID and change summary, or say 'start' to answer prompts"
---

# GitHub Title and Commit Text Skill

This skill generates a GitHub title and commit text in a clean, predictable format.
It is designed for reliability in terminals and git tooling where special characters can be mangled.

## When to Use

- User asks for a GitHub title
- User asks for commit message text
- User asks for an ASCII-safe commit format
- User wants a one-line commit command

## Output Format

Default output sections:

1. Commit subject:
2. Commit description:

Use plain ASCII only in generated title and commit text.

## Required Rules

- ASCII only: letters, numbers, spaces, and basic punctuation
- No em dash, smart quotes, bullets, or special symbols
- Keep ticket ID at the start when provided (example: CS0101046)
- Keep scope concise (integration ID or short system name)
- Title should be readable by business and technical users
- Commit subject should be imperative and specific
- Commit description should explain: what changed, why, and expected outcome

## Recommended Templates

### AMS ticket format

GitHub title:
`<TICKET_ID>: <INTEGRATION_ID> <Short change summary>`

Commit subject:
`<TICKET_ID> <INTEGRATION_ID>: <imperative change statement>`

Commit description:
Line 1: What changed.
Line 2: Why the old behavior failed.
Line 3: How the new behavior works.
Line 4: Expected outcome.

### Internal or implementation format

GitHub title:
`<INTEGRATION_ID> <Short change summary>`

Commit subject:
`<INTEGRATION_ID>: <imperative change statement>`

Commit description:
Line 1: What changed.
Line 2: Why it changed.
Line 3: Expected outcome.

## Prompting Flow

If the user has not provided enough details, ask only these:

1. Ticket ID (or N/A)
2. Integration ID or name
3. One-sentence summary of the fix
4. Root cause in one sentence
5. Desired audience tone: technical or mixed

Then generate output using either:

- Commit subject and commit description

## Quality Checks

Before finalizing, validate:

- All text is ASCII-only
- Title is under 90 characters where possible
- Commit subject is under 72 characters where possible
- Description is clear, factual, and not overly verbose
- Wording matches repo conventions

## Example

GitHub title:
CS0101046: INTF074 Fix Dokapi confirmation trigger in regular listener

Commit subject:
CS0101046 INTF074: trigger Dokapi confirmation when invoiceWID is present

Commit description:
Replace CallConfirmUBLFile execute-when condition in regular listener flow.
Old condition used Confirm Invoice Download to Dokapi, which is not populated.
New condition executes the confirm step when invoiceWID is not empty.
This prevents missing Dokapi confirmations after successful invoice creation.

Optional command:
git commit -m "CS0101046 INTF074: trigger Dokapi confirmation when invoiceWID is present" -m "Replace CallConfirmUBLFile execute-when condition in regular listener flow. Old condition used Confirm Invoice Download to Dokapi, which is not populated. New condition executes the confirm step when invoiceWID is not empty. This prevents missing Dokapi confirmations after successful invoice creation."
