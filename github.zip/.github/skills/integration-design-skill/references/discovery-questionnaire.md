# Integration Discovery Questionnaire

Structured discovery questions for Workday integration design. Walk through the applicable sections during discovery sessions. Every integration needs **General**, **File Delivery**, **Integration-Specific**, **Testing**, and **Go-Live**. Domain sections apply when relevant.

---

## General

| # | Question | Background |
|---|----------|------------|
| 1 | Who is the vendor and system name? | |
| 2 | Has this vendor integrated with Workday before? | If yes, what was the approach and what can be re-used? |
| 3 | What happens today? | Are there known issues with the current process? |
| 4 | What's the vision for Workday? | |
| 5 | Have you initiated the project with the vendor? | Has the vendor prepared for the project? People assigned, contractual cover? |
| 6 | Can technical specifications be provided? | Technical specifications ideally provide layout and purpose of fields at a minimum. |
| 7 | Do you have any concerns for this integration that immediately come to mind? | |
| 8 | Who is the key contact for answering questions about functionality, and who for technical detail? | |
| 9 | Who is the approver for this design? | |
| 10 | Who should always be included in any communication for this integration? | |

## File Delivery

| # | Question | Background |
|---|----------|------------|
| 1 | What should be the file name format for production and test? | |
| 2 | What file transfer method is expected to be used? | SFTP, HTTPS, etc. Note if a change is requested between current state and future Workday state. |
| 3 | If delivery is to an HTTPS endpoint, are there any message size limits or response codes to be aware of, react to, or report as errors/warnings? | Only relevant for HTTPS deliveries. |
| 4 | What is the process and lead time necessary to set up a new connection? | Important to address early — some vendors require significant lead time. Get the request in ASAP. |
| 5 | Are IP addresses whitelisted? | Workday provides differing IP addresses between production and non-production tenants. Both must be whitelisted. |
| 6 | What file transfer encryption options are supported? | Workday supports a variety of encryption options, most common being PGP. |
| 7 | Does the file need to be digitally signed? | Workday can digitally sign outbound files. |
| 8 | Should the file be compressed? | |
| 9 | Will we have security to use a temporary file during transport? | A temp file typically requires security to rename files. It helps ensure a partial file isn't picked up during large transports. |
| 10 | How will we authenticate? If given a password, does it expire? | Username and Password, SSH key, etc. |
| 11 | What is the address for test and production? | e.g. `sftp://ftp.customer.com` |
| 12 | What is the directory for test and production? | e.g. `/home` |
| 13 | How do we differentiate delivery during testing as opposed to production? | Different server addresses, directories, filenames, or field values help prevent accidentally sending test data to a production system. |

## Integration-Specific

| # | Question | Background |
|---|----------|------------|
| 1 | What is the integration scheduling, and are ad-hoc runs to be supported? | For payroll integrations this is also tied to pay periods. |
| 2 | What are expectations for rescinds and corrections? | Some Workday connectors support rescinds and corrections fully, others partially, and others not at all. Viability must be determined. |
| 3 | Should the output be sent as a full extract or a delta? | |
| 4 | Is there a requirement to send a wider scope of data when only a subset has changed? | If the integration produces more than one file (e.g. Employees, Earnings, Deductions), when a record is included in one file due to changes, does the same worker record need to appear in all other files? |
| 5 | How should effective dates be handled? | Snapshot vs changes as they become effective. Handling of retrospective transactions. Are future hires or past terminated employees included? |
| 6 | Are secondments or International Assignments in scope? | Not all Workday connectors handle secondments correctly. With international assignments there may be differences in how the employee is paid and what events the downstream system expects. |
| 7 | How are re-hires affecting the integration? | Would re-hire have the same ID in the downstream system? Does the system need to know this is a re-hire event? |
| 8 | How are records identified? | Is the Workday ID used, or is there a need to store a legacy ID in Workday? |
| 9 | Is there a requirement to capture both Contingent Workers and Employees? | Note: payroll connectors (PECI, PICOF) do not include contingent workers in output. Use WECI if CWs are needed. |
| 10 | How will conversions from Contingent Worker to Employee (and vice versa) impact the integration? | |
| 11 | How are additional data dictionaries synchronised? (e.g. Locations, Organisations) | |
| 12 | Are there data gaps — mandatory data that may not be available from Workday? | What is the plan to address missing data? |
| 13 | If terminated workers are expected, how long should they be included in the file? | Options: indefinitely / once then dropped / N days post-termination then dropped. |
| 14 | What is the population to be included? | Are there filters needed to exclude certain records? e.g. contingent workers, or data concerning specific organisations. Which workers should be sent on the interface? |

## Payroll-Specific

| # | Question | Background |
|---|----------|------------|
| 1 | What pay groups are in scope? | What does the payroll system expect (multi pay group)? Would you want to run them separately? Do you need to secure the populations separately? |
| 2 | Top of stack vs effective changes needed? | Determines PECI (full-stack, effective-dated) vs PICOF (top-of-stack, delta). |
| 3 | How are transfers between pay groups/companies to be handled? | If a worker transfers from another company — should they be sent as a hire? And if leaving, sent as a termination? |
| 4 | What are the external codes for all compensation-based earnings (allowances, one-time payments) that are to be sent to payroll? | |
| 5 | What are the external codes and names for all time offs that are to be sent to payroll? | |
| 6 | Will the integration need to include benefit-related earnings/deductions? Does the Workday earnings/deduction code match what the payroll provider needs? | |
| 7 | How should non-amount earnings be handled? | |
| 8 | Can an employee have multiple positions belonging to multiple pay groups? If so, are all done via external payroll providers or is it a mix of provider and Workday Payroll? | |
| 9 | How do you handle the no-show scenario? | Is it done via termination or rescind? How do you ensure the employee is not paid for 1 day? |
| 10 | Earliest open period vs period for current date? | Determines the Pay Period Selection Option launch parameter. |
| 11 | How are mid-period changes pro-rated? | |
| 12 | Is the payroll able to handle retro-active changes? | |
| 13 | How are amounts pro-rated for part-time employees? | |
| 14 | Time off — sent as daily summary vs month summary? | |
| 15 | How are long-term leaves handled? | |
| 16 | How is time off sent for hourly employees and part-time employees? | |
| 17 | How are corrections to leave and time off sent? | |
| 18 | Time off data sent in same period, or in arrears? | |
| 19 | Would terminations on the last day of the month be required in the current pay period run? | Relates to the "Reporting for Termination on Last Day of Pay Period" PECI attribute. |

## SAP-Specific

| # | Question | Background |
|---|----------|------------|
| 1 | Do you know which info-types are needed in SAP? | |
| 2 | Is "PA-PD" configuration enabled? Can it be turned off so that positions/orgs are then created via the worker feed? | |
| 3 | Do you know if both PA and OM modules are enabled in the SAP system? | If OM module is enabled, how do you plan to sync new positions, organisations, job profiles, and other foundational objects? |
| 4 | How will the file be imported to SAP? Is there another middleware system that will import the file? | |
| 5 | Usually integration to SAP includes a field called Action/Action Reason. What is the mapping from Workday to SAP for these fields? | |
| 6 | Is there any data that can only be calculated in SAP but needs to be in Workday? | For such data, a Workday inbound feed might additionally be needed. Example: tariff compensation calculations. |
| 7 | Is the organisation structure from SAP aligned to Workday? | If not, what is the plan to map it? How do you plan to handle manager logic in SAP vs Workday (in managed org vs above managed org)? |
| 8 | Do you need to sync additional data? Positions list, Organisations? | |
| 9 | What is the personal area, subarea, and employee group/subgroup mapping? | |
| 10 | How do you plan to deal with fields not available in Workday for certain infotypes? | |

## Identity

*Deferred — content will be added in a future update. Placeholder questions:*

- Is AD used across the whole company? Would there be more users in AD than in Workday?
- What is the username assignment policy?
- What impact does leave have on employee accounts?
- What impact does position change have on the integration?

## Testing

| # | Question | Background |
|---|----------|------------|
| 1 | Who is the primary contact for testing? | |
| 2 | Is a test system available for use during the implementation phase? | |
| 3 | Is parallel testing in scope? Will a comparison to a current production file be done? | During implementation, Workday tenants may have stale data based on a fixed point in time. Keep this in mind if a comparison to production is requested. |
| 4 | Is the test system able to receive real data, such as actual names or SSN? | Some target systems do not want to hold real data and prefer fictitious or masked information. |
| 5 | Can the vendor perform separate fictional scenario tests and data comparison tests? | Fictional scenarios might include new hires, dependent add/drop, benefit changes, terminations, rehires, etc. |
| 6 | Is Workday the only system/integration using the test system? | |
| 7 | What is the process and lead time for scheduling a test, and the turn-around time for a test file? | |
| 8 | Does the vendor require a specific number of test cycles or test plan completion? If so, describe and provide details. What is the testing strategy? | |
| 9 | What impact will the integration have on any downstream systems? Is there a risk existing integrations may be affected? | |

## Go-Live

| # | Question | Background |
|---|----------|------------|
| 1 | Are approvals required on your side before we go to production? If so, describe and provide details. | |
| 2 | When is the first production file? | |
| 3 | Do we need a production file with current Workday data to precede the first live file from Workday? | |
| 4 | Are there any other go-live specific items that should be considered at this point? | |
