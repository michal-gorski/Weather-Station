# WECI Reference — Worker Effective Change Interface

Comprehensive reference for the Worker Effective Change Interface (WECI) integration. Use WECI for full-stack worker change transmissions to non-payroll systems such as data warehouses, data hubs, and HCM vendors requiring contingent worker support.

---

## Overview

WECI is a full-stack integration that transmits worker changes based on organisation membership. It includes the effective date and data entry date for each change. Unlike PECI (which targets payroll providers), WECI is designed for broader HCM data distribution — data warehouses, data hubs, and third-party systems that need comprehensive worker change history.

**Key characteristics:**
- Full-stack, effective-dated change tracking
- XML output only
- Requires grid setup (contact Customer Care)
- 500,000 worker limit (all workers in specified organisations)
- Supports both employees and contingent workers
- 100MB data limit per worker (exceeding workers are skipped)
- Organisation-based population selection (not pay-group-based)
- No pay group assignment required
- Supports abort of in-progress integration runs

---

## When to Use WECI

- Vendor or downstream system requires full effective-stack worker changes
- Contingent workers must be included in the output
- Data warehouse or data hub integration
- System requires all effective changes within a date range (not top-of-stack)
- Need to capture retroactive changes and indirect changes
- Up to 500,000 workers in selected organisations

**Do NOT use WECI when:**
- You need payroll-specific data (earnings, deductions, pay data) — use PECI
- CSV output is required — use PICOF or Core Connector: Worker
- Vendor only needs top-of-stack changes — use Core Connector: Worker
- Time off or time tracking data is required (WECI does not capture these)
- Near real-time or event-driven integration is needed
- Population exceeds 500,000 workers

---

## WECI vs PECI — Key Differences

| Feature | WECI | PECI |
|---------|------|------|
| Worker limit | 500,000 | 250,000 per pay group |
| Contingent workers | Supported | Not supported |
| Pay group required | No | Yes |
| Grid required | Yes | Yes |
| Organisation-based selection | Yes (Restrict Results By Orgs) | No (pay-group-based) |
| Time off/time tracking | Not supported | Supported |
| Look-ahead functionality | Not supported | Supported |
| Business process orchestration | Not supported (max 1 per BP) | Not supported (max 1 per BP) |
| Abort running integration | Supported | Supported |
| Frequent runs (sub-daily) | Supported (every 6 hours with Effective Stack Sync) | Not supported in this way |
| Primary use case | Data warehouses, data hubs, HCM vendors | Third-party payroll providers |
| Field overrides | Configure Integration Field Overrides task | Configure Integration Field Overrides task |
| Multi-instance field overrides | Supported (with Reference ID Types) | Supported (with Reference ID Types) |
| Additional pay periods | Not supported | Supported |
| Full snapshot | Supported (launch parameter) | Supported (launch parameter) |

---

## Setup Prerequisites

1. Engage Workday Professional Services or a Consulting Partner
2. Contact Customer Care to enable grid on the tenant
3. Set custom organisation membership rules to **semidynamic** (strongly recommended)
   - If dynamic rules are required, enable the **Enable Dynamic Membership Rule Evaluation Optimisation** checkbox on Edit Tenant Setup - HCM
4. Perform upfront analysis of data requirements with the third-party vendor or data warehouse system
5. Grid can only be active on 1 tenant per environment at a time (e.g. Implementation or Implementation Preview)

---

## Setup Steps (Condensed)

1. Access **Create Integration System** → select "Worker Effective Change Interface" template
2. (Optional) Enable integration services:
   - Include Sections Configuration Service
   - Transaction Log Service
   - Integration Document Retention
   - Filename Sequence Generator
   - Effective Stack – Expanded Effective Changes
3. Grant ISU **Get and Put** access to the Payroll Interface domain
4. Configure Integration Attributes and Maps
5. Select and Set Up Connector Output Fields
6. (Optional) Add Custom Fields / Configure Integration Field Overrides
7. (Optional) Test Field Overrides (using custom report method)
8. (Optional) Configure Integration Population Eligibility
9. Set Up Integration Delivery
10. Set Up Integration Sequence Generators (if enabled)
11. Create a Document Transformation connector for output formatting
12. Launch the integration

---

## Integration Services

| Service | Purpose |
|---------|---------|
| Include Sections Configuration Service | Include a data section even if the integration detects no change for it |
| Transaction Log Service | Tracks event changes to worker data; enables filtering by transaction type |
| Integration Document Retention | Controls how long to retain generated files |
| Filename Sequence Generator | Applies unique names to each integration file |
| Effective Stack – Expanded Effective Changes | Reports each transaction separately even when multiple transactions share the same effective date (e.g. terminate and rehire on same day) |

### Transaction Log Service Notes

- Workday recommends selecting **Subscribe to all Transaction Types except** and specifying types you do not need
- When enabled, the integration does not output any Transaction Log that is an Event Lite Type
- Enable all fields on the Transaction Log data section when using Expanded Effective Changes
- This service does not support entry data roll-up configurations when Expanded Effective Changes is active

---

## Integration Attributes

### Key Attributes

| Attribute | Description |
|-----------|-------------|
| Output Document Tags | Tags appended to output file (e.g. ADP, Testing, PI Output EDI) |
| Audit Document Tags | Tags appended to DataChangesAudit.html and DiagnosticAudit.html |
| Suppress Worker Message Audits For Job Size | Auto-excludes message audits when >5,000 workers; override with Always Include |
| Suppress Audit Reports For Job Size | Auto-excludes audit reports when >30,000 workers; override with Always Include |
| Required Field Validation | Exclude (error, omit worker) or Include (warning, keep worker) |
| Max Length Field Validation | Include (warning, truncate) or Exclude (error, omit worker) |
| Country Code Type or Name | ISO 3166-1 Alpha 2 by default |
| Worker Type for Integration Run | Employees, contingent workers, or both (default: both) |
| Return Only Primary Position | When enabled, returns only primary position for multi-job workers |
| Future Change Detection | Up to 403 additional days for future effective-dated transactions on primary runs |
| Roll Up Entry Dated Changes | Specifies sections that display entry-dated changes for the Hire event |
| Report Post Termination Compensation | Include post-termination compensation in output |
| Document Retention Policy | Number of days output file remains available |

### "Include Section" Attributes

These attributes force a data section into the output even when no changes are detected:

- Include Personal Data Section
- Include Person Communication Data Section
- Include Worker Status Data Section
- Include Person Identification Data Section
- Include Additional Data Section
- Include Position Data Section (also supports "Job Change Reason Only (Secondary)")
- Include Compensation Data Section (also supports "Compensation Change Reason Only (Secondary)")
- Include Compensation Plans Data Section
- Include Payment Election Data Section

### Communication Attributes

| Attribute | Description |
|-----------|-------------|
| Address Usage Types | Address usage type to include in output |
| Address Usage | Works with Address Usage Type for primary/non-primary addresses |
| Phone Usage Type | Phone usage type for primary phone numbers |
| Phone Number Parsing | Parsed or unparsed phone numbers |
| Phone Number Format | E164 Formatted, National Formatted, etc. |
| Email Usage Type | Primary email for specified usage type |
| Additional Name Types | Extra name types to include |

### Organisation and Position Attributes

| Attribute | Description |
|-----------|-------------|
| Organisation Type for Organisation | Only include organisations matching this type |
| Organisations Role for Position | Only include assigned roles matching these organisation roles |
| Effective Date for Currency Conversion | Defaults to Effective Date From if not configured |
| Return End Date in Current Processing Effective Range | Specify end date to send for selected data sections |

### Compensation Attributes

| Attribute | Description |
|-----------|-------------|
| Exclude Amount Field for Percentage Based Plans | Exclude percentage-based amounts for Allowance Plans and/or Bonus Plans (improves performance) |
| Payment Election Rules | Only include Payment Elections matching specified rules |

---

## Integration Maps

Configure maps from the related actions menu: Integration System > Configure Integration Maps.

- Add a row for each tenant value needing translation
- Select the Internal Value and enter the corresponding External Value
- Optionally provide a Default Value for unmapped data elements

---

## Field Overrides

WECI supports field overrides natively via **Configure Integration Field Overrides** (no custom integration service needed).

### Testing Field Overrides

Before adding a calculated field to the integration, test it in a custom report:

1. Create a custom report: Type = Advanced, Data Source = Indexed All Workers
2. Add the calculated field on the Columns tab
3. Add a filter prompting for Employee ID
4. On the Prompts tab, enable effective date and entry date prompts
5. Run the report testing with dates before and after the event's effective/entry dates
6. Confirm the value changes as expected with the worker event

### Performance Considerations for Field Overrides

- Calculated fields with more than 8 levels in the hierarchy may cause performance degradation
- Test all scenarios including mass updates
- Avoid these report fields in calculated fields used as overrides:
  - Worker Events Completed
  - Staffing History – All / Approved
  - Worker History
  - Is Manager (use Assigned Role instead)
  - Terminated (based on report date) (use Terminated instead)
  - Job Classifications – Job Profile (use a lookup calculated field instead)

---

## Launch Parameters

### Primary Run

| Parameter | Notes |
|-----------|-------|
| Restrict Results By Orgs | Optional; restrict by supervisory org or company hierarchy. Will not run if >500,000 workers |
| Primary Run | Enable for scheduled runs; ignores all other parameters when selected |

Primary Run behaviour:
- Uses the last successful run date → current launch time as the effective range
- Change Detection is always "Include all changes in the effective date range"
- LSRD is per combination of organisations used in Restrict Results By Orgs
- Does not update LSRD if the run completes with errors

### Ad Hoc Run

| Parameter | Notes |
|-----------|-------|
| From Effective Date | Start of effective range |
| Effective Date | End of effective range |
| From As Of Entry Moment | Start of entry range |
| As Of Entry Moment | End of entry range |
| Change Detection | See below |
| Workers to Include/Exclude | Ad hoc worker selection |

Ad hoc runs do not affect the last successful primary extract date.

### Full Snapshot Run

- Sends all worker information as of current state in Workday
- **Must** disable Transaction Log Service before running (otherwise no workers are included)

---

## Change Detection

WECI supports two types:

| Type | Behaviour |
|------|-----------|
| Include all changes in the effective date range | Outputs all changes/events effective within the range, regardless of entry date |
| Include only changes entered since the last successful run | Outputs changes entered since LSRD and effective within the specified range |

---

## Frequent Integration Runs

WECI can run more frequently than the standard once-daily recommendation (up to every 6 hours) to refresh data warehouses.

### Setup

1. Enable the **Transaction Log** integration service
2. Enable the **Worker Effective Change Interface – Effective Stack Sync** integration service
3. Access **Maintain Worker Effective Change Integration System** task
4. Set the last successful run date in:
   - Created Date Time
   - Created Date Time for Additional Run
5. Launch with **Primary Run** enabled

### Behaviour

- Workday automatically increments Created Date Time for Additional Run based on run frequency
- The final daily run detects indirect and unreported changes not captured in sub-daily runs
- To manually adjust the time, delete worker-level LSRD for previously processed workers using the Delete by Batch ID task

---

## Staffing Events Reference

| Event Code | Definition | Status Event Date | Data Sections Included |
|------------|-----------|-------------------|----------------------|
| HIR | Worker hired or rehired (on completion of Hire BP) | Hire date | All data as of hire date |
| HIR-C | Correction to hire event (hire date moved earlier) | Hire date | Status section |
| HIR-R | Rescinded hire transaction | Hire date | Worker Status |
| DTA | Data change | Effective date of change | Changed sections only |
| TERM | Terminated (active → terminated) | Termination date | Personal, Person Communication, Worker Status, Position, Compensation, Compensation Plans |
| TERM-C | Corrected termination (date moved earlier) | Termination date | Worker Status |
| TERM-R | Rescinded termination (date moved to future, terminated → active) | Termination date | Worker Status, Person Communication, Position, Compensation, Compensation Plans |
| XFR | Transfer into supervisory org (no Restrict Results By Orgs set) | Organisation event date | Position |
| XFR-IN | Transfer into supervisory org (with Restrict Results By Orgs) | Organisation event date | Position |
| XFR-OUT | Transfer out of supervisory org (with Restrict Results By Orgs) | Organisation event date | Position |
| LOA | Leave of absence (first leave only; subsequent leaves report as DTA) | Leave start date | Worker Status, Leave of Absence |
| LOA-R | Rescinded leave of absence | Leave start date | Worker Status, Leave of Absence |
| LOA-C | Correction to leave end date or type | Leave end date | Worker Status, Leave of Absence |
| RFL | Return from leave of absence | Leave end date | Worker Status, Leave of Absence |
| RFL-R | Correction to end date of leave | First day back | Status, Leave of Absence |
| CONT-LOA | Continuous leave (return and immediate re-leave, back-to-back) | Original leave start date | Leave of Absence |

**Notes:**
- XFR, XFR-IN, XFR-OUT require "Supervisory" in the Organisation Type for Organisation attribute
- LOA, LOA-C, LOA-R, RFL, RFL-R, CONT-LOA only appear when the Leave of Absence data section is enabled
- With Expanded Effective Changes enabled: HIR-C appears for earlier hire date corrections; CONT-LOA is excluded
- For rescinded events, the status section matches the original event status
- Handle HIR or XFR-IN as net-new hires or a rebase of an existing record

### Correction Use Cases

| Scenario | Without Expanded Effective Changes | With Expanded Effective Changes |
|----------|-----------------------------------|---------------------------------|
| Correct hire date to earlier | HIR and DTA | HIR-C |
| Correct hire date to future | HIR-R and HIR | HIR-R and HIR |
| Correct termination date to earlier | TERM-C and DTA | TERM-C |
| Correct termination date to future | TERM-R and TERM | TERM-R and TERM |

---

## Data Sections Summary

| Data Section | Content Summary |
|--------------|-----------------|
| Worker Summary | WID, Name, Employee ID |
| Worker Status | Hire/termination dates, status flags, service dates, termination reasons, rehire eligibility |
| Worker Status / Secondary Termination Reason | Additional termination reason and category |
| Recruiting Information | Source category, referral details |
| Personal Data | Legal name, preferred name, additional names, disability, military service, citizenship, demographics, ethnicity, nationality |
| Person Communication | Addresses, phone numbers, email addresses (with usage types) |
| Person Identification | National IDs, government IDs, visa, passport, licence, other identifiers |
| Related Person | Dependents, beneficiaries, emergency contacts with demographics, relationships, identifiers, communication |
| Related Person Communication | Addresses, phones, emails for related persons |
| Related Person Identification | National/government/other IDs for related persons |
| Position | Position ID, job title, business title, worker type, time type, FTE, pay rate, job classification, business site, supervisor, organisations, assigned roles, probation data |
| Compensation | Package, grade, grade profile, step, change reason, compensation summaries (by grade, annualised, hourly) |
| Compensation Plans | Allowance plans, period salary plans, unit salary plans, salary/hourly plans, commission plans, bonus plans |
| Employee Contract | Contract ID, type, dates, status, description, reason, collective agreement, weekly hours |
| Leave of Absence | Position, leave dates, type, effects (benefits/payroll/PTO/service/stock), reason, family leave details |
| Payment Election | Rule, order, payment type, country, currency, bank account details, distribution |
| Collective Agreement | Dates, position, agreement details, factors and options |
| Costing Allocation | Order, level, position, allocation percentage, worktag details, dates |
| Union Member | Union, seniority date, membership details (start/end, position, type, notes) |
| Additional Information | Instance ID (custom/additional data) |
| Transaction Log | Transaction type, effective/entry moments, initiator details, correction/rescind flags, original/parent event references |

---

## Transaction Log Data Section — Important Notes

The Transaction Log section displays entries only when:
- The effective moment matches the entry moment
- The change has a corresponding business process change
- The change is a direct change

**Not displayed:** entry-dated changes without effective dates, changes without corresponding business processes (e.g. job profile changes), and indirect changes (e.g. cost centre name changes).

Indirect changes are only reported for a worker when the transaction log is enabled **and** the worker also has a direct change in the same run.

---

## Parallel Processing Guidance

When scheduling multiple WECI integrations in parallel, consider:

| Organisation Size | Recommended Parallel Runs |
|-------------------|--------------------------|
| ≤5,000 workers | Up to 4 integrations |
| ≤12,000 workers | Up to 2 integrations |
| >12,000 workers | Engage Professional Services for resource strategy |

Stagger integration schedules since grid is a shared resource.

---

## Security / ISU Requirements

The Integration System User (ISU) requires:

| Domain | Access Level | Purpose |
|--------|-------------|---------|
| Payroll Interface (Payroll Interface functional area) | Get and Put | Access all field attributes |
| Integration Build (Integration functional area) | Get | Create/view integration |
| Integration Configure (Integration functional area) | Get | Create/configure integration |
| Integration Debug (Integration functional area) | Get | Launch integration |
| Set Up: Payroll Interface (Payroll Interface functional area) | View | View data changes and diagnostic audit files |

For field overrides, the ISU requires **View** access to the fields used in the document field overrides.

---

## Audit Files

| File | Purpose | Suppression |
|------|---------|-------------|
| Data Changes Audit | Readable summary of worker changes and values | Suppress Audit Files attribute; auto-suppressed >30,000 workers |
| Diagnostic Audit | Troubleshooting — all processed workers including those with no output | Same as above |
| Payroll Extract | Actual XML output data | N/A |
| Messages Audit (zip) | Web service requests/responses, performance summary, configuration | Suppress Worker Messages Audit attribute |
| Schema XSD (PICommonOutput.xsd) | Content and structure definition based on current configuration | Generated every run |

### Performance Summary (inside Messages Audit)

The `Performance Summary.html` file lists:
- Top 10 slowest performing fields
- Top 10 slowest workers
- Field timings impacting performance

Use this to identify field overrides or report fields causing degradation.

---

## Troubleshooting: Performance Issues

### Poor Performing Report Fields in Field Overrides

**Problem:** Integration references one of these fields in a calculated field override:
- Worker Events Completed
- Staffing History – All / Approved
- Worker History

**Solution:** Create a "Worker Business Process Prompt" calculated field (Global object, Prompt for Value function, Multi-Instance, Worker Business Process). Replace the poor-performing field, then configure parameter and field override assignments with "Determine Value at Runtime".

### Is Manager Report Field

**Problem:** Is Manager field used in a calculated field override.

**Solution:** Remove the calculated field. Use the **Role** field in Position Data Section / Assigned Role to identify managers after processing.

### Terminated (based on report date)

**Problem:** This field is used in a calculated field override.

**Solution:** Replace with the **Terminated** report field (without "based on report date").

### Dynamic Membership Rules Without Optimisation

**Problem:** Dynamic membership rules are configured but the optimisation is not enabled.

**Solution:** Access Edit Tenant Setup - HCM → select the **Enable Dynamic Membership Rule Evaluation Optimisation** checkbox under the Payroll Interface section.

### Job Classifications – Job Profile

**Problem:** This field is used in a calculated field override.

**Solution:** Create a "Worker Job Classifications" calculated field (Position and Job - All Staffing Models, Look up related value, Lookup = Job Profile, Return = Job Classifications). Replace the poor-performing field in the override configuration.

---

## Limitations

- Does not capture time off or time tracking data
- Cannot define eligibility criteria based on managers
- Maximum 1 WECI integration on a business process
- Cannot detect future changes past 403 days outside the effective range
- LSRD must be within 2 months for primary runs, 6 months for ad hoc runs
- Not suited for near real-time or very frequent integrations (minimum interval: 6 hours with Effective Stack Sync)
- Full Snapshot requires Transaction Log Service to be disabled

---

## Recommendations

- Engage Workday Professional Services or a certified partner for implementation
- Set custom organisation membership rules to **semidynamic**
- Stagger grid integration schedules
- Turn off the transaction log to capture indirect changes
- Schedule WECI to run at least daily to avoid gaps in effective reporting range
- Use the Diagnostic Audit to identify workers reviewed but excluded from output
- Use Performance Summary.html to identify and resolve slow fields
- Test field overrides thoroughly in custom reports before adding to the integration
- For organisations >12,000 workers, consult Professional Services for resource strategy
