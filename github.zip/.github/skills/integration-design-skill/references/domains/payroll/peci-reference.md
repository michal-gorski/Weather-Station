# PECI Reference — Payroll Effective Change Interface

Comprehensive reference for the Payroll Effective Change Interface (PECI) connector. This is the **highest-priority** payroll integration knowledge.

---

## Overview

PECI is a full-stack integration transmitting each payroll change sequentially with effective date and entry date. It captures all personal, job, position, compensation, and benefits data in Workday HCM and sends changes to an external payroll provider.

**Key characteristics:**
- Full-stack, effective-dated change tracking
- XML output only
- Requires grid setup (contact Customer Care)
- 250,000 active employee limit per pay group
- Maximum 150 pay groups per single event
- Requires CCTPP (Cloud Connect for Third-Party Payroll) certification
- 100MB data limit per worker (exceeding workers are skipped)

---

## When to Use PECI

- Vendor requires full-stack integration with sequential history
- Vendor needs entry-dated vs effective-dated distinction
- Up to 250,000 workers per pay group
- Legacy third-party ERP conversion
- Real-time hire/termination needed (via Event-Driven Integration service)
- Cross-pay-group merging needed

**Do NOT use PECI when:**
- Contingent workers must be included (use WECI)
- CSV output is required (use PICOF)
- Population exceeds 250k per pay group
- No grid is available

---

## Setup Prerequisites

1. Engage Workday Professional Services or Consulting Partner
2. Establish third-party payroll organisations
3. Create future pay periods before the year begins
4. Establish third-party pay groups
5. Define third-party payroll earnings/deductions
6. Set up grid (contact Customer Care)
7. Set custom org membership rules to semidynamic (or enable Dynamic Membership Rule Evaluation Optimisation)

## Setup Steps

1. Access Create Integration System → select "Payroll Effective Change Interface"
2. Set Up PECI Integration Services
3. Grant ISU Get/Put access to domains (pay group, payroll interface, + at least 1 of: Integration Build/Event/Process)
4. Configure Integration Attributes and Maps
5. Select and Set Up Connector Output Fields
6. (Optional) Add Custom Fields
7. (Optional) Test Field Overrides
8. Set Up Integration Delivery
9. Set Up Integration Sequence Generators
10. (Optional) Create document transformation
11. (Optional) Set up frequent integration runs
12. Launch Integration
13. (Optional) Set up Event-Driven Integration
14. Review/correct vendor errors
15. (Optional) Access Maintain Dashboards → verify/add worklets

**Important:** Do not run PECI more than once per day unless required — it is resource-intensive. Can abort via Process Monitor if needed.

---

## Security Requirements

| Domain | Purpose |
|--------|---------|
| Integration Build, Integration Configure | Create PECI integration |
| Integration Build, Integration Configure, Integration Debug | Launch PECI integration |
| Integration Build | View launched PECI integration |
| Set Up: Payroll Interface, Set Up: Payroll Interface (Update Pay Period Status) | Run PECI in primary mode |
| Any 1 payroll pay calculation report (CAN/FRA/UK/USA) | View PECI data changes and diagnostic audit |
| Set Up: Payroll Interface, Manage: External Payroll Errors | View outputs and reports |
| Set Up: Payroll Interface | Generate Data Changes Audit report |

---

## Launch Parameters

| Parameter | Description |
|-----------|-------------|
| **Pay Group** | 1+ pay groups. Processes current active workers + terminated where it was last pay group |
| **Pay Period Selection Option** | "Use Pay Period for Current Date" or "Use Earliest Open Pay Period" |
| **Primary Run** | Non-ad hoc run. Updates LSRD after completion. Disables other parameters |
| **Pay Group Members** | Individual workers to include/exclude. Use unique identifier (WID/worker ID) for performance |
| **Exclude Members / Only Include Members** | Specifies workers to include or exclude from Pay Group Members list |
| **Change Detection** | "Include only changes entered since last successful run" or "Include all changes effective in pay period" |
| **Full Snapshot** | Captures all workers (active/terminated) with info as of period end date. Seeds payroll processor. Disables Transaction Log |
| **Last Successful Run Date** | Date/time of last successful run (editable). Not used for primary runs |
| **Merging Pay Groups** | Pay groups to merge with parent integration run (requires Merge Files service) |
| **Merging Past Events** | Integration events to merge with parent event |
| **Update Worker Last Successful Run Date** | Update LSRD for each worker to start date/time of integration run |
| **Effective Stack Sync Run** | Disable Transaction Log. Run full Effective Stack for entire population |

---

## Change Detection

### Two Methods

**1. Include all changes effective in the pay period**
- Use for the first launch in a pay period
- Includes all changes to employee data effective in the current pay period regardless of entry date
- Excludes transactions with effective date in a future pay period

**2. Include only changes entered since last successful run**
- Use for subsequent launches after the first run
- Includes changes entered after LSRD AND effective in current or prior pay period
- **Important:** An "all effective" run will not pick up entry-dated objects made before LSRD but effective in the current processing period

### Primary vs Ad Hoc Runs

**Primary Integration:**
- Automatic change detection
- Updates each pay group LSRD
- Updates period status to "In Progress" after first run
- Requires only 2 launch parameters: Pay Group + Pay Period Selection Option
- Automatically selects "all effective" if period status is "Not Yet Started"
- Selects "incremental" if period status is "In Progress"
- Must manually set period status to "Complete" after last payroll run

**Ad Hoc Integration:**
- Does not update pay group/period status
- Disables: Number of Additional Pay Periods, Enable Data Changes Audit For Faceted Search, EDI worker events
- Uses all populated launch parameter values

### Change Detection Logic

```
1. Is Entry Date after LSRD?
   ├─ No  → EXCLUDED
   └─ Yes → Continue
2. Is Change Detection = "All Effective"?
   ├─ Yes → Is Effective Date in current period?
   │        ├─ Yes → INCLUDED
   │        └─ No  → EXCLUDED
   └─ No  → Is Effective Date in current or prior period?
            ├─ Yes → INCLUDED
            └─ No  → EXCLUDED
```

### LSRD Recommendations

| Scenario | Recommended LSRD Lookback |
|----------|---------------------------|
| Primary runs | 2 months |
| Ad hoc runs | 6 months |

---

## Entry-Dated vs Effective-Dated Transactions

### Entry-Dated Changes
- Use the entry moment as the effective date
- Current period: Effective Date = Entry Date
- Previous period: Effective Date = last moment of previous period (23:59:59.999)

### Effective-Dated Changes
- Included when effective date occurs in the processing pay period
- Multiple same-date changes collapse into a single effective change (Entry Date = most recent transaction)
- Enable **Effective Stack - Expanded Effective Changes** service to prevent collapsing

### Non-Effective Dated Transactions
- Enable "Configuring an Effective Date for Non-Effective Dated Transactions" attribute to set effective date to entry date
- Prior period: effective = last date of period 23:59:59.999
- Future period: effective = first date of period 00:00:00.000

### Future-Dated Changes
- Not displayed if Effective To Date is before the event
- Example: Termination effective 3/1 during February pay period → not picked up until March
- Enable "Reporting for Termination on Last Day of Pay Period" to include terminations effective on the last day

---

## Integration Services

Enable via Related actions → Integration System > Configure Integration Services.

| Service | Purpose | Notes |
|---------|---------|-------|
| **Transaction Log** | Subscribe to events, filter worker data for changes. Improves performance | Does not detect indirect changes unless a qualifying transaction exists. Recommend: "Subscribe to all Transaction Types except" and specify exclusions |
| **Expanded Effective Changes** | Include expanded data change details for same effective date | Enable all Transaction Log fields. Does not support entry data roll up |
| **Include Sections Configuration** | Include all data sections even with no changes | |
| **Filename Sequence Generator** | Apply unique name to each output file | |
| **Merge Files Launch Parameters** | Merge output files from multiple pay groups | |
| **Worker Last Successful Run Date** | Display "Update Worker LSRD" launch parameter | |
| **Configurable Output** | Create Excel workbook of payroll effective changes | Max 5,000 workers |
| **Effective Stack Sync** | Run final synchronisation for frequent daily runs. Captures indirect changes | Enable simultaneously with Transaction Log. Primary runs only |
| **Event-Driven Integration (EDI)** | Send hire/termination automatically via business process step | 1 primary integration per pay group |
| **Integration Command Center (ICC)** | Use for ICC configurations | Also enable "Enable Data Changes Audit For Faceted Search" attribute |

---

## Integration Attributes

### Output & File Control

| Attribute | Description | Values |
|-----------|-------------|--------|
| Output Document Tags | Append document tags to output file | Free text |
| Audit Document Tags | Append tags to DataChangesAudit.html + DiagnosticAudit.html | Free text |
| Modify Output File Name | Do Not Append / Remove Special Characters / Replace Pay Group Name with Unique Identifier | Option |
| Append Country to Output File Name | Append two-digit country code to filename | Enabled/Disabled |
| Document Retention Policy | Days to retain output file | Days |
| Prevent Output File Delivery When Error | Prevent delivery when "Completed with Errors" status | Enabled/Disabled |

### Data Format

| Attribute | Description | Default |
|-----------|-------------|---------|
| Date Format | XSLT-supported date format | `[Y0001]-[M01]-[D01]` |
| Date Time Format | XSLT-supported datetime format | `[Y0001]-[M01]-[D01]T[H01]:[m01]:[s01]` |
| Country Code Type or Name | ISO code type in output | ISO 3166-1 Alpha 2 |
| Country Region Type or Name | Country region code/name for output | Country region name |
| Phone Number Parsing | Parsed (calculated) vs Unparsed (as entered) | Parsed |
| Override Descriptor with Reference ID | Return Reference ID instead of descriptor when no mapped value | Enabled/Disabled |

### Validation

| Attribute | Description | Default |
|-----------|-------------|---------|
| Required Field Validation | Exclude (error, exclude from extract) or Include (warning, include) | Exclude |
| Max Length Field Validation | Include (warning, truncate, include) or Exclude (error, exclude) | Include |

### Population & Scope

| Attribute | Description | Values |
|-----------|-------------|--------|
| Payroll Country | Country where employees reside (reporting only) | Country |
| Payroll Vendor | Payroll vendor (reporting only) | Vendor list |
| Payroll Company Organisation Type | Org type identifying payroll company. Required if pay group in multiple orgs | Org type |
| Organisation Type for ORG Event | Org type generating staffing event (ORG) when employee changes orgs but not pay groups | Org type |
| Report Only Primary Position | Only When All Positions Same Pay Group / Always | Option or None |
| Number of Additional Pay Periods | Additional pay periods to include (1–13 months) | Number |
| Maximum Number of Future Days | Control future days look-ahead. Set to 403 for 13 months/57 weeks | Days |
| Number of Years Limit for Terminated Employees | Years to include terminated workers. Default: 2 | Years |

### Change Detection & Processing

| Attribute | Description | Values |
|-----------|-------------|--------|
| Override Integration Event Field | Disable if uploading external payroll errors. Recommended: disabled | Enabled/Disabled |
| Override Pay Group WID Field | Include pay group WID in Summary Section of XML | Enabled/Disabled |
| Configure Effective Date for Non-Effective Dated Transactions | Set effective date to entry date for non-effective transactions | Enabled/Disabled |
| Roll Up Entry Dated Changes | Display entry-dated changes in Hire business process | Enabled/Disabled |
| Include Secondary Event Code | Include secondary event code when higher-priority event occurs | Enabled/Disabled |
| Additional Primary Integration | Enable multiple PECI systems per pay group. Cannot use with: Effective Stack Sync, EDI, Merge Files, Worker LSRD | Enabled/Disabled |
| Configure Rescind Rehire Staffing Event | Set: rescind rehire = HIR-R. Unset: rescind rehire = TERM | Enabled/Disabled |
| Reporting for Termination on Last Day of Pay Period | Include terminations effective on last pay period day in current period | Enabled/Disabled |
| Enable Hire Data Checkpoint | Send data after required onboarding complete. Primary runs only | Enabled/Disabled |
| Time Tracking Shift Date | Report time tracking by Shift Date vs Calculated Date | Enabled/Disabled |
| Exclude Last Successful Run Date Update for Status(es) | Select statuses to prevent LSRD auto-update | Status selection |

### Compensation

| Attribute | Description | Values |
|-----------|-------------|--------|
| Report Post Termination Compensation | Report post-termination compensation. Non-existent reports zeros | Enabled/Disabled |
| Configurable Compensation Basis | Configure customisable compensation basis option for position | Basis selection |
| Effective Date for Currency Conversion | Default: Period End Date | Date type |
| Exclude Amount Field for Percentage Based Plans | Exclude percentage-based amounts for selected subsections | Section selection |
| Report Deleted One-Time Payment Effective Same Day As Transfer | Report deleted OTPs with same effective date as pay group transfer | Event selection |

### Contact & Address

| Attribute | Description | Values |
|-----------|-------------|--------|
| Additional Name Types | Specify Additional Name Types to include | Name type |
| Address Usage Type | Specify Address Usage Type to include | Usage type |
| Address Usage | Combined with Address Usage Type for address inclusion rules | Usage |
| Phone Usage Type | Output primary phone numbers for selected type | Usage type |
| Email Usage Type | Output primary email for selected type | Usage type |
| Payment Election Rules | Output payment elections matching selected rules | Rule selection |
| Organisation Type for Organisation | Output organisations with matching types | Org type |
| Organisation Role for Position | Output assigned roles with matching roles | Role selection |

### Data Section Inclusion

These attributes control when data sections are included in output. Options: **Always** (always include), **During PGI Event** (include for PGI even with no changes), or unset (only include when changes exist).

| Attribute | Additional Options |
|-----------|-------------------|
| Include Personal Data Section | Always / During PGI Event |
| Include Personal Data By Country Data Section | Enabled/Disabled |
| Include Person Identification Data Section | Always / Enabled/Disabled |
| Include Position Data Section | Always / During PGI Event / Job Change Reason Only (Secondary) / Post Termination (Secondary) |
| Include Compensation Data Section | Always / As Of Termination Date (Secondary) / Compensation Change Reason Only (Secondary) / During PGI Event |
| Include Compensation Plans Data Section | Always / During PGI Event / As Of Termination Date (Secondary) |
| Include Compensation Earnings and Deductions Data Section | Always / During PGI Event / Report Removal During PGO/PCO |
| Include Person Communication Data Section | Always / Enabled/Disabled |
| Include Worker Status Data Section | Always / Enabled/Disabled |
| Include Payment Election Data Section | Always / During PGI Event |
| Include Contract Data Section | Always / During PGI Event / Exclude Ended Contracts |
| Include Collective Agreements Data Section | Always / During PGI Event |
| Include Additional Data Section | Always / Enabled/Disabled |
| Return leave(s) with Payroll Effect only | Enabled/Disabled |
| Output Unrounded Time Tracking Calculated Quantities | Rounds to 2 decimals (disabled) or 6 decimals (enabled) |
| Return End Date in Current Processing Pay Period | Send end date for Compensation Plans + Contracts in current period. Enable only with Transaction Log disabled |

### Performance

| Attribute | Description | Default |
|-----------|-------------|---------|
| Suppress Worker Message Audits For Job Size | Auto-excludes message audits when >5,000 workers | Auto |
| Suppress Audit Reports For Job Size | Auto-excludes audit reports when >30,000 workers | Auto |
| Exception Handling Mode for DIS | Report DIS exceptions as errors or warnings | Informational |

---

## Data Sections

PECI organises output into the following data sections. Each section can be configured to include always, only when changed, or during specific events.

| Data Section | Key Fields |
|-------------|------------|
| **Pay Group Summary** | Additional Primary Integration System, Last Processed Periods |
| **Worker Summary** | WID, Name, Employee ID, Currency Conversion Effective Date, Change Detection Override |
| **Worker Status** | Status, Active, Hire Date, Termination Date, Original Hire Date, End Employment Date, Continuous Service Date, Pay Through Date, Termination Reason/Category |
| **Personal** | Legal/Preferred/Additional names, Disability, Military, Citizenship, Gender, DOB, Marital Status, Ethnicity, Nationality, Language |
| **Personal By Country** | Country, Position ID, country-specific personal data |
| **Person Communication** | Address (usage, lines 1–9, city, postal code, country, subdivisions), Phone (device type, country code, number), Email |
| **Person Identification** | National ID, Government ID, Visa, Passport, License, Other ID (with type, country, dates) |
| **Related Person** | Dependent/Beneficiary/Emergency Contact IDs, name, relationship, gender, birth info |
| **Education** | School, degree, year, field of study, GPA |
| **Position** | Position ID, Job Title, Business Title, Worker Type, FTE%, Pay Rate Type, Job Profile, Job Change Reason, Business Site, Supervisor, Organisation, International Assignment data, Probation data |
| **Compensation** | Package, Grade, Grade Profile, Step, Change Reason, Annualised/Hourly/Pay Group Frequency summaries |
| **Compensation Plans** | Allowance/Period/Unit/Salary & Hourly/Commission/Bonus plans with %, amount, currency, frequency, start/end dates |
| **Compensation Earnings & Deductions** | Position ID, earning/deduction, non-prorated amount, frequency, compensation element |
| **Benefits Earnings & Deductions** | Position ID, external payroll code, earning/deduction, amount, %, frequency, currency, coverage/goal amounts |
| **Payment Election** | Rule, order, type, country, currency, bank info (account, IBAN, BIC), distribution |
| **Employee Contract** | Contract ID, type, start/end dates, status, reason, weekly hours, signatures |
| **Collective Agreement** | Start/end dates, collective agreement, factor |
| **Leave of Absence** | Leave dates, type, benefits/payroll/accrual effects, reason, leave % |
| **Benefit Elections** | Health care, HSA, insurance, retirement, spending account plans with coverage, provider, dates, deduction start/end |
| **Time Off Earnings & Deductions** | External code, time off type, unit, entries (units, start/end times, reason, worktag) |
| **Time Tracking** | External code, override rate, entries (quantity, worktag) |
| **Payroll Input Earnings & Deductions** | Payroll input ID, external code, earning/deduction, start/end dates, amount, rate, %, currency |
| **Compensation One Time Payment** | Payment ID, external code, amount, currency, reason, payment/clawback dates |
| **Payroll One Time Payment** | Payment ID, external code, amount, rate, %, currency, worktag |
| **Costing Allocation** | Order, level, position ID, %, worktag, start/end dates |
| **Union Member** | Union, seniority date, membership type, start/end dates |
| **Additional Information** | Instance ID |
| **Work Schedule Calendar** | ID, name |
| **Transaction Log** | Type, effective/entry moments, initiator, corrected/rescinded flags |

---

## Staffing Event Codes

| Code | Definition | Data Included |
|------|-----------|---------------|
| **HIR** | New hire into pay group | All sections for employee |
| **HIR-C** | Correction to hire date (earlier effective date) | Status section |
| **HIR-R** | Rescind new hire event | Status section |
| **TERM** | No longer employed (active → terminated) | Personal, ID, Status, Position, Compensation, Plans, E&D, Payroll Input |
| **TERM-C** | Correct termination date (earlier) | Status section |
| **TERM-R** | Rescind termination (terminated → active) | Status section |
| **DTA** | Other data changes | Changed sections only |
| **LOA** | On leave of absence | Status + Leave of Absence |
| **LOA-C** | Correction to LOA end date/type | Status + Leave of Absence |
| **LOA-R** | Rescind leave of absence | Status + Leave of Absence |
| **RFL** | Return from leave of absence | Status + Leave of Absence |
| **RFL-R** | Correction to leave end date | Status + Leave of Absence |
| **CONT-LOA** | Continuous leave (return + immediate new leave) | Leave of Absence |
| **PCI** | Transfer TO this pay group from different payroll company | All sections for employee |
| **PCO** | Transfer FROM this pay group to different payroll company | Personal, ID, Status, Position, Compensation, Plans, E&D, Payroll Input |
| **PGI** | Transfer TO this pay group from another in same company | Personal, ID, Status, Position |
| **PGO** | Transfer FROM this pay group to another in same company | Personal, ID, Status, Position |
| **ORG** | Change organisation but not pay group | All sections for employee |

### Key Event Handling Rules

- **HIR/PCI**: Treat as net-new/rebase — all sections included since vendor may not have existing data
- **PCO**: Includes Position End Date. **PCI**: Includes Job Transfer details + Job Change Reason
- **Rescind transfer**: Generates opposite event codes (reversal)
- **Correction use cases with Expanded Changes OFF**: Hire correction to earlier = HIR + DTA. Hire correction to future = HIR-R + HIR
- **Correction use cases with Expanded Changes ON**: Hire correction to earlier = HIR-C. Hire correction to future = HIR-R + HIR
- **LOA events excluded** if Leave of Absence section is not enabled (CONT-LOA, LOA, LOA-C, LOA-R, RFL, RFL-R)
- **isAdded / isDeleted annotations**: Evaluate event details for additions/deletions. Key field changes report both

---

## Frequent Integration Runs

Run PECI more frequently than once daily (up to 4x/day or every 6 hours with Effective Stack Sync Service).

**One-time setup:**
1. Enable Transaction Log service
2. Enable Effective Stack Sync service
3. Access Maintain Payroll Integration Systems for Pay Group
4. Enter LSRD in: Created Date Time + Created Date Time for Additional Run
5. Launch integration (4x/day or every 6 hours with Sync service)

**How it works:** Daily runs detect direct changes via Transaction Log. The final sync run captures indirect changes (e.g., manager changes) that the daily runs missed.

---

## Merge Integration Outputs

Combine output files from multiple pay groups into one file, exceeding the 250k worker limit.

**Setup:**
1. Create Integration System → select "PECI - Merge Files Integration Template"
2. Enable Filename Sequence Generator (optional)
3. Create ISU with Payroll Administrator group access
4. On PECI integration: enable "Merge Files Launch Parameters" service
5. Create business process with Integration-type step as last step

**Execution:**
- Specify pay groups in Pay Group field (runs together) and Merging Pay Groups (auto-launched separately)
- Merge step combines all outputs into single file with `<peci:Worker_Effective_Stack_Aggregate>` root element

---

## Correctable & Rescindable Business Processes

| Business Process | Correctable | Rescindable | Dated |
|-----------------|:-----------:|:-----------:|-------|
| Hire Worker | ✓ | ✓ | Effective |
| Job Change (Transfer/Promote/Change Job, Add Additional Job, Assign Collective Agreement, Start International Assignment) | ✓ | ✓ | Effective |
| Job Change (Change Business Title, End Collective Agreement) | ✓ | | Effective |
| Organisation (Change Organisation Assignments) | ✓ | ✓ | Effective |
| Personal Data Change (Edit Personal Info, Edit ID Info, Edit Government IDs, etc.) | ✓ | | Entry |
| Personal Data Change (Contact Change) | ✓ | ✓ | Effective |
| Payroll (Assign Pay Group) | ✓ | | Effective |
| Time and Leave (Enter Time Off, Place on Leave, Return from Leave) | ✓ | ✓ | Effective |
| Payroll Interface (Edit Position Data) | ✓ | | Effective |
| Compensation (Request Compensation Change, Request OTP, Grade Change, Bonus Payment) | ✓ | ✓ | Effective |

---

## Transaction Logs

Transaction logs flag workers for integration review. They are used for change detection.

**Key behaviour:**
- Only worker-level events trigger review
- Do not indicate whether a change was actually reported
- Do not create logs for indirect changes (e.g., cost centre name change affecting workers)
- Example: Manager change on George (direct) triggers review and reports both the direct change + indirect cost centre name change. Marie (indirect only, no direct qualifying transaction) is not reviewed

**Recommendation:** Enable Transaction Log for performance improvement on large populations.

---

## Reporting

| Report/Task | Purpose |
|-------------|---------|
| Data Changes Audit Report | Faceted search for effective changes from primary runs. Requires "Enable Data Changes Audit For Faceted Search" attribute |
| Maintain Errors from Third-Party Payroll | View + correct vendor-returned errors. Consolidates PECI + EDI. Vendor must use `Put_Integration_Event_Error_Message_Set` web service |
| Third-Party Payroll Errors | Comprehensive list of vendor-returned errors |
| Workers Not Processed by PECI Events | Workers hired but not processed by EDI, with EDI still in progress, with failed EDI, or needing corrections |
| View Payroll Integration System for Employee | Last successful run date by effective date |

---

## Limitations

- No contingent workers
- No out-of-order retroactive insertions
- No benefit elections with deduction begin date before hire date
- No one-time payments beyond 2 years past current period start
- No time tracking beyond 1 year
- No unpaid time off
- No orchestration (1 business process only)
- No more than 250,000 active employees per pay group
- No future change detection beyond 13 months
- No dynamic calculated compensation plans (use Event-Driven instead)
- No Buy Time Off
- Cannot display non-effective-dated stack sequences in descending order
- Creating pay periods during runs may cause discrepancies

---

## Field Override Testing

1. Create Custom Report: Advanced type, Data Source = "Worker from Prompt"
2. Add the calculated field as a column
3. Add Worker filter with Employee ID prompt
4. Add Runtime Date Prompts: Effective Date (prompt as of), Entry Date (prompt entry date/time)
5. Run report with effective + entry date matching the event under test
6. Verify calculated field returns expected value for the effective/entry date combination

**Note:** Calculated fields with >8 hierarchy levels may impact performance.

---

## Troubleshooting

### Compensation Changes

| Issue | Cause | Solution |
|-------|-------|----------|
| Reporting incorrect compensation changes | Ran integration before correction was made | Set LSRD to after the correction |
| Deleted entire compensation plan history | Rescinded change + initiated new change same day with different WID | Correct existing change instead of rescinding + new |
| Not reporting change in E&D section | Currency conversion rates missing, zero, or not configured for source→target currency | Verify via Currency Rates as of Date report; edit Maintain Currency Conversion Rates |
| Not reporting Compensation E&D for pay group transfer with compensation change | Transferred with comp change, then corrected job change to later date | Set "Include Compensation Earnings and Deductions Data Section" to "Report Removal During PGO and PCO Events"; rerun |

### One-Time Payments

| Issue | Cause | Solution |
|-------|-------|----------|
| Not reporting OTPs (data sections configured) | External earnings not configured for pay groups | Maintain External Payroll Earnings → select pay groups, add row with Name, Code, Pay Groups, Compensation Elements |
| Not reporting OTPs | Running full snapshot PECI | Disable Full Snapshot; enable Primary Run or run ad hoc |
| Not reporting deleted OTPs | Worker has OTP + later pay group transfer same effective date | Enable "Report Deleted One-Time Payment Effective Same Day As Transfer" attribute |
| Reporting OTPs for previous position in current position | Scheduled Payment Date set during current position pay period | Set Scheduled Payment Date + Effective Date to same date as previous position; run ad hoc for prior period/pay group |
| Retroactive OTP not reported after pay group move | Processed retroactive OTP after moving worker to new pay group | Run ad hoc PECI for worker for prior period + prior pay group |

### Time Tracking

| Issue | Cause | Solution |
|-------|-------|----------|
| Time entry not reported | Time calculation tag not mapped to external earning | Maintain External Payroll Earnings → assign Time Calculation Tags |
| Time entry not reported (international assignment) | Position Setup Options not enabled | Edit Tenant Setup - HCM → enable Position Setup Options + select Multiple Jobs; Assign Pay Group for IA position |
| Time entry not reported (pay group transfer) | Processed time entry after pay group transfer | Run ad hoc PECI for worker for prior period/pay group |
| Deleted time entry not reported | Manager hasn't approved entry, or net effect unchanged (0→8→0 = 0) | Manager must approve + reapprove deletions |

### Performance

| Issue | Solution |
|-------|----------|
| Poor performing report field (Worker Events Completed, Staffing History, Worker History) | Create calculated field with Worker business process prompt; use as field override |
| Referencing "Is Manager" report field | Use Role field in Position Data Section / Assigned Role; configure "Organisation Role for Position" attribute to "Manager" |
| Referencing "Terminated (based on report date)" | Use the "Terminated" report field instead |
| Dynamic rules without optimisation | Edit Tenant Setup - HCM → enable "Enable Dynamic Membership Rule Evaluation Optimisation" |
| Referencing Job Classifications - Job Profile field | Create calculated field (Function: Look up related value; Lookup: Job Profile; Return: Job Classifications) |

### General FAQ

| Question | Answer |
|----------|--------|
| Why did PECI report compensation change with no changes? | Indirect change (e.g., compensation frequency) impacted worker. Access compensation plan to see the change |
| Why did PECI add End Date to Allowance/Compensation Plan? | Worker not eligible per eligibility rules, OR edited existing plan (PECI treats as new plan with old plan End Date = 1 day before new plan Start Date) |
| Why didn't PECI report deleted time tracking entry? | Manager hasn't approved (must approve + reapprove deletions), OR net effect unchanged |
| Are compensation eligibility rule changes detected? | No — Workday does not detect Configurable Compensation Basis changes from eligibility rule updates. It detects position moves (eligible → not eligible) |
