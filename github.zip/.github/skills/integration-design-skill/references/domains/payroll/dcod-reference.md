# DCoD Reference — Data Changes on Demand

## Overview

Data Changes on Demand (DCoD) is a full-stack REST API integration that enables third-party payroll systems to query worker data on demand from Workday. It provides field-level change detection and returns current snapshots in JSON format via the `globalPayroll/effectiveChanges` REST API.

### Key Characteristics

- **Pull-based model** — the third-party vendor initiates requests; Workday does not push data on a schedule
- **JSON output** — not file-based XML like PECI/PICOF
- **Field-level change detection** — detects changes at individual field level (PECI does not)
- **No derived event codes** — vendors interpret raw data based on their own business logic
- **Flexible field requests** — each API request can specify exactly which data sections and fields to return
- **No CCTPP certification required** for implementation

### When to Use DCoD

| Use DCoD when… | Consider alternatives when… |
|---|---|
| Vendor requires a full-stack integration | Vendor needs simple CSV/XML → use PECI/PICOF |
| Vendor can initiate API requests from Workday | Integration must be Workday-scheduled → use PECI |
| Multiple countries with less implementation time needed | You need contingent worker data → use WECI |
| Vendor needs to interpret raw data without Workday event logic | You need derived event codes → use PECI |
| You need on-demand data transfer (not batch/scheduled) | You need a data warehouse feed for same pay group → use WECI for warehouse, DCoD for payroll |
| You need field-level change detection | Active employee count exceeds 50,000 → use PECI |

### Limitations

- Does not support contingent workers
- Maximum 50,000 active employees across all pay groups being processed
- Maximum 150 pay groups processing
- Does not support one-time payments beyond 2 years
- Does not support time tracking entries beyond 1 year
- Does not support unpaid time off
- Does not support dynamic calculated compensation plans (use event-driven instead)
- Cannot configure the order of effective changes in output
- Maximum 3-month range for effective date parameters when `allEffective = true`
- Maximum 2-month range for entry moment parameters
- Does not support the Third-Party Payroll Errors report
- Does not support Hire Data Checkpoint
- Does not support Buy Time Off directly (use External Payroll Inputs)
- Does not support net effective changes
- Does not support sub-document field overrides
- Concurrency limits: max 5 in-progress events for multi-worker jobs; max 25 for single-worker jobs per vendor

---

## Setup

### Prerequisites

1. **Grid enabled** — contact Customer Care; only 1 active tenant per environment can have grid
2. **Upfront analysis** with third-party payroll vendor to determine required data
3. **Third-party payroll organisations** established
4. **Pay periods created** in advance (before the year they are active)
5. **Third-party pay groups** established
6. **External payroll earnings and deductions** defined
7. **Custom organisation membership rules** set to semi-dynamic (or enable Dynamic Membership Rule Evaluation Optimisation)

### Setup Steps (Condensed)

1. **Create ISU** — Create Integration System User; set Session Timeout Minutes to 0
2. **Edit Domain Security** — grant ISU access to required domains (see Security section)
3. **Activate Pending Security Policy Changes**
4. **Register API Client** — scope: Integration + Global Payroll Interface Connect
5. **Create Integration System** — template: Data Changes On Demand; create 1 per vendor; do NOT configure field attributes, assign ISU, or add a business process
6. **Create External Payroll Vendor** (optional) — select DCoD from Features prompt
7. **Create External Payroll Vendor Mapping** — configure Key Pair (Do Not Allow Regeneration), add Feature Configuration rows for ISU, Acknowledgement Endpoint, and Integration System Endpoint
8. **Maintain Pay Group Vendor Associations** — associate pay groups with vendor for DCoD feature

### Key Recommendations

- Work with a payroll vendor to configure DCoD
- Create 1 integration system per third-party payroll vendor
- Do NOT add a business process to the DCoD integration
- Maintain `entryMomentFrom` / `entryMomentTo` values in the third-party system
- Each external payroll vendor mapping must have 1 unique ISU

---

## Security / ISU Requirements

| Domain | Access | Purpose |
|---|---|---|
| Manage: Data Changes On Demand (Global Payroll Connect) | Get and Modify | Run the REST API |
| Integration Build / Integration Debug / Integration Event (Integration) | View (at least 1) | Run the REST API |
| Reports: Data Changes On Demand Results (Global Payroll Connect) | View and Get | Retrieve JSON output |

Additional requirements:
- ISU should be exempt from password expiration (Maintain Password Rules task)
- ISU must have View access to any report fields used in field overrides (verify with View Security for Calculated Field task)

---

## Integration Attributes and Field Overrides

### Field Overrides

Field overrides allow customisation of integration output using report fields or calculated fields. The REST API accepts a `fieldOverrides` element in the request body.

**Supported data sections for field overrides:**
- Worker Status
- Personal
- Personal Communication
- Related Person
- Related Person Communication
- Position
- Compensation
- Additional Information

**Field override naming rules:**
- Must be alphanumeric
- No spaces or special characters (underscores permitted)
- Cannot start with a number

**Requesting field overrides in JSON:**
```json
"fieldOverrides": [
    {"path": "$.workers.additionalInformation.workSchedule"},
    {"path": "$.workers.workerStatus.lastTermDate"}
]
```

Field overrides only appear in output if the vendor explicitly requests them using the correct `jsonPath`.

### Integration Attributes

DCoD integration attributes are configured via Configure Integration Attributes on the integration system. Key attributes include:
- **Organisation Role for Position** — e.g., set to "Manager" to identify managers via the Assigned Roles section
- **Include Compensation Earnings and Deductions Data Section** — controls inclusion behaviour

---

## Change Detection

DCoD offers two change detection modes controlled by the `allEffective` request parameter:

### All Effective Changes (`allEffective = true`)

- Includes **all changes** effective between `effectiveFrom` and `effectiveTo`, regardless of when entered
- Also includes changes entered between `entryMomentFrom` and `entryMomentTo` that are effective before or within the current range
- Maximum 3-month (93-day) effective range
- **Use for:** first initial run of a new effective range, or single-extract-per-period scenarios

### Incremental Effective Changes (`allEffective = false`)

- Includes **only changes entered** between `entryMomentFrom` and `entryMomentTo`
- Changes must be effective on or before `effectiveTo`
- No effective range limit
- **Use for:** subsequent/incremental runs within an effective range

### Entry-Dated (Non-Effective-Dated) Changes

DCoD sets effective moments for non-effective-dated transactions as follows:
- **Current period** — effective date = entry date
- **Prior period** — effective date = last date of the period at 00:00:00.000
- **Future period** — effective date = first date of the period at 00:00:00.000

### Key Date Rules

- An `allEffective` run will NOT pick up entry-dated changes made before `entryMomentFrom` or after `entryMomentTo`
- Never set `entryMomentTo` to a future date — this creates gaps that cause missed transactions on subsequent runs
- The integration context views data as of the `entryMomentTo` date, not current run time
- Store the last successful `entryMomentTo` per worker and per pay group in the third-party system

### Change Detection Flow

```
Event Entry Date after entryMomentFrom?
  ├─ No → Event NOT in payroll extract
  └─ Yes → Is allEffective mode?
              ├─ Yes → Event Effective Date within effectiveFrom–effectiveTo?
              │         ├─ Yes → Event IN payroll extract
              │         └─ No → Event NOT in payroll extract
              └─ No → Event Effective Date on or before effectiveTo?
                        ├─ Yes → Event IN payroll extract
                        └─ No → Event NOT in payroll extract
```

---

## Data Sections Summary

Each data section is requested via its field path ID in the REST request body (e.g., `$.workers.workerStatus`). Use `.*` suffix to include all subfields.

| Data Section | Field Path ID | Content Category |
|---|---|---|
| Worker Status | `$.workers.workerStatus` | Hire/termination dates, employment status, service dates, termination reasons, leave return info |
| Creditable Service | `$.workers.workerStatus.creditableServices` | Service type, years/months/days |
| Recruiting Information | `$.workers.recruitingInformation` | Source category, referral details |
| Personal | `$.workers.personal` | Names, gender, DOB, nationality, marital status, disability, military, citizenship, ethnicities |
| Personal (Legal/Preferred/Additional Names) | `$.workers.personal.legalNames` / `.preferredNames` / `.additionalNames` | Name components by country |
| Personal (Disability) | `$.workers.personal.disabilityStatuses` | Disability details, certifications, grades |
| Personal (Military) | `$.workers.personal.militaryServices` | Service type, rank, veteran status |
| Personal Data By Countries | `$.workers.personalDataByCountries` | Country-specific personal data for secondary jobs |
| Personal Communication | `$.workers.personalCommunication` | Addresses, phones, emails with usage types |
| Personal Identification | `$.workers.personalIdentification` | National IDs, government IDs, visas, passports, licences, other IDs |
| Related Persons | `$.workers.relatedPersons` | Dependents, beneficiaries, emergency contacts with demographics |
| Related Person Communications | `$.workers.relatedPersonCommunications` | Addresses, phones, emails for related persons |
| Related Person Identifications | `$.workers.relatedPersonIdentifications` | National/government/other IDs for related persons |
| Education | `$.workers.educations` | Degrees, schools, fields of study |
| Positions | `$.workers.positions` | Position details, job profile, hours, FTE, pay rate, classifications, business site, supervisor, organisations, assigned roles, probation |
| Compensations | `$.workers.compensations` | Compensation package/grade/step, change reasons, summaries in multiple frequencies |
| Compensation Plans | `$.workers.compensationPlans` | Allowance, period salary, unit salary, salary/hourly, commission, and bonus plan details |
| Payment Elections | `$.workers.paymentElections` | Bank accounts, distribution amounts/percentages, IBAN, BIC |
| Employee Contracts | `$.workers.employeeContracts` | Contract type, status, dates, collective agreement |
| Collective Agreements | `$.workers.collectiveAgreements` | Agreement details and factors |
| Leave of Absence | `$.workers.leaveOfAbsence` | Leave type, dates, reasons, payroll/benefits effects, child-related fields |
| Benefit Elections | `$.workers.benefitElections` | Health care, HSA, insurance, retirement, spending account elections with plan details |
| Benefits Earnings and Deductions | `$.workers.benefitsEarningsAndDeductions` | Mapped benefit plan earnings/deductions with amounts and frequencies |
| Compensation Earnings and Deductions | `$.workers.compensationEarningsAndDeductions` | Compensation-linked earnings/deductions |
| Work Schedule Calendar | `$.workers.workScheduleCalendarSection` | Calendar ID and name (no overrides/time blocks) |
| Time Off Earnings and Deductions | `$.workers.timeOffEarningsandDeductions` | Time off types with individual entries (start/end times, reasons) |
| Grouped Time Off Earnings and Deductions | `$.workers.groupedTimeOffEarningsandDeductions` | Time off grouped by consecutive days |
| Time Tracking | `$.workers.timeTracking` | Approved time entries with quantities (max 1-year lookback) |
| Payroll Input Earnings and Deductions | `$.workers.payrollInputEarningsAndDeductions` | External payroll inputs (ongoing/recurring) |
| Compensation One Time Payments | `$.workers.compensationOneTimePayments` | Comp OTPs (bonus/scheduled payments) |
| Payroll One Time Payments | `$.workers.payrollOneTimePayments` | Payroll OTPs (from External Payroll Inputs) |
| Costing Allocations | `$.workers.costingAllocations` | Allocation percentages and worktags |
| Union Members | `$.workers.unionMembers` | Union membership details |
| Additional Information | `$.workers.additionalInformation` | Generic container for field overrides (enabled by default) |
| Personnel Action Requests | `$.workers.personnelActionRequests` | U.S. Federal PAR data (NOA codes, legal authorities) |
| Transaction Logs | `$.workers.transactionLogs` | Transaction type, entry/effective moments, initiator, correction/rescind flags |

**Notes:**
- Time Off and Grouped Time Off cannot be included in the same request
- Benefits E&D, Compensation E&D, and Payroll Input E&D are interdependent — enabling one may include the others
- Field set version: all fields are v1 unless specified; set `fieldSetVersion` to v2 for additional fields
- Currency conversion uses the pay group's assigned country currency for Benefits and Compensation E&D sections

---

## Request Criteria Parameters

### Required Request Headers

| Header | Description |
|---|---|
| `wd-external-request-id` | Unique identifier per request |
| `wd-external-application-id` | Source identifier (pay group, country, integration ID) |
| `wd-external-originator-id` | Third-party system name making the request |

### Request Criteria

| Parameter | Type | Required | Description |
|---|---|---|---|
| `entryMomentFrom` | DateTime | Yes | Start of entry window (PST). Max 2-month span with `entryMomentTo` |
| `entryMomentTo` | DateTime | Yes | End of entry window (PST). Must not be in the future |
| `effectiveFrom` | Date | Yes | Start of effective range. Must fall within an existing pay period |
| `effectiveTo` | Date | Yes | End of effective range |
| `allEffective` | Boolean | No | `true` = all effective changes (max 93-day range); `false` = incremental only |
| `extendedAllEffectiveTo` | Date | No | Extends effective range with `allEffective = true` behaviour for the extended period (max 93 days from `effectiveTo`) |
| `includeRequestCriteriaInResponse` | Boolean | No | Include request criteria in API response |
| `fields` | Object | Yes | Contains `fieldSetVersion` (v1/v2), `onlyInclude` (field path IDs), optional `fieldOverrides` |
| `organizations` | Multi-instance | Yes | 1 or more payroll interface pay groups |
| `excludeWorkers` | Boolean | No | `true` = exclude specified workers; `false` = include only specified workers |
| `workers` | Multi-instance | No | WID or reference ID (e.g., `Employee_ID=12345`) |
| `workerOverrides` | Multi-instance | No | Worker ID + `entryMomentFromOverride` per worker |
| `forceRerun` | Boolean | No | `true` = force new event even for duplicate request |
| `schemaOnly` | Boolean | No | `true` = return schema only without launching |

### Response Filters

| Filter | Description |
|---|---|
| `fullSnapshot` | `true` = include all workers (with and without changes) |
| `additionalNameTypes` | Limit which additional name types appear |
| `organizationTypes` | Limit organisation types in Position section |
| `organizationRoles` | Limit organisation roles in output |
| `paymentElectionRules` | **Required** to see payment elections — specify which rules to include |
| `addressUsageTypes` | Limit address types (Personal Communication / Related Person Communication) |
| `phoneUsageTypes` | Limit phone types |
| `emailUsageTypes` | Limit email types |
| `nationalIdTypes` | Limit national ID types |
| `governmentIdTypes` | Limit government ID types |
| `passportIdTypes` | Limit passport ID types |
| `visaIdTypes` | Limit visa ID types |
| `licenseIdTypes` | Limit licence ID types |
| `otherIdTypes` | Limit other ID types |
| `countryNameFormat` | `COUNTRY_NAME`, `ISO_3166-1_ALPHA-2_CODE` (default), `ISO_3166-1_ALPHA-3_CODE` |
| `countryRegionNameFormat` | `COUNTRY_REGION_ID`, `COUNTRY_REGION_NAME`, `ISO_3166-2_CODE`, `ISO_3166-2_COUNTRY_REGION_CODE` (default) |
| `overrideDescriptorWithReferenceId` | Output Reference IDs instead of descriptors for specific fields |
| `configurableCompensationBasis` | Specify WID/ref ID to include configurable comp basis |
| `excludeAdditionalJobs` | `true` = report primary jobs only |
| `includeEndedContracts` | `true` = include contracts ended before `effectiveFrom` |
| `includePayrollEffectedLeavesOnly` | `true` = only leaves with Payroll Effect = true |
| `reportPostTermCompensation` | `true` = include post-termination compensation |

---

## PECI vs DCoD Comparison

| Feature | PECI | DCoD |
|---|---|---|
| Output format | XML (file-based) | JSON (REST API response) |
| Scheduling | Workday-scheduled | Vendor-initiated on demand |
| Field-level change detection | Not supported | Supported |
| Derived event codes | Supported | Not supported (vendor interprets raw data) |
| Flexible field requests per run | Not supported | Supported |
| CCTPP certification required | Yes | No |
| Net effective changes | Supported | Not supported |
| Pay group limit | 250,000 active payees | 50,000 active payees |
| LSRD (Last Successful Run Date) | Workday-maintained | Vendor must maintain in their system |
| Effective range limit | 13 months | No limit (unless `allEffective = true`, then 93 days) |
| Entry moment range | N/A (LSRD-based) | Max 2-month span |
| Audit HTML files | Supported | Not supported |
| Business process orchestration | Only 1 PECI per BP | Multiple DCoD integrations per tenant |
| Expanded effective changes | Requires integration service | Default behaviour |
| Sub-document field overrides | Supported (Worker Status, Additional Info) | Not supported |
| Event Outbound Notifications | Event-Driven Integration service | Event Outbound Notifications template |
| Contingent workers | Not supported | Not supported (use WECI) |
| Retroactive changes | Supported | Supported |
| Prior values | Supported | Supported |
| Multiple changes per period | Reported separately | Reported separately |
| Transaction Log service | Supported | Not applicable (use Transaction Logs data section) |

---

## Retrieving the Output File

After a DCoD request completes, the third-party system receives a notification containing a document ID. Retrieve the JSON output using:

```
GET https://{hostname}/ccx/cc-blobitory/{tenant}/{collectionDocumentID}
```

- ISU requires access to Reports: Data Changes On Demand Results domain
- Default document retention: 60 days

---

## Event Outbound Notifications

Configure the **Event Outbound Notifications** integration template to automatically send hire and termination event notifications to the third-party payroll system. This tells the vendor when to request data for new/terminated workers.

Requirements:
- Pay group assignment step must be before the hire completion step on the hire business process
- Notifications include reference IDs and effective moments

---

## FAQ

**What are info blocks in the DCoD response?**
Info blocks appear when a field's current value differs from its value at the effective/entry moment of another field's change. They are informational — they show what the value was at the time of a related change, not that the field itself changed.

**How do I get reference IDs and WIDs for the API call?**
Use the `Get_References` web service in the Workday Web Services Directory.

**Why are benefit plan values missing from my response?**
Benefits Earnings and Deductions only outputs data mapped through external earnings/deductions configuration, and only values greater than 0.

**What is the difference between Payroll OTP and Compensation OTP?**
- Payroll OTP = driven by External Payroll Inputs
- Compensation OTP = driven by compensation OTPs or scheduled bonus payments

**Are compensation eligibility rule changes detected?**
Position changes that affect eligibility are detected. However, if the eligibility rule itself is updated (changing the eligible population), this is NOT detected.

**Why is my OTP not reporting?**
You must set up earnings/deductions mapping for both compensation OTPs and external payroll input OTPs.

**Why no Event Outbound Notification for a new hire?**
The pay group assignment step must be configured before the hire completion step on the hire business process.

**Why are payment election values missing?**
You must specify a value for the `paymentElectionRules` response filter in your API request.

---

## Troubleshooting

### Performance Issues

| Problem | Cause | Solution |
|---|---|---|
| Poor-performing report field in field override | Using Worker Events Completed, Staffing History - All/Approved, or Worker History | Create a calculated field using "Prompt for Value" with Worker Business Process, configure as Document Parameter |
| Is Manager report field causing slowness | Using Is Manager calculated field as field override | Remove the field override; use the Assigned Roles data section with Organisation Role for Position attribute set to "Manager" |
| Terminated (based on report date) field issues | Using this report field in a calculated field | Replace with the standard "Terminated" report field |
| Dynamic rules without optimisation | Dynamic membership rules without the optimisation flag | Enable "Enable Dynamic Membership Rule Evaluation Optimisation" on Edit Tenant Setup - HCM |
| Job Classifications - Job Profile field | Using this report field in a field override | Create a calculated field using "Look up related value" (Lookup: Job Profile → Return: Job Classifications) |

### Common Issues

- **Missed transactions** — check that `entryMomentTo` is not set to a future date; verify the relationship between entry moment dates, effective dates, and event dates
- **Duplicate data** — maintain `entryMomentFrom` values per worker in the third-party system; use `workerOverrides.entryMomentFromOverride` for individual worker requests
- **Integration stops immediately** — total active employees across all pay groups exceeds 50,000; split pay groups
- **Missing pay period data** — `effectiveFrom` must reference a date within an existing pay period
- **Field overrides not appearing** — vendor must explicitly request them using correct `jsonPath` in the `fieldOverrides` section
- **Integration errors with field overrides** — calculated fields used in overrides are either invalid or perform poorly
- **Work schedule calendar not detected** — inherited calendars using custom calculated fields in eligibility rules may not be detected; use assignment calendar events instead
