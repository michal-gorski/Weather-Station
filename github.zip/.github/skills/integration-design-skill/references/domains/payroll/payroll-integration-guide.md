# Payroll Integration Guide

Overview and decision hub for Workday payroll integrations. For deep technical detail, see the dedicated references:
- [PECI Reference](./peci-reference.md) — Payroll Effective Change Interface Connector
- [PICOF Reference](./picof-reference.md) — Payroll Interface Connector

---

## What Are Workday Payroll Interfaces?

Workday Payroll Interfaces enable managing payroll data and sending it to external payroll providers. They are integration templates with a configurable set of HCM data. Because payroll providers only need a subset of employee data in Workday, you can specify:
- Which data elements to include in payroll extracts
- When to include them (change detection, scheduling, pay period alignment)

Output is XML or CSV. Integrations can deliver files to external systems, perform transformations, or generate audit reports for manual entry.

---

## Integration Selection Matrix

Use this matrix to select the right integration type based on requirements gathered during discovery.

| Criterion | PECI | PICOF | WECI | DCoD | Event-Driven |
|-----------|------|-----|------|------|-------------|
| **Model** | Full-stack (effective-dated changes) | Top-of-stack (delta/full extract) | HCM-focused (effective-dated changes) | API-driven on demand | Real-time via business process |
| **Output** | XML only | XML or CSV | XML only | API response | XML only |
| **Grid required** | Yes | No | Yes | No | No (runs as PECI service) |
| **Worker limit** | 250,000 active per pay group | No limit | 500,000 | N/A | 500 events/hour |
| **Contingent Workers** | No | No | Yes | Yes | No |
| **Retroactive changes** | Yes | Yes | Yes | Yes | N/A |
| **Prior values** | Yes | Yes (XML only) | Yes | N/A | N/A |
| **Change detection** | Entry-dated + effective-dated | Delta (transaction log) | Entry-dated + effective-dated | On demand | Business process event |
| **Field overrides** | Yes | Yes | Yes | N/A | N/A |
| **Merge outputs** | Yes (across pay groups) | No | No | N/A | N/A |
| **CCTPP certification** | Required | Not required | Not required | N/A | N/A |
| **Primary use** | External payroll vendor (full history) | External payroll vendor (simple extract) | Non-payroll HCM vendor, CW populations | Ad hoc data queries | Immediate hire/termination notification |

### When to Use Each

**PECI** — The vendor requires a full-stack integration with sequential effective-dated changes. Typical for large-scale payroll providers who need complete change history. Requires grid setup and has a 250k active employee limit per pay group.

**PICOF** — The vendor needs a simpler top-of-stack extract (current state or delta). Supports CSV output. No grid required, no worker limit. Best for vendors with straightforward file-based integrations.

**WECI** — The target system needs HCM data but is not a payroll system, or contingent workers must be included. Similar change detection to PECI but not tied to payroll-specific constraints.

**DCoD (Data Changes on Demand)** — The vendor integrates via API and pulls data on demand rather than receiving scheduled file drops. Supports contingent workers.

**Event-Driven Integration** — A service within PECI that sends hire and termination data immediately via business process steps rather than waiting for the next batch run. Used when regulatory or operational requirements demand real-time notification.

---

## PECI vs PICOF Decision Checklist

Ask these questions during discovery to determine PECI vs PICOF:

| Question | If PECI | If PICOF |
|----------|---------|--------|
| Does the vendor need full effective-dated change history? | Yes | No — top-of-stack is sufficient |
| Does the vendor need to know the sequence of changes? | Yes | No |
| Is the worker population under 250k per pay group? | Yes | Population exceeds 250k or no grid available |
| Is CSV output required? | No — XML only | Yes — CSV or XML |
| Does the vendor require entry-dated vs effective-dated distinction? | Yes | No |
| Is the vendor CCTPP certified? | Required | Not required |
| Does the customer need merge across pay groups? | PECI supports this | PICOF does not |
| Does the customer need real-time hire/termination? | PECI + Event-Driven | Not available in PICOF |

---

## Other Payroll Integration Types

### Integration Command Center (ICC)

Centralised hub sending data every 15 minutes based on one-time configurations. Automates and controls payroll data extraction for prioritised transactions.

- Sends 1 worker per file, up to 100 files every 15 minutes
- Supports batch runs (1x/day) + priority runs (every 15 minutes)
- Up to 25 active ICC configurations
- **PECI integration only** — not available for PICOF
- Cannot use with: Additional Primary Integration attribute, EDI service, Merge Files

**Use when**: Multiple countries/payroll systems need prioritisation and continuous monitoring beyond daily batch runs.

### Event-Driven Integration (EDI)

Enables PECI to send hire and termination info automatically via business process steps in real-time.

- Configured on Hire and Termination business processes
- Sends future-dated hires and terminations automatically
- Sends corrections and rescinds immediately
- Vendor must build REST endpoints for delivery and retrieval
- 500 worker events/hour limit
- Does not process Mass Operation Management events

**Use when**: Regulatory compliance requires immediate payroll notification for terminations, or same-day new-hire reporting is needed.

### Payroll Interface Configurable Output

Configures PECI output as an Excel workbook instead of XML for small populations.

- For payroll administrators managing individual or small groups of workers
- Maximum 5,000 workers
- Does not support field overrides or Buy Time Off
- Create layout (sheets, event types, fields) + definition (key fields, included layouts)

**Use when**: Small non-headquarters country populations where manual entry into the payroll system is acceptable.

### Third-Party Payroll Errors Collaboration

Enables resolution of payroll errors returned by the vendor.

- Vendor uses `Put_Integration_Event_Error_Message_Set` web service to send errors back
- Errors are viewable in Maintain Errors from Third-Party Payroll report
- Configure security groups, statuses, and reasons for error tracking
- Consolidates PECI and EDI errors into one view

### Global Payroll Reconciliation

Compares and reconciles worker payroll data between Workday and the third-party system.

- Automatic identification of data discrepancies
- Supports multiple pay group reconciliation per period
- Can include terminated employees (1–5 year lookback)
- Vendor must build 3 REST endpoints: initiating, retrieval, schema
- Supported data sections: Worker Status, Personal (Legal Name), Person Communication (Address), Person Identification (National ID), Position (Organisation), Compensation (Annualised Summary), Payment Election, Employee Contract, Payroll Input E&D, Compensation OTP, Payroll OTP

---

## Cross-Cutting Patterns

### Pay Group Setup

All payroll integrations require external payroll organisation setup:

1. **Establish payroll organisation** — create external payroll organisation type, assign roles
2. **Create pay groups** — create or edit period schedule, create pay group for third-party payroll, assign to payroll company
3. **Assign workers** — assign pay group to employees
4. **Define earnings & deductions** — manage external payroll earnings (with pay groups, compensation elements, time calculation tags) and deductions

### External Codes for Earnings & Deductions

- Every earning/deduction sent to payroll needs an **external code** that maps to the vendor's code
- Configure via Maintain External Payroll Earnings / Deductions
- Associate earnings with: pay groups, compensation elements, time calculation tags
- For one-time payments: external earnings must be configured for the pay groups involved

### Time Off Patterns

Discovery questions to resolve:

| Decision | Options | Impact |
|----------|---------|--------|
| Summary granularity | Daily summary vs monthly summary | Determines data section output |
| Timing | Same period vs in arrears | Determines which period captures the data |
| Hourly/PT handling | Same as salaried vs separate logic | May need calculated fields for pro-ration |
| Corrections | Send as corrections vs resend full period | Determines change detection approach |
| Long-term leave | Continue reporting vs stop after N periods | Determines terminated worker inclusion rules |

### SAP-Specific Patterns

When the target system is SAP:

| SAP Concept | Workday Mapping Consideration |
|-------------|-------------------------------|
| Info-types | Map to PECI/PICOF data sections + field overrides |
| PA-PD configuration | If enabled, positions/orgs must be managed separately; if disabled, worker feed can create them |
| PA and OM modules | If OM enabled, need separate sync for positions, orgs, job profiles |
| Action/Action Reason | Map from Workday staffing event codes (HIR, TERM, DTA, LOA, etc.) to SAP action codes |
| Personal area/subarea | Map from Workday organisations via integration maps |
| Employee group/subgroup | Map from Workday worker type / employment status |
| Middleware | Determine if SAP imports directly or via middleware (e.g. SAP PI/PO, MuleSoft) |
| Fields not in Workday | Plan for custom fields, calculated fields, or inbound feed from SAP |

---

## Key References

- [PECI Reference](./peci-reference.md) — full PECI setup, attributes, data sections, change detection, troubleshooting
- [PICOF Reference](./picof-reference.md) — full PICOF setup, attributes, data sections, change detection, troubleshooting
- [WECI Reference](./weci-reference.md) — full WECI setup, attributes, data sections, staffing events, troubleshooting
- [DCoD Reference](./dcod-reference.md) — full DCoD setup, change detection, data sections, PECI comparison, FAQ
- [Payroll Setup and Operations](./payroll-setup-and-operations-reference.md) — third-party payroll setup, ICC, Event-Driven Integration, reconciliation, external documents/results, notifications
- [Discovery Questionnaire](../discovery-questionnaire.md) — structured discovery questions
- [Design Template Guide](../design-template-guide.md) — how to populate the design document
