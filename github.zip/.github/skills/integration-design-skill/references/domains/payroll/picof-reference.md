# PICOF Reference — Payroll Interface Connector (Output File)

Comprehensive reference for the Payroll Interface Connector, internally referred to as **PICOF**. In Workday documentation this connector appears as "Payroll Interface" (PI) under the Cloud Connect for Third-Party Payroll (CCTPP) template.

---

## Overview

PICOF is a top-of-stack, delta-based connector that extracts employee payroll data and delivers it as CSV or XML to an external payroll provider. Unlike PECI, it does not require a grid and has no hard worker limit.

**Key characteristics:**
- Top-of-stack data (current values, not full effective-dated history)
- CSV or XML output
- No grid required
- No hard worker count limit
- Delta/change detection via Transaction Log or full extract
- Requires CCTPP (Cloud Connect for Third-Party Payroll) certification
- Simpler setup than PECI — suited for file-based vendor integrations

---

## When to Use PICOF

- Vendor accepts flat-file (CSV) payroll feeds
- Only current (top-of-stack) values needed — no effective-dated history
- No grid is available or wanted
- Large populations where PECI grid limit (250k) is a constraint
- Simple file-based integration with minimal transformation
- Vendor does not need entry-dated vs effective-dated distinction

**Do NOT use PICOF when:**
- Vendor requires full effective-dated stack (use PECI)
- Contingent workers must be included (use WECI)
- Real-time event-driven integration is needed (use PECI + EDI)
- Merge files across pay groups is needed (use PECI)

---

## Setup Prerequisites

1. Engage Workday Professional Services or Consulting Partner
2. Set up payroll organisations
3. Create and assign third-party payroll pay groups
4. Define external payroll earnings/deductions

## Setup Steps

1. Access Create Integration System → select "Cloud Connect for Third Party Payroll > Payroll Interface"
2. Enable required and optional integration services
3. Grant ISU Get + Put access to required domains
4. Configure Transaction Log service (subscribe to transaction types)
5. Select fields for payroll extract (per data section)
6. Configure Integration Attributes and Maps
7. Set Up Integration Delivery (enable PI Delivery Service first)
8. (Optional) Set Up Integration Sequence Generators (unique filenames)
9. (Optional) Add Custom Fields to Payroll Integration
10. (Optional) Document transformation
11. Access Maintain Functional Areas → enable USA Payroll functional area
12. (Optional) Launch/Schedule Payroll Integration

---

## Security Requirements

| Domain | Purpose |
|--------|---------|
| Integration Build | Create and configure PICOF integration |
| Set Up: Payroll Interface | Configure payroll interface settings |
| Person Data: Personal Data | Unconstrained access for person data extraction |
| Person Data: Birth Place, Citizenship Status, Disabilities, Ethnicity, Gender, ID Information, Marital Status, Military Status, Nationalities, Religion | Individual person data domains |
| View: External Pay Groups | View pay group configuration |
| Worker Data: Benefit Elections, Compensation, Payees, Skills and Experience | Worker data extraction |
| Manage: Organisation Update Integration, Organisation Integration | Organisation data |

---

## Required Integration Services

These services must be enabled for PICOF to function:

| Service | Purpose |
|---------|---------|
| **Payroll Interface** | Core connector service |
| **PI Launch Parameters** | Launch parameter configuration |
| **Payroll Effective Change Interface - Summary DIS** | Summary data information service |
| **Transaction Log Service** | Change detection (not enabled by default — must enable manually) |

---

## Optional Integration Services

PICOF supports 30+ optional services controlling which data sections appear in output:

### Data Section Services

| Service | Data Included |
|---------|--------------|
| PI Personal Data Section Fields | Employee personal/contact information |
| PI Status Data Section Fields | Employment status + service dates |
| PI Position Data Section Fields | Job profile, salary, base compensation, org membership |
| PI Compensation Data Section Fields | Worker compensation |
| PI Allowance Plan Data Section Fields | Allowance plan details |
| PI Commission Plan Data Section Fields | Commission plan details |
| PI Period Salary Plan Data Section Fields | Period salary details |
| PI Unit Salary Plan Data Section Fields | Unit salary details |
| PI Salary & Hourly Plan Data Section Fields | Salary & hourly plan details |
| PI Bonus Plan Data Section Fields | Bonus plan details |
| PI Contract Data Section Fields | Employee contract data |
| PI Collective Agreement Data Section Fields | Collective agreement data |
| PI Job History Data Section Fields | Job history |
| PI Education Data Section Fields | Education data |
| PI Leave of Absence Data Section Fields | Leave of absence data |
| PI Earnings and Deductions Section Fields | Earnings/deductions for compensation + benefits + multi-period payroll input |
| PI T1 Tax Section Fields | Canadian federal tax elections |
| PI W4 Tax Section Fields | U.S. federal tax elections |
| PI Identifiers Section Fields | National/government/visa/passport/licence/other IDs |
| PI Payment Elections Section Fields | Payment election data |
| PI Pay Data Section Fields | One-time payments |
| PI Paid Time Off Section Fields | Paid time off data |
| PI Time Off Correction Section Fields | Time off corrections |
| PI Related Person Section Fields | Dependent/beneficiary/emergency contact |
| PI Related Person Identifier Section Fields | Related person IDs |
| PI Cost Allocations Section Fields | Cost allocation data |
| Time Tracking Data | Time tracking entries |
| Time Tracking Correction Data | Time tracking corrections |

### Delivery & File Services

| Service | Purpose |
|---------|---------|
| PI Delivery Service | File transport + encryption options |
| PI Filename Sequence Generator | Unique sequence filenames for output |
| PI Data Changes Audit Filename | Sequence filenames for audit |
| PI Diagnostic Audit Filename | Sequence filenames for diagnostic audit |
| PI Members Launch Parameters | Pay group member inclusion/exclusion for ad hoc runs |
| PI Change Detection Launch Parameters | Ad hoc change detection options |
| PI Full Extract With No Diff | Full extract of all active/terminated employees regardless of changes (seeds external system) |

---

## Field Configuration

After enabling data section services, configure individual fields per section:

1. View Integration System
2. Related actions → Configure Integration Field Attributes
3. For each field, set:
   - **Include in Output**: include field in output file
   - **Required Field**: field must contain a value (generates error/warning if missing)
   - **Maximum Length**: length limit (truncates if exceeded)
   - **Operation**: required in Position Data, T1 Tax, W4 Tax, Identifiers, Payment Elections sections — indicates new/changed/deleted

---

## Integration Attributes

### Output & File Control

| Attribute | Values/Description | Default |
|-----------|-------------------|---------|
| Output Format | XML or CSV | XML |
| Version | Connector version number | Current Workday version |
| Document Retention Policy | 30, 60, 90, 120, 180 days | 30 |
| Output Document Tags | Free text appended to output file | |
| Audit Document Tags | Tags for DataChangesAudit.html + DiagnosticAudit.html | |

### Data Format

| Attribute | Values/Description | Default |
|-----------|-------------------|---------|
| Date Format | XSLT-supported date format | `[Y0001]-[M01]-[D01]` |
| Date Time Format | XSLT-supported datetime format | `[Y0001]-[M01]-[D01]T[H01]:[m01]:[s01]` |
| Country Code | Country code type in output | ISO standard |
| Phone Number Parsing | Parsed (calculated) or Unparsed (as entered) | Parsed |
| Phone Number Format | Format string for phone output | |
| Use Preferred Name when present | Use Preferred Name instead of Legal Name | Yes |
| Use Address in Local Script | Include local address fields | No (Western) |
| Name Type for Maiden Name | Name type for maiden name fields | |

### Validation

| Attribute | Values/Description | Default |
|-----------|-------------------|---------|
| Required Field Validation | Include (warnings) / Omit - Report Warning / Abort | Include |
| Max Field Length Validation | Include (truncate) / Omit - Report Warning / Abort | Include |
| National ID Required | Require 1+ national identifier per worker | Disabled |

### Population & Scope

| Attribute | Values/Description | Default |
|-----------|-------------------|---------|
| Payroll Country | Country of residence (reporting only) | |
| Payroll Vendor | Vendor name (reporting only) | |
| Payroll Vendor, if Other selected | Free text vendor name if not in list | |
| Payroll Company Organisation Type | Org type identifying payroll company (required if pay group in multiple orgs) | |
| Organisation Type for ORG Event | Org type generating ORG staffing event when employee changes orgs but not pay groups | |
| Return Only Primary Position | Report primary positions only + primary within past 12 months | |
| Primary Payroll Integration | Scheduled (Primary) vs ad hoc runs | |

### Change Detection

| Attribute | Values/Description | Default |
|-----------|-------------------|---------|
| Extract All Payee Data | Extract configured sections with annotations; no deletions without Operation field. Cannot use with Transaction Log | Disabled |
| Include Prior Values | Include prior values alongside current (XML format only) | Disabled |
| Period Look Ahead All Effective Lookup | Include workers with specified status within look-ahead days after period end | Disabled |
| Period Look Ahead Days | Whole days after period end to detect future payee changes | |
| Period Look Ahead Payee Status | Payee status values for look-ahead | |
| Pay Group Transfer Staffing Event Precedence | PCI/PCO/PGI/PGO takes precedence over LOA/RFL (default: leave precedence) | Leave precedence |

### Address & Contact

| Attribute | Values/Description | Default |
|-----------|-------------------|---------|
| First/Second Address Type | Home or Work | |
| First/Second Address Usage | Address usage type | |
| Communications Usage Type for Phone | Phone usage type | |
| Communications Usage Type for First/Second Email | Email usage type | |
| Countries which Require Extended Address Type | Countries requiring extended addresses | |
| Restrict Addresses to These Countries | Valid countries for addresses | |

### Organisation

| Attribute | Values/Description | Default |
|-----------|-------------------|---------|
| Organisation Type for Organisation One/Two/Three/Four/Five | Organisation type (e.g., Cost Centre, Region) | |
| Organisation Default Value Type | Default for unmapped organisations | |
| Job Classification Group for Job Classification One/Two/Three | Job classification group type | |

### Data Section Inclusion

These attributes control when data sections are included in output.

| Attribute | Options |
|-----------|---------|
| Include Personal Data Section | Always / Include only when changed |
| Include Status Data Section | Always / Include only when changed |
| Include Position Data Section | Always / Include only when changed |
| Include Compensation Data Section | Always / Include only when changed |
| Include Earnings and Deductions Section | Always / Include only when changed |
| Include Identifiers Section | Always / Include only when changed |
| Include Leave of Absence Section | Always / Include only when changed |
| Include Paid Time Off Section | Always / Include only when changed |
| Include Pay Data Section | Always / Include only when changed |
| Include Payment Elections Section | Always / Include only when changed |
| Include Contract Section | Always / Include only when changed |
| Include Job History Section | Always / Include only when changed |
| Include Education Section | Always / Include only when changed |
| Include T1 Tax Section | Always / Include only when changed |
| Include W4 Tax Section | Always / Include only when changed |
| Include Related Person Section | Always / Include only when changed |
| Include Cost Allocations Section | Always / Include only when changed |
| Include Time Tracking Data Section | Always / Include only when changed |

Additional options for Leave of Absence: "Include only leave that affects payroll" (default: Yes)

### Performance

| Attribute | Purpose |
|-----------|---------|
| Suppress Worker Messages Audit | Skip worker details in Messages Audit for large runs |
| Suppress Audit Files | Skip Data Changes + Diagnostic Audit generation for large runs |

### Benefits & Compensation

| Attribute | Values/Description |
|-----------|-------------------|
| Calculate Benefits as of Pay Check Date | Calculate based on pay check date vs period end |
| Enable Employee Contracts for Terminated and Rehired Employees | Include contracts for terminated/rehired workers |
| Worktag Type for Costing Worktag One/Two | Cost Centre or Region |
| Time Tracking Reporting Interval | Per-day or per-pay period |

---

## Integration Maps

Maps convert Workday tenant values to external (vendor) values.

**Configuration:**
1. View Integration System → Related actions → Configure Integration Maps
2. Add rows: Internal Value → External Value; optional Default Value

**Map Rules:**
- Map with 1+ rows: uses map to convert; unmapped values use default or generate error/warning
- Empty map: uses reference IDs (exception: Region uses region name); unmapped values generate error/warning
- Maps apply to specific data fields (e.g., Gender, Marital Status, Country, State/Region)

---

## Transaction Log Configuration

The Transaction Log is critical for change detection in PICOF.

**Setup:**
1. Related actions → Configure Integration Transaction Log
2. Select "Subscribe to all Transaction Types except" and specify exclusions (recommended)
3. Or select specific transaction types to subscribe to

**Behaviour:**
- Only worker-level events trigger review
- Does not detect indirect changes (e.g., cost centre name change) unless a direct qualifying transaction exists
- Recommend enabling for performance on large populations

**Without Transaction Log:** PICOF scans all workers for changes — slower on large populations.

---

## Custom Fields

Add custom calculated fields to any data section:

1. View Integration System → Related actions → Configure Integration Custom Fields
2. Select data section
3. Add calculated field
4. Configure field attributes (Include in Output, Required, Max Length)

**Note:** Calculated fields with >8 hierarchy levels may impact performance.

---

## Change Detection

### Methods

**1. Transaction Log (recommended)**
- Subscribes to business process events
- Flags workers with qualifying transactions for review
- Only reviews flagged workers — better performance
- Does not detect indirect changes without a qualifying direct transaction

**2. Extract All Payee Data (alternative)**
- Extracts all configured sections with annotations
- Does not extract deletions without the Operation field
- Cannot be used simultaneously with Transaction Log

**3. Full Extract With No Diff (seeding)**
- Extracts all active and terminated employees as of current date/period end
- Ignores change detection entirely
- Used to seed the external payroll system with initial data

### Period Look-Ahead

Configure look-ahead to detect future changes:
- Set **Period Look Ahead Days** (whole days after period end)
- Set **Period Look Ahead Payee Status** (which statuses to detect)
- Optionally enable **Period Look Ahead All Effective Lookup** to include workers with matching status within the look-ahead window

**Caution:** Look-ahead may over-report changes.

---

## Staffing Event Codes

PICOF uses the same staffing event codes as PECI:

| Code | Definition |
|------|-----------|
| **HIR** | New hire into pay group |
| **TERM** | Termination (active → terminated) |
| **DTA** | Other data changes |
| **LOA** | On leave of absence |
| **RFL** | Return from leave |
| **PCI** | Transfer TO this pay group from different payroll company |
| **PCO** | Transfer FROM this pay group to different payroll company |
| **PGI** | Transfer TO this pay group within same company |
| **PGO** | Transfer FROM this pay group within same company |
| **ORG** | Organisation change without pay group change |

### Key Differences from PECI

- PICOF does not support correction event codes (HIR-C, TERM-C, LOA-C, RFL-R) — corrections appear as DTA
- PICOF reports top-of-stack values; corrections replace the existing value rather than showing correction history
- Pay Group Transfer Staffing Event Precedence attribute controls whether transfer events take precedence over LOA/RFL

---

## Multiple Positions

- By default, PICOF reports all positions for multi-position workers
- Use **Return Only Primary Position** attribute to limit to primary positions only (+ primary within past 12 months)
- For pay group transfers with multiple positions: first position generates PCI, subsequent additional jobs do not generate separate staffing events

---

## Output Format

### XML Output
- Default format
- Supports **Include Prior Values** attribute (shows old + new values)
- Supports all data sections and field configurations

### CSV Output
- Flat-file format suitable for direct vendor import
- Does not support Include Prior Values
- Column order matches field configuration order
- Header row included by default

---

## Delivery Configuration

Requires **PI Delivery Service** enabled.

**Transport options:**
- SFTP
- FTPS
- PGP encryption
- Document transformation (post-processing)

**Sequence generators** (optional):
- PI Filename — unique output file names
- PI Data Changes Audit Filename — unique audit file names
- PI Diagnostic Audit Filename — unique diagnostic file names

---

## Comparison: PICOF vs PECI

| Aspect | PICOF | PECI |
|--------|-------|------|
| Data model | Top-of-stack (current values) | Full effective-dated stack |
| Output format | CSV or XML | XML only |
| Grid required | No | Yes |
| Worker limit | No hard limit | 250,000 per pay group |
| Change detection | Transaction Log or full extract | Transaction Log + LSRD-based |
| Merge files | Not supported | Supported |
| Event-Driven Integration | Not supported | Supported |
| Effective Stack Sync | Not supported | Supported |
| Integration Command Centre | Not supported | Supported |
| Prior values | XML only (attribute) | Built into effective stack |
| Correction events | Appear as DTA | Dedicated codes (HIR-C, TERM-C, etc.) |
| Entry-dated vs effective-dated | Not distinguished | Distinguished |
| Configurable Output (Excel) | Not supported | Supported (≤5,000 workers) |
| Reconciliation | Not supported | Supported |
| Complexity | Lower | Higher |
| Setup time | Shorter | Longer |

---

## Payee Validation

PICOF validates workers during extraction:

- **Required Field Validation**: If a required field is missing, behaviour depends on attribute setting:
  - Include (default): warning generated, worker included
  - Omit - Report Warning: warning generated, worker excluded
  - Abort: error generated, integration aborts

- **Max Length Validation**: If field exceeds maximum length:
  - Include (default): warning generated, field truncated, worker included
  - Omit - Report Warning: warning generated, worker excluded
  - Abort: error generated, integration aborts

- **National ID Required**: If enabled and worker has no national identifier, generates error/warning per validation setting

---

## Limitations

- No full effective-dated history (top-of-stack only)
- No merge file support across pay groups
- No Event-Driven Integration (EDI)
- No Integration Command Centre (ICC) support
- No Effective Stack Sync service
- No reconciliation support
- No configurable output (Excel) support
- CSV output does not support prior values
- No contingent workers
- No Buy Time Off support
- Extract All Payee Data cannot be used with Transaction Log simultaneously

---

## Troubleshooting

### Common Issues

| Issue | Cause | Solution |
|-------|-------|----------|
| No changes detected | Transaction Log not enabled | Enable Transaction Log service; configure transaction type subscriptions |
| Missing data sections in output | Data section service not enabled | Enable the corresponding PI data section service |
| Missing fields in data section | Field not configured for output | Configure Integration Field Attributes → set Include in Output |
| Workers excluded unexpectedly | Required field validation set to Omit or Abort | Check Required Field Validation attribute; verify required fields are populated |
| Truncated field values | Max length configured and exceeded | Increase Maximum Length or set Max Field Length Validation to Omit |
| Indirect changes not detected | Transaction Log only detects direct worker events | Direct qualifying transaction must exist; consider periodic full extract |
| Unmapped values causing errors | Integration map has no matching row or default | Add map rows or configure default value |
| Prior values not appearing | Output format is CSV or Include Prior Values disabled | Switch to XML output; enable Include Prior Values attribute |
| Organisation not appearing | Organisation Type not configured | Set Organisation Type for Organisation One/Two/etc. attribute |
| Performance issues on large population | Transaction Log not enabled, scanning all workers | Enable Transaction Log; suppress audit files for large runs |

### Performance Recommendations

- Enable Transaction Log for populations >10,000 workers
- Use Suppress Worker Messages Audit for large runs
- Use Suppress Audit Files for very large runs
- Avoid calculated fields with >8 hierarchy levels
- Use Return Only Primary Position if multi-position reporting is not needed
