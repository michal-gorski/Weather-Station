# Payroll Setup and Operations Reference

This reference covers the supporting infrastructure around Workday's third-party payroll interfaces — the setup, operations, and supporting integrations needed regardless of which interface (PECI, PICOF, or EDI) you use.

For core interface references, see:
- `peci-reference.md` — deep PECI reference
- `picof-reference.md` — deep PICOF reference
- `payroll-integration-guide.md` — selection matrix and pay group patterns

---

## Third-Party Payroll Setup

### Organisation Setup

Before creating pay groups, establish a payroll organisation hierarchy:

1. **Create External Payroll Organisation Type** — use Maintain Organisation Types; set Organisation Subtype to "Pay Group"; enable "Allows Hierarchy" if nesting payroll companies
2. **Assign Roles** — add Payroll Interface Partner and Payroll Partner roles to the organisation type via Maintain Assignable Roles
3. **Create Reorganisation** — establishes the effective date for the payroll organisation structure
4. **Create External Payroll Company** — one per external payroll company; match names between Workday and the external system
5. **(Optional) Create Superior Organisations** — roll up multiple payroll companies under a common integration system

**Key decisions:**
- The payroll company determines transfer logic — without it, Workday cannot infer whether a pay group transfer crosses company boundaries
- Set the Reference ID on the payroll company to match the external system's company code
- A single integration system can support multiple payroll companies if the external system processes them the same way

### Pay Group Setup

| Step | Detail |
|------|--------|
| Create Period Schedule | Define pay frequency, start/end dates, payment dates for each period in a calendar year |
| Set Up Pay Run Category | Select "Use in Payroll Interface"; optionally enable state supplemental flat tax rate |
| Create Pay Group | One per group of employees sharing a pay frequency; reference ID must concatenate name and ID |
| Assign Pay Group to Payroll Company | Link pay groups to the correct payroll company |
| Assign Pay Group to Employee | Via staffing events or direct assignment |
| Maintain External Pay Period Status | Set pay period selection option (Earliest Open or Current Date) |
| (Optional) Manage Payroll Integration System for Pay Group | Associate the primary integration system |

**Period schedule considerations:**
- Ensure at least one period exists before the effective date of your first Workday transactions
- Payment Date Offset Days Default auto-calculates payment dates relative to period end
- Settlement Date Overrides allow country-specific payment dates for different bank schedules
- Update the period schedule every calendar year

### Earnings and Deductions

Define external earnings and deductions for your pay groups. If pay groups share earning/deduction codes in the external system, you can assign multiple pay groups to a single earning or deduction.

- Use Maintain External Payroll Earnings and Maintain External Payroll Deductions tasks
- Each earning/deduction requires: Name, Code, associated Pay Groups, and Compensation Elements
- The external payroll code maps Workday compensation elements to the vendor's codes
- Override frequencies are optional — defaults to the pay group frequency

### External Vendor Mapping and Associations

**Vendor Mapping** links your Workday tenants to the external payroll vendor:
- Create a separate mapping per Workday environment
- Assign an x509 private key pair to each mapping (select "Do Not Allow Regeneration")
- Configure feature-specific attributes (endpoints, ISUs) on the Feature Configuration grid

**Pay Group Vendor Associations** link pay groups to specific vendor features:
- Use Maintain Pay Group Vendor Associations task
- Select the vendor, feature, pay groups, and payroll organisation type
- A single pay group cannot be mapped to multiple external payroll vendors

---

## Global Payroll Hub

### What It Is

The Global Payroll Hub (GPH) provides a centralised view for processing payroll and performing time-sensitive actions on vendor-provided payroll data across multiple countries and vendors simultaneously.

### Capabilities

- View all external pay groups you manage across pay vendors
- View payroll status, employee counts, and total payment breakdowns per period
- Drill into current, previous, next, and off-cycle pay periods
- Analyse variances between current and previous periods (gross/net)
- Manage checklists, comments, and attachments for payroll processing
- Approve payroll and access third-party payroll tasks (e.g. running calculations)

### Setup Checklist

1. (Optional) Create External Payroll Vendor — only required if vendor is not a preconfigured partner (ADP Celergo, ADP GlobalView, CloudPay, Payslip, PwC, Strada Global)
2. Create External Payroll Vendor Mapping — map environment to vendor; configure GPH feature endpoints
3. Maintain Pay Group Vendor Associations — associate pay groups with the Global Payroll Hub feature
4. Configure Home Page Content — add the Global Payroll Hub worklet
5. Configure security:
   - Manage: Global Payroll Processing domain (Global Payroll Connect) — for actions on payroll data
   - View: Global Payroll Hub domain (Global Payroll Connect) — for user access

### When to Use

- You use one or more third-party payroll vendors across multiple countries
- You want a single interface to monitor payroll status without logging into each vendor system
- Your vendor must build REST APIs for the landing page data display

---

## Integration Command Center (ICC)

### What It Is

The Payroll Interface Integration Command Center automates and controls data extraction and transfer to external systems. It provides:
- Priority runs every 15 minutes for specific transaction types
- Batch runs on a configurable daily schedule
- A centralised data queue for monitoring and prioritisation

### Setup Steps

1. Stop existing scheduled PECI batch runs for the integration
2. Enable integration subscriptions (Edit Tenant Setup - Integrations)
3. Configure PECI integration:
   - Enable integration attribute: **Enable Data Changes Audit for Faceted Search**
   - Enable integration service: **Payroll Interface Integration Command Center**
4. Create a dedicated ISU for the Queue Populator integration (separate from the PECI ISU)
5. Configure ICC (Create Payroll Interface Integration Command Center Configuration):
   - Select PECI integration system
   - Define pay groups
   - Set transaction type priorities
   - Configure batch schedule
6. (Optional) Configure Data Transferring Activity — schedule downtime windows when the vendor cannot accept data

### Batch vs Priority Runs

| Aspect | Batch Run | Priority Run |
|--------|-----------|--------------|
| Frequency | Once per day (scheduled) | Every 15 minutes |
| Output | One file per pay group | One worker per file |
| Volume | Full change detection | Top 100 workers (highest priority) across all configurations |
| Use case | Regular payroll processing | Time-sensitive events (e.g. time-offs, urgent terminations) |

### Limits and Constraints

- Maximum 25 active ICC configurations
- Priority runs send up to 100 workers every 15 minutes
- Only works with PECI integrations
- Does not support: Additional Primary Integration attribute, EDI service, or Merge Files Launch Parameters service
- If monitoring Hire transactions, the Assign Pay Group step must be at or before the Completion step

---

## Event-Driven Integration (EDI)

### What It Is

An integration service enabled on PECI that sends hire and termination information to an external payroll vendor immediately after business process completion, rather than waiting for the next scheduled batch run.

### Business Process Flow

1. Hire or Termination business process completes
2. Workday transmits employee data to the vendor's delivery endpoint
3. Vendor validates and processes the data
4. Vendor sends processing status back via REST API
5. Review step owner receives success confirmation or errors to correct in My Tasks

### Setup Steps

1. Verify primary integration system for pay group is a PECI connector (Maintain Payroll Integration Systems for Pay Group)
2. Enable PECI service: **Payroll Effective Change Interface - Event Driven Integration for Third Party Payroll**
3. Configure integration attributes: External Payroll Vendor, Pay Period Selection Option, PGP Public Key
4. Create External Payroll Vendor Mapping — configure Delivery Endpoint and Retrieval Endpoint
5. Add business process steps:
   - Hire: Add "Transmit Employee Data to Third Party Payroll" after Assign Pay Group and after Completion
   - Termination: Add after Completion
6. Configure REST API client for vendor response (OAuth 2.0, Non-Expiring Refresh Token, Payroll Interface scope)
7. Share Client ID, Client Secret, Refresh Token, and endpoints with vendor

### Corrections and Rescinds

- EDI supports corrections to hire and termination events
- Vendor response indicates success or returns errors
- Errors are visible in Maintain Errors from Third-Party Payroll and Workers Not Processed by PECI Events reports

### Limits

- Primary PECI integration will not pick up changes for a worker while an EDI event is in progress
- Maximum 500 worker events per hour through EDI
- Does not process events from Mass Operation Management tasks
- Does not pick up future new hires beyond the current period
- Future-dated transactions can be skipped via condition rules using "Is Event Driven Integration Transaction Future Effective"

---

## Configurable Output

### What It Is

An integration service on PECI that produces an Excel workbook of effective payroll changes, designed for manual data entry into third-party payroll systems for small populations.

### When to Use

- Small employee populations (fewer than 5,000 workers)
- Manual payroll entry into downstream systems
- Reviewing payroll changes in a non-XML format
- Non-headquarter countries with small worker counts

### Setup Steps

1. Enable Payroll Interface Configurable Output integration service on PECI
2. Create a Payroll Interface Configurable Output Layout (defines sheet content — data sections, event types, fields)
3. Create a Payroll Interface Configurable Output Definition
4. Create a separate Payroll Interface Configurable Output integration system per pay group
5. Configure integration attributes: Input Document Tags (matching pay group), Output Definition
6. Add an integration step on the PECI business process (after Fire Integration) to launch the configurable output system
7. Launch PECI — Excel file is attached to the integration event

### Limitations

- Maximum 5,000 workers per output
- Does not support field overrides
- Does not support Buy Time Off
- Label names must be under 31 characters and cannot contain `: \ / ? * [ ]`

---

## Notifications

### Event Outbound Notifications

Sends notifications from Workday to external payroll systems after hire or termination events occur. Supports corrections and rescinds.

**Setup:**
1. Enable integration subscriptions (Edit Tenant Setup - Integrations)
2. Create ISU with access to Business Process Administration, Integration Event, and Integration Process domains
3. Create Integration System using the Event Outbound Notifications template (one system only, regardless of number of vendors)
4. Set Up Integration Subscriptions:
   - Subscribe to: Hire - Hire Employee Event and Termination - Terminate Employee Event
   - Subscribe to Rescind Business Process Type
   - Configure Launch Integration with ISU and integration criteria
5. Create External Payroll Vendor Mapping — configure Event Outbound Notifications feature with Worker Event Types and Delivery Endpoint attributes
6. Maintain Pay Group Vendor Associations — associate pay groups with the Event Outbound Notifications feature

**Notification payload** includes: transaction timestamps, business process type, worker ID, transaction log reference, and organisation details.

### Inbound Notifications

Enables third-party vendors to send custom notification messages to specific workers or role groups within Workday via REST API.

**Setup:**
1. Create ISU with View, Modify, and Get access to Manage: Global Payroll Inbound Notifications domain
2. Activate security policy changes
3. Register API Client (OAuth 2.0) with Integration and Global Payroll Connect scopes
4. (Optional) Create External Payroll Vendor with Inbound Notifications feature
5. Create External Payroll Vendor Mapping — configure ISU on the Feature Configuration grid

**Routing:** When sending notifications for Additional Payroll Data, specify Feature properties (PayGroup, ActedOnUser) and a valid pay group with a vendor association to that feature.

**Recipients:** Notifications can target organisation recipients (by role) or specific worker recipients. Messages support translations for multiple languages.

---

## Additional Payroll Data

### Concept

Enables sending country-specific payroll data from Workday to a third-party vendor without persisting the data in Workday. Workers and administrators enter data through Workday; the vendor validates it, stores it, and returns the forms/fields to display.

The vendor controls: validations, field names and options, whether records can be added/edited/deleted, attachment support, and PDF preview availability.

### Setup

1. Configure security policies for Self-Service and Worker Data domains (Payroll Interface - Additional Payroll Data)
2. Create External Payroll Vendor Mapping
3. Maintain Pay Group Vendor Associations (feature: Additional Payroll Data)
4. (Optional) Add Additional Payroll Data report to the Pay worker profile group
5. (Optional) Create Maintain Additional Payroll Data business process definition
6. (Optional) Add Maintain Additional Payroll Data action step to relevant business processes (Hire, Change Job, Termination, etc.)

### Attachments

Vendor determines: maximum file count, whether attachment is required, and whether delete is permitted.

Supported file types: CSV, DOC, DOCX, JPG, JPEG, PDF, PNG.

**Important:** For new workers, run the certified payroll integration before entering additional payroll data to ensure the worker exists in the vendor's system.

---

## Local Payroll Data

> **Note:** Workday plans to retire Local Payroll Data. Migrate to the Additional Payroll Data feature.

### Concept

Similar to Additional Payroll Data but limited to payroll administrators (no employee self-service). Sends local payroll data to a vendor; the vendor returns forms/fields for data entry. Data does not persist in Workday.

### Setup

1. Create External Payroll Vendor (select Local Payroll Data feature)
2. Create External Payroll Vendor Mapping
3. Maintain Pay Group Vendor Associations
4. (Optional) Add Local Payroll Data report to Pay for Worker Profile
5. (Optional) Add Maintain Local Payroll Data action step to business processes

### Key Differences from Additional Payroll Data

- No employee self-service support
- Being retired in favour of Additional Payroll Data
- If you have an existing Maintain Local Payroll Data step, remove it before adding the Maintain Additional Payroll Data step

---

## External Payroll Documents and Results

### External Payroll Documents

Import payslips, tax documents, and other payroll documents from an external payroll system into Workday.

**Document types:**
- External Payslips (displayed on Payslips tab)
- External Tax Documents (displayed on Tax Documents tab)
- Other External Payroll Documents — custom types you define (displayed on Additional Documents tab)

**Import methods:**
- Import External Payroll Document web service
- Import External Payslips integration (template-based, retrieves from SFTP)
- External Payslips REST API (real-time retrieval from vendor)
- External Tax Documents REST API (real-time retrieval from vendor)

**File limits:**
- Individual attachment: max 2.5 MB (600 KB for Import External Payslips)
- Manifest or archive ZIP: max 30 MB (1 GB for Import External Payslips)
- Up to 199,999 documents per batch ID
- Combined limit of 1,000 external tax documents + other documents per worker
- Payslips uploaded up to 7 years before current pay period end date

**Manifest file format:** CSV or XML. Each payslip requires a unique combination of worker, pay group, pay period end date, payment date, and check number.

### External Payroll Results Inbound

Imports payroll results (earnings, deductions, net/gross pay) from an external payroll vendor into Workday in CSV or XML format.

**Setup:**
1. Create Integration System (template: External Payroll Results Inbound)
2. Configure integration attributes (file format, date format, vendor, document retention)
3. (Optional) Configure integration maps for earning/deduction/pay group code translation
4. (Optional) Configure sequence generators for batch IDs
5. Set up document retrieval from SFTP
6. Create ISU with access to Integration Event, Set Up: Payroll Interface, and View: External Pay Groups domains
7. Launch integration

**After import:** Enable self-service so employees/managers can view results on the Pay tab of the worker profile.

### Callback Pattern

Sends a callback message to the vendor when Workday completes an import of external payroll documents or results.

**Setup:**
1. Create ISU with Get and Put access to Background Process Management, Set Up: Payroll, Payroll Interface domains
2. Create External Payroll Vendor Mapping — select Callback feature, configure ISU attribute

### External Payslips REST API

Workday calls a vendor-managed REST API in real-time to retrieve payslips for workers in mapped pay groups.

**Key points:**
- Vendor builds and hosts the REST endpoint
- Workday does not store the payslips — retrieves on demand
- Can coexist with imported historical payslips (enable "historical external payslips")
- Setup: Create vendor, map to endpoint, associate pay groups, configure security

### External Tax Documents REST API

Workday calls a vendor endpoint in real-time to retrieve tax documents.

**Key points:**
- Vendor returns: year, document_type, date, URL (for PDF), and optional organisation details
- Documents display in the External Tax Documents section of the worker profile
- Workday does not persist the documents
- Setup: Create vendor (feature: REST API External Tax Documents), map retrieval endpoint, associate pay groups

---

## Global Payroll Reconciliation

### Concept

Compares worker data between a PECI integration output and a third-party payroll system to identify discrepancies. Produces a reconciliation report showing:
- Employees missing in either system
- Field-level discrepancies (classified as Errors or Informational)

### REST Endpoints Required

For vendors other than ADP GlobalView, you or your vendor must build three REST endpoints:
1. **Initiating endpoint** — receives reconciliation parameters from Workday
2. **Retrieval endpoint** — Workday picks up vendor data
3. **Schema endpoint** — declares which fields the vendor supports for reconciliation

### Setup Steps

1. (Optional) Create External Payroll Vendor with Global Payroll Reconciliation feature
2. Create External Payroll Vendor Mapping — configure endpoints, polling frequency, vendor date format
3. Create Integration System (template: Global Payroll Reconciliation)
4. Configure integration attributes: Allowable Difference Due to Rounding, Number of Years to Include Terminated Employees
5. Set Up Information to Reconcile — select fields from PECI, choose comparison options (Daily vs Period End Date, Exact Match vs At Least One Match, Error vs Informational)
6. Configure business process steps and security for reconciliation notifications
7. Create ISU with access to Integration Process and Set Up: Payroll Interface domains
8. (Optional) Create Document Transformation integration system for data transformation rules
9. Launch integration — select pay groups, PECI integration, and options

### Comparison Options

| Option | Description |
|--------|-------------|
| Daily | For fields where exact date of change impacts calculations (e.g. compensation) |
| Period End Date | For fields that don't impact calculations (e.g. business title) |
| Exact Match | Discrepancy if any data in any instance doesn't match |
| At Least One Match | Discrepancy only if no instances match (for multi-instance sections) |
| Error | Treated as a discrepancy requiring resolution |
| Informational | Logged but not flagged for mandatory resolution |

### Administration

After reconciliation runs, assign discrepancies for resolution:
- Define statuses (Complete, Ignore, In Progress, Not Yet Started) via Maintain Global Payroll Statuses
- Define reasons via Maintain Global Payroll Reasons
- Assign items to authorised resolvers via the reconciliation results report

---

## Third-Party Payroll Errors Collaboration

### Concept

Enables tracking, assigning, and resolving payroll errors returned by your third-party vendor for PECI and Event-Driven Integration runs.

### Error Flow

1. Third-party vendor processes data from PECI or EDI
2. Vendor calls `Put_Integration_Event_Error_Message_Set` on the Payroll_Interface web service to report errors
3. Errors appear in:
   - **Maintain Errors from Third-Party Payroll** task (consolidated view)
   - **Third-Party Payroll Errors** report (customisable)
   - **External Payroll Response for Integration Events** report (success/error/no results)
4. Administrators assign errors to authorised resolvers (filtered by severity, worker, date)
5. Assignees receive notifications and resolve errors via My Assigned Third-Party Payroll Errors

### Setup

1. Configure security domains:
   - Set Up: Payroll Interface — for web service and status/reason configuration
   - Manage: External Payroll Errors — for administrators who assign errors
   - Process: External Payroll Errors — for resolvers who fix errors
2. Maintain Global Payroll Statuses (feature: Third-Party Payroll Errors) — map custom statuses to Workday statuses (Complete, In Progress, Not Yet Started)
3. Maintain Global Payroll Reasons — create tracking reasons
4. Configure Global Payroll Notifications — notify role holders when errors are available

### Assignment Workflow

- Assign errors to members of security groups with Process: External Payroll Errors access
- Set due dates, statuses, and comments
- Assignees receive "Third-Party Payroll Errors: Assigned to me" notification
- History and Comments tabs track all updates

---

## Global Payroll Results

### What It Returns

Global Payroll Results reports combine payroll results from both Workday Payroll and third-party systems into a single view. They enable analysis of global payroll costs across all pay groups.

### Setup

1. Set up and run an External Payroll Results Inbound integration (imports third-party results)
2. Create Global Payroll Reporting Groups (Maintain Global Payroll Reporting Groups task) — associate comparable Workday and external pay components/groups

### Available Reports

| Report | Description |
|--------|-------------|
| View Global Payroll Results | Comprehensive view of Workday and external results for selected organisations/employees |
| Global Payroll Results Number of Employees by Pay Group | Employee count with results for a specified period |
| Global Payroll Results Average Cost for Pay Component | Average cost per employee by component over time |
| Global Payroll Results Variant by Pay Component | Compares pay component values across two pay periods |
| Global Payroll Results Variant by Worker | Compares pay component values per worker across two periods |

All reports support currency conversion to a specified currency (uses conversion rate on report date if no date specified).

---

## Quick Reference: Security Domains

| Feature | Key Domains | Functional Area |
|---------|-------------|-----------------|
| Pay group setup | Set Up: Payroll Interface | Payroll Interface |
| Organisation setup | Set Up: Payroll Interface; Create: Custom Organisation | Payroll Interface; Organisations and Roles |
| ICC | Integration Build/Debug/Event; Set Up: Payroll Interface; Manage: ICC Data Queue | Integration; Payroll Interface |
| EDI | Set Up: Payroll Interface; Business Process Administration | Payroll Interface; System |
| Event Outbound Notifications | Integration Event; Integration Process; Business Process Administration | Integration; System |
| Inbound Notifications | Manage: Global Payroll Inbound Notifications | Global Payroll Connect |
| Additional Payroll Data | Self-Service: Payroll Interface (APD); Worker Data: Payroll Interface (APD) | Payroll Interface |
| External Payroll Documents | Integration Event; Payroll Interface; Self-Service: Payroll Interface | Integration; Payroll Interface |
| Global Payroll Reconciliation | Set Up/Manage/Process/View: Global Payroll Reconciliation | Payroll Interface |
| Third-Party Payroll Errors | Set Up: Payroll Interface; Manage/Process: External Payroll Errors | Payroll Interface |
