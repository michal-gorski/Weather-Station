# Journals and General Ledger Reference

This reference covers the three primary Workday journal connectors: the **Accounting Journal Connector** (inbound), the **Financial Journal Lines Outbound Connector**, and the **Payroll Journal Line Export Connector** (outbound).

## Quick Comparison

| Feature | Accounting Journal (Inbound) | Financial Journal Lines (Outbound) | Payroll Journal (Outbound) |
|---------|------------------------------|-------------------------------------|----------------------------|
| Direction | Inbound (import) | Outbound (export) | Outbound (export) |
| Template name | Core Connector: Accounting Journal Inbound | Financial Journal Lines Outbound Connector | Payroll Journal Outbound Connector |
| File formats | CSV or XML | CSV or XML | XML only |
| Primary use case | Load external GL data into Workday | Export high-volume journal lines | Export payroll journal entries |
| Summarisation | N/A | Yes (Group By dimensions) | No |
| Parallel processing | No | No | Yes (recommended for 50k+ entries) |

---

## Accounting Journal Connector (Inbound)

### Concept

Imports accounting journal data into Workday from an external SFTP endpoint. Translates data between external chart of account structures and Workday worktag/account structures. Supports both XML and CSV input formats.

The connector consists of:
- **Create Source System** — defines external source endpoints
- **Create Integration Worktag Mapping** — maps external codes to ledger accounts/worktags
- **Core Connector: Accounting Journal Inbound** — the integration template that retrieves, translates, maps, and loads data

### Setup

- Create source systems for each external endpoint (task: Create Source System)
- Create integration worktag mappings for external codes → ledger accounts/worktags
- Create integration system using template `Core Connector: Accounting Journal Inbound`
- (Optional) Enable integration services:
  - **Maintain Journal Sources Configuration – DIS** — for Suspense Accounting with Journal Sources; converts errors to warnings for missing code mappings
  - **Financials Document Delivery Service** — delivers CSV Audit Diagnostic File and Errors Only File to external endpoints
- Create ISU with Get/Put access to: Accounting Journal Event (BP), Integration Event
- Configure Integration Attributes on the integration system
- Configure Integration Maps — associate worktag mappings with the integration system using the Worktag Mapping Definition for External Code map

### Key Integration Attributes

- **Create Errors Only File** — generates a file containing only failed journals for re-processing
- **Create Audit File in CSV Format** — produces an audit diagnostic file
- **Configure Files for External Delivery** — enables document delivery service

### Processing Notes

- If `LedgerAccountingReferenceID` exists in the input file, Workday ignores external code values that map to ledger accounts
- Integration attribute values can be overridden by populating them in the input file
- Backslashes are not supported in Journal Entry Memo, Journal External Reference ID, Journal Line External Reference ID, or Journal Line Memo when generating a CSV audit file

### Launch Options

- Launch on schedule (automatic at configured frequency)
- Launch immediately (manual)

### Error Handling

- Enable the **Create Errors Only File** attribute to generate an errors-only output
- The errors-only file uses the same format (XML or CSV) as the input
- Contains only journals that failed to load
- Re-submit the corrected errors-only file through the same connector

### CSV File Format

The CSV format uses two row types:

- **Header row** — first row; fixed column names; only one permitted per file
- **Journal Data rows** — journal header and line details; all lines sharing the same `JournalKey` load as a single journal entry

**Data conventions:**
- Boolean values: `1` (true), `0` (false)
- Date format: `YYYY-MM-DD`
- Reference ID fields require a corresponding `...ReferenceIDType` field
- Decimal fields: up to 26 digits before decimal, 2–6 after (varies by field)

#### Key Journal Header Fields

| Field | Type | Notes |
|-------|------|-------|
| JournalKey | Text | Groups lines into a single journal entry (required) |
| AccountingJournalID | Text | Create new, update existing, or change ID |
| AccountingJournalReferenceID | Text | References existing journal for updates |
| Submit | Boolean | 0 = draft (Created), 1 = submit (Posted) |
| CompanyReferenceID | Text | Reference to existing company |
| Currency | Text | Must match company currencies |
| LedgerType | Text | Existing ledger type or mapped external value |
| AccountingDate | Date | Accounting date of the journal |
| JournalSource | Text | Existing journal source in Workday |
| ControlTotalAmount | Decimal | Validates sum of all journal lines |
| AddOnlyJournal | Boolean | 0 = update existing, 1 = create new |
| LockedinWorkday | Boolean | 1 = lock journal (no edit/cancel/change) |
| CreateReversal | Boolean | 1 = create reversal journal |
| ReversalDate | Date | Accounting date for reversal; defaults to first day of next open period |
| IncludeTaxLines | Boolean | 1 = journal includes tax detail data |
| JournalforAllLedgers | Boolean | Single ledger or primary + alternate |
| RecordQuantity | Boolean | 1 = Quantity and Unit of Measure provided on lines |

#### Key Journal Line Fields

| Field | Type | Notes |
|-------|------|-------|
| JournalLineOrder | Text | Sort order for display (e.g. 1a, 1b, 1c) |
| LedgerAccountReferenceID | Text | Direct reference to ledger account |
| DebitAmount | Decimal | Provide debit OR credit, not both |
| CreditAmount | Decimal | Provide debit OR credit, not both |
| LineCurrency | Text | 3-digit ISO code |
| LineCurrencyRate | Decimal | Exchange rate for line currency |
| LedgerDebitAmount / LedgerCreditAmount | Decimal | Ledger currency amounts |
| LineMemo | Text | Freeform text on the journal line |
| BudgetDate | Date | Required if View Budget Date enabled on ledger |
| ExcludefromSpendReport | Boolean | Exclude from capital project spend reporting |

#### Worktag Handling on Lines

- Worktags use the prefix `Worktag_` followed by the worktag type (e.g. `Worktag_Cost_Center_Reference_ID`)
- Multiple worktags can be added as additional columns at the end of each row
- External code mappings use the prefix `ExternalCode_` followed by the map name (e.g. `ExternalCode_Region`)
- Balancing worktags on the header use `BalancingWorktagReferenceID` or external code map fields
- Optional balancing worktags use prefix `OptionalBalancingWorktags_` (e.g. `OptionalBalancingWorktags_Cost_Center`)

#### Tax Line Fields (Optional)

Required when `IncludeTaxLines = 1`:
- TaxTransactionDate, TaxTypeReferenceID, TaxCodeReferenceID, TaxRateReferenceID — all required
- TaxApplicabilityReferenceID — required when tax code is provided
- TaxRecoverabilityTypeReferenceID — required (Fully Recoverable or Non Recoverable)
- TaxPointDateTypeReferenceID — required (e.g. Accounting Date, Payment Date, Transaction Date)
- TaxableEventLineReferenceLineOrder — relates tax line to journal line; separate multiple with semicolons

#### Business Process Fields (Optional)

- `BP_AutoComplete` — 1 = auto-complete approvals, bypass reviews, suppress notifications
- `BP_Comment` — freeform comment
- `InterCompanyBP_AutoComplete` / `InterCompanyBP_Skip` — mutually exclusive

#### Attachment Fields (Optional)

- `Attachment_FileName` — max 255 characters
- `Attachment_FileType`, `Attachment_FileEncoding`, `Attachment_Compressed`
- Intercompany attachments use `IntercompanyBP_Attachment_FileBase64` for Base64-encoded content

### XML Format

- Root element: `JournalConnectorFileData`
- Namespace: `urn:com.workday/JournalConnector`
- Structure mirrors CSV fields in XML element form
- External code references use: `<ExternalCode jc:name="MapName">Value</ExternalCode>`

### Common Issues and Troubleshooting

- **Journal won't post** — check Submit field is `1`; verify accounting date falls within an open period
- **Missing ledger account mapping** — ensure worktag mappings are created AND associated with the integration system via the Integration Map
- **Control total mismatch** — ControlTotalAmount must equal the sum of all debit and credit lines
- **Intercompany errors** — do not set `RoundLedgerAmounts` on intercompany journals
- **Locked journal cannot be modified** — `LockedinWorkday = 1` prevents all changes
- **Backslash in memo fields** — not supported when generating CSV audit files

---

## Financial Journal Lines Outbound Connector

### Concept

Exports high volumes of journal lines from Workday to a single CSV or XML file. Designed for bulk extraction of GL data. Supports two output modes:
- **Detailed Journal Line Data** — individual journal lines with full detail
- **Summary Journal Line Data** — aggregated/summarised output grouped by configurable dimensions

### Setup

- Create integration system using template `Financial Journal Lines Outbound Connector`
- (Optional) Enable integration services:
  - **Accounting Date Filter Service** — filters by accounting start/end date (mutually exclusive with Aggregation and Eliminations services)
  - **Eliminations or Translations Filter** — enables translation rule sets, elimination parameters, and translation currency
  - **Aggregation and Summarization Service** — summarises data by Group By dimensions
  - **Enable Message Auditing** — includes audit details (user, launch details, parameters)
- Configure Integration Attributes (output format, compression)
- Configure Integration Field Attributes — select which fields to include in output
- (Optional) Configure Integration Field Overrides — add extended fields (e.g. Cost Center instances, Cost Center Manager calculated fields)

### Key Integration Attributes

| Attribute | Description |
|-----------|-------------|
| Output File Format | CSV (default) or XML |
| Compress Output | Compress the output file |

### Launch Parameters

- **Detailed output** — leave Group By prompt blank
- **Summary output** — select Group By dimensions matching your integration attribute configuration

### XML Schema Structure

The XML output uses namespace `urn:com.workday/bsvc`:

```
JournalLine
  └── Journal_Line_Document (repeating)
        ├── Detailed_Journal_Line_Data (repeating)
        └── Summary_Journal_Line_Data (repeating)
```

#### Detailed Journal Line Data — Key Fields

- Identifiers: Journal_Line_WID, Journal_Number, Journal
- Company/Organisation: As_Entered_Company, Journal_Source
- Period: Period, Year, Ledger_Period, Accounting_Date
- Accounts: Ledger_Account, Balance_Sheet_Ledger_Account, Alternate_Account
- Amounts (three currency layers):
  - Ledger: Ledger_Debit_Amount, Ledger_Credit_Amount, Ledger_Debit_Minus_Credit
  - Transaction: Transaction_Debit_Amount, Transaction_Credit_Amount
  - Translated: Translated_Debit_Amount, Translated_Credit_Amount
- Currencies: Ledger_Currency, Transaction_Currency, Translation_Currency
- Status: Journal_Status, Operational_Transaction, Operational_Journal
- Memo: Memo, Line_Memo
- Metadata: Created_By, Last_Updated_Moment, Reversed_Journal

#### Summary Journal Line Data — Key Fields

Includes all standard worktag dimensions:
- Organisations: Company, Business_Unit, Cost_Center, Region, Location
- Financial: Ledger_Account, Fund, Grant, Project, Program
- Custom: Custom_Organization_01–10, Custom_Worktag_01–15
- Amounts: same three-currency-layer amounts as detailed data
- Reference IDs: each dimension includes both `_Reference_ID` and `_WID` variants
- Period references: Fiscal_Period, Financial_Period with Reference_ID and WID

### Differences from Payroll Journal Outbound

- Covers all journal sources (not just payroll)
- Supports CSV and XML output
- Supports aggregation/summarisation
- Does not include payroll-specific fields (pay group, pay cycle, payment date)

---

## Payroll Journal Line Export Connector

### Concept

Exports payroll journal entries, including payroll accounting details, from Workday to an external endpoint. Uses a Workday-defined XML format only (no CSV option). Best suited for feeding payroll GL entries to external ERP/finance systems.

### Setup

- Create integration system using template `Payroll Journal Outbound Connector`
- (Optional) Enable integration services:
  - **Payroll Journal Outbound Filter Service** — adds launch parameters: Journal Source, Reversed Journal, Pay Cycle Type, Pay Off-cycle Type
  - **Payroll Journal Outbound Pay Period Filter Service** — adds Payment Period parameter
  - **Payroll Journal Outbound Pay Period Date Filter Service** — adds Payment Period Date Option, From, To
  - **Payroll Journal Entry DIS** — define additional fields in Journal_Entry or Journal_Lines sections
- Configure Integration Attributes
  - **Enable Parallel Processing** — recommended for 50,000+ journal entries; generates concurrent output files
- Configure Integration Field Overrides — additional fields for output
- Set up integration delivery
- Create ISU with Get/Put access to: Integration Event, Process: Journals, Worker Data: Position and Employee Worktag
- (Optional) Create integration notifications

### Integration Services Summary

| Service | Required | Purpose |
|---------|----------|---------|
| Payroll Journal Outbound Deployed Service | Yes | Launches the integration |
| Payroll Journal Outbound Request | Yes | Standard launch params: Company, Journal Date Query Option, From/To Date, Pay Group |
| Payroll Journal Outbound Filter Service | No | Journal Source, Reversed Journal, Pay Cycle/Off-cycle Type |
| Payroll Journal Outbound Pay Period Filter Service | No | Pay Period parameter |
| Payroll Journal Outbound Pay Period Date Filter Service | No | Pay Period Date Option, From, To |
| Filename Sequence Generator | Yes | Unique filename per output file |

### Launch Options

- Launch via Integration step on a business process
- Launch on schedule (automatic)
- Launch immediately (manual)

### XML Schema Structure

Namespace: `http://www.workday.com/payroll/JournalOutbound`

```
PayrollJournalOutboundFile
  └── Journal_Entry (repeating)
        ├── WID, Journal_Sequence_Number, Journal_Status
        ├── Company (ID, Code)
        ├── Currency, Book_Code, Ledger, Ledger_Period
        ├── Accounting_Date, Journal_Source, Transaction_Date
        ├── Total_Ledger_Debits, Total_Ledger_Credits
        ├── Payroll_Period_Start_Date, Payroll_Period_End_Date
        ├── Payment_Date, Pay_Cycle_Type, Pay_Group, Prior_Period
        ├── Operational_Transaction (EFT_Payment_ID, Name)
        ├── Reversed_By / Reverses Journal references
        ├── Creation_Date, Originated_by
        └── Journal_Line (repeating)
              ├── WID, Company (ID, Code)
              ├── Ledger_Account, Alternate_Ledger_Account_Reference
              ├── Debit_Amount, Credit_Amount
              ├── Currency, Currency_Rate
              └── [Worktag fields via DIS/Field Overrides]
```

### Key Differences from Financial Journal Lines Outbound

- **Payroll-specific** — includes pay group, pay cycle type, payment date, payroll period dates
- **XML only** — no CSV option
- **No summarisation** — individual journal entries and lines only
- **Parallel processing** — available for large volumes
- **Operational transactions** — includes EFT Payment ID linkage

---

## Cross-Connector: Worktag Patterns

### Inbound (Accounting Journal)

Worktags are handled through two mechanisms:

1. **Direct reference** — provide a Workday reference ID for the worktag type (e.g. `Worktag_Cost_Center_Reference_ID = CC001`)
2. **External code mapping** — create mappings via Create Integration Worktag Mapping task, then reference by map name (e.g. `ExternalCode_Region = West`)

The external code approach is preferred when external systems use different codes than Workday reference IDs.

### Outbound (Financial Journal Lines / Payroll Journal)

- Worktag values appear as named elements in XML or columns in CSV
- Custom organisations (01–10) and custom worktags (01–15) are included as separate fields
- Summary mode can group by any worktag dimension
- Field overrides can add calculated field values for worktag instances (e.g. Cost Center Manager)

---

## Cross-Connector: Security Requirements

All journal connectors require an Integration System User (ISU) with appropriate domain access:

| Connector | Required Security Domains |
|-----------|--------------------------|
| Accounting Journal (Inbound) | Accounting Journal Event (BP), Integration Event |
| Financial Journal Lines (Outbound) | Integration Build, Integration Configure |
| Payroll Journal (Outbound) | Integration Event, Process: Journals, Worker Data: Position and Employee Worktag |

Setup tasks require: Integration Build and Integration Configure domains in the Integration functional area.

---

## Troubleshooting and FAQs

### General

- **Which connector for GL extract?** — Use Financial Journal Lines Outbound for all-source GL data; use Payroll Journal Outbound if you only need payroll journals with payroll-specific fields
- **CSV vs XML?** — Accounting Journal supports both for import; Financial Journal Lines supports both for export; Payroll Journal is XML-only
- **Performance for large volumes** — enable Parallel Processing on Payroll Journal (50k+ entries); Financial Journal Lines is designed for high-volume export natively

### Accounting Journal (Inbound)

- **Partial load failures** — use the Errors Only File to identify and re-submit failed journals without re-processing the entire file
- **Worktag mapping not found** — enable Maintain Journal Sources Configuration DIS to downgrade errors to warnings and continue processing
- **Journal created but not posted** — check that `Submit = 1` and accounting date is in an open period
- **Duplicate journal** — use `AddOnlyJournal = 1` to force new creation; use `AccountingJournalReferenceID` to target existing journals for update
- **Currency mismatch** — currencies in the file must match configured company currencies

### Outbound Connectors

- **Empty output file** — verify launch parameters (date range, company, pay group) match existing journal data
- **Missing fields in output** — check Integration Field Attributes; fields must have "Include in Output" enabled
- **Need additional worktag data** — use Integration Field Overrides to add calculated fields or extended worktag details
- **Summarised output not working** — ensure Aggregation and Summarization Service is enabled AND Group By dimensions are selected at launch
