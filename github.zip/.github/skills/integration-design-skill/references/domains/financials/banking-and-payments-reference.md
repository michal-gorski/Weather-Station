# Banking and Payments Reference

This reference covers Workday financials connectors for banking, payments, credit cards, and related integrations.

---

## Bank Statement Import Integrations

### Concept

Bank statement integrations import prior-day and intraday bank statement files into Workday from an external endpoint. Workday provides multiple templates supporting different file formats.

### Supported Formats

| Template | Format |
|----------|--------|
| Import ISO 20022 Bank Statements | camt.053.001.02/08 (prior day), camt.052.001.02/08 (intraday) |
| Import BAI2 Bank Statement | BAI2 |
| Import BTRS Bank Statement | BTRS |
| Import MT940/942 Bank Statements | MT940 (prior day), MT942 (intraday) |
| Core Connector Inbound - Bank Statements | Any format (requires Document Transformation to convert to Workday XML) |

### Setup

- Create integration system using the appropriate template
- Enable **Bank Statements Connector Common Configurations** service (recommended)
- Enable **Document Attachment Service** (Core Connector only) to attach custom XSLT for transformation
- Enable **Message Auditing** only during initial implementation or troubleshooting
- Create ISU with Get/Put access to: Integration Event, Process: Banking, Process: Bank Reconciliation
- Configure integration attributes and integration maps
- Configure retrieval from external SFTP endpoint
- For Core Connector: create a Document Transformation to convert native format to Workday XML

### Key Decisions

- Use a format-specific template (BAI2, MT940, ISO 20022) when your bank supports standard formats — no transformation needed
- Use Core Connector only when the bank uses a non-standard format, as it requires building an XSLT transformation
- File uniqueness validation can be enabled/disabled via the Common Configurations service
- Schema validation (Core Connector only) can reject entire files or just invalid statements

### Launch Options

- Scheduled run frequency (automatic retrieval)
- Manual launch (Run Now)
- Integration step on a business process

---

## Payment Connector

### Concept

The Payment Connector exports payment data from Workday to external financial institutions. It provides configurable output fields so you can select only the data elements your bank requires, delivered in XML or CSV format.

The **Core Connector: Payments Outbound V2 (Enhanced Performance)** template only supports XML output.

### Setup

- Create integration system from **Core Connector: Payments Outbound V2 (Enhanced Performance)** template
- Select integration services for fields to include
- Create ISU with Get/Put access to: Integration Event, Process: Settlement
- Configure integration attributes (use **Raw Output** format for faster disbursement of large payment volumes)
- Create integration business process; if using raw output, configure Document Delivery
- Configure integration maps (company, bank account, tax ID mappings)
- Set up sequence generators
- Select and configure connector output fields
- Optionally set up DIS field overrides and/or Document Transformation for bank-specific formats

### Data Sections

The connector output is organised into these sections:
- **Payment Group Data** — group ID, payment date/type/method/category, currency, count, sum
- **Originating Party and Bank Data** — company name, tax ID, contact, address, bank details
- **Payment Data** — payment ID, amount, check/EFT number, prenote flag, memo
- **Receiving Party and Bank Data** — payee details, bank account, routing numbers
- **Invoice Data** — line-level remittance information

### Key Decisions

- Use **Raw Output** for high-volume payment processing (fewer fields supported but faster)
- Use **Enhanced Performance** templates for improved processing times (DIS-based)
- Multiple integration systems can be assigned to a single bank account for different payment categories/countries
- Configure field truncation rules to meet bank character limits

### Audit Files

Each run generates:
- **Data Changes Audit** — readable version of output (contains actual payment data; secure separately)
- **Diagnostic Audit** — troubleshooting information

---

## Electronic Payment Integrations

### Concept

Electronic payment integrations generate formatted payment files for settlement processing. You create one or more integration systems per combination of bank and payment type.

### Supported Protocols

- ACH CCD/CCD+ (cash concentration/disbursement)
- ACH CTX (corporate trade exchange)
- ACH IAT (international)
- ACH PPD (prearranged payment and deposit)
- BACS Standard 18
- ISO 20022 V2 (PAIN.001.001.02)
- ISO 20022 V3
- ISO 20022 V9 (PAIN.001.001.09 — global payment processing)
- Zengin
- CyberSource credit card processing

### Setup

- Create ID definitions and sequence generators (ACH sequences must be numeric; outsourced payment groups need at least one non-numeric character)
- Configure **Edit Tenant Setup - Financials** with gapless sequence generator for Payment External EFT ID
- Create integration system using Enhanced Performance template where available
- Create ISU with Get/Put access to: Integration Event, Process: Settlement
- Configure integration attributes
- Set up integration delivery (Document Delivery step on business process)
- Assign integration system to bank account payment type for settlement

### Key Decisions

- Always use **Enhanced Performance** templates for faster processing (DIS-based)
- Use **Document Transformation** to convert output to bank-specific protocol formats
- Existing integrations can be migrated to Enhanced Performance using the **Migrate Payment Integration Systems** task
- Single endpoint: Document Delivery on Payment Release Event BP
- Multiple endpoints: Document Delivery on Integration Process Event BP per integration

### Converting to Enhanced Performance

- Use the **Migrate Payment Integration Systems to (Enhanced Performance)** task
- Select template and integration systems to convert
- Enhanced Performance uses DIS for customisable output and improved processing

---

## Workday Bank Connectivity (Kyriba)

### Concept

Workday Bank Connectivity leverages **Kyriba Bank Connectivity as a Service (BCaaS)** for preconfigured bank payment scenarios meeting country/local regulations globally. It provides a unified solution for payments, bank statements, and payment acknowledgements without needing custom bank format integrations.

### Prerequisites

- Purchase the **Workday Bank Connectivity SKU**
- Subscribe to **Innovation Services** (MSA-type agreements)
- Obtain from Kyriba: API credentials, referential data workbook, SFTP details
- Set up settlement in Workday

### Integration Templates

| Template | Purpose |
|----------|---------|
| Workday Bank Connectivity - Payments Initiation | Send payment files to Kyriba |
| Workday Bank Connectivity - Import Payment Status | Import payment acknowledgements |
| Workday Bank Connectivity - Import Bank Statements | Import bank statements |
| Workday Bank Connectivity - Positive Pay | Send check information for fraud prevention |
| Workday Bank Connectivity - Referential Data Updates | Synchronise core data with Kyriba |

### Data Flow

1. Workday generates payment files → SFTP → Kyriba
2. Kyriba transforms to bank-accepted formats based on payment scenarios
3. Kyriba sends formatted files to bank
4. Bank returns statements/acknowledgements → Kyriba → SFTP → Workday

### Referential Data

Workday and Kyriba synchronise:
- Bank accounts
- Bank branches
- Companies
- Financial institutions

External IDs are generated in Workday and mapped to Kyriba. Initial bulk setup followed by automatic incremental updates during payment processing.

### Setup (High-Level)

- Enable Bank Connectivity Reference Data (generates external IDs)
- Generate CSV files with referential data for initial Kyriba load
- Create External Client CredStore for Kyriba OAuth2 credentials (one CredStore for all integrations)
- Set up each integration template (Payments Initiation, Import Payment Status, Import Bank Statements, Positive Pay)
- Review bank routing rules to route payments through Bank Connectivity
- Assign integration systems to bank accounts on the Settlement Setup tab
- Populate Kyriba referential data workbook and send to Kyriba professional services

### Bank Statement Formats (via Kyriba)

- BAI2
- ISO 20022 (camt.053 prior day, camt.052 intraday)
- MT940 (prior day), MT942 (intraday)
- Other formats: contact Kyriba professional services

### When to Use Bank Connectivity vs Direct SFTP

| Consideration | Bank Connectivity (Kyriba) | Direct SFTP |
|---------------|---------------------------|-------------|
| Multiple banks/countries | Preferred — preconfigured scenarios | Requires per-bank integration |
| Standard formats only | Handles format transformation | You build/maintain transformations |
| Speed to implement | Faster for multi-bank | Simpler for single bank/format |
| Cost | Additional SKU required | Included in base licence |
| Format conversion | Kyriba handles bank-specific formats | Custom XSLT needed |
| Fraud prevention (positive pay) | Built-in | Separate custom integration |

### Troubleshooting

- If API errors occur during payment initiation, the integration stops and marks the payment release event as failed
- Options: enable **Ignore Referential Data Failures** attribute or fix data issues, then relaunch
- When moving to Production via Object Transporter, EBICS users must be recreated and contracts re-initialised in the new tenant
- External IDs must be 4–12 alphanumeric characters (no symbols/special characters)

---

## EBICS Integrations

### Concept

EBICS (Electronic Banking Internet Communication Standard) is a transmission protocol for secure bank communication. It replaces standard document delivery/retrieval steps on integration business processes for:
- Payment file delivery (outbound)
- Bank statement retrieval (inbound)
- Payment acknowledgement retrieval (inbound)

### Setup

- Create EBICS contract with partner ID and user IDs from financial institution
- Configure EBICS users with appropriate signature types:
  - **E signature** alone, OR
  - **A signature** + second user with A or B signature
  - **T signature** for EBICS T contracts
- Initialise users (generates initialisation letter for bank)
- Activate users after bank confirms
- Initialise contract when bank provides keys
- Create ISU with access to: Configuration Set: Integrations, Set Up: Bank Entity
- Edit business process to replace Document Delivery/Retrieval step with EBICS step
- Configure order type compatible with the integration

### Key Decisions

- EBICS replaces the Document Delivery or Document Retrieval step — do not use both
- For payments: add EBICS users as approvers on Settlement Run Event BP
- When migrating tenants with Object Transporter: must recreate/activate users and re-initialise contracts in new tenant (reset EBICS credentials with bank first)
- Signature priority follows user order in the contract

### Testing

- Create a settlement run with a test payment file
- Verify delivery via: Payment Groups tab → Payment Message → Business Process tab → Integration Process: EBICS → check integration event shows Completed

---

## Credit Card Integrations

### Concept

Workday imports credit cards and transaction data from card providers for processing in Workday Expenses. Supported providers include Visa, MasterCard, and American Express, each with dedicated templates.

### Templates

| Template | Purpose |
|----------|---------|
| Import MasterCard CDF3 File Masked | MasterCard CDF3 15.01 transactions (masked) |
| Import Visa VCF4 Scrubbed | Visa VCF 4.4 transactions (scrubbed numbers) |
| Import Credit Cardholder File (AMEX GL1205 - MASKED) | AMEX cardholder listings |
| Import Credit Card Transaction File (AMEX GL1025 - MASKED) | AMEX transaction files |
| Import AMEX Central Travel Data File (Masked) | AMEX central travel card transactions |
| Global Remittance for AMEX | Export remittance files to AMEX |

### Setup

- Establish merchant codes/names in: Maintain Airlines, Car Rental Agencies, Class of Service, Credit Card Expense Code Mapping, Hotels, Travel Cities
- Create integration system from appropriate template
- Enable Dynamic Map Services (Cities, Airlines, Hotels, Car Rental) for transaction mapping
- Create ISU with access to: Process: Credit Card, Integration Event
- Configure integration attributes (accept defaults for Dynamic Map Service unless directed by Workday Support)
- Configure integration maps: Class of Service, Transaction Types, Transaction Status Codes
- Set up sequence generators and retrieval

### Key Decisions

- **Masked vs Tokenised** (AMEX): use tokenised if planning Global Remittance
- MasterCard identifies transactions via Employee ID field
- Visa identifies transactions via Account Number + Posting Date + Sequence Number + Transaction Reference
- Level 3 enhanced data supported for airfare and hotel folio only
- Transaction Status Codes map controls which transactions self-service users can see (admins see all)

### Error Handling

- If a file has an invalid employee ID, transactions load but remain unassigned
- A subsequent file with the correct employee ID automatically links unassigned transactions
- For manually created cards, use **Fix Errors** on the Integration Details tab to assign transactions

---

## Currency Exchange Rate Connector

### Concept

Imports currency exchange rates from an external endpoint into Workday. Supports automatic calculation of inverse rates and cross rates to reduce data retrieval costs.

### Supported Formats

- Workday-defined XML
- Comma-Separated Value (CSV)

### Setup

- Create integration system from **Core Connector: Currency Rates** template
- Optionally enable Message Auditing
- Configure integration attributes (inverse rate calculation, cross rate calculation, anchor currency)
- Configure retrieval from external endpoint
- Create ISU with access to: Integration Event, Set Up: Currency Rates
- Set up notifications

### Key Configuration Options

- **CalculateInverseRate** — automatically generates the reverse rate for each pair (e.g., USD/EUR → EUR/USD)
- **CalculateCrossRates** — derives cross rates between two currencies via a common anchor currency
- **CrossRatesAnchorCurrency** — must match the source currency in the file
- **CurrencyRateType** — valid values: Average, Budget, Current, Financial Budget, Historic Equity, Quarterly Average
- Rate precision: up to 12 decimal places

### CSV Format Key Fields

- EffectiveTimestamp (DateTime or Date)
- FromCurrency / TargetCurrency (ISO 4217 codes)
- CurrencyRateType
- CurrencyRate (up to 12 decimal precision)
- CalculateInverseRate / CalculateCrossRates / CrossRatesAnchorCurrency (file-level overrides)

---

## Ad Hoc Bank Transaction Connector

### Concept

Imports ad hoc bank transactions (e.g., bank fees, interest, miscellaneous credits/debits) from an external endpoint into Workday. Supports worktag mapping to automatically assign ledger accounts.

### Supported Formats

- Workday-defined XML
- Comma-Separated Value (CSV)

### Setup

- Create source systems (one per external endpoint) via **Create Source System** task
- Create integration worktag mappings (external code → ledger account + worktags)
- Create integration system from **Core Connector: Ad Hoc Bank Transactions Inbound (Enhanced Performance)** template
- Configure integration attributes and maps
- Configure retrieval from SFTP endpoint
- Create ISU with access to: Integration Event, Process: Ad hoc Bank Transaction - Core
- Set up notifications

### Key Decisions

- Use Integration Worktag Mapping to translate external account codes to Workday ledger accounts and worktags
- If `LedgerAccountingReferenceID` exists in the input file, it overrides the external code mappings
- Integration attribute values can be overridden by populating them in the input file
- Supports both submit (for approval) and save-in-draft modes via the `Submit` flag
- `LockedInWorkday` flag prevents users from editing/cancelling the transaction in Workday

---

## Bank Fee Analysis Connectors

### Concept

Imports bank fee statements from financial institutions for analysis and reporting. Useful for tracking and auditing banking charges across accounts.

### Supported Formats

| Template | Format |
|----------|--------|
| Import EDI 822 Bank Fee Statements | ASC X12 EDI 822 |
| Import ISO 20022 V1 Bank Fee Statements | camt.86 V1 |
| Import ISO 20022 V2 Bank Fee Statements | camt.86 V2 |
| Core Connector: Bank Fee Statements Inbound | Workday-defined XML (requires custom transformation for non-standard formats) |

### Setup

- Create integration system using the appropriate template for your bank's format
- Configure retrieval from external endpoint
- Configure integration attributes and maps
- Create ISU with access to: Integration Event, Process: Bank Fee Statements
- Set up notifications

### Key Decisions

- Use format-specific templates (EDI 822, ISO 20022) when banks support standard formats
- Use Core Connector only for non-standard formats (requires building a Document Transformation XSLT)
- Bank account identification: provide either CustomerAccountNumber or IBAN, and either RoutingNumber or BIC

---

## Payments Inbound (Payment Status Reports)

### Concept

Imports payment acknowledgement files from banks in ISO 20022 format, enabling Workday to update payment statuses as they flow through settlement processing.

### Supported Formats

- ISO 20022 pain.002 (V2, V3, V10)

### Setup

- Create integration system from **Import Payment Status Report** template
- Enable **ISO20022 Payment Status Report** service
- Configure integration attributes
- Optionally configure status code maps if bank uses non-standard acceptance codes
- Create ISU with access to Integration Event plus the relevant Process domain for each payment type (e.g., Process: Settlement, Process: Supplier Invoice Payment/Settlement, Process: Payroll Settlement)
- Configure retrieval and launch schedule

### Default Status Code Mappings

| Status | Default Acceptance Codes |
|--------|-------------------------|
| Accepted | ACSC, ACWC, PART |
| Rejected | ACCR, RJCT |
| Received | ACCP, ACSP, ACTC, PNDG, RCVD |

Configure integration maps if your bank uses different codes.

### CyberSource Credit Card Payments

Two templates for credit card payment processing:
- **Workday to CyberSource Customer Profile and CC Auth** — creates/maintains customer profiles and authorises payments
- **WPN - CyberSource Credit Card Payment Processing** — sends payment data for transaction processing

Key setup:
- Obtain CyberSource security key and configure .p12 certificate (PKCS12 authentication)
- Enable **Cybersource PKCS12 Certificate DIS** service
- Upload certificate via **Upload Cybersource Certificate** task
- Configure CBLoginCredentialsMap with CyberSource username/password
- Subscribe to Create Credit Card Authorization, Customer Change, and Update Merchant Customer Profile event types
- Add integration to Payment Release Event business process

---

## Customer Lockbox Integration

### Concept

A lockbox is a PO box accessible by a bank where customers send payments. The bank processes payments and deposits to the company's account. This inbound integration imports BAI2 lockbox data into Workday.

### Key Features

- Single template: **Import Customer Payments Lockbox**
- Supports auto-application of payments (matches invoice numbers between lockbox file and Workday)
- Supports multiple lockbox bank accounts in one file (enable **Lockbox Bank Account** checkbox)
- Supports check payment format; wires/ACH require bank to format data appropriately
- Integrates with Auto-Application Payment process for full cash receipt automation

### Setup

- Create integration system from **Import Customer Payments Lockbox** template
- Create ISU with access to: Customer Deposit Event, Integration Event, Process: Customer Deposit, Process: Customer Invoice, Process: Customer Invoice Payment
- Configure integration attributes (currency, payment type, duplicate checking, etc.)
- Configure integration maps: Account to Company, Account to Bank Account
- Configure retrieval from external endpoint
- Set up lockbox on bank account (Edit Bank Account → Lockbox Setup tab)
- Configure customer banking information (Remit-To Lockbox section)

### Integration Attributes

| Attribute | Purpose |
|-----------|---------|
| Currency | Currency for each payment (required) |
| Enable Deposit Control Total | Validates payment totals against batch total |
| Enable Duplicate Deposit Checking | Prevents duplicate deposits by Reference ID |
| Enable Invoice Currency on Payment | Sends invoice currency when all invoices share currency |
| Lockbox Bank Account | Enables multiple bank accounts via Processing Destination |
| Payment Date | Uses Processing Date instead of Check Date |
| Payment Locked in Workday | Disables editing/cancelling in UI (web service only) |
| Submit Deposit for Approval | Submits transaction; if unchecked, saves as draft |

### Processing Behaviour

- Each file is booked to one currency and one bank account
- Each deposit can contain many payments; each payment can reference 0, 1, or many invoices
- No match → payment status: Unapplied
- Partial match → invoice status: Partially Paid
- Null file → no payments or deposits generated
- Uses **Put Customer Payment** and **Submit Customer Deposit** web services

---

## Common Patterns and Guidance

### Security Domains (All Connectors)

All banking/payment integrations require:
- An Integration System User (ISU)
- ISU security group membership
- Get and Put access to **Integration Event** domain
- Get and Put access to the relevant process domain (varies by connector)

### Integration Retrieval

All inbound connectors share the same retrieval configuration pattern:
- Specify SFTP/endpoint details on the Document Retrieval step of the integration business process
- Configure file name patterns for file matching
- Schedule retrieval frequency

### Integration Delivery

All outbound connectors share the delivery configuration pattern:
- Add Document Delivery step to the integration business process
- Specify SFTP/endpoint details
- Use Document Transformation step for bank-specific format requirements

### Troubleshooting Tips

- **Enable Message Auditing** only during initial implementation or active troubleshooting — it generates large volumes of data
- Check **Integration Document Retention** settings to ensure files are available for debugging
- For bank statement issues: verify bank account number/IBAN mapping matches between Workday and the incoming file
- For payment delivery failures: check Document Transformation output format matches bank requirements
- For EBICS: verify user signatures are active and contract is initialised; check order type compatibility
- For Bank Connectivity (Kyriba): verify referential data external IDs are correctly mapped; check API endpoint URL
- Use the **Diagnostic Audit** file on integration events to trace processing errors
- For credit card integrations: use **Fix Errors** on Integration Details tab to reassign unmatched transactions
