# Procurement and Supplier Integration Reference

This reference covers Workday's procurement and supplier integration connectors: EDI (810, 850, 855, 856), Punchout (cXML), Electronic Invoice Connector (outbound), and Electronic Supplier Invoice Connector (inbound).

---

## EDI Supplier Integrations

### Concept

EDI supplier integrations send and receive ASC X12 format files between Workday and external suppliers. Workday provides four delivered connector templates:

| Template | Direction | Purpose |
|----------|-----------|---------|
| Supplier Invoice EDI 810 Inbound | Inbound | Import supplier invoices |
| Purchase Order EDI 850 Outbound | Outbound | Export purchase orders to suppliers |
| Purchase Order Acknowledgment EDI 855 Inbound | Inbound | Import PO acknowledgements |
| Advance Ship Notice EDI 856 Inbound | Inbound | Import advance ship notices |

### Launch Options

- **Business process step** — trigger from a business process (e.g. Purchase Order Issue Event for 850)
- **Scheduled** — run on a frequency; retrieves/sends files automatically
- **Manual** — launch immediately for reprocessing errors

### EDI 810 — Supplier Invoice Import

#### When to Use

Import supplier invoices in X12 810 format. Supports standard invoices, credit memos, and debit memos.

#### Key Setup Steps

- Configure units of measure with EDI codes via Maintain Units of Measure (populate the EDI Code field for all UOMs, even when identical to UN CEFACT codes)
- Create integration system from **Supplier Invoice EDI 810 Inbound** template
- Create integration business process and configure retrieval
- Configure integration attributes and maps
- Create ISU with Get/Put on Integration Event domain
- (Optional) Configure Maintain Supplier Invoice System Validation to ignore specific validation errors

#### Important Integration Attributes

| Attribute | Purpose |
|-----------|---------|
| Interchange Sender ID | Supplier's ISA06 value |
| Default Company/Supplier From PO | Populate company/supplier from the referenced PO |
| Skip Control Total Amount Verification | Suppress errors when TDS01 doesn't match line totals |
| Enable Pre-Processing | Create draft invoices instead of failing on certain errors |
| Spend Category for Freight and Other Charges | Handle freight as zero-cost line with a configured spend category |
| Include Landed Costs in Tax | Include freight/other charges in tax calculation |
| EDI 810 Work Area Enhancement | Process more data and enable error correction in Work Area |

#### Integration Maps

| Map | Purpose |
|-----|---------|
| Company Mapping EDI File | External value must match GS03 and ISA08 segments |
| Supplier Mapping EDI File | Map when supplier DUNS doesn't match GS02 segment |

#### Credit Memo Handling

- Ask suppliers NOT to populate BIG04 (PO number) on credit memos, or build a preprocessor to strip it
- If the Return to Supplier Event business process creates invoice adjustments, the 810 import may create duplicate credits

#### Troubleshooting

- Processing errors often caused by missing UOM EDI codes
- Use Supplier Invoice Work Area to correct invoices created in Draft status
- Enable Pre-Processing to create drafts instead of hard failures for invalid PO lines, missing line numbers, or non-existent POs

### EDI 850 — Purchase Order Export

#### When to Use

Export purchase orders in X12 850 format. Workday consolidates files by supplier and acknowledgement status.

#### Key Setup Steps

- Configure DUNS numbers on suppliers and companies
- Set EDI or EDI Auto as the issue option for purchase orders on supplier profiles
- Configure units of measure and (optionally) purchase order types with EDI codes
- Create integration system from **Purchase Order EDI 850 Outbound** template
- Configure two sequence generators (Batch ID and Filename) — must be 9 digits in length
- Configure business process (Purchase Order Issue Event) to launch the integration
- Use **Launch EDI 850 Outbound Integration** service step in the business process
- Use Maintain Supplier Links to route different companies/suppliers to different integration systems

#### Important Integration Attributes

| Attribute | Purpose |
|-----------|---------|
| Receiver ID | Supplier ID for ISA08 segment |
| Sender ID | Override when multiple companies share the same code |
| ISA07 Qualifier | Override the default ZZ (2-character value) |
| Interchange Usage Indicator | P (production) or T (test) in ISA15 |
| MSG segment for PO header | Split long memos across multiple MSG segments |
| N9 Before N1 Segment | Reorder segments when required by partner |
| Disable Unit Cost Rounding | Allow up to 6 decimal places on unit costs |

#### Notes

- Workday trims these delimiters from outbound files: `~ ^ : * |`
- When a supplier uses a non-DUNS ID, configure an Alternate Name Usage of "EDI Integration Name"
- Multiple 850 integrations can exist for different company/supplier combinations

### EDI 855 — Purchase Order Acknowledgement Import

#### When to Use

Import PO acknowledgements. Workday appends EDI status codes to each PO line memo and matches line numbers.

#### Key Setup Steps

- Enable Purchase Order Acknowledgements in Edit Tenant Setup - Financials
- Configure an ID Generator for Purchase Order Acknowledgement
- Set up UOMs with EDI codes
- Enable the Acknowledgement Expected checkbox on supplier profiles
- Create integration system from **Purchase Order Acknowledgment EDI 855 Inbound** template
- Configure retrieval and maps

#### Important Integration Attributes

| Attribute | Purpose |
|-----------|---------|
| Interchange Sender ID | Supplier ISA06 value (optional if supplier passes DUNS in ISA06) |
| Validate Receiver ID | Match ISA06 to company DUNS numbers in Workday |
| Validate Sender ID | Match GS02 to supplier DUNS in Workday |

#### Limitations

- Cannot process multiple acknowledgement lines for the same PO line within the same file
- When both Validate Sender ID and Validate Receiver ID are enabled and one fails, Workday displays an error even if the PO matches

### EDI 856 — Advance Ship Notice Import

#### When to Use

Import advance ship notices. Workday can automatically create receipts from ASNs to reduce dock workload.

#### Key Setup Steps

- Enable Advanced Ship Notices in Edit Tenant Setup - Financials
- Configure an ID Generator for Advanced Ship Notice
- Set up UOMs with EDI codes
- Enable the "Enable ASN" checkbox on supplier profiles
- Create integration system from **Advance Ship Notice EDI 856 Inbound** template
- (Optional) Configure the Advanced Ship Notice Event business process with the "Initiate Receipt Events from Advanced Ship Notice" service step

#### Notes

- Zero-quantity lines do not create receipts
- For just-in-time requisition types, use Schedule Purchase Order Close Lines for Receiving to close lines with zero shipped quantities

### Procure-to-Pay Integrations Work Area

A consolidated view for monitoring inbound EDI integration errors (810, 855, 856):

- **Overview tab** — status and error log of failed events, link to HTML error log
- **Work Area tab** — individual error details with document information (currently 855 and 856 only)

### Pre and Postprocessor Patterns

When inbound or outbound data deviates from Workday's EDI connector standards, a custom Studio pre/postprocessor may be needed. First consider:

- Can the supplier adjust their file?
- Does the requirement adhere to EDI standards?
- Is there an alternative way to consume/produce the data?

Working with the supplier or their EDI partner is often the fastest solution.

#### Common 850 Pre/Postprocessor Use Cases

| Pre | Post |
|-----|------|
| — | Update N102 (BT) to single company name |
| — | Update GS values (e.g. for GHX Metatrade) |
| — | Suppress blank PO1 ^LT^ on consignment POs |
| — | Suppress blank PER segments on consignment POs |
| — | Update fields for shipment methods |

#### Common 855 Pre/Postprocessor Use Cases

| Pre | Post |
|-----|------|
| BAK01 codes other than 01, 04, 06, 44 | — |
| Multiple ACK segments for same PO line in one file | — |
| Validate Supplier GS ID on 855 against the PO | — |

#### Common 856 Pre/Postprocessor Use Cases

| Pre | Post |
|-----|------|
| — | Close short-shipped lines not to be fulfilled |

#### Common 810 Pre/Postprocessor Use Cases

| Pre | Post |
|-----|------|
| PO line number validation | Process files updated by preprocessor |
| Credit memo — remove PO reference (BIG04) and make TDS01 absolute | Validate taxable amount/tax option |
| Remove ITD line to use PO payment terms | Validate supplier catalog number against PO line |
| Remove ^91^Customer Acct Number after N1^ST | Validate supplier on invoice matches supplier on PO |
| Populate spend category/item on non-PO invoices | — |

---

## Punchout Integrations

### Concept

Workday Punchout uses cXML (commerce eXtensible Markup Language) for real-time, synchronous communication between supplier eCommerce websites and Workday Procurement. Workers browse external supplier catalogues, select items, and return to Workday to complete the requisition.

### Business Benefits

- Access external supplier catalogues without maintaining hosted catalogues
- Reduce administration overhead and non-compliant spend
- Eliminate manual data entry for POs, PO acknowledgements, ASNs, and supplier invoices
- Automatically associate web items to purchase items via commodity codes and spend categories

### Punchout Flow (cXML Roundtrip)

1. Worker initiates "Connect to Supplier Website" from requisition
2. Workday sends a PunchOutSetupRequest (cXML) to the supplier's Service URL
3. Supplier returns a PunchOutSetupResponse with a URL to their catalogue
4. Worker browses supplier catalogue and adds items to cart
5. Supplier sends a PunchOutOrderMessage back to Workday with cart contents
6. Worker completes requisition in Workday
7. On approval, Workday issues a cXML OrderRequest (purchase order) to the supplier
8. Supplier can return a cXML InvoiceDetailRequest (invoice) to Workday

### Integration Templates

| Template | Purpose |
|----------|---------|
| Procurement Supplier Punchout - Custom Supplier | Connect to any cXML-capable supplier catalogue |
| Procurement Punchout Purchase Order - Custom Supplier | Issue cXML purchase orders |
| Supplier Network Connector - Procurement Punchout Purchase Order and Invoicing | PO issue + invoice receipt (use when accepting cXML invoices) |
| Preconfigured templates | CDW, Dell, Guest Supply, Staples (factory default credentials) |

Workday recommends the Custom Supplier templates for flexibility.

### Prerequisites

- Supplier or marketplace must support cXML
- Obtain punchout URL (HTTP endpoint), supplier credentials, and shared secret
- Associate UN/CEFACT codes to units of measure
- (Optional) Associate UNSPSC supplier product codes to spend categories
- Security: Integration Build, Integration Configure, Process: Requisition - Create/Edit, Self-Service: Requisition

### Key Integration Attributes (Punchout Catalogue)

| Attribute | cXML Element |
|-----------|--------------|
| Buyer Domain | Header.From.Credential@domain / Header.Sender.Credential@domain |
| Buyer Identity | Header.From.Credential.Identity / Header.Sender.Credential.Identity |
| Service URL | Supplier's punchout website URL |
| Supplier Domain | Header.To.Credential@domain |
| Supplier Identity | Header.To.Credential.Identity |
| Shared Secret | Header.Sender.Credential.SharedSecret |
| Public Key | Signature.KeyInfo.X509Data.X509Certificate |

### Key Integration Attributes (Purchase Order)

All the above plus:

| Attribute | Purpose |
|-----------|---------|
| Allow Multiple Address Lines With Max Number | Output 1–4 address lines as separate elements (default concatenates into one) |
| Include PO Attachments | Send external attachments in multipart cXML |
| Include Line Ship-To Information | Include deliver-to, ship-to address, ship-to contact |
| Include Service Lines | Include service lines (sets isAdHoc=yes, quantity=1) |
| Sender Identity / Sender Domain | Distinct sender values separate from buyer identity |
| Override Sender Identity | Dynamically set company DUNS as sender Identity |

### Punchout Purchase Order — cXML Invoice Receipt

When accepting cXML invoices from suppliers:

- Send the punchout URL (HTTP endpoint) to the supplier
- Endpoint format: `https://<datacentre>.workday.com/ccx/ProcurementcXMLReceiver`
- Determine your endpoint from Workday Community data centre pages
- Line-level taxes are aggregated to invoice header level
- Supported invoice elements: invoice ID, operation, invoiceDate, ShippingAmount, OrderID, lineNumber, quantity, UnitPrice, SubtotalAmount, Tax amounts, Comments

### Procurement Card in cXML POs

To include procurement card details:

- Enable the "Enable Procurement Card in PO cXML" integration service
- Set PCI Provider Identifier to `cXML-PO`
- Set Restrict values to template = Yes
- Set File Type to `AMEX-GL 1205`

Card info only populates when the PO header contains a credit card token.

### Business Process Configuration

| Business Process | Configuration |
|------------------|---------------|
| Integration Process Event | Must be configured or approved POs won't issue |
| Purchase Order XML Issue Event | Add integration step identifying the supplier integration |

### Supplier Marketplace Recommendation

Workday recommends integrating via a supplier marketplace (e.g. SciQuest, Jaggaer) to reduce the number of integrations to maintain. For other marketplaces, fully test the integration.

### Launch Parameters (Extrinsic Elements)

Suppliers may request additional identification. Configurable extrinsics:

- Email Address for Current Worker
- Location ID / Location Name for Current Worker
- Cost Center ID / Cost Center Name for Current Worker

### Limitations and Troubleshooting

- Encryption algorithm mismatches can cause issues — see FAQ: Encryption, Certificates, and Ciphers for Integrations
- If addresses have more than Address Lines 1–2, configure Allow Multiple Address Lines With Max Number (up to 4)
- For address components beyond line 4, a custom Studio postprocessor is required
- Workday doesn't update preconfigured supplier templates with each release
- When web items don't have a spend category populated, instruct users to select one manually for accurate reporting

---

## Electronic Invoice Connector (Outbound)

### Concept

The Electronic Invoice Connector exports customer invoice data electronically in XML format to external entities (vendors, payment portals, or government authorities). It supports custom configuration for local government e-invoicing requirements and third-party e-invoice solutions.

### Templates

| Template | Use Case |
|----------|----------|
| Core Connector: Electronic Customer Invoices | Generic XML output — configure field attributes to define output content |
| UBL 2.1 Electronic Customer Invoice | European EN-16931 semantic data model (business-to-government) |
| cXML Electronic Customer Invoice | Send to third-party supplier portals accepting cXML |

### Key Setup Steps

- Create integration system from the appropriate template
- Configure integration attributes (enable PDF, set max PDF size)
- Configure field attributes (enable/disable fields in output)
- (Optional) Configure field overrides for custom fields or calculated fields
- Configure integration delivery (business process with service step for document delivery)
- Create ISU with Get/Put on Integration Event and Process: Electronic Invoices domains
- Set up sequence generators
- Launch (recommend launching from Customer Invoice Event business process)

### Launch Recommendations

- Add an Integration step to the Customer Invoice Event business process
- Add condition rules so integration launches only:
  - When a PDF exists for the last printing run (Does PDF Exist for Last Printing Run is not blank)
  - For specific customer invoices within a given company
- Maximum 5,000 invoices per integration event

### UBL 2.1 Configuration

#### Integration Maps

Map Workday values to EU-standard external codes:

| Map | EU Code List |
|-----|-------------|
| Invoice Type to InvoiceTypeCode | UNTDID1001-inv |
| Statutory Invoice Type to InvoiceTypeCode | UNTDID1001-cn |
| Payment Type to PaymentMeansCode | UNCL4461 |
| Tax Code to TaxCategory ID | UNCL5305 |
| Tax Code to TaxExemptionReasonCode | Vatex |
| Unit of Measure to InvoicedQuantity | UMCode List |
| Company Tax ID Type to UBL Target Field | PEPPOL-COMMON-R045 |
| Company/Customer Tax ID Type to schemeID | ISO 6523 ICD |

#### Key UBL Attributes

| Attribute | Purpose |
|-----------|---------|
| Codes to Generate UBL 2.1 Credit Note Format | Invoice codes that trigger credit note format (default: 81,83,381,396,532) |
| CustomizationID | User-defined UBL customisation identifier |
| Use Invoice Number or Gapless Invoice Number | Select which number populates the ID field |
| Use Invoice Type or Statutory Invoice Type | Which map populates InvoiceTypeCode |
| Enable Tax Code Grouping | Group transaction tax codes with same percentage and external code |
| Enable Tax Mapping Lists for Invoices | Use Maintain External Tax Code List Mappings instead of integration maps |
| Concatenate Additional Address Line | Combine address lines 3–9 into a single third line |

#### Validation

- Ecosio Document Validator: `https://ecosio.com/en/peppol-and-xml-document-validator/`
- Interoperability Test Bed Validator: `https://www.itb.ec.europa.eu/invoice/upload` (goes down evenings PDT for maintenance)
- When multiple tax total elements exist, use the ITB validator

### cXML Configuration

#### Key cXML Attributes

| Attribute | Purpose |
|-----------|---------|
| cXML File Delivery | Post externally or attach to event (no acknowledgement if attached) |
| Use Vendor Issued ID or Customer DUNS Number | Source of To Credential Identity |
| To Credential Domain for Customer Identifier | Domain value (e.g. DUNS, Network ID) |
| XML Language | Language identifier for text elements (default: eng) |
| Enable Message Auditing | Record audit messages (enable only during implementation or diagnosis) |

#### Automated cXML Delivery Setup

1. **Maintain Electronic Invoice Integration Connections** — configure connection per supplier portal:
   - From Domain/Identity, Sender Domain/Identity, Shared Secret, Endpoint URL
2. **Maintain Document Delivery Types** — add Integration delivery method for Customer Invoice document type
3. **Maintain Document Delivery Rules** — map document delivery type to integration connection and integration system
4. **Edit Document Delivery Options** — set Integration delivery type on the customer profile
5. **Customer Invoice Event business process** — add "Electronic Invoicing Via Document Delivery Rules" service step

#### Result

When a customer invoice is submitted, the business process launches the cXML integration to post the invoice to the supplier endpoint. View response on the Electronic Invoice Acknowledgement tab.

### Processing Notes

- One XML file per customer invoice
- Invoice lines are NOT sorted (order may differ from standard invoice display)
- Diagnostic Audit file generated each run (identifies excluded invoices and missing-PDF warnings)
- Acknowledgements available via Get/Put Electronic Invoicing Acknowledgment web services

### Integration Services (All Templates)

| Service | Attribute | Purpose |
|---------|-----------|---------|
| Customer Invoices for Electronic Invoicing DIS | — | Global launch parameters |
| PDFs for Electronic Invoicing DIS | Max PDF Size in Kilobytes | Include PDF; restrict file size |
| Electronic Customer Invoice Core Service | Output Document Tags | Tag output files for identification |
| Integration Document Retention | Document Retention Policy | Retention duration in days |

---

## Electronic Supplier Invoice Connector (Inbound)

### Concept

The Electronic Supplier Invoice Connector imports supplier invoices from external vendors or payment portals into Workday Supplier Accounts. It uses an XML schema based on the `urn:com.workday/SupplierInvoiceConnector` namespace.

### Key Setup Steps

- Create integration system from **Core Connector: Electronic Supplier Invoice** template
- Create ISU with Get/Put on Accounting Journal Event and Integration Event domains
- Enable required and optional integration services (4 default, 3 optional)
- Configure integration retrieval via business process definition
- Configure integration attributes (retention period, validation rules, change detection)
- Configure integration maps (unit of measure, company Tax/VAT ID, supplier Tax/VAT ID)
- Configure security settings
- Launch or schedule

### XML Schema — Key Elements

The input XML uses the `SuppInvData` root type. Key fields:

| Element | Description |
|---------|-------------|
| RefID | Reference to existing supplier invoice (for updates) |
| BPParam | Business process parameters for auto-submit |
| InvID | Unique supplier invoice identifier |
| Submit | Boolean — submit for approval or save as draft |
| LockedinWD | Boolean — disable editing/cancelling in Workday UI |
| InvNum | Invoice number (should match RefID to avoid duplicates) |
| Company | Company reference ID |
| CompanyTaxID | Company VAT/Tax ID (alternative to company reference) |
| Supp | Supplier reference |
| SuppTaxID | Supplier VAT/Tax ID (alternative to supplier reference) |
| Ccy | Currency (defaults to payer/payee preferred or company base currency) |
| InvDt | Invoice date (MM/DD/YYYY, defaults to current date) |
| InvRcvdDt | Invoice received date |
| TaxCd | Tax code reference (defaults from payee if not submitted) |
| DfltWHTaxCd | Withholding tax code |
| ShipToAddr / BillFromAddr / ShipFromAddr | Address references |
| ExtSuppInvSource | External source (defaults to "E-invoice") |
| PmntPractices | Flag for Payment Practices Reporting |

### Integration Maps

| Map | Purpose |
|-----|---------|
| Unit of Measure | Map external UOM to Workday UOM |
| Company Tax/VAT ID | Map external company tax ID to Workday company |
| Supplier Tax/VAT ID | Map external supplier tax ID to Workday supplier |

### Key Considerations

- Invoice number and Reference ID should be the same value to prevent duplicates
- When LockedinWD is true, the invoice can only be updated via web service
- Company can be identified by reference ID or by Tax ID + Country combination
- Supplier can be identified by reference ID or by Tax ID + Country combination

---

## Security Requirements (All Connectors)

All procurement integrations require:

- **Integration System User (ISU)** with appropriate domain access
- Minimum domains: Integration Event (Get/Put)
- Additional domains vary by connector (e.g. Process: Electronic Invoices, Set Up: Procurement)
- Use **Assign Integration System Groups** on the ISU's security profile
- Never store passwords directly in assemblies — use integration system credentials

## Common Prerequisites (All Connectors)

- Know the external endpoint IP/URL
- Security: Integration Build and Integration Configure domains
- Set up units of measure with appropriate codes before first use
- Configure integration notifications for Completed With Warnings/Errors statuses
