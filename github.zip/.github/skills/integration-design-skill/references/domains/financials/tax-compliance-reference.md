# Tax and Compliance Reference

This reference covers Workday financials connectors for tax reporting and regulatory compliance across European jurisdictions.

## Country and Regulation Map

| Connector | Country | Regulation / Authority | Output Format |
|---|---|---|---|
| ELSTER | Germany | Periodic VAT Return (Umsatzsteuervoranmeldung) | XML |
| FEC | France | Fichier des Écritures Comptables (accounting entries audit file) | XML (ZIP) |
| GoBD | Germany | GoBD Z3 digital audit (tax-relevant data extraction) | CSV + XML index + DTD |
| SAF-T Core | Multi-country (OECD) | Standard Audit File for Tax, OECD v2.0 schema | XML (ZIP) |
| SAF-T Norway | Norway | SAF-T Financial v1.10 / v1.30 | XML (ZIP) |
| DAS2 | France | Declaration of third-party payments (TD/Bilatéral) | Text (ZIP) |
| Tax ID Validation | EU / UK | VIES (EU VAT) and HMRC (UK VAT) | Stored in tenant |

---

## ELSTER Integrations

### Concept

Generates XML for the German periodic VAT return (Umsatzsteuervoranmeldung). The output file is uploaded to the ELSTER tax portal. Workday supports annual updates to the declaration format via extended fields.

### Setup

- Create integration system using the **German ELSTER Periodic VAT Return** template
- Configure integration attributes: set **Tax ID Type for Company Tax Registration Number** to `Steuernummer`
- Enable XML creation on the tax declaration definition and select the VAT return year
- Configure field overrides on the **Umsatzsteuervoranmeldung** tab — map tax declaration result line amounts to Kennzahl fields (e.g. Kz81 for base taxable sales at standard rate)
- Optional: configure DatenLieferant, Berater, and Unternehmer tabs for data supplier, consultant, and entrepreneur details
- Optional: use field attributes to disable fields or set maximum lengths

### Key Integration Attributes

- **Tax ID Type for Company Tax Registration Number** — must be `Steuernummer`
- Field overrides map declaration lines to ELSTER Kennzahl elements
- Extended fields accommodate format changes between VAT return years

### Default Mappings (Key Fields)

| Element | Default Source |
|---|---|
| Erstellungsdatum (Creation Date) | Date the XML was created |
| DatenLieferant > Name | Full legal name of user who created the run |
| DatenLieferant > Strasse, PLZ, Ort | Primary public address of data supplier |
| DatenLieferant > Telefon | Primary work phone |
| DatenLieferant > Email | Primary email |
| Unternehmer > Bezeichnung | Company name as of last day of declaration run |
| Berater (all fields) | Not mapped by default — configure via overrides |

### Generating the XML

- Tax declaration run must be in **approved** state
- Enter a complete calendar month or quarter (Start/End Date) — incomplete periods are rejected
- For VAT groups, set the Primary Company to identify the group contact
- Submission parameters: Corrected Registration (Box 10), Offset Reimbursement (Box 29), Revoke SEPA Direct Debit (Box 26), Additional Information (Box 23/23B)

### Prerequisites

- Tax Declaration Definitions created
- Security: Integration Build domain; Set Up: Tax domain (Common Financial Management)

---

## FEC Integration

### Concept

Generates fichier des écritures comptables (FEC) audit files from accounting entries in the XML format specified by the French tax authority. Required for companies subject to French tax audits.

### Setup

- Create integration system using the **FEC Template**
- Optionally enable the **document retrieval service** to supply a custom XSD or updated schema from the tax authority
- Create ISU with Get and Put access to the Integration Event domain
- Optional: configure integration attributes to specify which schema the XSD validates against
- Launch or schedule the integration

### Integration Services

| Service | Purpose |
|---|---|
| FEC_Schema_Retrieval | Document retrieval for custom or updated XSD |

### Output Files

Each run generates:
- ZIP file containing the FEC XML
- Message log HTML (first 500 validation errors)

Files appear on the Output Files tab of the integration event.

### Scheduling Considerations

- For companies generating more than **5 million journal lines per month**: schedule outside business hours and run monthly rather than for larger periods

### Prerequisites

- Journal sequencing must be enabled for the company
- Security: Integration Build and Integration Configure domains

---

## GoBD Integration

### Concept

Extracts tax-relevant data from Workday and generates audit files for German tax authorities under **category Z3** of GoBD regulations. Produces up to four audit files depending on the source data provided.

### Setup

- Create integration system using the **GoBD Template**
- Optional: configure field overrides for additional fields related to customer invoices, expense reports, journals, or supplier invoices
- Create ISU with Get and Put access to the Integration Event domain
- Configure launch parameters: Account Set, Ledger, Book, Time Period, Period

### Launch Parameters

| Parameter | Purpose |
|---|---|
| Account Set | Source accounts for the audit data |
| Ledger | Ledger type used to generate files |
| Book | Accounting standards book |
| Time Period | Overall reporting period |
| Period | Specific interval within the time period |

### Output Files

The integration generates a ZIP folder containing:
- **DEU Audit File Customer Invoices** (CSV)
- **DEU Audit File Expenses** (CSV)
- **DEU Audit File GL Entries** (CSV)
- **DEU Audit File Supplier Invoices** (CSV)
- XML index file
- DTD validation file

CSV files use semicolons as delimiters and round values to 2 decimal places.

### Digital Audit Submission

For Z3 audits, submit the complete ZIP folder (CSVs + DTD + XML index) to the tax auditor.

### Prerequisites

- Security: Integration Build and Integration Configure domains

---

## SAF-T Integrations

### Concept

Standard Audit File for Tax — generates XML output files complying with SAF-T requirements. Workday provides three templates:

| Template | Schema | Use Case |
|---|---|---|
| SAF-T Core | OECD SAF-T v2.0 | Multi-country; configurable for other v2.0-compatible schemas |
| SAF-T Norway 1.1 | Norwegian SAF-T Financial v1.10 | Norway |
| SAF-T Norway 1.3 | Norwegian SAF-T Financial v1.30 | Norway (2026R1+) |

For countries with schemas that differ in structure from OECD v2.0, use the Core template output as a data source for a custom integration step to transform the structure.

### Setup

- Create integration system using the appropriate SAF-T template
- Optionally enable **SAF-T Schema Retrieval** to provide a different schema
- Optionally enable source document services (Core template only): SAF-T_SalesInvoices, SAF-T_PurchaseInvoices, SAF-T_SupplierPayments, SAF-T_CustomerPayments
- Create ISU with Get and Put access to Integration Event and Process: Tax Master domains
- Configure integration attributes
- Optional: field overrides for extension points; field attributes for max lengths
- Optional: add a custom integration step on the business process to transform output structure (Core only)

### Integration Services

| Service | Description |
|---|---|
| SAF-T_CustomerPayments | Include customer invoice payments |
| SAF-T_PurchaseInvoices | Include approved AP transactions (Core only) |
| SAF-T_SalesInvoices | Include approved AR transactions (Core only) |
| SAF-T_Schema_Retrieval | Provide custom SAF-T schema |
| SAF-T_SupplierPayments | Include supplier invoice payments |

### Output Files

- ZIP file containing the SAF-T XML
- Message log HTML (first 500 errors) — generated only when validation errors occur

### Prerequisites

- SAF-T data created in Workday (review setup considerations for SAF-T)
- Security: Integration Build and Integration Configure domains

---

## DAS2 Integration

### Concept

Generates the French DAS2 declaration of payments made to third parties in the electronic TD/Bilatéral format. Reports the totals of supplier invoice payments (including adjustments), ad hoc payments, and miscellaneous payments when the total paid to a payee exceeds the threshold set by the tax authority.

### Setup

- Access **Maintain Third-Party Payments Configuration** → Aggregate Category Mapping → map DAS2 payment categories to Workday spend categories/hierarchies → set the threshold
- Optional: create supplier classifications to differentiate companies from individuals (names, profession)
- Create integration system using the **DAS2** template
- Create ISU with Get and Put access to the Integration Event domain
- Configure integration attributes (select Individual Supplier Classification if using individual classifications)
- Optional: configure field overrides on the IndividualAsSupplier subdocument
- Launch the integration

### Key Configuration Decisions

- **Threshold**: set via Aggregate Category Mapping — payees below threshold are excluded
- **Individual vs. company payees**: use supplier classifications and field overrides to provide first name, last name, and profession for individuals
- **Payee inclusion**: assign the DAS2 tax authority form type to ad hoc payees, contingent workers, miscellaneous payees, or suppliers

### Source Data Requirements

- All fields must have values (Workday inserts zero or space when blank — avoid this by completing all data)
- French companies and payees require: full address with street number extension (Bis/Ter/Quater/Quinquies), numeric postcode not beginning with 00, APE code, SIREN, SIRET
- SIRET cannot be entered for ad hoc payees or contingent workers — use these types only for payees outside France

### Output Files

- ZIP file containing the DAS2 text file (TD/Bilatéral format)

### Prerequisites

- Company: address with valid extension and postcode, SIREN, SIRET, APE code tax IDs
- Payees: address, payee category, DAS2 tax authority form type
- Security: Set Up: Tax domain; Integration Build and Integration Configure domains

---

## Tax ID Validation Integrations

### Concept

Validates tax IDs in the tenant by submitting them to an external validation service. Supports:
- **VIES** (European VAT Information Exchange System) — EU member states
- **HMRC** Check a UK VAT Number — United Kingdom

Can be configured as a standalone process, a Data Initialisation Service (DIS), or a business process step.

### Supported Tax ID Formats

| Service | Format Requirements |
|---|---|
| VIES | Country code + 2–12 characters; special characters only for Netherlands |
| HMRC | 9 or 12 digits, no spaces or special characters |

### Setup Options

**Option A — Manual/scheduled launch:**
- Create integration system using the **Tax ID Validation** template
- Launch or schedule; optionally filter by Entity Type (company, customer, supplier)

**Option B — Data Initialisation Service (DIS):**
- Create a custom report with fields: Country for Tax ID, Tax ID, External Validation Service
- Configure a DIS on the integration system populated by the custom report
- Leave launch parameters blank to avoid duplicate validation

**Option C — Business process step:**
- Add the integration as a step on any business process with a report field returning tax IDs
- Specify tax IDs in the Tax IDs prompt (Tax IDs by Validation Service and Entity Type must be blank)

### VIES Supported Countries

Austria, Belgium, Bulgaria, Croatia, Cyprus, Czechia, Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy, Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden, United Kingdom (Northern Ireland only).

### Results

Workday stores:
- Valid/Invalid status
- Date and time of check
- Name and address from government data (when provided)
- Last 5 responses visible in the Validation Status column on reports

### Prerequisites

- Tax IDs must comply with the format requirements of the target validation service
- Security: Integration Build, Integration Configure domains; Set Up: Tax domain

---

## Troubleshooting Tips

### General

- Check the **Output Files** tab on the integration event for message logs — most connectors generate an HTML log with the first 500 validation errors
- Ensure the ISU has Get and Put access to relevant domains before launching
- For large data volumes (FEC, SAF-T), schedule runs outside business hours and limit to monthly periods

### ELSTER

- Tax declaration run must be **approved** before generating XML
- Start/End dates must cover a complete month or quarter — partial periods produce no output
- Missing primary public address or phone on the data supplier will omit those elements from the XML

### FEC

- Journal sequencing must be enabled — if disabled, the integration will fail or produce incomplete data
- Validation errors often relate to missing mandatory fields on journal entries

### GoBD

- CSV values are rounded to 2 decimal places — verify source data precision
- All four output files may not appear if the selected account set has no data for certain categories

### SAF-T

- If your country's schema structure differs from OECD v2.0, you must add a custom integration step to transform the output — the standard template cannot restructure the XML
- Field attributes with max length of zero will ignore Workday-specified limits — use deliberately

### DAS2

- Missing data is replaced with zeros/spaces — this can cause rejection by the tax authority; complete all required fields before running
- SIRET cannot be set for ad hoc payees/contingent workers — use supplier records for French payees

### Tax ID Validation

- Ensure IDs match format requirements exactly (country code + correct length for VIES; digits only for HMRC)
- When using DIS, leave launch parameters blank to avoid duplicate validation calls
- Only the 5 most recent validation responses are displayed — run a custom report for full history
