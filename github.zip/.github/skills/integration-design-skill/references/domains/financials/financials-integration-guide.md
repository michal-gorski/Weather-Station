# Financials Integration Guide

Overview and decision hub for Workday financials integrations. For deep technical detail, see the dedicated connector references in this folder.

---

## Connector Catalog

| Connector | Direction | Purpose |
|-----------|-----------|---------|
| Accounting Journal Connector | Inbound | Import journal entries from external GL systems (CSV or XML) |
| Ad Hoc Bank Transaction Connector | Inbound | Import one-off bank transactions (XML or CSV) |
| Bank Fee Analysis Connectors | Inbound | Import bank fee statements for analysis |
| Bank Statement Import | Inbound | Import bank statements (BAI2, SWIFT MT940/942, CAMT.053) |
| Contract Management Integration | Outbound | Transfer financial business documents to contract management |
| Credit Card Integrations | Inbound | Import credit card transactions (MasterCard CDF3, Visa VCF4, etc.) |
| Currency Exchange Rate Connector | Inbound | Import daily/periodic exchange rates |
| Customer Lockbox Integration | Inbound | Import customer payment lockbox files |
| DAS2 Integration | Outbound | Generate French DAS2 tax declaration |
| EBICS Integrations | Both | Electronic Banking Internet Communication Standard connectivity |
| EDI Supplier Integrations | Both | EDI 810 (invoices), 850 (POs), 855 (PO acks), 856 (ASNs) |
| Electronic Invoice Connector | Outbound | Generate electronic invoices (UBL 2.1, cXML) |
| Electronic Payment Integrations | Outbound | Process electronic payments and 1099 filing |
| ELSTER Integrations | Outbound | German tax declaration (periodic VAT return) |
| FEC Integration | Outbound | French FEC audit file generation |
| Financial Journal Lines Outbound | Outbound | Export journal line data for external reporting |
| Financial Management Connector for Salesforce | Both | Sync financial data with Salesforce |
| GoBD Integration | Outbound | German GoBD compliance audit export |
| Inventory Label Data Integrations | Outbound | Export inventory label data for printing/tracking |
| Payment Connector | Outbound | Generate payment files for banks |
| Payments Inbound | Inbound | Import payment status reports and credit card payments |
| Payroll Journal Line Export | Outbound | Export payroll journal entries to external GL |
| PSA Inbound Connector | Inbound | Import project/resource data from PSA systems |
| Punchout Integrations | Both | Supplier punchout catalogue and PO integration (cXML) |
| SAF-T Integrations | Outbound | Standard Audit File for Tax (Nordic/European compliance) |
| Supplier Accounts Integrations | Inbound | Import electronic invoices from suppliers |
| Third-Party Payments Integration | Outbound | Send payment data to third-party processors |
| Travel Booking Inbound Connector | Inbound | Import travel booking data from TMCs |
| Tax ID Validation Integrations | Both | Validate VAT/tax IDs (e.g. VIES) |
| Workday Bank Connectivity | Both | Managed bank connectivity via Kyriba (payments, statements, positive pay) |

---

## Integration Selection by Use Case

### Banking and Payments

| Scenario | Connector |
|----------|-----------|
| Import bank statements | Bank Statement Import |
| Send payment files to banks | Payment Connector or Workday Bank Connectivity |
| Import payment status/acknowledgements | Payments Inbound or Bank Connectivity - Import Payment Status |
| Positive pay file generation | Workday Bank Connectivity - Positive Pay |
| Bank fee analysis | Bank Fee Analysis Connectors |
| One-off bank transactions | Ad Hoc Bank Transaction Connector |
| Credit card transaction import | Credit Card Integrations |
| Customer lockbox payments | Customer Lockbox Integration |
| EBICS-based banking (Germany/France) | EBICS Integrations |

### Procurement and Suppliers

| Scenario | Connector |
|----------|-----------|
| Supplier catalogue punchout | Punchout Integrations |
| EDI purchase orders (850) | EDI Supplier Integrations |
| EDI invoices from suppliers (810) | EDI Supplier Integrations |
| EDI PO acknowledgements (855) | EDI Supplier Integrations |
| EDI advance ship notices (856) | EDI Supplier Integrations |
| Electronic invoicing to customers | Electronic Invoice Connector |
| Electronic invoices from suppliers | Supplier Accounts Integrations |

### General Ledger and Journals

| Scenario | Connector |
|----------|-----------|
| Import journal entries from external system | Accounting Journal Connector |
| Export journal lines for external reporting | Financial Journal Lines Outbound |
| Export payroll journals to external GL | Payroll Journal Line Export |

### Tax and Compliance

| Scenario | Connector |
|----------|-----------|
| German VAT return (ELSTER) | ELSTER Integrations |
| French DAS2 declaration | DAS2 Integration |
| French FEC audit file | FEC Integration |
| German GoBD compliance | GoBD Integration |
| Nordic/European SAF-T | SAF-T Integrations |
| VAT ID validation (EU VIES) | Tax ID Validation Integrations |
| US 1099 electronic filing | Electronic Payment Integrations |

### Other

| Scenario | Connector |
|----------|-----------|
| Exchange rate updates | Currency Exchange Rate Connector |
| Salesforce financial sync | Financial Management Connector for Salesforce |
| Travel booking import | Travel Booking Inbound Connector |
| PSA project data import | PSA Inbound Connector |
| Inventory label export | Inventory Label Data Integrations |
| Contract document transfer | Contract Management Integration |
| Third-party payment processing | Third-Party Payments Integration |

---

## Common Patterns

### Workday Bank Connectivity vs Direct Bank Integration

**Workday Bank Connectivity** (via Kyriba) is the managed approach — Workday handles the bank connection, file formatting, and transmission. Use when:
- Customer wants a managed service with less operational overhead
- Multiple banks need connecting through a single hub
- Customer prefers not to manage SFTP/file drops

**Direct bank integration** (Payment Connector + Bank Statement Import) gives more control:
- Customer has existing bank connectivity infrastructure
- Specific file format requirements not supported by Bank Connectivity
- Cost sensitivity around the managed service

### EDI Integration Patterns

EDI connectors support pre and postprocessors for data transformation. Common use cases:
- Map internal item codes to vendor codes
- Apply tax calculations
- Generate acknowledgement documents
- Split large files by supplier

### Accounting Journal Import Patterns

The Accounting Journal Connector accepts CSV or XML. Key decisions:
- **CSV** — simpler for flat journal files, limited to basic fields
- **XML** — full schema support including worktags, attachments, and multi-currency

Always validate the journal source against the Workday chart of accounts before go-live.

---

## Anti-Patterns

- **Using EIB for high-volume bank statement imports** — Use the Bank Statement Import connector instead; EIBs lack the format parsing and reconciliation features
- **Manual exchange rate entry** — Always automate via the Currency Exchange Rate Connector for production
- **Skipping the DIS step for initial data loads** — Data Initialization Service is required for loading opening balances; the Accounting Journal Connector alone does not handle carry-forward correctly
- **Direct SFTP without Bank Connectivity evaluation** — Evaluate managed connectivity first; it reduces operational burden and provides built-in monitoring
