# Other Financials Connectors Reference

This reference covers miscellaneous Workday financials connectors: PSA Inbound, Travel Booking Inbound, Financial Management Connector for Salesforce, Inventory Label Data, Contract Management, and Third-Party Payments.

---

## PSA Inbound Connector

### Concept

The Professional Services Automation (PSA) Inbound Connector imports worker data from an external endpoint into Workday, enabling PSA applications. Use it when a non-Workday application is the source of truth for worker data that needs synchronising with Workday HCM.

**Capabilities:**
- Create and update supervisory organisations
- Assign organisational roles for supervisory organisations
- Hire and terminate employees and contingent workers
- Change worker data (organisation assignments, positions, names, contact information)
- Deactivate Workday accounts

**Limitations:**
- Cannot rescind or correct business processes — requires a System Administrator for corrections
- Requires HCM functional consultant expertise for setup

### Prerequisites

- Workday Core Financials solution must exist in the tenant
- External endpoint capable of generating change data in Workday-defined XML format
- The following business processes must complete automatically:
  - Add/Update Supervisory Organization, Assign Roles, Change Organization Assignments, Contact Change, Contract Contingent Worker, Edit Position, End Contingent Worker Contract, Hire, Hiring Restrictions, Legal Name Change, Move Workers (By Organization), Preferred Name Change, Termination
- Pre-configure: countries, employee types, job profiles, locations, termination reasons, time types

### Setup (Key Steps)

1. Configure external endpoint to generate data in supported XML format
2. Create Integration System using template **Core Connector: Professional Services Automation Inbound**
3. Enable optional integration services (e.g. Document Delivery, Document Retrieval, Post-Processing)
4. Create ISU with Get/Put access to **Manage: Organization Update Integration** domain
5. (Optional) Create Integration Business Process for document delivery/retrieval workflow
6. Configure Integration Retrieval for file pickup from external server
7. Schedule or manually launch the integration

### Integration Attributes

| Attribute | Purpose |
|-----------|---------|
| Input File Retrieval Label | Custom label for document retrieval (overrides default "Retrieved") |
| Include Web Service Requests in Message Audit | Debug aid — significantly increases audit file size |
| Create Errors Only File | Generates XML file containing only failed input records |
| Configure Files for External Delivery | Delivers Errors Only File externally (requires Create Errors Only File) |
| Document Retention Policy | Days to retain output (default: 30) |

### Integration Services

| Service | Purpose |
|---------|---------|
| Deployed Service | Imports certification achievements |
| Connector Service | Launches the integration |
| Supervisory Organizations DIS | Imports supervisory organisation data |
| Workers DIS | Imports worker data |
| Document Retrieval Service | Retrieves file from external location |
| Post-Processing Service | Additional processing after file load |
| Document Delivery Service | Delivers files to external location |

### File Format

- Workday-defined XML schema (namespace: `urn:com.workday/ProfessionalServicesAutomation`)
- Top-level element: `Professional_Services_Automation_Data`
- Major data sections: Create/Update Supervisory Organization, Hire Employee, Change Employee Legal/Preferred Name, Maintain Contact Information, Change Organization Assignments, Change Position, Move Organization, Terminate Employee, Contract/End Contingent Worker, Role Assignments

### Process Flow

1. External endpoint generates XML file and places on file server
2. Integration launches (scheduled or manual)
3. File retrieved per Document Retrieval configuration; document tags applied
4. If file not in Workday XML format, Document Transformation converts it
5. Connector calls multiple web services in sequence
6. Data imported into Workday

### Audit Files

- **DataChangesAudit.html** — readable version of import data
- **DiagnosticAudit.html** — all errors from the run
- **Errors Only File** — XML of failed records (can be corrected and reloaded)
- **MessageAudit.html** — information about previous runs (ZIP)

---

## Travel Booking Inbound Connector

### Concept

The Travel Booking Inbound Connector loads travel booking data from a third-party travel management company (TMC) into Workday. It provides a unified view of corporate travel bookings, supports accruals and management reporting, and reduces data entry by populating expense report lines from booking records.

**Travel types supported:**
- Air travel
- Hotel reservations
- Car rentals

### Prerequisites

- External server accessible by both the TMC endpoint and the integration system
- Travel booking provider generates files in Workday XML format, **or** a Document Transformation integration converts the provider's native format

### Setup (Key Steps)

1. Create Integration System using template **Import Travel Booking Records**
2. Enable optional Dynamic Map Services (Airlines, Car Rentals, Cities, Hotels)
3. Create ISU with access to **Process: Travel Booking** domain
4. Configure integration attributes (Default Company, ISO Currency/Country Code types)
5. Map integration data (travel type, booking status, purchase status, class of service)
6. Set up sequence generators and integration retrieval
7. Schedule the integration
8. Create a Document Transformation integration to convert inbound files to required XML format

### Integration Attributes

| Attribute | Purpose |
|-----------|---------|
| Default Company | Fallback company when Employee ID has no matching company |
| ISO Currency Code Type | Currency code format in inbound file (default: ISO Alphabetic) |
| ISO Country Code Type | Country code format in inbound file (default: ISO 2-character) |
| Dynamic Map Services | Accept Workday-delivered settings; modify only with Workday Support guidance |

### Integration Maps

Map external values to Workday internal values for:
- Travel Type
- Booking Status
- Purchase Status
- Class of Service

**Important:** Map values are case-sensitive and space-sensitive.

### File Format

- Workday-defined XML schema (namespace: `urn:com.workday/travelbookingconnector`)
- Top-level element: `TravelBookingFile` containing `Travel_Booking_Record` elements
- Key required fields: `Travel_Provider_Booking_Record_ID`, `Travel_Provider`
- Key optional fields: Employee_ID, Booking_Date, Ticket_Number, Itinerary_Number, Travel_Type, Booking_Status, Class_Of_Service, location codes, amounts, dates, credit card details
- Amount fields: Decimal with 6 fraction digits, 26 total digits
- Currency codes: 3-letter alpha or 3-digit numeric
- Country codes: 2 or 3 letter alpha

### Process Flow

1. Connector retrieves file from TMC's external server
2. Document Transformation converts file to required XML format
3. Connector reads transformed XML and loads data into Workday

### TMC Integration Pattern

Most TMCs do not produce Workday-native XML. The standard pattern is:
1. TMC drops a file (CSV, proprietary format) on a shared server
2. A Document Transformation integration converts it to Workday XML
3. The Travel Booking Inbound Connector retrieves the transformed file

---

## Financial Management Connector for Salesforce

### Concept

The Financial Management Connector for Salesforce is a prebuilt, configurable Salesforce app (available on AppExchange, requires separate purchase) that integrates Salesforce sales data with Workday Financials. It is **not** hosted in Workday — it runs within your Salesforce tenant.

**Capabilities:**
- Import selected sales data from Salesforce into Workday (Salesforce → Workday)
- Display Workday customer activity data in Salesforce (Workday → Salesforce)
- View in Salesforce without a Workday account: Invoices, Payments, Adjustments, Writeoffs, Payment Returns, Refunds, Transfers In/Out

**Key features:**
- Two-way integration with configurable synchronisation rules
- Scenario-based mapping (multiple scenarios per Salesforce object)
- Exponential back-off retry for 24 hours on sync failure
- Built-in integration logs and sync status reports

### Prerequisites

- Separate purchase of the Workday Financial Management Connector app from Salesforce AppExchange
- Salesforce administrator access
- Workday tenant with appropriate security configuration

### Setup (Key Steps)

**Salesforce side:**
1. Download and install from AppExchange (Install For Admins Only)
2. Grant permission sets: Workday System Admin Set (Read/Edit + Sync), Workday Customer Support Set (Read + Sync), Workday Others Set (Sync only)
3. Add Workday app tab in Salesforce
4. Configure remote site settings (Web Services URL, Cloud Listener/ESB URL)
5. Create security certificate
6. Configure page layouts and field-level permissions

**Workday side:**
7. Register API Client: JWT Bearer Grant, X.509 certificate, Bearer access token, scope includes Customer Accounts, Customer Contracts, Customers, Integration, Project Tracking, Worktags
8. Create ISU with Get/Put access to: Customer Event, Create Project, Integration Event/Process, Manage: Related Worktags, Process: Opportunity, Reports: Customer Accounts, Set Up: Customer Maintenance, View: Customer (plus optional banking/credit/payment/summary change event BPs)

**App configuration:**
9. Add environment in app (Environment Name, User, Tenant, Token Endpoint, Integration Endpoint, REST API Endpoint, Certificate, Client ID)
10. Configure Salesforce → Workday sync settings
11. Configure Workday → Salesforce sync settings
12. Test endpoints
13. Create scenarios: select object, define sync rules, add field/value mappings

### Scenario Configuration

Scenarios define what syncs and how:
- Select the Salesforce object to map
- Specify synchronisation rules (when data is sent)
- Add field mappings (including custom fields like Customer Category, Currency, Company)
- Add value mappings (e.g. state/country codes)
- Multiple scenarios can map the same Salesforce object to different Workday objects
- Scenarios sync alphabetically by name

### Integration Process

- As events occur in Salesforce, they are queued internally
- At scheduled sync time (or on-demand via Sync Now), data is sent to Workday
- On failure: exponential back-off retry for up to 24 hours
- Reports available: Current Sync Item Status, Integration Logs

---

## Inventory Label Data Integrations

### Concept

Workday provides integration templates to export inventory label data in a Workday-defined file format for use with external label printing services or applications. You can configure which data fields appear in the output using configurable data sections, report fields, and calculated fields.

### Available Templates

| Template | Purpose |
|----------|---------|
| Inventory Label Printing Locations | Location label data |
| Inventory Label Printing Goods Delivery Groups | Goods delivery group labels |
| Inventory Label Printing Goods Delivery Tickets | Goods delivery ticket labels |
| Inventory Label Printing Inventory Locations | Inventory location labels (item + location detail) |
| Inventory Label Printing Par Locations | Par location/bin labels |
| Inventory Label Printing Receipts | Receipt line labels |
| Inventory Label Printing Enabled Locations | Enabled locations |

### Setup (Key Steps)

1. Create an Integration System for each required template
2. Create ISU with Get/Put access to **Integration Event** domain
3. Configure integration attributes
4. Configure integration field attributes (select fields for output)
5. Set up integration delivery and sequence generators
6. Add integration steps to relevant business processes:
   - **Inventory Label Event BP**: Locations, Goods Delivery Groups, Par Locations, Goods Delivery Tickets, Inventory Locations, Receipts
   - **Goods Delivery Group BP**: Goods Delivery Groups template
   - **Goods Delivery Event BP**: Goods Delivery Tickets template (with Create Goods Delivery Run service step)
   - **Receipts BP**: Receipts template

### Data Sections (Summary)

**Goods Delivery Groups:** Group Number, Description, Assigned To, Created Date, Number of Copies, Label Printer, Label Template

**Goods Delivery Tickets:** Ticket details, Created Date/Worker, Deliver-To address, Origin, Requester, Originating Business Document

**Inventory Locations:** Location identifiers (GLN, name, external name), Inventory Location Attributes (site, zone, chain, usage type), Item Descriptor (name, ID, GTIN, CAS, spend category, UOM, manufacturer, unit price, hazardous/controlled flags), Item Inventory Attributes (reorder point, order quantity, ABC classification, lead time)

**Locations:** Location identifiers, hierarchies, superior location, worksite ID, inventory attributes (site, zone, chain, source site)

**Par Locations:** Location, Bin, Item details, Par Level, Par Company, Replenishment Source, UOM, Just In Time flag

**Receipts:** Receipt line data

### Field Overrides and Extensions

After setup, use **Configure Integration Field Override** to:
- Override field mappings at header and/or line layer
- Add custom XML elements via the External Fields section

### Output Files

Each run generates:
- **Data Changes Audit file** — readable version of integration output (may contain sensitive data)
- **Diagnostic Audit file** — troubleshooting information for integration errors

---

## Contract Management Integration

### Concept

The Contract Management (Evisort) document transfer functionality migrates and synchronises financial business documents from Workday to Contract Management and Document Intelligence. It is designed for customers who use Contract Management and Document Intelligence to analyse existing and ongoing Workday contract data.

**Use cases:**
- Initial large-scale sync: migrating years of existing documents for baseline analysis
- Ongoing synchronisation: regularly syncing new documents as they are added
- Targeted transfers: using customised report filters to sync specific document types

### Integration Types

| Type | Description |
|------|-------------|
| Standard Transfer | Uses standard tasks and preconfigured metadata integration system; supports immediate or scheduled migrations |
| Custom Integration | Template-based (Evisort Document Transfer Connector); supports subfolders by external party, folder mapping, custom tags via Field Override Framework |

**Custom integration features:**
- **Automated subfolder organisation:** Append destination folder with sub-folder per external party (e.g. by Customer ID or Supplier ID)
- **Folder mapping:** Specify destination folders based on document type
- **Custom tags:** Send additional Workday information as custom tags

### Setup (Key Steps)

1. Copy the standard **Syncable Document** report and customise filters
2. (Optional) Create Integration System using template **Evisort Document Transfer Connector**
3. (Optional) Create ISU with Get/Put access to: Process: Transfer Document to Evisort, Public Reporting Items
4. Transfer documents using:
   - **Transfer Document to Evisort** task — immediate, manual transfers
   - **Schedule Transfer Document to Evisort** task — automated recurring sync

### Security

Configure the security policy for **Process: Transfer Document to Evisort** domain in the Common Financial Management functional area.

### Scope

Supports both customer and supplier contracts. Financial business documents in Workday are synchronised to Contract Management and Document Intelligence, where subfolder organisation by external party is available when enabled.

---

## Third-Party Payments Integration

### Concept

Some tax authorities require companies to report payments made to third parties. The Third-Party Payments integration template exports payment details to an XML audit file. You can set threshold values to exclude payments below specified amounts.

**Payments exported (in company base currency):**
- Supplier invoice payments (including adjustments)
- Ad hoc payments
- Miscellaneous payments
- Corrections via accounting adjustments

**Payee types included:**
- Ad hoc payees
- Contingent workers
- Miscellaneous payees
- Suppliers

**Note:** You can exclude payment types but cannot exclude individual payees.

### Setup (Key Steps)

1. Create Tax Authority Form Type — define payment categories, exclude irrelevant payment types
2. Maintain Third-Party Payments Configuration — map payment categories to Workday spend categories/hierarchies and set thresholds
3. Create Integration System using template **Third-Party Payments**
4. Create ISU with Get/Put access to **Integration Event** domain
5. (Optional) Configure integration attributes and field overrides
6. (Optional) Select connector output fields to include/exclude
7. Launch the integration

### Threshold Configuration

Two mapping approaches:

| Approach | Description |
|----------|-------------|
| Aggregate Category Mapping | Group payment categories and set a threshold per group (e.g. Accommodation + Food > 2,000) |
| Category Mapping | Set individual thresholds for each payment category |

**Example (Aggregate):**
- Accommodation + Food threshold: 2,000 → combined total 2,225 → included
- Fees + Other Payments threshold: 1,800 → combined total 1,800 → included (equal to threshold counts)

**Example (Per-payee threshold):**
- Map all categories to one group with a single threshold (e.g. 1,200) → includes all payees exceeding that total in the period

### Output

- ZIP file containing XML output, available on the Output Files tab of the integration event
- If the tax authority requires a different format, create a custom integration (e.g. Document Transformation) to convert the XML

### Related Integrations

- **DAS2 Integration** — French-specific third-party payments declaration (uses similar patterns)

---

## Common Patterns Across These Connectors

- All use Integration System Users (ISUs) with domain-level security grants
- Most support Document Retention, Sequence Generators, and Delivery/Retrieval configuration
- Inbound connectors (PSA, Travel Booking) typically require a Document Transformation integration when the source system cannot produce Workday-native XML
- Outbound connectors (Inventory Labels, Third-Party Payments) generate Workday-defined XML that may need further transformation for downstream systems
- Integration maps are case-sensitive and space-sensitive across all connectors
