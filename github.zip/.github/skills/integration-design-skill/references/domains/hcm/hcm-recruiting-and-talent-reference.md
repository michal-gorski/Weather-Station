# HCM Recruiting and Talent Connectors Reference

This reference covers Workday connectors for recruiting, talent management, and job-related data integration. All connectors generate output in Workday XML format unless stated otherwise, and typically require Document Transformation for downstream system compatibility.

---

## Core Connector: Job Postings

### Overview

Exports all active job postings from Workday to external job posting services or websites. As postings are created, updated, or unposted, the integration generates an output file containing all active postings.

**Use when:** Sending job posting content to external career sites, job boards, or aggregators.

### Setup (Condensed)

1. Create integration system using template `Core Connector: Job Postings`
2. Enable optional integration services (Filename Sequence Generator, Document Delivery, Document Retention)
3. Create ISU with Get/Put access to: Integration Event, Job Postings: External, Job Postings: Internal
4. Configure Integration Maps — all Internal Values must map to an External Value (or set a Default Value)
5. Configure Integration Attributes
6. Set up integration delivery and (optionally) add as an integration step on the Post Job business process
7. Configure Document Transformation for the required output format

### Integration Services

| Service | Required | Purpose |
|---------|----------|---------|
| Job Postings Init Svc | Yes | Extracts job posting data, generates XML output |
| Filename Sequence Generator | Optional | Unique sequenced filenames |
| Document Delivery Service | Optional | Delivers output via AS2, FTP, FTPS, SFTP |
| Integration Document Retention | Optional | Stores output files for audit |
| Transaction Log Service | N/A | Do not enable |

### Launch Options

- **Business process step** — add to the Post Job BP for event-driven launch
- **Scheduled** — recommended daily frequency; collects all active postings
- **Manual** — launch immediately with optional parameters

**Launch parameters:** Job Requisition(s), Job Posting(s), Job Posting Site Name(s), Job Posting Start Date, Job Posting End Date.

### Output Schema

XML namespace: `urn:com.workday/coreconnector/outbound/jobpostingsout`

Key fields: Job_Posting_ID, Job_Posting_Title, Job_Posting_Description, Job_Posting_Site, External_Job_Path, External_Apply_URL, Job_Requisition_ID, Primary_Posting_Location, Additional_Posting_Locations, Job_Posting_Start_Date, Job_Posting_End_Date, Job_Family, Time_Type, Job_Type, Supervisory_Organization, Similar_Jobs, Additional_Data.

### Security

ISU requires Get/Put on: Integration Event, Job Postings: External, Job Postings: Internal (Integration functional area).

---

## Core Connector: Job Requisitions

### Overview

Exports changes to job requisition data from Workday in XML format. As requisitions are created, updated, or deleted, the integration generates output containing the changes. Provides a configurable set of data across multiple categories with field-level selection.

**Use when:** Sending open/closed/future position data to external recruiting systems, workforce planning tools, or analytics platforms.

**Do not use for:** Tracking changes to a worker in a position, or evergreen job requisitions.

### Setup (Condensed)

1. Create integration system using template `Core Connector: Job Requisitions`
2. Enable optional services (Transaction Log, Position Data, Job Qualification Data, Delivery, etc.)
3. Create ISU with Get/Put access to: Integration Event, Job Requisition Data
4. (Optional) Configure Integration Transaction Log subscriptions
5. Configure Integration Attributes and Maps
6. Select and configure output fields (field-level inclusion/exclusion, required flags, truncation)
7. (Optional) Add custom fields
8. Set up delivery and Document Transformation
9. Launch/schedule the integration

### Key Integration Attributes

- **Country Code Type** — ISO-3166-1-Alpha-2 or Alpha-3
- **Required Field Validation** — Omit (exclude errored records) or Include (include with warnings)
- **Include Prior Values** — includes previous field values alongside current
- **Format Line Breaks For HTML** — converts line breaks in job description to `<br>`
- **Include Non-Recruitable Job Requisitions** — includes requisitions not flagged for recruiting

### Change Detection

Uses a three-step process:
1. Checks transaction log for requisitions with matching transactional changes
2. Compares current values against last successful run values
3. Generates creation, change, or deletion messages for requisitions with changed fields

**Full-Diff Extract:** Disable Transaction Log Service to extract all requisition data regardless of changes (performance impact — use with caution).

### Data Sections

| Section | Key Fields |
|---------|-----------|
| Job Requisition Data | Requisition ID/Status, Supervisory Org, Job Posting Title, Positions Allocated/Available, Job Description, Recruiting Start/Target Hire/Target End Dates, Job Profile, Worker Type, Location, Time Type, Scheduled Hours, Work Shift |
| Job Qualification Data | Competency, Certification, Education, Language, Responsibility, Training, Work Experience qualifications (each with sub-fields) |
| Position Data | Position-related fields for the requisition |

### Launch Parameters

- As Of Entry Moment / Effective Date / Last Successful dates — for incremental change detection
- Full Extract — extracts all regardless of changes
- Job Requisition(s), Location(s), Supervisory Organization(s) — filters

### Security

ISU requires Get/Put on: Integration Event, Job Requisition Data.

---

## Core Connector: Job Profile and Job Family

### Overview

Exports job family and job profile definitions from Workday. Provides a single source-of-truth for core job-related reference data that can be transformed for multiple downstream endpoints.

**Use when:** Synchronising job catalogue data (profiles, families, classifications) to external HRIS, learning management, or talent systems.

### Setup (Condensed)

1. Create integration system using template `Core Connector: Job Profile and Job Family`
2. Enable optional services: Job Family Data Section Fields, Job Profile Data Section Fields
3. Configure Integration Attributes and Maps
4. Create ISU with Get/Put access to: Integration Event, Job Information
5. Select and configure output fields
6. Set up delivery, sequence generator, and (optionally) Document Transformation
7. Launch/schedule

### Data Sections

| Section | Key Fields |
|---------|-----------|
| Job Family Data | Job Family ID, Inactive flag, Job Family Name, Job Family Summary, Job Profile |
| Job Profile Data | Job Profile ID, Inactive, Job Title, Job Profile Summary, Public Job, Work Shift Required, Management Level, Job Category, Job Level, Job Family, Job Classifications, Job Exempt, Compensation Grade, Company Insider Type, Critical Job, Difficulty to Fill, Pay Rate Country/Type, Workers Compensation Code |

### Launch Parameters

- As Of Entry Moment / Effective Date / Last Successful dates
- Full Extract — extracts all profiles/families regardless of changes
- Job Families / Job Profiles — extract specific items only

### Security

ISU requires Get/Put on: Integration Event, Job Information.

---

## Core Connector: Candidate Outbound

### Overview

Exports candidate and job application data from Workday to external applications. Detects changes from job applications, job requisitions, prospect profiles, and recruiting business processes.

**Use when:** Sending candidate/application data to external ATS, CRM, or analytics systems.

**Does not track:** Delegated/reassigned tasks, Approval steps, Review Documents steps, or To Do steps.

### Setup (Condensed)

1. Create integration system using template `Core Connector: Candidate Outbound`
2. Enable optional services (DIS Performance Log, Effective Stack Performance Log, Document Retention, Integration Maps)
3. Configure Integration Field Attributes — select which candidate fields to include
4. Configure Integration Attributes and Maps
5. Create ISU with Get/Put on Integration Build domain (plus custom field domains if applicable)
6. Launch with appropriate criteria

### Launch Modes

| Mode | Behaviour |
|------|-----------|
| Full File ✓, Change Detection ✗ | Exports all data |
| Full File ✗, Change Detection ✓ | Exports only updated data with prior values |
| Full File ✓, Change Detection ✓ | Exports only updated data without prior values |

### Security

ISU requires Get/Put on: Integration Build (plus domains for any custom fields added).

---

## Core Connector: Background Check Order

### Overview

Connects Workday to external background check vendors through two integration systems:
- **Outbound** — sends background check requests to the vendor
- **Inbound** — receives results and updates Workday data

**Use when:** Automating pre-employment or in-employment background screening with third-party providers.

### Setup (Condensed)

**Outbound:**
1. Create integration system using template `Core Connector: Background Check Order Outbound`
2. Enable optional services (Delivery, File Sequence Generator, Document Retention)
3. (Optional) Add Evergreen Requisition field override for evergreen requisition background checks
4. Configure Integration Attributes and Maps
5. Set up delivery and sequence generators
6. Add Integration Steps to Background Check Business Process (see below)
7. Create ISU with access to: Integration Event, Worker Data: Background Check Status, Job Requisition Data, Manage Pre-Hires, Pre-Hire Data: Background Check Status, Candidate Data (Background Check History, Job Application), Manage: Evergreen Requisitions, Worker Data: Public Worker Reports, Pre-Hire/Worker Skills and Experience

**Inbound:**
1. Create integration system using template `Core Connector: Background Check Inbound`
2. Configure Integration Attributes
3. Set up Integration Retrieval
4. Create ISU with access to: Worker Data: Background Check Status, Pre-Hire Data: Background Check Status, Candidate Data: Background Check History, Manage: Evergreen Requisitions

### Business Process Integration

Add steps to the Background Check BP in this order:
1. **Initiation**
2. **Integration** — runs the outbound connector (set Background Check ID to "Determine Value at Runtime"; As of Entry Moment to "Current Moment (DateTime)")
3. **Document Delivery** — sends XML to vendor
4. **Background Check Overall Status** — HR Admin/Manager/Recruiter action
5. **Make Background Check Decision** — (conditional, if sub-event of Recruiting Event)

### Outbound File Schema

XML namespace: `urn:com.workday/coreconnector/outbound/backgroundcheckout`

Key data elements:
- **Header** — integration metadata
- **Background_Check_Data** — Background Check ID, Submission Date
- **Package_Data** — check package details
- **Requester_Data** — Worker ID (Employee/Contingent Worker), name, email, phone
- **Recipient_Data** — Recipient ID (Applicant/Employee/Contingent Worker), name, address, email, phone, education data, work experience
- **Job_Requisition_Data** — requisition context
- **Additional_Data** — extensible elements

### Security

Outbound ISU requires access across Integration, Personal Data, Pre-Hire Process, Recruiting, Staffing, and Worker Profile functional areas. Inbound ISU requires Personal Data (Background Check Status), Pre-Hire Data, and Recruiting domains.

---

## Core Connector: Competency Model

### Overview

Exports competency model definitions from Workday in XML format. As competencies are created, updated, or deleted, generates an output file with the changes.

**Use when:** Synchronising competency frameworks to external learning, performance, or talent management platforms.

### Setup (Condensed)

1. Create integration system using template `Core Connector: Competencies Outbound`
2. (Optional) Set up sequence generators
3. Configure Integration Attributes and Maps
4. Create ISU with Get/Put access to: Integration Event, Set Up: Skills and Experience
5. Select and configure output fields
6. Create Integration Business Process
7. Launch/schedule

### Data Section: Competency Data

Key fields: Competency ID, Competency Name, Competency Description, Competency Category, Inactive flag, plus nested Competency Level data (Level ID, Level Name, Level Behavior, Level Value, Range Begin/End, Exclude from Calculations).

**Note:** The Competency Level attribute does not send data directly but enables the related sub-attributes (Level ID, Name, Behavior, Value, Range).

### Launch Parameters

- As Of Entry Moment
- Effective Date

### Security

ISU requires Get/Put on: Integration Event, Set Up: Skills and Experience.

---

## LinkedIn Recruiter System Connect (RSC)

### Overview

Synchronises data between LinkedIn Recruiter and Workday Recruiting, reducing application switching for recruiters. Supports:
- Candidate data exchange
- LinkedIn InMail import
- Job application stage sharing
- Prospect data
- One-Click Export (export LinkedIn profiles directly to Workday as prospects)

**Three integration templates:**
- LinkedIn Recruiter System Connect Export
- LinkedIn Recruiter System Connect Import
- LinkedIn Recruiter System Connect One Click Export

### Prerequisites

- LinkedIn Recruiter admin licence
- Supported browsers: Chrome, Firefox, Microsoft Edge
- Security: Candidate Data: LinkedIn Recruiter System Connect, Set Up: LinkedIn Middleware (Recruiting functional area)

### Setup: Overall

1. (Optional) Create a recruiting source mapped to Recruiter System Connect for reporting
2. Set up ISU and integration for One-Click Export
3. Edit Tenant Setup – Recruiting > Configure LinkedIn Integrations: select ISU, accept Terms and Conditions
4. Select the LinkedIn RSC integration package in LinkedIn Recruiter Admin
5. Verify enablement in Edit Tenant Setup – Recruiting
6. Configure Inbound integration
7. Configure Outbound integration
8. Add LinkedIn Data reports to profile groups (InMail History, LinkedIn Profile)
9. Set up scheduled integrations

**Important:** When switching to a new environment, repeat configuration. If testing in non-production, contact LinkedIn before going to Production to deactivate and delete test data.

### Inbound Integration (Import)

Imports from LinkedIn to Workday:
- LinkedIn InMail messages
- LinkedIn Profiles

**Setup:**
1. Create integration system from `LinkedIn Recruiter System Connect Import` template
2. Configure LinkedIn Contract ID attribute
3. Create ISU with access to: Candidate Data: Web Service LinkedIn Recruiter System Connect, Integration Event
4. Launch — sync minimum 2 years of historical data (in 1–3 month batches to avoid failures)
5. Schedule ongoing integrations (every 15–60 minutes depending on business needs)

### Outbound Integration (Export)

Sends from Workday to LinkedIn:
- External candidates
- Job applications and stages
- Job postings (as private — not a job posting integration)
- Prospects

**Setup:**
1. Create integration system from `LinkedIn Recruiter System Connect Export` template
2. Configure Included External Job Posting Site attribute; optionally configure Excluded Countries
3. Create ISU with access to: Candidate Data: Web Service LinkedIn Recruiter System Connect, Integration Event
4. Launch — sync 2 years of history (in 1–3 month batches), then schedule every 15–60 minutes

**One per external career site.** Multiple export integrations are supported but only one per site.

### One-Click Export

Enables recruiters to export a LinkedIn profile directly to Workday and attach it to a job requisition. Requires:
1. Create ISU
2. Create unconstrained integration system security group
3. Grant Put access to Candidate Data: Web Service LinkedIn Recruiter System Connect
4. Activate pending security policy changes
5. Create integration from `LinkedIn Recruiter System Connect One Click Export` template (only one allowed)
6. Assign ISU to integration system
7. Enable 1-click export in LinkedIn Recruiter Admin ATS settings

### Scheduled Integrations

After historical data sync, schedule both inbound and outbound:
- Set Integration Start Time to "As Of Entry DateTime of Last Completed Integration Event" (or "...Completed with Warnings")
- Set Integration End Time to "Current Moment (DateTime)"
- Configure Catch Up Behaviour and Dependency settings as appropriate

### Security Considerations

- Workday **excludes confidential candidates and job applications** from export to LinkedIn (different security models)
- Imported LinkedIn data cannot be associated with confidential data in Workday
- Only recruiters with LinkedIn Recruiter access can view exported candidate data in LinkedIn
- Users with candidate/prospect profile security can view imported LinkedIn Profile and InMail data

### Troubleshooting

| Issue | Resolution |
|-------|-----------|
| Internal server errors enabling RSC after multiple attempts | Reset the LinkedIn Middleware integration (removes Workday-side configuration; requires re-setup) |
| InMail data not appearing for prospects | Verify InMail Stub Profile setting is enabled in LinkedIn Recruiter admin; check candidate privacy settings |
| Large data volumes causing integration failures | Reduce sync window to 1–3 months per batch during historical sync |
| Data not displaying for candidates | Verify LinkedIn privacy settings allow data sharing; LinkedIn must match the candidate to a LinkedIn profile |

### Support Boundaries

| Workday Supports | LinkedIn Supports |
|------------------|-------------------|
| Displaying inbound LinkedIn data | All APIs for data transfer |
| Inbound/outbound RSC integrations | All RSC features in LinkedIn Recruiter |
| One-Click Export integration | Candidate matching |
| | InMail history and contact info |
| | One-Click Export data |
| | Onboarding and Profile widgets |

---

## Kenexa Connectors

### Overview

Synchronises data between Workday and IBM Kenexa Talent Acquisition Suite (US workers only). Requires **Job Management staffing model** — not compatible with Position Management.

**Three templates — implement all three for full integration:**
- Kenexa Foundation Data
- Kenexa User Provisioning
- Kenexa Hire Inbound

### Kenexa Foundation Data

Exports organisation, location, job family, job classification, and job profile data to Kenexa BrassRing.

**Integration services:**

| Service | Purpose |
|---------|---------|
| Organizations Data Init Service | Monitors organisation structure changes |
| Locations Data Init Service | Monitors location changes |
| Job Families Data Init Service | Monitors job family changes |
| Job Profiles Data Init Service | Monitors job profile changes |
| Job Classifications Data Init Service | Monitors job classification changes |

**Setup:** Create from template `Kenexa Foundation Data`, enable services, create ISU (Integration Event domain), configure attributes and maps.

### Kenexa User Provisioning

Creates, updates, and disables accounts in Kenexa. Generates a CSV file with worker changes and delivers to SFTP.

**Key attributes:** First Name, Last Name, Middle Name, User Name, Email Address, HRIS Employee Id, Phone Number, Phone Extension, Job Title, Active, Country, Locale, Fax Number, Sender Employee Id, Source, User SSO Id, SSO Enabled.

**Required fields:** First Name, Last Name, User Name, Email Address, HRIS Employee Id, Active, Country, Locale, Sender Employee Id.

**Setup:** Create from template `Kenexa User Provisioning`, create ISU (Integration Event domain), configure Eligibility Criteria (True/False Condition calculated field), configure Field Overrides, set up delivery.

### Kenexa Hire Inbound

Imports new hire data from Kenexa Onboarding XML files via external SFTP.

**Setup:**
1. Create from template `Kenexa Hire Inbound`
2. (Optional) Enable Pay and Tax Service for payment elections and tax data
3. Create ISU with access to: Contract Contingent Worker (BP), Hire (BP), Manage: Payment Election, Manage Pre-Hires, Personal Information Change (BP)
4. Configure Integration Attributes
5. Set up Integration Retrieval from SFTP
6. Launch/schedule

**Uniqueness check:** Configure Worker ID or Custom ID to prevent duplicates across multiple input files and support rehires of previously terminated workers.

### Launch Parameters (Foundation and User Provisioning)

- As Of Entry Moment
- Effective Date
- Last Successful As Of Entry Moment
- Last Successful Effective Date

### Security

- Foundation Data and User Provisioning: ISU needs Get/Put on Integration Event
- Hire Inbound: ISU needs access to Contract Contingent Worker, Hire, Manage: Payment Election, Manage Pre-Hires, Personal Information Change business processes

---

## Inline Assessments

### Overview

Integrates with third-party assessment vendors to register candidates applying via an external career site. Workday sends candidate details to the vendor automatically when a candidate advances past the first application page and the job requires an inline assessment.

**Use when:** External assessments (psychometric tests, skills assessments) must be triggered automatically during the application process.

### Setup (Condensed)

1. Create integration system from template `Inline Assessment`
2. Create ISU with Get/Put access to: Candidate Data: Assessment Results, Integration Event
3. Configure Integration Attributes (vendor endpoint URL, credentials)

### Integration Services

| Service | Required | Purpose |
|---------|----------|---------|
| Inline Assessment Registration – ESB Service | Yes | Launches the integration |
| Integration Document Retention | Yes | Retains copy of each integration file |

### Launch Behaviour

Automatic — triggered when:
- A candidate advances past the first application page on the external career site, AND
- The job requires an inline assessment

No manual launch or scheduling is required.

### Output Format

SOAP XML message containing:
- Assessment_Test_Reference (WID, ID)
- Job_Application_Reference (WID, ID)
- Candidate_Reference (WID, ID)
- Candidate_First_Name
- Candidate_Last_Name
- Candidate_Email

### Security

ISU requires Get/Put on: Candidate Data: Assessment Results, Integration Event.

---

## Talent Profile Inbound Connector

### Overview

Imports worker talent profile updates from an external system into Workday. Supports certifications, competencies, completed training, and worker experience. Enables a non-Workday application to serve as the source-of-truth for talent profile data.

**Use when:** An external LMS, credentialing system, or skills platform needs to update worker talent profiles in Workday.

### Setup (Condensed)

1. Configure external endpoint to generate data in Workday-supported format (XML or CSV)
2. Create integration system from template `Core Connector: Talent Profile Inbound`
3. Enable optional services based on data types to import:
   - Worker Certification Achievement Data
   - Worker Competency Achievement Data
   - Worker Training Achievement Data
   - Worker Experience Data
4. Create ISU with Get/Put access to: Manage Certifications (BP), Manage Competencies (BP), Manage Training (BP), Worker Data: Public Worker Reports, Worker Data: Skills and Experience, Worker Data: Workers
5. Set up Integration Retrieval — for CSV, configure separate retrieval steps per file type with Document Tags:
   - `Talent Profile Inbound Certification`
   - `Talent Profile Inbound Competency`
   - `Talent Profile Inbound Training`
6. Launch/schedule

### Supported File Formats

**XML** — namespace: `urn:com.workday/coreconnector/inbound/talentprofile`

**CSV** — separate files per data type, each with a defined column order.

### File Schema Summary

**Certification (CSV fields):** Worker_ID, Worker_Type, Certification_Reference_ID, Remove_Certification, Certification_ID, Certification_Name, Issuer, Country_Code, Issued_Date, Expiration_Date, Examination_Date, Examination_Score, Certification_Number

**Competency (CSV fields):** Worker_ID, Worker_Type, Competency_Reference_ID, Competency_Level_ID, Note, Assessed_On, Assessed_By_Worker_ID, Assessed_By_Worker_Type

**Training (CSV fields):** Worker_ID, Worker_Type, Training_Reference_ID, Remove_Training, Training_Name, Description, Training_Type_ID, Completion_Date, Training_Duration

**Worker Experience (CSV fields):** Worker_ID, Worker_Type, Experience_Reference_ID, Remove_Experience, Experience_Rating_Reference_ID, Experience_Comment

### XML Structure

Top-level element: `Import_Talent_Profiles_Request` containing unbounded `Worker_Talent_Profile` elements, each with:
- Worker_ID, Worker_Type (defaults to Employee)
- Certification (unbounded) — Reference ID, Remove flag, ID/Name/Issuer, Country, dates, score, number
- Competency (unbounded) — Reference ID, Level ID, Note, Assessed On/By
- Training (unbounded) — Reference ID, Remove flag, Name, Description, Type, Completion Date, Duration
- WorkerExperience (unbounded) — Reference ID, Remove flag, Rating Reference ID, Comment

**Key behaviour:** `Remove_*` boolean fields allow deletion of specific records from a worker's talent profile. Reference IDs must match values defined in Workday.

### Integration Process Flow

1. External endpoint generates file (XML or CSV)
2. File placed on server accessible to the integration
3. Integration retrieves file per Document Retrieval configuration and applies document tags
4. Integration processes file and imports data into Workday

### Security

ISU requires Get/Put on: Manage Certifications (BP), Manage Competencies (BP), Manage Training (BP), Worker Data: Public Worker Reports, Worker Data: Skills and Experience, Worker Data: Workers.

---

## Common Patterns and Notes

### Audit Files

All connectors generate on each run:
- **Data Changes Audit** — readable version of the output file (can be secured separately as it contains actual data)
- **Diagnostic Audit** — troubleshooting information
- **Schema XSD** — output structure reflecting current configuration (generated only by running the integration)

Found in: Reports and Other Output Files section of the Integration Event.

### Document Transformation

Most outbound connectors produce Workday XML that requires transformation for external systems. Options:
1. Transformation step on the integration business process
2. Workday Studio integration launched from the BP
3. Third-party transformation tool

### General Security Pattern

All connectors require an Integration System User (ISU) with appropriate domain access. Common domains include Integration Event (nearly always required) plus connector-specific data domains.

### Performance Considerations

- Transaction Log Service improves performance by monitoring only relevant changes (vs. full-diff extraction)
- Full Extract mode extracts all records regardless of changes — can adversely affect tenant performance
- Schedule integrations during off-peak hours for large data volumes
- LinkedIn RSC: batch historical syncs in 1–3 month windows to avoid timeout failures
