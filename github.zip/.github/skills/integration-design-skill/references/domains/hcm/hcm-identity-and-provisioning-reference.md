# HCM Identity and Provisioning Reference

This reference covers Workday connectors for identity management, account provisioning, employment verification, and worker image handling.

---

## Account Provisioning (Template)

### Purpose

The Account Provisioning integration template sends worker profiles and provisioning group membership data to an external endpoint in SCIM (Simple Cloud Identity Management) format. It enables automatic addition and removal of hired and terminated workers from downstream services such as Active Directory, Google Apps, or Salesforce Chatter.

### When to Use

Use this template when:
- You need SCIM-formatted output for an external provisioning endpoint.
- The endpoint manages account lifecycle (open/close) based on Workday provisioning group membership.
- You need event-driven or scheduled delivery of provisioning changes.

### Launch Options

| Method | Description |
|--------|-------------|
| Scheduled in Workday | Preset interval schedule |
| Trigger by event | Transaction Log Service subscribes to business process events |
| Scheduled externally | External endpoint calls Launch Integration Event web service, polls with Get Integration Events, retrieves output from My Reports |

### Setup (Condensed)

1. Create Integration System using template **Account Provisioning**.
2. (Optional) Enable **Transaction Log Service** — restricts output to changed fields only. Subscribe to relevant business processes (Hire, Termination, Contract Contingent Worker, Start/End International Assignment, Add/End Additional Job).
3. Configure **Integration Field Overrides** — map Workday report fields to external fields (Worker ID, Legal Name, Email, Phone, Position, Manager ID, Hire Date, Termination Date, Active Status, etc.).
4. (Optional) Configure integration delivery if not launching via web service.
5. Create ISU with access to: External Account Provisioning, Worker Data: All Positions, Worker Data: Business Title on Worker Profile, Worker Data: Current Staffing Information, Worker Data: Public Contact Information, Worker Data: Public Worker Reports.

### Key Fields

The integration maps standard worker identity and position fields. A calculated field is required for Primary Work Messenger Type (no direct report field exists). All other fields map to standard Workday report fields.

---

## Account Provisioning Connector

### Purpose

The Account Provisioning Connector extracts worker account-related data and sends it to an endpoint in Workday-defined XML format. Unlike the Account Provisioning template (SCIM), this connector produces XML that typically requires downstream transformation.

### Account Provisioning vs Account Provisioning Connector

| Aspect | Account Provisioning (Template) | Account Provisioning Connector |
|--------|-------------------------------|-------------------------------|
| Output format | SCIM | Workday XML |
| Transformation needed | Usually none (SCIM is standard) | Usually yes (Document Transformation, Studio, or third-party) |
| Templates available | Single template | Two templates: Worker and Group |
| Event monitoring | Transaction Log Service | Web Services API change detection |
| Best for | Direct SCIM-compatible endpoints | Endpoints requiring custom XML formats |

### When to Use

Use the Connector when:
- Your endpoint requires a non-SCIM format.
- You need to chain a Document Transformation or Studio integration to reshape the output.
- You already use Account Provisioning Groups and need to extract group membership data.

### Setup (Condensed)

1. Create Integration System using template **Account Provisioning Connector: Worker** (and optionally **Account Provisioning Connector: Group**).
2. (Optional) Enable services: Filename Sequence Generator, Define Eligibility.
3. Configure Integration Attributes: Output Document Tags, Document Retention Policy.
4. Set up Sequence Generators and Integration Delivery.
5. (Optional) Configure Document Transformation step.
6. Create ISU with access to: Worker Data: Current Staffing Information, Worker Data: Public Worker Reports. (Add External Account Provisioning for Group template.)

### Launch Parameters

**Worker template:** Workers, As Of Entry Moment, Effective Date.

**Group template:** Provisioning Groups, As Of Entry Moment.

### Audit Files

Each run generates:
- **Data Changes Audit** — readable version of output (may contain sensitive data; secure separately).
- **Diagnostic Audit** — troubleshooting information.
- **Schema XSD** — defines output structure based on current configuration.

Suppress audit generation with integration attributes: Suppress Messages Audit, Suppress Audit Reports.

---

## Okta Integration

### Purpose

The Okta integration monitors Workday events and sends notifications to your Okta tenant when worker data changes. It sends only the Workday ID (WID) for each affected worker; Okta then extracts additional data via Workday Web Services API.

### When to Use

Use this when implementing Workday-driven provisioning to Okta. If Okta drives the data import, configure Okta's native Workday import instead.

### Architecture

- Workday pushes WID notifications to Okta on hire, transfer, termination, and other worker events.
- Okta pulls full worker details from Workday using the Web Services API.
- This is a push-notification model, not a full data extract.

### Integration Services

| Service | Required | Description |
|---------|----------|-------------|
| Worker - ESB | Required | Extracts worker data |
| Worker - Configuration | Required | Manages Okta integration config and attribute values |
| Integration Document Retention | Required | Defines output file retention period |
| Define Eligibility | Optional | Filters which workers trigger notifications |

### Setup (Condensed)

1. Create Integration System using template **Okta - Worker**.
2. (Optional) Enable optional integration services (e.g. Define Eligibility).
3. Create ISU with Get and Put access to: Worker Data: Current Staffing Information, Worker Data: Public Worker Reports.
4. Configure Integration Attributes (Okta tenant location and token).
5. (Optional) Configure eligibility filter via Integration Field Override.
6. Configure event monitoring via Integration Step or Integration Subscriptions (subscribe to hire, transfer, termination, etc.).
7. Configure Okta tenant to extract required data from Workday.

### Security

- ISU requires Get/Put on worker data domains.
- Optionally grant View: Account Provisioning Integration Document for output file visibility.

---

## E-Verify Integration

### Purpose

Integrates Workday with the E-Verify service (USCIS) to submit Form I-9 data for employment eligibility verification. Supports case creation, duplicate case handling, photo match, data verification, case closure, status sync, and bulk resubmission.

### Business Benefits

- Streamlines Form I-9 authorisation for employees.
- Receives verification results from DHS and SSA databases promptly.
- Reduces manual administrative work.
- Maintains compliance with employment eligibility requirements.

### Prerequisites and Enrolment

1. Enrol in E-Verify program via USCIS enrolment website.
2. Select access method: **Web Services Employer** or **Web Services Employer Agent**.
3. Execute the appropriate Memorandum of Understanding (MOU).
4. Add company details, assign Program Administrator, complete E-Verify Knowledge Session.
5. Request production and staging accounts from E-Verify via email.
6. Create staging accounts for testing before production use.

**Important:** Only the MOU for Web Services Employers or Web Services Employer Agents functions with Workday.

### Setup (Condensed)

1. Enable jpeg, pdf, and png file types in **Edit Tenant Setup - System**.
2. Create Integration System using template **E-Verify - Employment Verification**.
3. Configure Integration Attributes:

| Attribute | Description |
|-----------|-------------|
| E-Verify URL | Staging or production environment URL |
| E-Verify User Id | Web services account ID |
| E-Verify Password | Web services account password (must change every 90 days) |
| E-Verify Contact Name | Default point of contact for case queries |
| E-Verify Email Address | Contact email for E-Verify |
| E-Verify Phone Number | Contact phone for E-Verify |
| E-Verify Company | Company associated with integration (required for sync/resubmit) |
| E-Verify employer agent | Check box for employer agent web services |

4. Create ISU with Get/Put access to: Integration Event, Person Data: ID Information, Person Data: Name, Person Data: Personal Data, Person Data: Personal Information, Worker Data: I-9 Forms, Worker Data: Staffing.
5. Create Integration Step on **Complete Form I-9** and **Amend Form I-9** business processes.
6. (Employer agents) Configure client company IDs via Maintain E-Verify Employer Agent Client Company ID task.

### Multiple Companies

- Create a separate integration for each E-Verify Account ID / FEIN.
- Configure condition rules on business processes to route appropriately.
- Employer agents can use a single integration with client company IDs.

### Password Management

E-Verify requires password changes every 90 days. Minimum 5 days between changes. If expired, the account locks.

**To change password:**
1. Launch / Schedule Integration > select E-Verify integration.
2. Set E-Verify Service Call = **ChangePassword**.
3. Enter new password (must contain uppercase/lowercase, number, special character; no more than 2 identical consecutive characters from previous password).
4. After successful launch, update the E-Verify Password integration attribute.

**Recommendation:** Set calendar reminders for password changes.

### Service Call Options (Manual Launch)

| Service Call | Purpose |
|---|---|
| ChangePassword | Update E-Verify web services password |
| CloseCase | Manually close a specific case |
| GetCaseClosureReason | Retrieve closure reasons for open duplicate cases |
| MassRetry | Bulk resubmit Forms I-9 (for integration failures, shutdowns, password expiry) |
| SyncCaseStatus | Sync case statuses from E-Verify on schedule |
| VerifyConnection | Ping E-Verify service to confirm connectivity and credentials |
| VerifyCredentials | Verify username and password |
| WorkerSubmit | Manually resubmit a single worker's I-9 data |

### Mass Resubmit (MassRetry)

Resubmits Forms I-9 to E-Verify in bulk. Use when integration previously failed due to template error, government shutdown, or password expiry.

**Limitations:**
- Cannot resubmit forms with validation errors (invalid document number, incorrect SSN).
- Forms requiring photo match, duplicate case, or data verification after resubmit can only be progressed on the E-Verify website.
- Self-initiated Forms I-9 for employees with multiple positions in different companies are excluded.

**Recommendation:** Reset password before running MassRetry if failures were caused by password expiry. Schedule at non-peak hours.

### Integration Process Flow

1. Complete Form I-9 / Amend Form I-9 business process passes data to E-Verify integration.
2. Integration sends Form I-9 data to E-Verify service.
3. E-Verify checks against DHS and SSA records.
4. Results returned:
   - **Employment Authorized** → case auto-closes.
   - **Duplicate cases found** → option to close duplicates before creating new case.
   - **Photo on file** → photo match request routed to appropriate role.
   - **MANUAL_REVIEW** → DHS physically reviewing; sync status to progress.
   - **No match found** → retry request routed; amend and reverify.
   - **PENDING_REFERRAL** (second failure) → must process directly on E-Verify website.

### Limitations and Troubleshooting

- **Never send test data to E-Verify production.** Use staging environment with fake data only.
- If initial submission fails, options are: cancel and reinitiate, or create case manually on E-Verify website.
- PENDING_REFERRAL cases cannot be processed further in Workday.
- When using Update Form I-9 Receipts task, Data Verification and Photo Match responses are not available.
- If not configured for status sync, Authorization Pending cases must be managed on E-Verify website directly.
- Validation condition recommended on Complete Form I-9 to require SSN in Section 1.
- If employee enters Foreign Passport in Section 1 but presents I-766 for Section 2, send back Section 1 to enter Alien number.

### Security Requirements

| Domain | Functional Area |
|--------|----------------|
| Integration Build | Integration |
| Integration Event | Integration |
| Integration Debug | Integration |
| Process: I-9 Forms | Onboarding |
| Worker Data: I-9 Forms | Onboarding |
| Process: Resubmit Form I-9 | Onboarding |

### Reporting

- **E-Verify Account Details** — lists all E-Verify integrations in tenant.
- **View E-Verify Account Details** — single integration credentials and contact info.
- **U.S. Electronic Form I-9 Verifications** — verify status of resubmitted forms.

---

## Social Security Number Verification Service (SSNVS)

### Purpose

Generates flat files in SSNVS format for upload to the Social Security Administration's Social Security Number Verification Service. Used to verify employee names and SSN match SSA records.

### When to Use

- Verifying an entire payroll database.
- Hiring many workers at a time and needing bulk SSN verification.
- Wage reporting (Form W-2) purposes only.

### Concept

The SSNVS is an overnight batch service. Files can contain up to 250,000 names/SSNs; results typically arrive the next government business day. If you exceed 250,000 employees, the integration automatically splits into multiple files.

**Restrictions:** Only for current or former employees, only for wage reporting purposes.

### Setup (Condensed)

1. Enrol your organisation in SSNVS with the Social Security Administration.
2. Create Integration System using template **Social Security Number Verification**.
3. Create ISU with Get/Put access to Integration Event domain.
4. (Optional) Grant ISU access to View: Social Security Number Verification Integration Document.
5. Configure Integration Attributes (document retention days).
6. Set up Sequence Generators — add `.txt` to the Sequence ID Format field.
7. Launch and verify output.
8. Manually upload output files to SSNVS for overnight processing.

**Important:** The integration does not deliver files directly to SSNVS. Download from the integration event and upload manually.

### Launch Parameters

| Parameter | Description |
|-----------|-------------|
| Begin Date / End Date | Employees with Hire Date in range |
| Calendar Year | Employees paid at any point during year |
| Employee | Specific employees by name |

---

## Workday Connector for Equifax Verification

### Purpose

Automates delivery of income and employment data to Equifax for the Work Number® verification services. Enables authorised third parties (lenders, government agencies) to verify employment and income for your employees.

### Verification Inquiry Types

| Type | Description |
|------|-------------|
| Verification of Employment (VOE) | Current/past employment info for lenders or agencies |
| Verification of Income (VOI) | Current/past income info for financial assessments (requires Workday Payroll for U.S.) |
| Social Services Verification (SSV) | Employment/income info for social assistance eligibility |

### How It Works

1. **Weekly matching file:** Connector sends hashed SSN, employment status, unique Workday-generated employee ID, and company ID to Equifax for inquiry matching.
2. **Per-inquiry data:** When Equifax receives an authorised verification request, Workday sends relevant employee data from the most recent weekly snapshot.
3. **Transaction logs:** Weekly encrypted email with verification inquiry details sent to configured address.

### Data Sent to Equifax

Categories include: Workday ID, legal name, job title, employee status, hire dates, termination date, FEIN, work location address, home address, date of birth, SSN, pay frequency, rate of pay, hours, and (for VOI/SSV) detailed pay period and compensation data.

### Setup (Condensed)

1. Determine subscription agreement type (UMSA or MSA):
   - **UMSA:** Feature automatically available.
   - **MSA:** Must enable via Innovation Services Opt-In (HCM ML Features and Third Party Connectors GA).
2. Access **Set Up Workday Connector for Equifax Verification** task.
3. Verify Enable check box is selected.
4. Enter **Email Address for Verification Inquiry Transaction Log** — set up a secure inbox accessible only to HR/payroll staff.
5. Workday auto-creates ISU `ISU FOR VOIE EXTRACT - DO NOT EDIT`. Do not modify or delete this ISU.

### Notifications (UMSA Only)

1. Create security policy on **AI Features and Third Party Notification** domain.
2. Ensure workers in security groups have work email addresses.
3. Activate pending security policy changes.
4. Configure notification delivery in Edit Tenant Setup - Notifications.

Workday sends notifications at day 1 and day 15 after feature delivery, providing a 30-day opt-out window.

### Disabling the Connector

Access Set Up Workday Connector for Equifax Verification and clear the Enable check box.

### Reviewing Verification Data

Use the **Verification of Employment and Income Data for Worker** report with the WID and Verification Inquiry Date from the transaction log email to view what was sent to Equifax.

### Security

- Set Up: Tenant Setup - HCM domain (System functional area) for setup.
- AI Features and Third Party Notification domain for notifications.

---

## Image Upload

### Purpose

Bulk upload of worker photos from an external server to Workday. Photos display throughout Workday (profiles, directories, org charts) and are dynamically scaled and cropped at runtime.

### Setup (Condensed)

1. Create Integration System using template **Image Upload Template**.
2. Create ISU with Put access to: Integration Event, Person Data: Personal Photo.
3. Configure Integration Attributes.
4. Enable **Document Image Retrieval Service** (do not enable FTP client simultaneously — the Document Image Retrieval Service supports multiple protocols and is recommended).
5. (Optional) Set up Integration Retrieval configuration.
6. Launch integration.

### Photo Recommendations

| Feature | Recommendation |
|---------|---------------|
| Maximum size | 10 MB |
| Aspect ratio | Square (200×200 px ideal); images display as circles |
| Background | Transparent (PNG) or solid white |
| Colour space | RGB only (CMYK not supported) |
| File format | PNG or JPG preferred; GIF may produce poor results when resized |
| Layout | Consistent photographic layout across all workers |

### Key Points

- Images are dynamically scaled and cropped but aspect ratio is preserved.
- Individual photos can also be loaded via the **Load Worker Photos Individually** task.
- Supported formats: JPG, PNG, GIF.

---

## Security Summary

All identity and provisioning integrations require an Integration System User (ISU) with appropriate domain access. Common patterns:

| Connector | Key Security Domains |
|-----------|---------------------|
| Account Provisioning | External Account Provisioning, Worker Data (multiple) |
| Account Provisioning Connector | Worker Data: Current Staffing Information, Public Worker Reports |
| Okta | Worker Data: Current Staffing Information, Public Worker Reports |
| E-Verify | Integration Event, Person Data (multiple), Worker Data: I-9 Forms, Staffing |
| SSNVS | Integration Event |
| Equifax | Auto-provisioned ISU (do not edit) |
| Image Upload | Integration Event, Person Data: Personal Photo |

**General security principles:**
- Always use unconstrained integration security groups for ISUs unless organisation-level restriction is required.
- Grant minimum necessary domains.
- Never store passwords directly — use integration attributes for credential management.
- For E-Verify, password rotation every 90 days is mandatory.
