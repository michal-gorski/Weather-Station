# HCM Time, Absence and Third-Party Connectors Reference

This reference covers Workday connectors for time tracking, absence calendar synchronisation, and third-party system integrations including Kronos, Salesforce, Skillsoft, Medicare, ACA, and others.

---

## Absence Third-Party Calendar Integration

### Purpose

Sends approved time off events from Workday to Google Calendar and/or Microsoft Outlook. The integration automatically creates, updates, and removes time off entries, corrections, and cancellations in external calendars.

Only processes time off entries when these business process events reach Successfully Completed status: Correct Time Off, Request Absence, Request Time Off.

### Prerequisites

- Google: G Suite Basic, Enterprise, or Business account.
- Microsoft: Azure Active Directory work account with Exchange Online only. Hybrid on-premise Exchange deployments are not supported.

### Setup Steps (Condensed)

1. **Configure the integration** — access Configure Absence Third-Party Calendar Integration. Select time offs/absence tables, calendar display options (employees, managers, or both), and organisations to include.
2. **Register the client** — register a Google service account or Microsoft Azure AD application (or both).
3. **Create credential store** — store OAuth2 credentials in an External Client CredStore for each calendar provider.
4. **Create integration system** — use the `Absence Third-Party Calendar` template. Enable Google Calendar Integration and/or Microsoft Calendar Integration services.
5. **Configure integration attributes** — the Enabled attribute requires two rows (one per environment).
6. **Create ISU** — grant Get and Put on Integration Event domain.
7. **Launch or schedule** — organisation selection from the Configure task takes precedence over the launch parameter.

### Google Calendar Setup

- Create or reuse a Google Cloud Platform service account with editor permissions.
- Assign the Super Admin role (required for domain-wide calendar access; no custom role alternative exists).
- Create a Google-managed service account key (JSON). Save the JSON file.
- Enable domain-wide delegation: add API client with Calendar OAuth scopes (`calendar.events`, `calendar`).
- Enable Google Calendar API in the API & Services Library.
- Store credentials in an External Client CredStore with Auth Scheme = OAuth 2.0 Jwt Bearer.

### Microsoft Outlook Setup

- Register the application in Azure AD portal (single-tenant, client secret).
- Add Application permissions: `Calendars.Read` and `Calendars.ReadWrite` via Microsoft Graph.
- Grant admin consent.
- Store credentials in an External Client CredStore with Auth Scheme = OAuth 2.0 Client Credential.

### X.509 Key Pairs (Google)

Two options:
- **Third-party key pair**: store the private key and certificate from Google's JSON file in Workday.
- **Workday-generated key pair**: generate in Workday, then upload the public certificate to the Google service account.

### Output Files

| File | Purpose |
|------|---------|
| Summary | Summarises time off entry processing results |
| Retry Partition Store | Entries queued for retry on next run |
| Retry Partition Tracker | Tracks retry state |
| Synchronisation Failures Log | Entries that failed permanently (not retried) |
| sync_detail_log.csv | Advanced logging (debugging only, first 50,000 records; Google stops at 10,000) |

### FAQ Highlights

- **National cloud services**: Not supported (Microsoft Graph global service only).
- **Multiple email domains**: Supported as comma-separated list if all domains are in the same Google/Microsoft tenant.
- **Time zones**: Uses worker's preferred time zone, falls back to tenant time zone, then PST. Manager view converts to their time zone.
- **Partial days without start/end times**: Display as full-day events; recommend using start/end times.
- **Opting out**: Workers/managers can opt out via Change Preferences. Opting out only affects absence calendar events.
- **Leave of absence**: Not supported — only processes time off entries.
- **Recommended schedule**: Workday recommends frequent scheduling (e.g. every 15–30 minutes).
- **Reset option**: Reprocesses last 30 days and all future entries; skips retry queue.

### Troubleshooting

- **Events not appearing**: Enable Advanced Logging temporarily to generate sync_detail_log.csv.
- **Retry logic**: Workday retries HTTP 500 errors up to 3 times before logging a synchronisation failure.
- **2-hour limit**: Unprocessed entries without errors go to the retry queue for the next run.

---

## Worker Time Block Inbound Connector

### Purpose

Imports worker time blocks (reported time) from an external endpoint into Workday. Suitable for one-off or supplemental time entries (training, events, holiday hours).

> **Note:** Workday recommends using the Import Reported Time Blocks web service instead, for improved error handling and performance.

### What Data Is Imported

Detailed time block data including: employee/contingent worker ID, time entry code, project, project plan task, date, units, in/out date-time, out reason, position, override rate, worktags (business unit, cost centre, custom organisations 1–10, custom worktags 1–15), fund, grant, job profile, location, program, region, comment, and gift.

### File Schema Overview

- **CSV format**: fixed column order (Employee_ID through Worker_Reference_Type). Worker_Reference_Type values: E (employee), C (contingent worker), empty (defaults to employee).
- **XML format**: root element `TimeBlockInboundFile` containing multiple `TimeBlockEntry` elements with the same fields as CSV.

### Integration Attributes

| Attribute | Default | Description |
|-----------|---------|-------------|
| Input File Format | CSV | CSV or XML |
| Input Date Format | yyyy-MM-dd | Java simple date format |
| Input Date Time Format | yyyy-MM-dd HH:mm:ss | Java simple date format |
| Document Retention Policy | 30 days | How long Workday retains imported files |

### Setup Steps

1. Configure external endpoint to generate file in supported format.
2. Create integration system using `Worker Time Block Inbound` template.
3. Create ISU with access to Integration Event and Reported Time Batch Event (business process). ISU must be in a security group that can initiate and approve the batch event.
4. Configure integration attributes.
5. Set up integration retrieval (SFTP).
6. Launch or schedule.

### Security

- Integration Configure domain (attributes).
- Reported Time Batch Event business process security (role-based).

---

## Kronos Workforce Timekeeper Outbound

### Purpose

Synchronises HCM data (workers, organisations, job profiles) from Workday to Kronos Workforce Timekeeper. Kronos collects time and attendance data; Workday is the source-of-truth for HCM data.

After initial full-file synchronisation, subsequent runs send changes-only files containing complete records for new or changed workers.

### Setup Steps

1. Create integration system using `Kronos Employee Extract Template`.
2. Configure integration attributes and integration maps.
3. Create ISU with Get/Put access to: Integration Event, Set Up: Compensation, Worker Data: Public Worker Reports.
4. (Optional) Set up integration subscriptions.
5. Launch or schedule.

### Integration Data Mapping

Maps Workday values (Internal) to Kronos values (External). Examples:

| Map | Workday Value | Kronos Value |
|-----|---------------|--------------|
| Business Title | Staff Payroll Specialist | SPYS |
| Ethnicity | White (Not Hispanic or Latino) | CAUC |
| Leave Type Name | Workers Compensation | WC |

### Output Format

Pipe-delimited files with a fixed set of 111 fields. Use Kronos Connect to map desired fields to Kronos.

### Importing Kronos Time Data Back to Workday

Use the Absence and Payroll Input Connectors to import time card data from Kronos into Workday.

### Suppress Audit File

Set the `Suppress Messages Audit` attribute to True to suppress audit file generation (delivered as True for new systems).

### FAQ

- **File format**: Pipe-delimited.
- **Field selection**: Cannot change the 111-field output; use Kronos Connect for mapping.
- **Record filtering**: Cannot filter by worker/organisation. Use launch parameter dates for full vs. change extract. Edit Subscriptions to target specific events.
- **Import Kronos data**: Yes, via Absence and Payroll Input Connectors.

---

## Affordable Care Act (ACA) Connectors

### Purpose

Submit IRS Form 1094-C and 1095-C data under the ACA. Workday provides two connector types:
- **ACA Information Returns (AIR) Connector** — sends/receives data to/from the IRS AIR system.
- **ACA Mailing Connector** — sends data to an external mailing service (CIC Plus) for printing and mailing 1095-C forms.

### AIR Connector Setup

1. Create integration system using the year-specific template (e.g. `ACA Information Returns 2025`).
2. Create ISU with Get/Put on: Affordable Care Act (ACA) Administration, Integration Event.
3. Accept ACA Electronic Reporting Notice (related action).
4. Set up ACA Forms 1094-C and 1095-C data.
5. Manually launch (do not schedule — IRS processing times are variable).

### AIR Connector Launch Parameters

| Parameter | Description |
|-----------|-------------|
| Company | Company for submission |
| Run Mode | Validate without Sending / Send Data / Check Status |

### Mailing Connector Setup

1. Create integration system using `ACA Mailing Connector` template.
2. Configure integration attributes.
3. Set up integration delivery.
4. Create ISU with access to ACA Administration and Integration Event.
5. Launch.

### IRS Completion Statuses

| Status | Meaning |
|--------|---------|
| Rejected | File needs changes (replacement with code R) |
| Accepted with Errors | Accepted but has discrepancies; use Create ACA 1095-C/1094-C Data (Corrections) task |
| Accepted | No issues |

### Troubleshooting

| Issue | Resolution |
|-------|------------|
| Finding the record in error | Review Transmission_MessageAudit_1.zip; fix via EIB, resubmit in validate-only mode |
| Address/name field too long | Use Address Field 2 to avoid 35-character limit |
| Exclude workers with tuning rules | Use Calculate 1094-C Total and FTE Counts by Month task, then filter |
| Corrections workflow | Run Create ACA 1095-C/1094-C Data (Corrections) task before any EIB updates |

---

## Unistaff Connectors

### Purpose

Synchronise data between Workday and Unistaff to meet data privacy requirements for employees in the Russian Federation. Both connectors are required for a complete implementation.

### Unistaff Foundation Connector (Outbound)

Exports organisation, location, job family, position, and job profile data. Sends incremental updates as changes occur; supports a Full Extract launch parameter.

**Integration services:**
- Organisations Data Init Service
- Locations Data Init Service
- Job Families Data Init Service
- Job Profiles Data Init Service
- Position Restrictions Data Init Service

**Setup:** Create using `Unistaff Foundation Data` template → enable optional services → create ISU → configure attributes and maps → configure field overrides → set up delivery (SFTP) → launch/schedule.

### Unistaff Hire Inbound Connector

Imports new hires and updates to personally identifiable information for Russian citizens. Workday provides the XML format; contact Unistaff for file generation assistance.

**Supported actions:** Hire, Address, Certification, Compensation change, Education, Government ID, Job History, Legal Name, License, National ID, Other IDs, Passport/Visa, Personal Information, Phone/Email/IM/Web, Preferred Name, Leave of Absence, Add Dependent.

**Setup:** Create using `Unistaff Inbound` template → create ISU (extensive domain list including Hire Employee, Contract Contingent Worker, Manage Education, etc.) → configure attributes → set up retrieval (SFTP) → launch/schedule.

### Launch Parameters (Foundation)

- As Of Entry Moment
- Effective Date
- Last Successful As Of Entry Moment / Effective Date
- Full Extract

### Security

ISU for Foundation requires Integration Event domain. ISU for Inbound requires access to numerous business process domains (Hire Employee, Legal Name Change, Manage Education, etc.).

---

## AngelPoints Integration

### Purpose

Synchronises worker accounts between Workday and AngelPoints (recognition platform). Creates accounts, updates on change, and reports status changes for activation/deactivation.

After initial full-file sync, subsequent runs send changes-only files.

### Setup Steps

1. Create integration system using `AngelPoints - Worker Sync` template.
2. Enable integration services: Define Eligibility, Account Provisioning (Worker Sync, Common Configuration, Delivery Service), AngelPoints Additional Fields, Transaction Log.
3. Create ISU with access to: Integration Event, Person Data: Gender, Home Contact Information, Worker Data (Current Staffing, Public Reports, Work Contact).
4. Configure integration attributes (Include Inactive Workers, Required Field Validation, ISO Country Code, Region Organisation Type, Send Rehire Date, Employee ID Name, Use WID, Document Retention Policy).
5. Configure field overrides (up to 9 organisation fields, eligibility criteria, custom fields up to 20).
6. Configure integration maps.
7. Set up sequence generators and delivery.
8. Configure transaction log (if enabled).
9. Launch.

### SSO Worklets

Create worklets for SSO-based access to AngelPoints from within Workday:
1. Create X.509 private key pair and send public certificate to AngelPoints.
2. Configure tenant setup security with the key pair.
3. Create SAML SSO links (SAML 1.1, SHA256 signature) with appropriate AngelPoints URLs.
4. Create worklets pointing to the SSO links.

---

## Skillsoft Integration

### Purpose

Imports licensed courseware from Skillsoft into the Workday Learning catalogue as external digital courses.

### Setup Steps

1. Create integration system using `Learning SkillSoft Course Sync` template.
2. Enable all optional integration services.
3. Create ISU with access to Integration Event.
4. Register API client: Scope = Backpack Hub Service, Non-Expiring Refresh Tokens selected.
5. Record Client ID, Refresh Token, and Token Endpoint from View API Clients report.
6. Configure integration attributes.
7. Configure External Content task (topic mapping available after first run).
8. Launch with initiation mode parameter.

### Launch Modes

| Mode | Description |
|------|-------------|
| ALL | Gets metadata for all course content (use for first run) |
| DELTA | Gets new or updated metadata only (default) |
| ALL_NOT_RESET | Gets all metadata without resetting ALL/DELTA mode |

### Output Files

| File | Retention | Purpose |
|------|-----------|---------|
| Diagnostic-Audit.html | 30 days | Courses added/updated/removed |
| Skillsoft-Asset-Metadata.zip | 7 days | AICC packaged content (debugging) |
| Skillsoft-Full-Course-Listing.csv | 7 days | Catalogue hierarchy (debugging) |
| Diag_Course_Sync_Summary.xml | 3 days | Intermediate processing records |
| Post-Processing-*.zip | 3 days | State persistence between invocations |

### Troubleshooting

- **Error syncing in DELTA mode**: Integration timed out waiting for Skillsoft to generate the ZIP file. Re-run in DELTA mode later, or run in ALL mode.
- **Mobile support**: Only Skillsoft courses designed for mobile are supported.

---

## Medicare Integrations

### Purpose

Support Employer Voluntary Data Sharing Agreements (VDSAs) with the Centers for Medicare & Medicaid Services (CMS). Enables sending and receiving coordination of benefits request/response files for active and retired employees.

### Prerequisites

- Sign VDSA agreement with CMS and obtain a VDSA ID.
- Designate employer-named contact and CMS EDI contact.

### Templates

| Template | Direction | Scope |
|----------|-----------|-------|
| Medicare Secondary Payer Input File Outbound | Outbound | Active employees |
| Medicare Secondary Payer Response File Inbound | Inbound | Active employees |
| Non-Medicare Secondary Payer Input File Outbound | Outbound | Retired employees/dependents |
| Non-Medicare Secondary Response File Inbound | Inbound | Retired employees/dependents |

### Key Considerations

- Supports Employer VDSA only — not Section 111 compliance reporting.
- Does not maintain Medicare Part C data.
- Non-Medicare Outbound does not support Drug Subsidy reporting (use Import Medicare Part D EGWP web service).
- Transmits Medicare Beneficiary Identifier (MBI); no longer transmits HICN.
- Launch manually during CMS submission windows — do not schedule.

### Security

ISU requires Get/Put on: Integration Build, Worker Data: Medicare.

---

## Organisation Inbound Connector

### Purpose

Imports organisation data from an external system into Workday. Can add new organisations, update existing ones, and inactivate organisations. Enables a non-Workday application to be the source-of-truth for organisation data.

### Supported Operations

- **Create**: new organisation with unique Reference ID (hierarchy, name, date, code, type/subtype, location).
- **Edit**: update existing organisation by pre-existing Reference ID (includes moving via superior organisation change, role assignments — 1 role-to-position assignment per load).
- **Inactivate**: sets organisation inactive; moves active subordinates up to the active superior (or a specified target).

### File Format

- CSV or XML (Workday-defined format).
- **Must send full file** — does not support change-only files. The integration determines new vs. changed based on Reference ID.
- For high-volume loads, batch organisations for better performance.

### CSV Fields (Key)

Organisation_Reference_ID, Organisation_Name, Availability_Date, Organisation_Code, Organisation_Type_Name, Organisation_Subtype_Name, Organisation_Visibility_Name, Organisation_Inactive, Inactivation_Date, Superior_Organisation_Reference_ID, Container_Organisation_Reference_ID, Frozen_Status, Staffing_Model, Primary_Business_Site_Reference, plus role/position pairs.

### Audit Files

- **DataChangesAudit.html**: operation per organisation (Add, Update, Inactivate) with changed fields.
- **DiagnosticAudit.html**: document name, Reference ID, errors, and validation messages.

### Security

ISU requires: Integration Build, Manage: Organisation Integration, Manage: Organisation Update Integration, Worker Data: Organisation Information, Worker Data: Public Worker Reports. Must also have assignable role membership.

---

## Assign Organisations Inbound Connector

### Purpose

Imports organisation assignments from an external system that manages chart-of-account assignments. Updates worker assignments to Companies, Cost Centres, Regions, and Business Units.

### Limitations

- Workers and organisations must already exist in Workday.
- Does not support Supervisory organisations or custom Organisations.

### File Format

CSV (17 fields) or XML. Key fields: Worker_ID, Worker_Type, Position_Reference_ID, Effective_Date, Company/Cost_Centre/Region/Business_Unit Organisation Reference IDs.

### Integration Attributes

| Attribute | Description |
|-----------|-------------|
| Business Process Auto Complete | Completes BP automatically if selected |
| Input File Tag | Document tags identifying the input file |
| Validation Process | Skip (continue on error) or Abort (stop all processing; no rollback) |
| Input File Format | XML |
| Document Retention Policy | Days to retain (default 30) |

### Audit Files

Same pattern as Organisation Inbound: DataChangesAudit.html and DiagnosticAudit.html.

### Security

ISU requires: Integration Build, Integration Event, Manage: Organisation Integration, Manage: Organisation Update Integration, Worker Data: Organisation Information, Worker Data: Public Worker Reports.

---

## Salesforce.com Worker Sync

### Purpose

Synchronises worker accounts between Workday and Salesforce.com. Creates accounts as workers are hired, updates on change, and deactivates when workers leave. Can provision Chatter accounts, Salesforce accounts, or both.

After initial full-file sync, subsequent scheduled runs send changes-only files.

### Key Output Fields

| Salesforce Field | Workday Source |
|-----------------|----------------|
| Username | Primary Work Email Address |
| Email | Primary Work Email Address |
| Alias | Worker ID |
| IsActive | Worker Active + Eligibility criteria |
| Title | Position Title |
| FirstName | Preferred First Name |
| LastName | Preferred Last Name |
| ProfileId | Integration Field Override |
| Department | Integration Field Override |
| Division | Integration Field Override |

### Setup Steps

1. Create integration system using `Salesforce - Worker Sync` template.
2. Configure integration attributes (Salesforce credentials, environment URL, locale, time zone).
3. Configure field overrides: Define Eligibility (Boolean field), Salesforce_Profile, Department, Division.
4. (Optional) Configure transaction log — subscribe to all transaction types except irrelevant ones.
5. Create ISU with access to: Worker Data (Current Staffing, Private Contact, Public Reports), Person Data: Gender.
6. Launch/schedule.

### Launch Parameters

- Last Successful Launch Moment (auto-populated)
- As Of Moment
- Full File (extracts all data; note: cannot deactivate accounts in Full File mode)
- Restrict Results By Orgs

### Notes

- Salesforce passwords expire every 3 months — update attributes accordingly.
- Launching frequently does not affect performance.
- Suppress audit files by setting Suppress Audit Reports / Suppress Messages Audit to True.

---

## Salesforce.com Chatter

### Purpose

Exports My Tasks items from Workday to Salesforce.com Chatter as private messages. Requires the Salesforce - Worker Sync integration to be configured first.

### Setup Steps

1. **Create custom report**: copy the My Tasks standard report; change Data Source to "Business Process Transactions Awaiting Employee ID"; add columns (Business Process Event, Subject, Date Time Initiated, Due Date); add filter on Date and Time Initiated; add prompts for Employee ID and As Of DateTime Initiated; enable as Web Service (v15); share with all authorised users.
2. **Create integration system** using `Salesforce - Chatter Workfeed Sync` template.
3. **Create ISU** with Get/Put on Integrations: Workfeed domain.
4. **Configure integration attributes**: Salesforce Integration User ID, Password, Security Token, Workfeed Report Owner, Workfeed Report Name, Workday Default URL, Salesforce Environment.
5. **Launch/schedule**.

### Salesforce Configuration Notes

- Set User Account Name to Admin User or Company User (displays as private message sender).
- Do not set an Alias for the account.
- Admin account can see all messages for all workers.
- Passwords expire every 3 months.

---

## Common Security Requirements

All connectors require:
- An **Integration System User (ISU)** with appropriate domain access.
- Security domains typically include **Integration Event** (Get and Put) at minimum.
- Additional domains vary by connector (documented in each section above).
- For outbound connectors sending PII, secure the Data Changes Audit file separately.
- Activate pending security policy changes after granting new domain access.

## General Troubleshooting

| Symptom | Approach |
|---------|----------|
| Integration not launching | Verify ISU has correct domain access; check integration attributes are configured |
| Missing data in output | Review field overrides and eligibility criteria; check transaction log subscriptions |
| File retrieval failures | Verify SFTP connectivity and Document Retrieval configuration |
| Audit files not generated | Check Suppress Audit attributes; verify domain access to view output files |
| Integration exceeds 2-hour limit | Reduce data volume per run; use change-only mode where supported |
| Inbound validation errors | Review DiagnosticAudit.html; check file format matches expected schema |
