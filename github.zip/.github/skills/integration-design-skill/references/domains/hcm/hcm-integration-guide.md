# HCM Integration Guide

Overview and decision hub for Workday HCM connectors. For deep technical detail, see the dedicated cluster references in this folder.

---

## Connector Catalog

| Connector | Direction | Category | Purpose |
|-----------|-----------|----------|---------|
| Core Connector: Worker | Outbound | Worker data | Primary worker extract (demographics, job, compensation, benefits) |
| Core Connector: Global Worker | Outbound | Worker data | Simplified worker extract for global vendors |
| Core Connector: Positions | Outbound | Worker data | Position data extract with custom fields |
| Core Connector: Location | Outbound | Worker data | Location data extract |
| Core Connector: Organization | Outbound | Worker data | Organisation hierarchy extract |
| Core Connector: LMS Outbound | Outbound | Worker data | Worker data formatted for LMS systems |
| Directory Service | Outbound | Worker data | Lightweight worker directory for identity systems |
| Core Connector: Job Postings | Outbound | Recruiting | Active job postings for job boards |
| Core Connector: Job Requisitions | Outbound | Recruiting | Requisition data for ATS/vendor systems |
| Core Connector: Job Profile and Job Family | Outbound | Recruiting | Job catalogue data |
| Core Connector: Candidate Outbound | Outbound | Recruiting | Candidate data to external ATS |
| Core Connector: Background Check Order | Both | Recruiting | Background check orders and results |
| Core Connector: Competency Model | Outbound | Talent | Competency framework export |
| LinkedIn Recruiter System Connect | Both | Recruiting | LinkedIn RSC integration (inbound/outbound) |
| Kenexa Connectors | Both | Recruiting | Foundation data, user provisioning, hire inbound |
| Inline Assessments | Inbound | Talent | Import assessment results |
| Talent Profile Inbound Connector | Inbound | Talent | Import talent/skills data |
| Account Provisioning | Outbound | Identity | Provision accounts to external systems |
| Account Provisioning Connector | Outbound | Identity | Template-based account provisioning |
| Okta | Outbound | Identity | Push user lifecycle events to Okta |
| E-Verify | Both | Verification | Employment eligibility verification (US) |
| SSN Verification Service | Outbound | Verification | Social Security number verification (US) |
| Workday Connector for Equifax | Both | Verification | Employment/income verification |
| Image Upload | Inbound | Identity | Bulk worker photo loading |
| Absence Third-Party Calendar | Outbound | Time/Absence | Sync absence to Google/Outlook calendars |
| Worker Time Block Inbound | Inbound | Time/Absence | Import time blocks from external systems |
| Kronos Workforce Timekeeper | Outbound | Time/Absence | Worker extract for Kronos |
| Organization Inbound Connector | Inbound | Organisations | Import organisation structures |
| Assign Organizations Inbound | Inbound | Organisations | Assign workers to organisations |
| Salesforce.com Worker Sync | Outbound | Third-party | Sync worker data to Salesforce |
| Salesforce.com Chatter | Outbound | Third-party | Post to Salesforce Chatter |
| AngelPoints | Both | Third-party | Recognition platform integration |
| Skillsoft | Inbound | Third-party | Learning content sync |
| Medicare Integrations | Outbound | Compliance | Medicare reporting (Australia) |
| ACA Connector | Outbound | Compliance | Affordable Care Act reporting (US) |
| Unistaff Connectors | Both | Third-party | Foundation data + hire inbound |

---

## Connector Selection by Use Case

### Worker Data to External Systems

| Scenario | Connector |
|----------|-----------|
| Full worker extract (demographics, job, comp, benefits) | Core Connector: Worker |
| Simplified global worker extract | Core Connector: Global Worker |
| Worker data for LMS/learning systems | Core Connector: LMS Outbound |
| Lightweight directory for identity systems (AD, LDAP) | Directory Service |
| Position data with custom fields | Core Connector: Positions |
| Organisation hierarchy | Core Connector: Organization |
| Location data | Core Connector: Location |

### Recruiting and Talent

| Scenario | Connector |
|----------|-----------|
| Post jobs to external job boards | Core Connector: Job Postings |
| Send requisitions to ATS/vendor | Core Connector: Job Requisitions |
| Export job catalogue | Core Connector: Job Profile and Job Family |
| Send candidates to external ATS | Core Connector: Candidate Outbound |
| Background checks (order + inbound results) | Core Connector: Background Check Order |
| LinkedIn integration | LinkedIn Recruiter System Connect |
| Import candidate assessment results | Inline Assessments |
| Import talent/skill profiles | Talent Profile Inbound Connector |

### Identity and Provisioning

| Scenario | Connector |
|----------|-----------|
| Provision accounts (AD, systems) | Account Provisioning or Account Provisioning Connector |
| Okta user lifecycle | Okta |
| E-Verify employment eligibility (US) | E-Verify |
| SSN verification (US) | Social Security Number Verification Service |
| Employment/income verification (Equifax) | Workday Connector for Equifax |
| Bulk photo upload | Image Upload |

### Time and Absence

| Scenario | Connector |
|----------|-----------|
| Sync absence to Google/Outlook calendars | Absence Third-Party Calendar |
| Import time blocks from external time system | Worker Time Block Inbound |
| Worker extract for Kronos | Kronos Workforce Timekeeper Outbound |

---

## Key Decisions

### Core Connector: Worker vs Directory Service vs Global Worker

| Criterion | CC: Worker | Directory Service | CC: Global Worker |
|-----------|-----------|-------------------|-------------------|
| Data depth | Full (all data sections) | Limited (directory-focused) | Medium (simplified) |
| Custom fields | Yes | Yes | Limited |
| Performance at scale | Heavy (needs tuning >50k) | Lightweight | Medium |
| Change detection | Attribute-level | Basic | Basic |
| Use case | Payroll vendors, HR systems | AD/LDAP/identity | Global multi-country vendors |

### Account Provisioning vs Account Provisioning Connector

| Criterion | Account Provisioning | Account Provisioning Connector |
|-----------|---------------------|-------------------------------|
| Template-based | No | Yes (uses integration template) |
| Field configuration | Manual field setup | Pre-configured fields |
| Flexibility | Higher | More structured |
| Use case | Custom provisioning logic | Standard provisioning patterns |
