# HCM Worker Data Connectors Reference

This reference covers the core Workday HCM connectors for extracting worker, organisation, position, and location data. These connectors output data in Workday-defined XML format (or CSV/LDIF for Directory Service) and support change detection, configurable data sections, and delivery to external endpoints.

## Key Differences Between Connectors

| Connector | Purpose | Change Detection | Eligibility | Output Format |
|---|---|---|---|---|
| **Core Connector: Worker** | Worker data changes (personal, status, position, compensation) | Transaction log | True/False calculated field on Worker | XML or CSV |
| **Core Connector: Global Worker** | Worker data changes with local time zone effective dates | Transaction log | True/False calculated field on Worker | XML |
| **Core Connector: Positions** | Position data changes (open, closed, future positions) | Transaction log or Full-Diff | Results filtering (open/closed) | XML |
| **Core Connector: Organisation** | Organisation definitions and changes | Transaction log (limited) | Define Organisation Eligibility service | XML |
| **Core Connector: Location** | Location definitions and changes | Full extract with change comparison | N/A (all locations or specified) | XML |
| **Core Connector: LMS Outbound** | Combined worker + org + location + competency data for LMS | Transaction log per data type | True/False calculated field on Worker | XML |
| **Directory Service** | Worker data to LDAP/Active Directory servers | Transaction log | Boolean field on Worker | LDIF or CSV |

**When to use Global Worker instead of Worker:** Use Global Worker when you have workers in multiple time zones and need effective dates applied based on local time zones rather than the tenant time zone.

**When to use Directory Service instead of Worker:** Use Directory Service when the target is an LDAP or Active Directory server and you need output in LDIF format with Distinguished Name (DN) support.

---

## Core Connector: Worker

### Overview

Extracts changes to worker data from Workday and sends them to external applications for identity management, talent management, time tracking, and other downstream systems. This is the most commonly used HCM connector.

Core Connector: Worker with the **Worker Data Initialization Service (DIS)** enabled extracts data more efficiently using updated frameworks. Workday strongly recommends DIS for all new integrations.

### Setup Steps (Condensed)

1. Create Integration System using template **Core Connector: Worker**
2. Enable optional integration services (see Data Section Services below)
3. Configure Integration Transaction Log — subscribe to relevant transaction types (recommend: subscribe to all except known irrelevant types)
4. (Optional) Add custom fields via Integration Field Override Services
5. Set Up Integration Sequence Generators
6. Configure Integration Attributes
7. Configure Integration Maps (internal-to-external value mappings)
8. Create ISU and grant security access (see Security section)
9. Configure Integration Population Eligibility (True/False calculated field)
10. Select and Set Up Connector Output Fields (Version 17+)
11. Create Integration Business Process
12. (Optional) Set Up Document Transformation Connector
13. Launch

### Integration Services

| Service | Description |
|---|---|
| Worker Data Initialization Service (DIS) | Recommended. More performant and resilient extraction without API calls. Supports multiple jobs. |
| Transaction Log Service | Subscribe to Workday events; reports only changed fields. Improves performance. |
| Worker Personal Data Section Fields | Personal data and contact information |
| Worker Status Data Section Fields | Employment status and service dates |
| Worker Position Data Section Fields | Job profile, compensation elements, organisation membership |
| Worker Contract Data Section Fields | Employment contract data |
| Worker Leave of Absence Data Section Fields | Leave of absence data |
| Worker Compensation Data Section Fields | Compensation data |
| Worker Identification Data Section Fields | Identification documents |
| Worker Related Person Data Section Fields | Dependants, beneficiaries, emergency contacts |
| Worker Qualification Data Section Fields | Education, certifications, competencies |
| Worker Transaction Log Data Section Fields | Transaction log data |
| Worker Profile Photo | Photo in base64 binary format |
| CSV Options | Quotation formatting and column headers |
| Filename Sequence Generator | Custom-formatted unique filenames |
| Integration Document Retention | Preserves output files for later viewing |

### Key Integration Attributes

| Attribute | Purpose |
|---|---|
| Output Filename | Name of output file (leave empty if using sequence generator) |
| Version | Output file version (recommend 25+) |
| Output Format | XML or CSV (XML recommended for performance) |
| Include Inactive Workers in Full File | Include/exclude inactive workers in full extracts |
| Name Type | Which name types to include (Version 17+) |
| Country ISO Code Type | Country code format for addresses |
| Phone Number Format | Output format for phone numbers |
| Include Prior Values | Include previous field values in output |
| Required Field Validation | Behaviour when validation fails (Omit-Report Error / Omit-Report Warning / Include-Report Warning) |
| Include Terminated and Transferred Workers from Restrict Results By Orgs | Override standard behaviour for org-restricted runs |
| Include Multiple Positions | Return additional jobs and international assignments (DIS only, Version 25+) |
| Generate Multiple Output Files | Split output into files of 1000 workers each (DIS only, Version 34+) |
| Suppress Audit Reports | Disable Data Changes and Diagnostic Audit files |

### Worker Selection (Population Eligibility)

Define which workers are included using a **True/False Condition** calculated field based on the Worker business object:

- Configure via: Integration System > Configure Integration Field Overrides > Define Eligibility / Eligibility criterion
- Field must return Boolean `true` (include) or `false` (exclude)
- Can use simple report fields (e.g. "Worker is Employee") or complex calculated fields combining multiple conditions

**Example:** A calculated field returning true when:
- Worker is an employee AND
- Primary location is a specific country AND
- Worker belongs to a specific organisation

### Data Sections Summary

| Section | Description |
|---|---|
| Worker Personal Data | Single record. Name, gender, disability, address, phone, email data. Name fields default to Legal Name unless overridden. |
| Worker Status Data | Single record. Staffing event codes (HIR, TRM, LOA, RFL, TFR), employee status (Active, OnLeave, Terminated, NotYetHired), hire/termination dates, probation dates. |
| Worker Position Data | Single record (primary position). Position ID, title, worker type, time type, job profile, management level, organisation data, job classifications, business site, supervisor. |
| Worker Contract Data | Multiple records. Contract ID, type, start/end dates, status. Historical and future contracts included. |
| Worker Leave of Absence Data | Multiple records. Position-specific leave data including leave type, start/end dates. |
| Worker Qualification Data | Single record. Competency achievements, certifications, training, education, external job history. |
| Worker Compensation Data | Compensation amounts, currency, and change reasons. |
| Worker Identification Data | ID documents by type. |
| Worker Related Person Data | Beneficiaries, dependants, emergency contacts. |

### Launch Parameters

| Parameter | Description |
|---|---|
| As Of Entry Moment / Effective Date | Extract records current as of these timestamps |
| Last Successful As Of Entry Moment / Last Successful Effective Date | Compare against these timestamps for change detection |
| Full File | Extract all eligible workers regardless of changes |
| Restrict Results By Orgs | Limit to specified organisations and subordinates |
| Workers | Limit to specified workers (useful for re-running after errors) |

### Performance Recommendations

- Enable the Worker Data Initialization Service for new integrations
- Use Transaction Log Service (avoids full data comparison)
- Set Version attribute to 25 or higher
- Use XML output format (not CSV)
- Do not make integration field attributes required
- Do not configure maximum field lengths
- Avoid more than 20 field overrides
- Avoid Worker History business object and related report fields (Staffing History - All, Worker Events Completed, etc.)
- Do not group additional information fields (unless using DIS)

### Limitations

- Cannot send time-worked data (but can notify external time systems of hire/change/termination)
- With DIS enabled: Worker Photo section does not include image field; contextual security not applied; field overrides must use Worker business object without restricted usage
- Changes to Job Classification (on Job Profile template) do not trigger change detection (but are included in full extracts)

### Security Requirements

**Configuration access:**
- Integration Build
- Integration Configure

**ISU data access (grant Get and Put):**
- Manage: Organisation Integration
- Person Data domains (Birth Place, Citizenship Status, Date of Birth, Disabilities, Emergency Contacts, Ethnicity, Gender, Home Contact Information, ID Information, Institutional Contact Information, Marital Status, Military Status, Name, Nationalities, Personal Data, Personal Information, Preferred Name, Religion)
- Worker Data domains (Beneficiaries and Dependents, Benefit Elections, Compensation, Compensation by Organisation, Leave of Absence, Organisation Information, Public Worker Reports, Staffing, Workers)

**Note:** If DIS is enabled, the ISU only needs access to the Integration Event domain.

---

## Core Connector: Global Worker

### Overview

Exports worker data changes from Workday in XML format with **effective dates applied based on local time zones**. As you hire, promote, transfer, terminate, or update worker data, the integration generates an XML file containing the changes.

Use this connector when your organisation has workers across multiple time zones and downstream systems need time-zone-accurate effective dates.

### Setup Steps (Condensed)

1. **Prerequisite:** Create a True/False Condition calculated field (based on Worker business object) for population eligibility
2. Create Integration System using template **Core Connector: Global Worker**
3. Enable optional services (Transaction Log Service, Sequence Generator)
4. Configure Integration Transaction Log (subscribe to all except known irrelevant types)
5. Set Up Integration Sequence Generators
6. Select and Set Up Connector Output Fields
7. Configure Integration Attributes
8. Create ISU with Get/Put access to Integration Event domain
9. (Optional) Grant ISU access to View: Core Connector Integration Document domain
10. Configure Integration Population Eligibility
11. Set Up Integration Delivery
12. (Optional) Set Up Document Transformation Connector
13. Launch

### Change Detection

Uses a three-step process:

1. **Transaction log check** — identifies workers with changes matching configured transaction events
2. **Field comparison** — for each affected worker, compares report field values between current run time and last successful run time
3. **Message generation** — produces creation, change, or deletion messages for workers with actual field value changes

**Limitation:** Changes to Job Classification (on the Job Profile template) do not trigger change detection, as the context is on the template rather than the worker's job instance. Full extraction does include job classification.

### Data Sections

| Section | Description |
|---|---|
| Personal Data | Worker personal and contact information |
| Status Data | Employment status, dates, staffing events |
| Position Data | Job profile, organisation, compensation |
| Leave of Absence Data | Leave types and dates |

### Launch Parameters

| Parameter | Description |
|---|---|
| As Of Entry Moment / Effective Date | Extract records current as of these timestamps |
| Last Successful As Of Entry Moment / Last Successful Effective Date | Baseline for change comparison |
| Full File | All eligible workers regardless of changes |
| Restrict Results By Orgs | Limit to specified organisations |
| Workers | Limit to specified workers |

### Key Differences from Core Connector: Worker

- Applies effective dates based on **local time zones** (Worker uses tenant time zone)
- Does not support the Worker Data Initialization Service
- Fewer data section options (4 vs 10+)
- Output includes separate elements for current and prior values per field

---

## Core Connector: Positions

### Overview

Exports position changes from Workday in XML format. Use this connector to send data on **open, closed, and future positions**. Do not use this connector to track changes to a worker in a position — use Core Connector: Worker for that.

### Setup Steps (Condensed)

1. Create Integration System using template **Core Connector: Positions**
2. Enable optional services (Job Qualification Data, Job Requisition Data, Filename Sequence Generator, Transaction Log Service)
3. Configure Integration Transaction Log
4. Configure Integration Attributes
5. Create ISU with Get/Put access to Integration Event, Job Information, Worker Data: All Positions
6. Select and Set Up Connector Output Fields
7. (Optional) Add Custom Fields via Integration Field Override Service
8. Create Integration Business Process
9. (Optional) Set Up Sequence Generators
10. (Optional) Set Up Document Transformation Connector
11. Launch

### Change Detection

Same three-step process as other Core Connectors:
1. Transaction log check for position changes
2. Field comparison between current and last successful run
3. Generation of creation/change/deletion messages

### Full-Diff Extract

Disable the Transaction Log Service to enable Full-Diff mode. Extracts all applicable data for all positions regardless of changes since last run. **Warning:** This can adversely affect performance as it selects all positions before determining changes.

### Results Filtering

Filter positions by:
- Open positions only (including frozen)
- Closed positions only
- Open and closed positions

Additional attribute filters:
- Positions available for recruiting
- Positions available for hire

**Restrict to Positions in the Entry Range** attribute: Bypasses the from-date Effective Date parameter; returns only positions entered between Last Successful As Of Entry Moment and As Of Entry Moment.

### Data Sections

| Section | Description |
|---|---|
| Position Data | Position ID, supervisory organisation, job posting title, description, availability, job family/profile, location, worker type, time type, filled-by worker |
| Job Qualification Data | Competency, certification, education, language, responsibility, training, and work experience qualifications for the position |
| Job Requisition Data | Associated job requisition information |

### Custom Fields

Add unlimited custom fields using Integration Field Override Services based on the Position business object (or directly related objects). Custom fields appear in an ADD record in the output. Values are included only when they change (by default).

### Launch Parameters

| Parameter | Description |
|---|---|
| As Of Entry Moment / Effective Date | Extract records current as of these timestamps |
| Last Successful As Of Entry Moment / Last Successful Effective Date | Baseline for change comparison |
| Full Extract | All positions regardless of changes |
| Location(s) | Limit to specified locations |
| Position(s) | Limit to specified positions |
| Supervisory Organisation(s) | Limit to specified supervisory organisations |

**Note:** Without the Restrict to Positions in the Entry Range attribute, the integration does not return positions with effective dates prior to 1 January 1970.

---

## Core Connector: Organisation

### Overview

Extracts organisation-related definitions, transforms the data, and sends it to an external endpoint. Uses the Get Organisations public API as its foundation. Provides a single source-of-truth for organisation data across multiple downstream endpoints.

### Setup Steps (Condensed)

1. Create Integration System using template **Core Connector: Organization Outbound**
2. Enable optional services (Filename Sequence Generator, Transaction Log Service, Define Organisation Eligibility)
3. Configure Integration Attributes
4. Configure Integration Maps
5. (If eligibility service enabled) Configure Integration Field Overrides with a Boolean report/calculated field for organisation eligibility
6. Create ISU with Get/Put access to Integration Event and Manage: Organisation Integration
7. Select and Set Up Connector Output Fields
8. Set Up Integration Delivery
9. Set Up Sequence Generators
10. (Optional) Set Up Document Transformation Connector
11. Launch

### Transaction Log Service — Important Limitations

The Transaction Log Service for organisations has significant limitations:

- **Does not detect** changes to organisation data such as organisation name and code
- Event logs do not capture all organisation changes
- Workday recommends **disabling** the Transaction Log Service for better change detection
- When disabled, the integration compares all organisations meeting configured criteria between current and last successful timestamps

### Organisation Eligibility

When the Define Organisation Eligibility service is enabled:
- Configure an Integration Field Override with a Boolean report/calculated field based on the Organisation business object
- `true` = include the organisation; `false` = exclude

### Launch Parameters

| Parameter | Description |
|---|---|
| As Of Entry Moment / Effective Date | Extract records current as of these timestamps |
| Last Successful As Of Entry Moment / Last Successful Effective Date | Baseline for comparison |
| Full Extract | All qualifying organisations regardless of changes |
| Organisation Type | Limit to specified organisation types |
| Organisation(s) | Limit to specified organisations |

---

## Core Connector: Location

### Overview

Extracts location-related definitions and delivers them to an external endpoint. Uses the Get Locations public API as its foundation. Provides a single source-of-truth for location data.

Best used in combination with Core Connector: Worker to create a complete data set for downstream systems.

### Setup Steps (Condensed)

1. Create Integration System using template **Core Connector: Locations**
2. Configure Integration Attributes
3. Configure Integration Maps
4. Create ISU with Get/Put access to Integration Event and Manage: Location
5. Select and Set Up Connector Output Fields
6. (Optional) Add Custom Fields via Integration Field Override Service (based on Location business object)
7. Set Up Integration Delivery
8. Set Up Sequence Generators
9. (Optional) Set Up Document Transformation Connector
10. Launch

### Data Sections

| Section | Fields Include |
|---|---|
| Location Data | Location ID/name, usage, type, inactive flag, time zone, default currency, country, address fields, phone fields, email fields |

### Launch Parameters

| Parameter | Description |
|---|---|
| As Of Entry Moment / Effective Date | Extract records current as of these timestamps |
| Last Successful As Of Entry Moment / Last Successful Effective Date | Baseline for change comparison |
| Full Extract | All locations regardless of changes |
| Location(s) | Limit to specified locations |

---

## Core Connector: LMS Outbound

### Overview

A combined connector designed specifically for sending worker, organisation, location, and competency data to external Learning Management Systems (LMS). Bundles multiple data types into a single integration system with separate output files per data type.

### Setup Steps (Condensed)

1. Create Integration System using template **Core Connector: LMS Outbound**
2. Enable relevant optional services (see below)
3. Configure Transaction Log for each enabled data type
4. Configure Integration Attributes for each enabled service
5. Create ISU with appropriate domain access
6. Configure output fields and delivery
7. Launch

### Integration Services

The LMS Outbound connector includes services for multiple data domains, each independently enabled:

**Organisation data:**
- Core Connector: Organisation Outbound Integration Configuration
- Core Connector: Organisation Data Section Fields
- Core Connector: Organisation Filename Sequence Generator
- Core Connector: Organisation Transaction Log Service
- Define Organisation Eligibility

**Location data:**
- Core Connector: Location Integration Configuration
- Core Connector: Location Data Section Fields
- Core Connector: Location Filename Sequence Generator

**Competency data:**
- Core Connector: Competencies Outbound Integration Configuration
- Core Connector: Competency Data Section Fields
- Core Connector: Competencies Outbound Filename Sequence Generator

**Worker data** (uses standard Core Connector: Worker services for the worker portion)

Each data domain produces a separate output file. Organisation, location, and competency services require their parent configuration service to be enabled first.

---

## Directory Service

### Overview

Exports worker data changes from Workday in a format supporting LDAP and Microsoft Active Directory servers. Assumes Workday is the **source-of-truth** for HCM data. One-way integration only (Workday → directory server via FTP/SFTP).

The integration writes an LDIF or CSV file and posts it to a specified FTP/SFTP server. It cannot connect directly to directory servers.

### Setup Steps (Condensed)

1. Create Integration System using template **Directory Service**
2. Enable optional services:
   - Active Directory (if target is Microsoft AD)
   - Simple DN or Directory Service Distinguished Name (based on DN format)
   - Transaction Log Service
   - Integration Document Retention
   - Filename Sequence Generator
   - CSV Options
3. Configure Integration Transaction Log
4. Set Up Sequence Generators
5. Configure Integration Attributes (including base DN, output format)
6. Create ISU with Get/Put access to Integration Event and Worker Data: Public Worker Reports
7. Map integration data (create Integration Field Override Service)
8. Select workers to include (eligibility criterion)
9. Create Integration Business Process
10. Launch

### Data Mapping

Unlike other Core Connectors, the Directory Service uses Integration Field Override Services to define **all** output fields:

1. Create an Integration Field Override Service selecting the business object (Worker, Employee, or Contingent Worker)
2. Define field names matching the target directory schema (e.g. `displayName`, `givenName`, `sn`, `mail`)
3. Map each field to a Workday report field or calculated field

**Example mapping (inetOrgPerson schema):**

| Field | Override External Field |
|---|---|
| displayName | Legal Name |
| givenName | Legal Name - First Name |
| sn | Legal Name - Last Name |
| mail | Email - Primary Work |
| employeeType | Worker Type - Text |

### Distinguished Name (DN) Support

- **Simple DN:** Select a report field (e.g. Legal Name in Display Format) for Simple DN / User Identity. Set prefix (e.g. CN) in integration attributes.
- **Complex DN:** Create a calculated field that constructs the full DN string with prefixes and concatenation.

Base DN is set in integration attributes (e.g. `DC=acmeinc,DC=com`).

### Worker Eligibility

Same pattern as Core Connector: Worker — a Boolean report field or calculated field on the Worker business object determines inclusion.

For multiple directory servers, configure a **separate integration** for each, with distinct eligibility criteria and data definitions.

### Synchronisation Options

| Option | When to Use |
|---|---|
| Create | Workday is the primary source; workers are added to Workday before the directory server |
| Update | Workers are added to directory server manually before being added to Workday |

Selecting the wrong option causes LDIF import errors (attempting to create existing accounts or modify non-existent ones).

### Output Formats

- **LDIF** (LDAP Data Interchange Format) — supports LDAP and Active Directory
- **CSV** — includes values without field labels; can be post-processed for other directory formats

### Launch Parameters

| Parameter | Description |
|---|---|
| Last Successful Launch Moment | Defaults to last successful launch; override to widen the change window |
| Workers | Restrict to specific workers (does not force inclusion — only includes if changes detected) |

Can also be scheduled to run automatically at a defined frequency.

### Audit Files

| File | Content |
|---|---|
| DataChangesAudit.html | Field names, current/prior values, and worker transactions for each Integration Field Override Service |
| DiagnosticAudit.html | Worker transactions detected during the date range |
| Event_Name.csv / Event_Name.ldif | Actual integration output |

Audit files can be suppressed via the Suppress Audit Reports and Suppress Messages Audit attributes.

### FAQ

**Q: What directory servers are supported?**
A: LDAP and Microsoft Active Directory (via LDIF). CSV output can be post-processed for others.

**Q: Can it connect directly to my directory server?**
A: No. It posts files to FTP/SFTP. You import from there into your directory server.

**Q: Can I export changes from my directory server back to Workday?**
A: No. The integration is one-way (Workday → directory server). Workday does not detect changes made directly on directory servers.

---

## Common Concepts

### Integration Audit Files

All Core Connectors generate these files per integration run (found in Reports and Other Output Files on the Integration Event):

| File | Purpose |
|---|---|
| Data Changes Audit | Readable version of the output file (only generated when changes detected) |
| Diagnostic Audit | Troubleshooting information for the integration event |
| Schema XSD | Defines content and structure of the output; reflects configuration at time of run |

The Data Changes Audit contains actual worker data and can be secured separately from the integration output.

### Integration Maps

Maps translate internal Workday values to external values required by the target system:

1. Configure via Integration System > Maintain Integration Maps
2. Specify Internal Value Type and External Value Type (can be enumerations or report fields)
3. Add rows mapping each Internal Value to its External Value
4. Optionally set a Default Value for unmapped values

For custom fields (ADD section), use naming format: `ADD-<FieldName>`.

### Custom Fields (Field Overrides)

All Core Connectors support unlimited custom fields via Integration Field Override Services:

1. Create an Integration Field Override Service on the relevant business object
2. Define field names in the service
3. Enable the service on the integration (Custom Integration Services grid)
4. Map each field to a report field or calculated field via Configure Integration Field Overrides

Custom fields appear in an ADD record in the output. By default, included only when values change.

### Document Transformation Options

All connectors support post-processing of their XML output:

- **Business process transformation step** — XSLT within the integration business process
- **Workday Studio integration** — launched from the business process to transform the file
- **Third-party tool** — external transformation of the delivered file

### Scheduling

All connectors support:
- **Scheduled Run Frequency** — automatic launches at defined intervals
- **Run Now** — manual launch with specified parameters

Running integrations frequently does not affect performance (when Transaction Log Service is enabled).
