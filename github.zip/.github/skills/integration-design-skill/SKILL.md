---
name: integration-design-skill
description: "Workday integration design workflow. Use when designing a new integration, running a discovery session, populating a design document, creating field mappings, selecting between integration types (PECI/PICOF/WECI/DCoD/EIB/Studio), or reviewing an existing design. Covers discovery questionnaires, design template structure, file mapping format, and domain-specific integration guides."
argument-hint: "Describe the integration you want to design or the design task you need help with"
---

# Integration Design Workflow

This skill provides the structured workflow for designing Workday integrations — from initial discovery through design document completion. It covers universal patterns (questionnaires, file mapping, delivery) and domain-specific guidance (payroll, SAP, identity).

## When to Use

- Designing a new integration from scratch (discovery → design document)
- Running or preparing for a discovery session with a customer
- Populating a design document or field mapping spreadsheet
- Selecting between integration types for a given requirement
- Reviewing or critiquing an existing integration design
- Handling a change request that affects integration design
- Troubleshooting a payroll integration (PECI, PICOF, WECI)

## Procedure

### New Integration Design

1. **Identify the domain** — ask the user which functional area the integration covers:

   | Domain | Reference to load |
   |--------|-------------------|
   | Payroll (PECI, PICOF, WECI, DCoD, Event-Driven) | [payroll-integration-guide.md](./references/domains/payroll/payroll-integration-guide.md) |
   | Payroll — PECI deep-dive | [peci-reference.md](./references/domains/payroll/peci-reference.md) |
   | Payroll — PICOF deep-dive | [picof-reference.md](./references/domains/payroll/picof-reference.md) |
   | Identity / Account Provisioning | *Deferred — content TBD* |
   | Benefits | *Deferred — content TBD* |
   | Financials | *Deferred — content TBD* |
   | Custom / Other | Use general questionnaire only |

2. **Load the discovery questionnaire** — read [discovery-questionnaire.md](./references/discovery-questionnaire.md) and walk through the applicable sections with the user. Every integration needs **General**, **File Delivery**, **Integration-Specific**, **Testing**, and **Go-Live**. Domain sections (Payroll, SAP, Identity) apply when relevant.

3. **Select the integration type** — based on discovery answers, recommend the appropriate Workday integration approach. For payroll, consult the [payroll-integration-guide.md](./references/domains/payroll/payroll-integration-guide.md) selection matrix.

4. **If the recommended type is Workday Studio** — automatically hand off to `/create-studio-skill`. Pass forward all discovery context gathered so far: integration name, data source, target system/API, file layout, field mapping, processing model, error handling preference, and integration attributes. The user should not need to re-state requirements that were already captured during discovery. Summarise the design decisions as a structured brief before invoking the skill.

5. **Populate the design document** — use the [design-template-guide.md](./references/design-template-guide.md) to help the user complete the questionnaire tab and file mapping tab. The file mapping format supports CSV, fixed-width, and XML outputs.

6. **Apply naming conventions** — consult `naming-conventions.instructions.md` for integration system names, report names, XSLT file names, and security group names.

### Change Request

1. Understand what is changing — load the relevant domain reference
2. Assess impact on field mapping, integration attributes, delivery, or scheduling
3. For payroll changes, check whether the change affects PECI/PICOF attributes, data sections, field overrides, or change detection behaviour

### Bug Fix / Troubleshooting

1. Identify the integration type (PECI, PICOF, WECI, EIB, Studio, etc.)
2. Load the relevant domain reference — for payroll, the PECI and PICOF references contain comprehensive troubleshooting sections
3. Check common causes: LSRD configuration, change detection mode, field override issues, currency conversion, missing security domains

## Quick Reference — Integration Type Selection

| Requirement | Recommended Type |
|-------------|-----------------|
| Full-stack payroll, effective-dated changes, vendor needs sequential history | **PECI** |
| Top-of-stack payroll, delta/full extract, CSV or XML | **PICOF** |
| HCM data for non-payroll vendor, contingent workers needed | **WECI** |
| API-driven payroll data on demand | **DCoD** |
| Real-time hire/termination to payroll vendor | **Event-Driven Integration** (PECI service) |
| Centralized multi-country payroll monitoring | **ICC** (PECI service) |
| Simple file extract from custom report | **EIB** |
| Complex transformation, multi-step orchestration | **Workday Studio** |
| Spreadsheet-based bulk data load | **Inbound EIB** |
| Document transformation (CSV/fixed-width formatting) | **Document Transformation** or **MDT** |

## References

- [Discovery Questionnaire](./references/discovery-questionnaire.md) — structured discovery questions for all integration types
- [Design Template Guide](./references/design-template-guide.md) — how to populate the integration design document
- [Payroll Integration Guide](./references/domains/payroll/payroll-integration-guide.md) — payroll integration overview and decision matrix
- [PECI Reference](./references/domains/payroll/peci-reference.md) — Payroll Effective Change Interface deep-dive
- [PICOF Reference](./references/domains/payroll/picof-reference.md) — Payroll Interface Connector deep-dive
