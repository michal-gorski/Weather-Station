---
name: build-release-note-skill
description: "Generate AMS build and release notes for Workday integration changes. Use when a ticket is ready for production deployment or when the user asks to write, draft, or generate a build note, release note, or B&R note. Covers the full interview-to-output workflow — gathering ticket context, change summary, test evidence, and rollback details, then producing output in HTML (Kainos branded), plain text, or Word (.docx) template format."
argument-hint: "Describe the ticket and integration, or say 'start' to be walked through the questions"
---

# Build & Release Note — Workflow Skill

This skill produces AMS build and release notes to the Kainos AMS standard. A build note is required for every production change and should be the definitive record of what was done, why, and how it was tested.

## When to Use

- Ticket is approaching production deployment and a build note is needed
- User asks to "write a build note", "draft a release note", or similar
- Post-deployment documentation for a completed ticket

## Procedure

### Step 1 — Gather Information

Ask the user the following questions. They can answer all at once or interactively. Only ask for what you do not already know from context.

| # | Question | Notes |
|---|----------|-------|
| 1 | What is the **ServiceNow ticket ID**? | e.g. `CS0066361` |
| 2 | What is the **integration name and ID**? | e.g. `INTF029 CAMT053 Customer Payment Inbound` |
| 3 | What is the **customer / organisation name**? | e.g. `Securex` |
| 4 | Who is the **approver**? | Format: `Organisation / Name` |
| 5 | What **environment** is this note for? | Impl → Sandbox → Production |
| 6 | What was the **issue or requirement**? | One paragraph, plain language |
| 7 | What did investigation reveal? | Root cause, findings |
| 8 | What **change was made**? | Describe each file or config object changed. Include before/after code if available |
| 9 | What **tests were run** and what were the results? | Group by theme, one line per scenario |
| 10 | Are there **rollback instructions**? | Steps to reverse the change if needed |
| 11 | Any **additional comments**? | Known limitations, follow-up tickets, caveats |
| 12 | **Format preference**: HTML, plain text, or Word (.docx)? | Default: Word (.docx). Word mode fills the Kainos AMS template automatically |

### Step 2 — Apply These Rules Before Writing

- **One issue per build note.** If there are fixes to multiple integrations, they belong on separate tickets with separate notes
- **Do not list pre-existing bugs** as part of this change — a brief mention is fine if context requires it
- **Requirement Summary** must be high level: one sentence purpose statement followed by 6-8 bullet points. Do not reproduce the full ticket history
- **Testing Steps Completed** must be concise: one line per scenario with `[PASS]` or `[FAIL]`, grouped by theme. No per-field detail
- **The build note must stand alone** — someone unfamiliar with the ticket should be able to understand the entire change from the note alone

### Step 3 — Produce Output

Generate the build note in the chosen format.

- For **HTML**: follow [html-template.md](./references/html-template.md)
- For **plain text**: follow [text-template.md](./references/text-template.md)
- For **Word (.docx)**: follow the [Word Fill Procedure](#word-fill-procedure) below

For HTML and plain text, output the full note in a code block so the user can copy it directly.
For Word, use a two-step flow by default for the first pass on a ticket:

1. Show the full build note text first so the user can review the content before file generation.
2. After user confirmation or requested edits, produce the filled `.docx` file and return the file path.

If the user explicitly asks to generate the Word document immediately, you may skip the review-first step.

Word output filename convention:

- `[Customer Name] [Case No] Build & Release Note.docx`
- Example: `Securex CS0101046 Build & Release Note.docx`

Default output behaviour:

- Default format: Word (.docx)
- Default first pass: show the full draft text before creating the document
- After approval: generate the `.docx` file using the approved text

---

## Quick Reference — Required Sections

| Section | Content |
|---------|---------|
| **Deployment Notice** | Customer, integration, environment, consultant, approver, date |
| **Requirement Summary** | Purpose + 6-8 bullet points (high level) |
| **Implementation Steps** | Numbered steps, each file/config changed, before/after code blocks where relevant |
| **Steps Completed** | Test results — one line per scenario, `[PASS]`/`[FAIL]`, grouped by theme |
| **Rollback Instructions** | How to reverse the change |
| **Additional Comments** | Caveats, follow-up items, known limitations |

---

## Word Fill Procedure

When the user selects Word (.docx) format, fill the Kainos AMS template stored at `references/templates/Build_Note_Template.docx` using PowerShell XML DOM manipulation. **Never use Word COM automation** (hangs in headless terminals) and **never use string replacement** on docx XML (Word splits text across multiple XML runs, so placeholders are fragmented).

### Approach

1. Copy the template to the user's output location using this filename format: `[Customer Name] [Case No] Build & Release Note.docx` (for example: `Securex CS0101046 Build & Release Note.docx`)
2. Open the copy as a ZIP archive using `System.IO.Compression.ZipFile`
3. Extract `word/document.xml` and parse it as `System.Xml.XmlDocument`
4. Locate each section table by reading the **header cell text** (not positional index)
5. Replace cell content using DOM operations: remove existing `w:p` children, create new `w:p` → `w:r` → `w:t` with `xml:space="preserve"`
6. If a section has more content items than template rows, clone the last `w:tr` element to add rows
7. Validate the modified XML is well-formed before saving
8. Write back to the ZIP and close

### Fill Script

Adapt this script per ticket. Replace the content strings with gathered interview data.

```powershell
param(
    [string]$TemplatePath,   # Path to Build_Note_Template.docx
    [string]$OutputPath,     # Output file path
    [string]$Approver,       # e.g. 'Securex / Jens De Rijcke'
    [string]$TicketID,       # e.g. 'CS0100239'
    [string]$Environment,    # e.g. 'Production'
    [string]$Team,           # e.g. 'Integrations'
    [string]$Consultant,     # e.g. 'Andrew Hylands'
    [string]$DateTime,       # e.g. '04/06/2026 16:05 CET'
    [string[]]$RequirementItems,       # Array of requirement summary bullets
    [string[]]$ImplementationItems,    # Array of implementation steps
    [string[]]$TestingItems,           # Array of testing results
    [string[]]$RollbackItems,          # Array of rollback steps
    [string]$AdditionalComments        # Single block of text
)

Copy-Item -Path $TemplatePath -Destination $OutputPath -Force

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$zip = [System.IO.Compression.ZipFile]::Open($OutputPath, [System.IO.Compression.ZipArchiveMode]::Update)
try {
    $entry = $zip.GetEntry('word/document.xml')
    $stream = $entry.Open()
    $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
    $xmlText = $reader.ReadToEnd()
    $reader.Close()
    $stream.Close()

    $doc = New-Object System.Xml.XmlDocument
    $doc.PreserveWhitespace = $true
    $doc.LoadXml($xmlText)

    $ns = New-Object System.Xml.XmlNamespaceManager($doc.NameTable)
    $ns.AddNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main')

    function Get-CellText([System.Xml.XmlNode]$cell, [System.Xml.XmlNamespaceManager]$nsMgr) {
        $texts = $cell.SelectNodes('.//w:t', $nsMgr)
        $parts = @()
        foreach ($t in $texts) { $parts += $t.InnerText }
        return ($parts -join '')
    }

    function Set-CellText([System.Xml.XmlDocument]$docObj, [System.Xml.XmlNode]$cell, [System.Xml.XmlNamespaceManager]$nsMgr, [string]$text, [bool]$center = $false) {
        $wNs = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
        $xmlNs = 'http://www.w3.org/XML/1998/namespace'

        $existingP = $cell.SelectSingleNode('./w:p[1]', $nsMgr)
        $pPrClone = $null
        $rPrClone = $null
        if ($existingP -ne $null) {
            $pPr = $existingP.SelectSingleNode('./w:pPr', $nsMgr)
            if ($pPr -ne $null) { $pPrClone = $pPr.CloneNode($true) }
            $rPr = $existingP.SelectSingleNode('./w:r[1]/w:rPr', $nsMgr)
            if ($rPr -eq $null -and $pPr -ne $null) {
                $rPr = $pPr.SelectSingleNode('./w:rPr', $nsMgr)
            }
            if ($rPr -ne $null) { $rPrClone = $rPr.CloneNode($true) }
        }

        $children = @($cell.ChildNodes)
        foreach ($ch in $children) {
            if ($ch.LocalName -eq 'p') { [void]$cell.RemoveChild($ch) }
        }

        $p = $docObj.CreateElement('w', 'p', $wNs)
        if ($pPrClone -ne $null) {
            [void]$p.AppendChild($pPrClone)
        } else {
            [void]$p.AppendChild($docObj.CreateElement('w', 'pPr', $wNs))
        }

        if ($center) {
            $pPrNode = $p.SelectSingleNode('./w:pPr', $nsMgr)
            $jc = $pPrNode.SelectSingleNode('./w:jc', $nsMgr)
            if ($jc -eq $null) {
                $jc = $docObj.CreateElement('w', 'jc', $wNs)
                [void]$pPrNode.AppendChild($jc)
            }
            $valAttr = $jc.Attributes['w:val']
            if ($valAttr -eq $null) {
                $valAttr = $docObj.CreateAttribute('w', 'val', $wNs)
                [void]$jc.Attributes.Append($valAttr)
            }
            $valAttr.Value = 'center'
        }

        $r = $docObj.CreateElement('w', 'r', $wNs)
        if ($rPrClone -ne $null) {
            [void]$r.AppendChild($rPrClone)
        }

        $t = $docObj.CreateElement('w', 't', $wNs)
        $spaceAttr = $docObj.CreateAttribute('xml', 'space', $xmlNs)
        $spaceAttr.Value = 'preserve'
        [void]$t.Attributes.Append($spaceAttr)
        $t.InnerText = $text
        [void]$r.AppendChild($t)
        [void]$p.AppendChild($r)
        [void]$cell.AppendChild($p)
    }

    function Add-TableRow([System.Xml.XmlDocument]$docObj, [System.Xml.XmlNode]$tbl, [System.Xml.XmlNamespaceManager]$nsMgr, [string]$stepNum, [string]$content) {
        $rows = $tbl.SelectNodes('./w:tr', $nsMgr)
        $lastRow = $rows.Item($rows.Count - 1)
        $newRow = $lastRow.CloneNode($true)
        $cells = $newRow.SelectNodes('./w:tc', $nsMgr)
        if ($cells.Count -ge 2) {
            Set-CellText $docObj $cells.Item(0) $nsMgr $stepNum $true
            Set-CellText $docObj $cells.Item(1) $nsMgr $content
        }
        [void]$tbl.AppendChild($newRow)
    }

    $tables = $doc.SelectNodes('//w:tbl', $ns)

    foreach ($tbl in $tables) {
        $rows = $tbl.SelectNodes('./w:tr', $ns)
        if ($rows.Count -lt 2) { continue }
        $row1Cells = $rows.Item(0).SelectNodes('./w:tc', $ns)
        if ($row1Cells.Count -lt 1) { continue }
        $h1 = Get-CellText $row1Cells.Item(0) $ns
        $h2 = if ($row1Cells.Count -ge 2) { Get-CellText $row1Cells.Item(1) $ns } else { '' }

        # Deployment Notice table (3-column: Approver | Ticket | Environment)
        if ($h1 -like '*Organization*Approver*' -and $row1Cells.Count -ge 3) {
            $r2 = $rows.Item(1).SelectNodes('./w:tc', $ns)
            if ($r2.Count -ge 3) {
                Set-CellText $doc $r2.Item(0) $ns $Approver
                Set-CellText $doc $r2.Item(1) $ns $TicketID
                Set-CellText $doc $r2.Item(2) $ns $Environment
            }
            if ($rows.Count -ge 4) {
                $r4 = $rows.Item(3).SelectNodes('./w:tc', $ns)
                if ($r4.Count -ge 3) {
                    Set-CellText $doc $r4.Item(0) $ns $Team
                    Set-CellText $doc $r4.Item(1) $ns $Consultant
                    Set-CellText $doc $r4.Item(2) $ns $DateTime
                }
            }
            continue
        }

        # Requirement Summary
        if ($h1 -eq 'Requirement' -and $h2 -like '*Requirement Summary*') {
            for ($i = 0; $i -lt $RequirementItems.Count; $i++) {
                $rowIdx = $i + 1
                if ($rowIdx -lt $rows.Count) {
                    $cells = $rows.Item($rowIdx).SelectNodes('./w:tc', $ns)
                    if ($cells.Count -ge 2) {
                        Set-CellText $doc $cells.Item(0) $ns ($i + 1).ToString() $true
                        Set-CellText $doc $cells.Item(1) $ns $RequirementItems[$i]
                    }
                } else {
                    Add-TableRow $doc $tbl $ns ($rowIdx).ToString() $RequirementItems[$i]
                }
            }
            continue
        }

        # Implementation Steps (Configuration Details)
        if ($h1 -eq 'Step' -and $h2 -like '*Configuration Details*') {
            for ($i = 0; $i -lt $ImplementationItems.Count; $i++) {
                $rowIdx = $i + 1
                if ($rowIdx -lt $rows.Count) {
                    $cells = $rows.Item($rowIdx).SelectNodes('./w:tc', $ns)
                    if ($cells.Count -ge 2) {
                        Set-CellText $doc $cells.Item(0) $ns ($i + 1).ToString() $true
                        Set-CellText $doc $cells.Item(1) $ns $ImplementationItems[$i]
                    }
                } else {
                    Add-TableRow $doc $tbl $ns ($i + 1).ToString() $ImplementationItems[$i]
                }
            }
            continue
        }

        # Testing Steps
        if ($h1 -eq 'Step' -and $h2 -like '*Testing Details*') {
            for ($i = 0; $i -lt $TestingItems.Count; $i++) {
                $rowIdx = $i + 1
                if ($rowIdx -lt $rows.Count) {
                    $cells = $rows.Item($rowIdx).SelectNodes('./w:tc', $ns)
                    if ($cells.Count -ge 2) {
                        Set-CellText $doc $cells.Item(0) $ns ($i + 1).ToString() $true
                        Set-CellText $doc $cells.Item(1) $ns $TestingItems[$i]
                    }
                } else {
                    Add-TableRow $doc $tbl $ns ($i + 1).ToString() $TestingItems[$i]
                }
            }
            continue
        }

        # Rollback Instructions
        if ($h1 -eq 'Step' -and $h2 -like '*Rollback Details*') {
            for ($i = 0; $i -lt $RollbackItems.Count; $i++) {
                $rowIdx = $i + 1
                if ($rowIdx -lt $rows.Count) {
                    $cells = $rows.Item($rowIdx).SelectNodes('./w:tc', $ns)
                    if ($cells.Count -ge 2) {
                        Set-CellText $doc $cells.Item(0) $ns ($i + 1).ToString() $true
                        Set-CellText $doc $cells.Item(1) $ns $RollbackItems[$i]
                    }
                } else {
                    Add-TableRow $doc $tbl $ns ($i + 1).ToString() $RollbackItems[$i]
                }
            }
            continue
        }

        # Additional Comments (1-column table — do not skip with column count guard)
        if ($h1 -like '*Comments*' -and $row1Cells.Count -eq 1) {
            if ($rows.Count -ge 2) {
                $r2 = $rows.Item(1).SelectNodes('./w:tc', $ns)
                if ($r2.Count -ge 1) { Set-CellText $doc $r2.Item(0) $ns $AdditionalComments }
            }
            continue
        }
    }

    # Write back by overwriting the existing entry stream (not delete+recreate,
    # which leaves [trash] entries that corrupt the docx for Word)
    $stream2 = $entry.Open()
    $stream2.SetLength(0)
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    $bytes = $utf8NoBom.GetBytes($doc.OuterXml)
    $stream2.Write($bytes, 0, $bytes.Length)
    $stream2.Close()
}
finally {
    $zip.Dispose()
}

Write-Host "Build note generated: $OutputPath"
```

### Section-to-Table Mapping

| Build Note Section | Table Header (Cell 0) | Table Header (Cell 1) | Notes |
|---|---|---|---|
| Deployment Notice | `*Organization*Approver*` | — | 3-column, rows 2 and 4 |
| Requirement Summary | `Requirement` | `*Requirement Summary*` | 2-column, content in cell 1 |
| Implementation Steps | `Step` | `*Configuration Details*` | 2-column, step # in cell 0 |
| Testing Steps | `Step` | `*Testing Details*` | 2-column, step # in cell 0 |
| Rollback Instructions | `Step` | `*Rollback Details*` | 2-column, step # in cell 0 |
| Additional Comments | `Comments` | — | Single cell row below header |

---

## Template Structure

The Word template (`references/templates/Build_Note_Template.docx`) contains:

- **Deployment Notice**: 3-column table with 4 rows. Row 1 = headers (Organization/Approver, Ticket, Environment). Row 2 = values. Row 3 = headers (Team, Consultant, Date/Time). Row 4 = values.
- **Requirement Summary**: 2-column table. Header row labels "Requirement" | "Requirement Summary". Content rows have step number in column 0 (often just row index), summary text in column 1.
- **Configuration Details**: 2-column table. Header "Step" | "Configuration Details". Content rows: step number | implementation description.
- **Testing Details**: 2-column table. Header "Step" | "Testing Details". Content rows: step number | test result line.
- **Rollback Details**: 2-column table. Header "Step" | "Rollback Details". Content rows: step number | rollback instruction.
- **Additional Comments**: Header row "Comments", then one content row spanning the table width.

### Key Rules

- **Never use string replacement** on `.docx` XML — Word fragments text across multiple `<w:r>` and `<w:t>` elements. Placeholders like `{{TICKET_ID}}` will be split (e.g. `{{TICK`, `ET_`, `ID}}`) and replacement will silently fail or corrupt the document.
- **Always use XmlDocument DOM operations** — locate nodes by XPath, remove children, create new elements.
- **Preserve `w:tcPr`** (table cell properties) — only remove/replace `w:p` paragraph children, never the cell properties node.
- **Add `xml:space="preserve"`** on all `w:t` elements to prevent Word from stripping leading/trailing whitespace.
- **Clone `w:tr` for extra rows** — if you have more content items than the template provides rows, clone the last data row and append to the table.
- **Never delete+recreate ZIP entries** — `$entry.Delete()` followed by `$zip.CreateEntry()` leaves `[trash]` folders in the ZIP archive that corrupt the docx. Instead, open the existing entry's stream, truncate with `SetLength(0)`, and write the modified XML as raw UTF-8 bytes (no BOM).
- **Use `$doc.OuterXml` for write-back, not `XmlWriter` or `StreamWriter`** — `XmlWriter` can alter namespace declarations, strip whitespace formatting, and change encoding case. Writing `OuterXml` as raw bytes with `UTF8Encoding($false)` preserves the original document structure.
- **Comments table has 1 column** — do not skip tables with `$row1Cells.Count -lt 2`. The Additional Comments table has a single-column header row ("Comments") and a single-column content row. Guard with `-lt 1` and handle 1-column tables in the match logic.
- **Trim unused data rows after fill** — if the template has more prebuilt rows than provided content (for example, a single-paragraph Requirement Summary), remove extra rows so no blank numbered rows remain.
- **Center-align all step numbers consistently** — when writing to column 0 in numbered tables, enforce centered paragraph alignment to match the template style.
- **Preserve template font/style on inserted text** — clone existing `w:pPr`/`w:rPr` from the target cell before replacing content so inserted text keeps Century Gothic and existing table formatting.
- **Remove appendix content when not required** — if the build note does not use the appendix, remove trailing appendix and unit-test placeholder content nodes after the Additional Comments table.

---

## Word Template Compatibility

| Platform | Support |
|---|---|
| Windows + PowerShell 5.1+ | Full support — primary path |
| Windows + PowerShell 7 | Full support |
| macOS / Linux | Not supported — .NET `System.IO.Compression` available but untested |
| VS Code terminal disabled | Fallback to plain text with paste map (see below) |

### Fallback: Plain Text Paste Map

If the terminal is unavailable or the user is not on Windows, output the build note as plain text with a **paste map** showing exactly which text goes into which table cell:

```
=== PASTE MAP (for manual Word template fill) ===

[Deployment Notice — Row 2]
  Cell 0 (Approver): <value>
  Cell 1 (Ticket):   <value>
  Cell 2 (Env):      <value>

[Deployment Notice — Row 4]
  Cell 0 (Team):       <value>
  Cell 1 (Consultant): <value>
  Cell 2 (DateTime):   <value>

[Requirement Summary]
  Row 1: <text>
  Row 2: <text>
  ...

[Configuration Details]
  Step 1: <text>
  Step 2: <text>
  ...

[Testing Details]
  Step 1: <text>
  Step 2: <text>
  ...

[Rollback Details]
  Step 1: <text>
  Step 2: <text>
  ...

[Additional Comments]
  <text>
```

### Template Customization

Users can substitute their own Word template if it follows the same section header names in column 0/1 of each table. The fill script matches by header text pattern (using `-like` wildcards), not by table position.
