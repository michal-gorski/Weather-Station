# Plain Text Build & Release Note Template

Use this template when the user requests plain text output. Use `===` for top-level dividers and `---` for subsection dividers. Output in a code block so the user can copy it directly.

---

## Template

```
================================================================================
  KAINOS AMS INTEGRATIONS — BUILD & RELEASE NOTE
  {{TICKET_ID}} — {{INTEGRATION_NAME}}
================================================================================

DEPLOYMENT NOTICE
-----------------
Customer       : {{CUSTOMER_NAME}}
Integration    : {{INTEGRATION_NAME}}
Environment    : {{ENVIRONMENT}}
Consultant     : {{CONSULTANT_NAME}}
Approver       : {{ORGANISATION}} / {{APPROVER_NAME}}
Date           : {{DATE}}
Ticket         : {{TICKET_ID}}


================================================================================
1. REQUIREMENT SUMMARY
================================================================================

{{PURPOSE_STATEMENT}}

  - {{BULLET_1}}
  - {{BULLET_2}}
  - {{BULLET_3}}
  [up to 8 bullets]


================================================================================
2. IMPLEMENTATION STEPS
================================================================================

Step 1 — {{STEP_1_TITLE}}
--------------------------
{{STEP_1_DESCRIPTION}}

  BEFORE:
  -------
  {{BEFORE_CODE_LINE_1}}
  {{BEFORE_CODE_LINE_2}}

  AFTER:
  ------
  {{AFTER_CODE_LINE_1}}
  {{AFTER_CODE_LINE_2}}

[Repeat numbered steps for each change. Omit BEFORE/AFTER if config-only.]


================================================================================
3. STEPS COMPLETED
================================================================================

{{TEST_GROUP_1}}
  [PASS] {{TEST_SCENARIO_1}}
  [PASS] {{TEST_SCENARIO_2}}
  [FAIL] {{FAILED_SCENARIO}}

{{TEST_GROUP_2}}
  [PASS] {{TEST_SCENARIO_3}}

[Group scenarios by theme. One line per scenario. No per-field detail.]


================================================================================
4. ROLLBACK INSTRUCTIONS
================================================================================

{{ROLLBACK_DESCRIPTION}}

[If no rollback needed: "No rollback required. Redeploy the previous assembly
version from the main branch on GitHub to restore prior behaviour."]


================================================================================
5. ADDITIONAL COMMENTS
================================================================================

{{ADDITIONAL_COMMENTS}}

[If none: "No additional comments."]


================================================================================
  END OF BUILD & RELEASE NOTE — {{TICKET_ID}}
================================================================================
```

## Notes

- Keep column alignment consistent using spaces (not tabs) so the note renders correctly in monospace environments (email, ServiceNow)
- The label column (`Customer`, `Integration`, etc.) is padded to 15 characters with spaces before the colon
- Omit the BEFORE/AFTER block from a step if no code changed (e.g. report configuration, integration attribute update)
- `[PASS]` and `[FAIL]` are fixed-width 6-character tokens — do not change the format
