# HTML Build & Release Note Template

Use this template when the user requests HTML output. Substitute all `{{PLACEHOLDER}}` values with real content. Output the completed HTML in a code block.

## Kainos Brand Notes

- Header background: linear gradient from `#1a1a4e` (dark navy) to `#00a3a3` (Kainos teal)
- Logo: inline SVG text "KAINOS" in white, bold — use if no image asset is available
- Font: Arial / sans-serif throughout
- `[PASS]` badges: `#28a745` green; `[FAIL]` badges: `#dc3545` red
- Section headings: `#1a1a4e` dark navy
- Before/after code blocks: dark background (`#1e1e1e`), monospace font

---

## Template

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Build &amp; Release Note — {{TICKET_ID}}</title>
  <style>
    body { font-family: Arial, sans-serif; font-size: 14px; color: #333; margin: 0; padding: 0; background: #f5f5f5; }
    .header { background: linear-gradient(135deg, #1a1a4e 0%, #00a3a3 100%); color: white; padding: 28px 36px; display: flex; align-items: center; gap: 20px; }
    .header .logo { font-size: 28px; font-weight: bold; letter-spacing: 4px; color: white; }
    .header .doc-title { font-size: 18px; opacity: 0.9; }
    .header .subtitle { font-size: 13px; opacity: 0.75; margin-top: 4px; }
    .container { max-width: 960px; margin: 30px auto; padding: 0 20px; }
    .card { background: white; border-radius: 6px; box-shadow: 0 1px 4px rgba(0,0,0,0.1); margin-bottom: 24px; overflow: hidden; }
    .card-header { background: #1a1a4e; color: white; padding: 12px 20px; font-size: 14px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.5px; }
    .card-body { padding: 20px; }
    table.meta { width: 100%; border-collapse: collapse; }
    table.meta td { padding: 7px 10px; vertical-align: top; border-bottom: 1px solid #eee; }
    table.meta td:first-child { font-weight: bold; color: #555; width: 200px; }
    table.meta tr:last-child td { border-bottom: none; }
    ul.summary { margin: 0; padding-left: 20px; line-height: 1.8; }
    .step { margin-bottom: 18px; }
    .step-num { display: inline-block; background: #1a1a4e; color: white; border-radius: 50%; width: 24px; height: 24px; text-align: center; line-height: 24px; font-size: 12px; font-weight: bold; margin-right: 8px; }
    .step-title { font-weight: bold; }
    .code-label { font-size: 11px; font-weight: bold; color: #888; margin: 8px 0 4px; text-transform: uppercase; letter-spacing: 0.5px; }
    pre { background: #1e1e1e; color: #d4d4d4; padding: 14px 16px; border-radius: 4px; overflow-x: auto; font-size: 12px; margin: 6px 0 12px; line-height: 1.5; }
    .test-group { margin-bottom: 14px; }
    .test-group-title { font-weight: bold; color: #1a1a4e; margin-bottom: 6px; }
    .test-row { display: flex; align-items: baseline; gap: 10px; padding: 4px 0; border-bottom: 1px solid #f0f0f0; font-size: 13px; }
    .test-row:last-child { border-bottom: none; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; color: white; white-space: nowrap; }
    .badge.pass { background: #28a745; }
    .badge.fail { background: #dc3545; }
    .test-desc { flex: 1; }
    .footer { text-align: center; font-size: 12px; color: #aaa; padding: 20px 0 40px; }
  </style>
</head>
<body>

<div class="header">
  <div>
    <div class="logo">KAINOS</div>
  </div>
  <div>
    <div class="doc-title">Build &amp; Release Note</div>
    <div class="subtitle">{{TICKET_ID}} — {{INTEGRATION_NAME}}</div>
  </div>
</div>

<div class="container">

  <!-- Deployment Notice -->
  <div class="card">
    <div class="card-header">Deployment Notice</div>
    <div class="card-body">
      <table class="meta">
        <tr><td>Customer</td><td>{{CUSTOMER_NAME}}</td></tr>
        <tr><td>Integration</td><td>{{INTEGRATION_NAME}}</td></tr>
        <tr><td>Environment</td><td>{{ENVIRONMENT}}</td></tr>
        <tr><td>Consultant</td><td>{{CONSULTANT_NAME}}</td></tr>
        <tr><td>Approver</td><td>{{ORGANISATION}} / {{APPROVER_NAME}}</td></tr>
        <tr><td>Date</td><td>{{DATE}}</td></tr>
        <tr><td>Ticket</td><td>{{TICKET_ID}}</td></tr>
      </table>
    </div>
  </div>

  <!-- Requirement Summary -->
  <div class="card">
    <div class="card-header">Requirement Summary</div>
    <div class="card-body">
      <p>{{PURPOSE_STATEMENT}}</p>
      <ul class="summary">
        <li>{{BULLET_1}}</li>
        <li>{{BULLET_2}}</li>
        <!-- Add up to 8 bullets total -->
      </ul>
    </div>
  </div>

  <!-- Implementation Steps -->
  <div class="card">
    <div class="card-header">Implementation Steps</div>
    <div class="card-body">

      <div class="step">
        <span class="step-num">1</span>
        <span class="step-title">{{STEP_1_TITLE}}</span>
        <p>{{STEP_1_DESCRIPTION}}</p>
        <!-- Include before/after only when code changed -->
        <div class="code-label">Before</div>
        <pre>{{BEFORE_CODE}}</pre>
        <div class="code-label">After</div>
        <pre>{{AFTER_CODE}}</pre>
      </div>

      <!-- Repeat .step block for each change -->

    </div>
  </div>

  <!-- Steps Completed (Testing) -->
  <div class="card">
    <div class="card-header">Steps Completed</div>
    <div class="card-body">

      <div class="test-group">
        <div class="test-group-title">{{TEST_GROUP_1}}</div>
        <div class="test-row">
          <span class="badge pass">PASS</span>
          <span class="test-desc">{{TEST_SCENARIO_DESCRIPTION}}</span>
        </div>
        <div class="test-row">
          <span class="badge fail">FAIL</span>
          <span class="test-desc">{{FAILED_SCENARIO_DESCRIPTION}}</span>
        </div>
        <!-- Repeat test-row for each scenario in this group -->
      </div>

      <!-- Repeat test-group for each theme -->

    </div>
  </div>

  <!-- Rollback Instructions -->
  <div class="card">
    <div class="card-header">Rollback Instructions</div>
    <div class="card-body">
      <p>{{ROLLBACK_DESCRIPTION}}</p>
      <!-- If no rollback is needed: "No rollback required. Redeployment of the previous assembly version from GitHub will restore prior behaviour." -->
    </div>
  </div>

  <!-- Additional Comments -->
  <div class="card">
    <div class="card-header">Additional Comments</div>
    <div class="card-body">
      <p>{{ADDITIONAL_COMMENTS}}</p>
      <!-- If none: "No additional comments." -->
    </div>
  </div>

</div>

<div class="footer">Kainos AMS Integrations &mdash; {{TICKET_ID}} &mdash; {{DATE}}</div>

</body>
</html>
```

## Notes

- Remove the before/after code block pair from a step if the change was configuration-only (no code diff to show)
- If all tests passed, the `fail` badge row can be omitted
- The footer repeats the ticket ID and date for printed copies
- Do not add a Kainos logo image unless the user provides one — the text "KAINOS" in the header serves as the wordmark
