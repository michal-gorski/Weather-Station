# Workday Integrations Glossary

Key Workday terms relevant to integration design, build, and support. Sourced from the official Workday Admin Guide.

## A

### Aggregation Security Group

A security group that grants access rights to members of an included set of security groups. Revokes access of members of any excluded security groups.

*Integration relevance: used when configuring broad access for integration system users that need permissions from multiple security groups.*

### Approve

An action in a business process that designated participants select to progress the event to the next step.

*Integration relevance: integrations often need to wait for or trigger approval steps; approval status is a common data point in outbound feeds.*

## B

### Benefit Event Type

Identifies the events that trigger benefit enrolment, such as open enrolment, new hires, or the birth of a child. Also identifies the coverage types to make available to employees when an event of this type occurs.

*Integration relevance: benefit provider integrations (e.g. health, dental) are often triggered by or filtered on benefit event types.*

### Benefit Group

A group of employees who qualify for benefits based on eligibility rules. Employees must be included in a benefit group to enrol in a benefit plan.

*Integration relevance: benefit connector integrations use benefit groups to scope which workers are included in outbound files.*

### Business Object

Objects used to store data in Workday (such as organisations or workers). A business object has fields and instances, analogous to rows and columns in a spreadsheet. Workday links related business objects: a worker is associated with a position, the position to a job profile, and so on.

*Integration relevance: business objects are the building blocks of custom reports, data sources, and web service operations.*

### Business Process Definition

The tasks that compose a business process, the order in which they must be done, and who can do them.

*Integration relevance: integrations can be configured as steps within a business process definition, triggering automatically when a transaction reaches that step.*

### Business Process Instance

A business process that the initiator has started. The Hire Employee for Organisation X business process definition becomes an instance when the initiator uses it to hire an employee.

*Integration relevance: integration events are often correlated with specific business process instances for audit and troubleshooting.*

### Business Process Security Policy

A security policy that secures the steps and process-wide actions including view, rescind, cancel, and correct. It specifies which security groups have access to each action.

*Integration relevance: integration system users may need access granted via business process security policies to initiate or interact with business processes.*

## C

### Cancel (Business Process)

Cancelling a business process stops the workflow in progress and reverses changes made to data. You cannot cancel a completed business process; you must rescind it. A securable action in a business process security policy.

### Company

An organisation within Workday representing an internal business entity. In Financial Management, companies are the primary organisation for all business processes. A Company is considered the level at which one holds a balanced set of books and should reflect Legal Entities where possible.

*Integration relevance: company is a fundamental filter and grouping dimension in payroll, financials, and HCM integrations.*

### Company Hierarchy

Defines a parent-child or reporting relationship between Companies in your organisations. Influences role assignments, planning, and reporting.

### Compensation Component

The umbrella term for compensation packages, grades, grade profiles, and plans that can be associated with compensation eligibility rules.

*Integration relevance: compensation components are commonly extracted in payroll and total rewards integrations.*

### Compensation Element

Compensation elements link Compensation to Payroll. When a compensation element is attached to a plan assigned to an employee, Workday can determine which earnings to use to pay the employee.

*Integration relevance: critical in payroll integrations (PECI, PICOF) where compensation elements map to external pay codes.*

### Conditions

One or more logical matches resolved to True or False, used to decide if an action should be taken. You can add conditions to steps in a business process to determine if the step should run.

*Integration relevance: conditions on business process steps control whether an integration step fires — e.g. only trigger a feed for certain worker types.*

### Connector

A set of one or more integration templates that provide a framework for building integrations in a particular functional area. A connector can support a specific type of data or a specific endpoint (e.g. Salesforce.com or Okta).

*Integration relevance: connectors are the primary mechanism for building standard integrations in Workday without Studio.*

### Contextual Custom Report

A custom report created from the related actions menu of a Workday object by selecting Reporting > Create Custom Report from Here. Simplifies choices of data and fields to those related to the context of the object.

### Correct (Business Process)

Correcting a business process changes a specification or data in the workflow while in progress. A securable action in a business process security policy.

*Integration relevance: corrections can retrigger integration steps or cause delta detection logic to fire again.*

### Custom Report

Reports not delivered by Workday, built using the Workday Report Writer. Can be created new or by copying another standard or custom report.

*Integration relevance: custom reports are the primary data source for EIB integrations and RaaS (Report as a Service) web service calls.*

## D

### Dashboard

A specialised landing page containing a set of pre-configured worklets for a functional area. You can copy, modify, or add custom worklets using the report writer.

### Data Source

A data source defines a set of business object instances for reporting purposes. Allows reporting access to all business objects related to those in the data source.

*Integration relevance: data sources underpin custom reports and determine which related business objects and fields are available for extraction.*

### Deny (Business Process)

When you deny a business process, it is terminated and all Workday data is restored to its state before the business process started. To restart, you must submit the process again and redo all previously completed steps.

### Domain

A collection of related securable items such as actions, reports, report data, report data sources, or custom report fields. Each domain is secured by a domain security policy.

*Integration relevance: integration system users must be granted access to the appropriate domains to read or write data via web services or reports.*

### Domain Security Policy

A collection of related securable elements and user-specified security groups that have access to elements of each type.

*Integration relevance: configuring domain security policies is a core setup task for any integration — the ISU's security groups must include policies granting Get/Put access to required domains.*

## E

### Enterprise Interface Builder (EIB)

An integration tool that enables you to create simple, secure, and customisable integrations with Workday. An EIB consists of an integration system, an integration data source, an integration transformation, and an integration transport protocol.

*Integration relevance: EIBs are the most common integration type for simple inbound/outbound file-based integrations. They support scheduled execution, business process triggering, and custom transformations.*

### Event

A business process transaction that occurs within your organisation, such as hiring or terminating an employee.

*Integration relevance: events are the triggers for many outbound integrations — change-based feeds detect completed events to determine what data to send.*

## F

### Field Overrides

A tool that lets you customise integration systems based on a connector template. Field overrides are managed through an integration service. They use calculated fields or report fields to supply values to an integration system.

*Integration relevance: field overrides are the primary customisation mechanism for connector-based integrations — used to map Workday data to external system requirements without modifying the connector template itself.*

### Functional Area

A collection of domain or business process security policies related to the same set of product features (e.g. Benefits or Compensation).

*Integration relevance: functional areas group security policies logically, making it easier to grant an ISU access to all policies needed for a particular integration domain.*

## I

### Initiation Step

The first step of a business process.

*Integration relevance: some integrations are configured to fire on the initiation step rather than waiting for completion.*

### Integration Attribute

An integration component that specifies the tenanted value of a data element in Workday. Example: Plan Sponsor Name is a type of attribute in benefit provider integrations.

*Integration relevance: integration attributes store tenant-specific configuration values (e.g. company codes, file naming patterns) that customise a connector's behaviour without code changes.*

### Integration Data Source

Indicates the type of data that Workday receives from or exports to an external system and its location.

*Integration relevance: defines what data flows through the integration — for outbound, typically a custom report; for inbound, the expected file format and mapping.*

### Integration Event

The record of an integration process. Every integration — current or past, involving the import or export of data, successful or not — gets recorded as an integration event. The integration event contains all information about the integration process, including its status.

*Integration relevance: integration events are the primary monitoring and troubleshooting artefact — they hold logs, documents, errors, and timing information.*

### Integration Map

An integration component that specifies how values in Workday map to values in an external system. Example: Pay Rate Frequency is a type of map in third-party payroll integrations.

*Integration relevance: integration maps provide code translation between Workday reference IDs and external system codes (e.g. mapping Workday country codes to ISO codes).*

### Integration Service

A group of related integration attributes, maps, and XSLT that provides a framework to transform Workday data into the format required by an external system.

*Integration relevance: integration services are the organisational container for all customisation artefacts attached to a connector-based integration.*

### Integration System

A tenanted definition of an integration between Workday and an external system, based on a template that provides the methodology for communicating data.

*Integration relevance: the integration system is the top-level configuration object for any integration — it holds the ISU assignment, scheduling, notifications, and links to services.*

### Integration Template

A collection of integration services that enables communication between Workday and an external system. Workday provides templates in categories such as Benefits, Financials, HCM, Payroll, Procurement, Recruiting, Security, and Settlement. Many contain default values for attributes and prompt values for attributes and maps.

*Integration relevance: templates are the foundation that connectors and Studio integrations build upon — they define the structure that tenanted integration systems inherit.*

### Integration Transformation

Converts data into a format that Workday or a receiving external system can understand. Workday provides some delivered transformations, and you can also create custom transformations.

*Integration relevance: transformations are typically XSLT stylesheets that convert Workday XML into the target format (CSV, fixed-width, XML, JSON, etc.).*

### Integration Transport Protocol

Controls how Workday exports data to an external endpoint or imports data from an external endpoint. Workday supports several transport protocols including email, FTP/SFTP, HTTP/SSL, Workday attachments, and Workday Web Services.

*Integration relevance: transport configuration defines how and where files are delivered — SFTP endpoints, HTTP URLs, email addresses, or Workday document storage.*

### Intersection Security Group

A security group whose members are other security groups. Members associated with all included security groups are granted access through an intersection security group.

*Integration relevance: intersection security groups are useful for granting integrations access only where multiple conditions are met (e.g. workers in a specific company AND job family).*

## J

### Job-Based Security Group

A security group that includes one or more job-related attributes or objects including job profile, job family, job category, management level, or exempt/non-exempt status.

### Job Profile

The generic features and characteristics of a job or position, such as management level, pay rate type, compensation, skills, and other qualifications.

*Integration relevance: job profile is a commonly extracted field in HCM integrations and is often used as a filter criterion.*

## L

### Location Membership Security Group

A security group whose members are any workers assigned to that location.

*Integration relevance: can be used to scope integration access to workers in specific locations.*

## O

### Organisation Security Group

A security group whose members are any workers assigned to that organisation.

*Integration relevance: commonly used in integration security configuration to restrict data access to specific supervisory organisations or cost centres.*

## P

### Passive Event

Events that result from the passage of time rather than from a specific change to employee data.

*Integration relevance: passive events (e.g. age milestones, benefit eligibility changes) can trigger integrations but are not always captured by standard change detection.*

### Position Management Staffing Model

A structure that defines different staffing rules and restrictions for each position in an organisation.

*Integration relevance: determines whether position data is available and how headcount is tracked — affects position-based integrations and org structure feeds.*

### Position Restrictions

The attributes and conditions that apply to an unfilled position in a supervisory organisation that uses the position management staffing model. Includes job profile, location, qualifications, and worker type.

### Pre-Hire

In Staffing, an individual you are tracking before employment. In Recruiting, a candidate who is in the Offer, Employment Agreement, Background Check, or Ready for Hire stage.

*Integration relevance: pre-hires are relevant to background check integrations, onboarding feeds, and provisioning integrations that need to act before the hire date.*

## R

### Reference ID

A unique identifier used to look up data for integration purposes.

*Integration relevance: reference IDs are the primary mechanism for matching records between Workday and external systems. Custom IDs (Employee_ID, Contingent_Worker_ID, Position_ID, etc.) are used in web service calls and inbound file loads.*

## S

### Staffing Model

A structure that defines how jobs and positions are created and filled in a supervisory organisation. Workday supports two kinds: Job Management and Position Management.

*Integration relevance: the staffing model affects which data is available for extraction and how position/headcount information is structured in outbound feeds.*

### System User

An account associated with and required to launch a Connector or Studio integration. Workday delivered and custom integrations require a system user account for authentication and web service calls. A system user account is not associated with a person in Workday.

*Integration relevance: the Integration System User (ISU) is the identity under which integrations execute. It must be assigned to the integration system and granted appropriate security group memberships to access required data and services.*

## T

### Time Block

A time block carries information about a portion of time, such as the number of hours worked or in/out times. Time blocks can be reported or calculated, but only calculated time blocks are pulled into Workday Payroll.

*Integration relevance: time tracking integrations (inbound clock data, outbound time feeds) work with time block data.*

### Time Calculation Tag

Workday applies calculation tags to time blocks during time calculations. Tags map to payroll earnings to drive how time blocks are paid and can be included in time off and accrual calculations.

*Integration relevance: time calculation tags appear in payroll integration output (PECI/PICOF) and external time system feeds.*

## W

### Workday Studio

An Eclipse-based development environment that enables you to build more complex integrations with Workday.

*Integration relevance: Studio is the tool for building integrations that require complex logic, multiple data sources, conditional routing, custom Java, or multi-step orchestration beyond what EIBs and connectors support.*

### Workday Web Services

Workday's public API. Based on open standards, Workday Web Services (WWS) provide the core method for integration with Workday.

*Integration relevance: WWS (SOAP-based) and REST APIs are used by Studio integrations, external systems, and RaaS calls to read and write Workday data programmatically.*

### Worker

An employee or a contingent worker.

*Integration relevance: the worker is the most fundamental data object in HCM integrations — nearly all outbound feeds are scoped to a population of workers.*

### Worklets

Mini applications represented by clickable icons in Workday, providing quick and easy access to tasks and data. Examples include the Inventory or Time Off worklets, or worklets based on custom reports.

*Integration relevance: worklets based on custom reports can surface integration status or data quality dashboards to business users.*
