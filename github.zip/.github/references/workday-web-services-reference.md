# Workday Web Services and Integration IDs Reference

Covers the SOAP API concepts, versioning, authentication headers, paging, Integration IDs, and common patterns needed when building or supporting integrations that use Workday Web Services.

---

## 1. Overview

Workday Web Services (WWS) provide a programmatic public API for Workday's on-demand business management services. WWS use industry standards including WSDL, SOAP, REST, and WS-* standards. Web services are a central component of the Workday architecture and the core enablement tool for integration.

**Key resources:**

| Resource | Purpose |
|----------|---------|
| SOAP Operation Directory | Full API documentation for all operations |
| SOAP API Explorer | Interactive exploration of web service operations on the Developer Site |

**API Support Policy:** Workday versions WWS to ensure stability and backward compatibility. Workday provides at least 18 months' notice before retiring an API version or operation, communicated through the Developer Network and direct customer notification.

---

## 2. Versioning

### Format and URL Patterns

Workday provides a new version of the WWS API with each release and regular updates between releases. Versions use the format `vNN.N` (e.g. `v33.1`). Before v21.0, whole numbers were used.

**Endpoint versioning:**
```
https://{Workday domain}/ccx/service/{tenant}/{service}/{version}
```

**WSDL retrieval:**
```
https://{Workday domain}/ccx/service/{tenant}/{service}/{version}?wsdl
```

### Version in the SOAP Message

You can specify the version in the SOAP envelope's root request element using the `wd:version` attribute:

```xml
<wd:Get_Locations_Request xmlns:wd="urn:com.workday/bsvc" wd:version="v33.1">
```

When both endpoint and message versions are specified, the **message version takes precedence**.

### Unversioned Requests

A versionless request defaults to **v15** of the WWS API. Workday strongly discourages unversioned requests. After v15 reaches End of Life, Workday uses the earliest available version.

### Combined WSDL for Multiple Services

Combine services with the `+` character:

```
https://{endpoint}/ccx/service/{tenant}/Staffing+Human_Resources+Recruiting?wsdl
```

Use `?xsd` to retrieve the combined XML Schema. Combined service WSDLs always return the **latest version**.

### Best Practices for Versioning

- Always specify the version at the message level
- Use the latest available version for optimum performance and stability
- Monitor the API Change Log report for version changes
- Workday does not generally enhance prior versions

---

## 3. SOAP API Headers

### External Integration Headers (Tracking)

These headers are logged by Workday for troubleshooting and analytics:

| Header | Purpose | Recommended Value |
|--------|---------|-------------------|
| `wd-external-request-id` | Track individual web service requests | UUID or unique alphanumeric string |
| `wd-external-application-id` | Track external systems sending requests | Name of the integration/tool |
| `wd-external-originator-id` | Track who initiated the request | User or system account name |

**Guidelines:**
- Limit header values to 50 characters (longer values are truncated)
- Do not include sensitive information
- For Workday partner API calls, `wd-external-application-id` is recommended; Workday may reject requests without it
- If no external integration headers are sent, the request headers are not logged

### Validate-Only Mode Header

Validates a SOAP request without persisting data in the tenant.

```
X-Validate-Only: 1
```

- Available from v27.0 onwards
- Returns validation errors but does not validate custom validations
- For Import operations, only tests validations listed in the operation's documentation
- Use `Get_Import_Process_Messages` to retrieve validation messages for Import operations
- EIB and Studio support validate-only mode; iLoad does not

### Request Timeout Header

Specify a custom timeout for request calls:

```
wd-request-timeout: 21600000
```

Value is in **milliseconds** (example: 21600000 = 6 hours).

### Disable Integration Subscriptions Header

Prevents integration subscriptions from firing on a web service request:

```
x-disable-subscriptions: 1
```

All subscriptions are disabled for that request (you cannot selectively disable individual subscriptions). Default is 0 (subscriptions enabled). In Studio, use the `set-headers` component before the web service call.

### Tenant Routing

The tenant is specified in the endpoint URL path (`/ccx/service/{tenant}/...`) rather than via a separate header. The tenant is also appended to the username for authentication (e.g. `ISU_benefits@my_tenant`).

---

## 4. Best Practices

From the official Workday Web Services Best Practices guidance:

| Practice | Detail |
|----------|--------|
| Always specify a version | Specify the version at the message level in every request |
| Use the latest version | Latest versions have optimum performance and stability |
| Specify `As_Of_Entry_DateTime` when paging | Ensures consistent paging results across pages |
| Never use a standard report with an integration | Copy it to a custom report first and enable Web Service |
| Always web-service-enable custom reports | Enforces additional validations and stabilises XML Schema |
| Only use `Descriptor` for readability | Descriptors change in format and value; never use as identifiers |
| Choose Put vs Import vs Bulk Import | **Put** for small/individual requests; **Import** for large documents; **Bulk Import** for many individual documents asynchronously |
| Use `wd-request-timeout` header | For long-running requests that may exceed default timeout |

---

## 5. Integration and Web Service Limits

Key limits referenced throughout the documentation:

| Limit | Value / Notes |
|-------|---------------|
| Import web service maximum payload size | 2 GB (~750,000 entries for student charges) |
| Maximum paging count per page | 999 elements (default: 100) |
| Maximum instances in a single response | 1,000,000 (requests exceeding this fail with error) |
| Paging optimisation cache timeout | 2 hours between consecutive paged requests; 30 minutes after the last page is requested |
| Integration runtime limit | 2 hours (Workday terminates integrations exceeding this) |
| Journal lines per Import request | Recommended ~10,000 lines per journal; split when approaching 100,000 |
| Bulk Import processing modes | `high-concurrency`, `low-concurrency`, `serial` |

**Note:** For current, comprehensive limits, refer to the "Reference: Integrations and Web Service Limits" page in the Workday Admin Guide, as these can change between releases.

---

## 6. Custom Objects in WWS

### What Custom Objects Are

Custom Objects are tenant-specific data structures. Because they are unique to each tenant, their schema is not in the public WSDL — you must retrieve a tenant-specific WSDL.

### Retrieving the Custom WSDL

**From within Workday:**
1. Access the Public Web Services report
2. Select any web service's related action menu
3. Select Web Service > View Custom WSDL

**Remotely (without logging in):**

Insert `Custom/Data` between the tenant and service in the URL:
```
https://{Workday Service}/ccx/service/{tenant}/Custom/Data/Human_Resources/v24.0?wsdl
```

Use basic authentication with username only (do not append `@tenant`).

**Security required:** Custom Object Management domain (Get Integration permissions) + Integration Build domain.

### XPath Queries for Custom Objects

Custom objects use a tenant-specific namespace:
```
xmlns:custom="urn:com.workday/tenants/{tenant}/data/custom"
```

Use `custom:` prefix for custom object elements and `wd:` for standard elements in XPath.

### Operations Available

Operations supporting custom objects typically include "Additional Data" in their names:
- Get Job Application Additional Data
- Put Job Application Additional Data
- Edit Worker Additional Data
- Edit Job Requisition Additional Data
- Edit Position Restrictions Additional Data

### Custom Lists

Specify Custom List values with type `ExtendedAlias`:
```xml
<cus:phoneModel>
    <cus:ID cus:type="ExtendedAlias">iphone6</cus:ID>
</cus:phoneModel>
```

### Single-Instance vs Multi-Instance

- **Single-instance:** Only one record per object; no Reference ID needed
- **Multi-instance:** Multiple records per object; Reference ID recommended; **you must include ALL instances in update requests** — omitted instances are removed as of the effective date

### Effective-Dated Custom Objects

- Processed by the associated business process (add an "Edit Additional Data" step for each Custom Object)
- Each update creates a new instance with a new WID — **do not use WIDs** to reference effective-dated Custom Objects
- Use the Reference ID instead

---

## 7. Integration IDs

### Three Types of IDs

| ID Type | Description | Characteristics |
|---------|-------------|-----------------|
| **External ID** | Two-part identifier: System ID + Value | System ID identifies an integration system; Value identifies the business object instance. Reserved System IDs (WD-WID, WD-EMPLID) support backward compatibility |
| **Reference ID** | Type + Value identifier | Constant across all Workday environments. Business objects can have multiple Reference IDs. Some have parent Reference IDs for uniqueness |
| **Workday ID (WID)** | 32-character auto-generated string | Unique per tenant; **different across tenants**. Non-changing for the object instance within a single tenant |

### Best Practices

**General:**
- Specify easily identifiable Reference IDs
- Avoid sensitive information in Reference ID values (they appear in URLs and reports)

**Connectors and Studio:**
- Never hard-code Reference IDs or WIDs — use integration attributes, maps, and launch parameters instead
- Use environment restriction on attributes and maps for tenant-specific values

**EIB:**
- Use Reference IDs on inbound EIBs
- Use calculated fields on outbound EIBs instead of hard-coded XSLT maps

### Integration IDs Report

The Integration IDs report shows Reference IDs for selected business objects. Use it to:
- Find Reference ID types and values for populating web service requests
- Verify IDs after data loads
- From a worker's related action: Integration IDs > View IDs

### Reference ID Maintenance

The **Put Reference** web service operation and **Maintain Reference IDs** task:
- Populate and maintain Reference IDs
- Cannot update Position IDs, hierarchical Reference IDs, or complex types
- Find valid Reference ID types in the Integrations web service directory under the `Reference_IndexObjectID` section of Put Reference

### Setting Up Reference IDs (Using EIB)

1. Access the Maintain Reference IDs task
2. Options: Include Empty Values Only, Include Defaulted Values Only, or all
3. Click OK without data to have Workday auto-generate values

**Important:** Use caution when editing Reference ID values — changes can break integrations using current values. Give objects Reference IDs unique across all tenants before migration with Object Transporter.

---

## 8. Import Web Service Pattern

### Import vs Put Distinction

| Aspect | Put | Import | Bulk Import |
|--------|-----|--------|-------------|
| Use case | Small requests, individual documents | Large requests, many lines | Many individual documents |
| Processing | Synchronous | **Asynchronous** (background process) | Asynchronous |
| Response | Full result | WID of background process | WID of background process |
| Scalability | Individual records | Large batch in one call | Many small documents |

### Asynchronous Processing Model

Import web services:
1. Accept the request and return immediately with a process WID
2. Split the document into chunks for parallel processing
3. Process in the background

An Import request creates a **sub business process step** — later steps in the parent business process wait until the Import finishes.

### Monitoring Import Progress

- **Process Monitor** in the Workday tenant UI
- **Get_Import_Processes** operation — monitors status
- **Get_Import_Process_Messages** operation — retrieves processing messages and errors

### Bulk Import Web Services

Load many individual documents asynchronously. Processing modes (set via `x-bulk-processing-mode-override` header):

| Mode | Description |
|------|-------------|
| `high-concurrency` | Maximum throughput; higher risk of data conflicts |
| `low-concurrency` | Reduced simultaneous processing; fewer conflicts |
| `serial` | Sequential processing; lowest conflict risk |

---

## 9. Replace_All and Delete Attributes

These attributes enable adding, editing, and removing data from multi-instance sets without resending all entries.

### How Replace_All Works

```xml
<bsvc:Multi_Instance_Data bsvc:Replace_All="?">
   <bsvc:Instance_Data bsvc:Delete="?">
      <bsvc:Instance_Data_Reference>...</bsvc:Instance_Data_Reference>
      <bsvc:Data_1>...</bsvc:Data_1>
   </bsvc:Instance_Data>
</bsvc:Multi_Instance_Data>
```

### Behaviour Summary

| Use Case | Replace_All | Delete | Reference |
|----------|-------------|--------|-----------|
| Create/modify entry, preserve existing | `false` | `false` | Omit for new; include for update |
| Delete specific entry, preserve others | `false` | `true` | Required (identifies instance) |
| Create/modify entry, remove all others | `true` | (omit) | Omit for new |
| Remove all entries | `true` | (omit) | Use empty data element |

### Key Rules

- `Replace_All = true` replaces all existing data (same as omitting Replace_All entirely)
- `Replace_All = false` preserves existing data
- `Delete = true` requires the instance Reference element to identify what to remove
- When `Replace_All = true`, Delete is irrelevant — omit it

---

## 10. Date, Time, and Time Zone Handling

### Supported Formats

| Format | Example | Description |
|--------|---------|-------------|
| `YYYY-MM-DDThh:mm:ss.fffZ` | `2013-02-26T19:06:57.493Z` | Datetime at UTC |
| `YYYY-MM-DDThh:mm:ss.fff-hh:mm` | `2014-04-15T19:06:57.493-08:00` | Datetime with offset |
| `YYYY-MM-DD` | `2014-02-26` | Date only (no time/offset) |

### Time Zone Behaviour by API Version

| Version | Behaviour |
|---------|-----------|
| v9 and earlier | Converts inbound datetimes based on offset to Pacific Time |
| v10 | Assumes all inbound values are Pacific Time regardless of offset |
| **v11 and later** | Converts inbound **datetimes** based on offset; assumes inbound **dates** are Pacific Time |

**All GET responses** return datetimes in Pacific Time (UTC-07:00 or UTC-08:00 depending on season).

### Recommendations

- Always provide offset values for datetimes from external systems
- Adjust for the difference between your business time zone and Pacific Time
- For operations using `As_Of_Effective_Date` across time zones, specify an explicit date appropriate to the target time zone
- If opted in to the Time Zones feature (Workday 32+) and not using an ISU, Workday uses the user's local time zone

---

## 11. Response Filter and Paging

### Response_Filter Element Structure

Most Get operations contain a `Response_Filter` element with these optional sub-elements:

```xml
<bsvc:Response_Filter>
  <bsvc:As_Of_Effective_Date>2013-07-16</bsvc:As_Of_Effective_Date>
  <bsvc:As_Of_Entry_DateTime>2013-07-16T22:04:00Z</bsvc:As_Of_Entry_DateTime>
  <bsvc:Page>1</bsvc:Page>
  <bsvc:Count>50</bsvc:Count>
</bsvc:Response_Filter>
```

### As_Of Filter Elements

| Element | Purpose |
|---------|---------|
| `As_Of_Effective_Date` | Filters by the effective date of changes (e.g. promotion date, compensation change date) |
| `As_Of_Entry_DateTime` | Filters by when data was entered into Workday. Critical for paging consistency and optimisation |

Both filters return elements **up to and including** the specified date/datetime only.

### Response_Date_Range_Filter

Used in combination with the dates set in Response_Filter to filter by date range.

### Paging

| Element | Description |
|---------|-------------|
| `Page` | Page number to return (starts at 1, default 1) |
| `Count` | Elements per page (default 100, maximum 999) |

### Paging Consistency

**Always specify the same `As_Of_Entry_DateTime` on every page request.** Without it, Workday uses the current time for each page, leading to:
- Missing entries
- Duplicate entries across pages

**Important for time zones:** Paged calls also require an `As_Of_Effective_Date`. Without one, each page defaults to the current date in the ISU's time zone. If your use case involves a different time zone, specify an appropriate `As_Of_Effective_Date`.

### Paging Optimisation Pattern

1. Specify `As_Of_Entry_DateTime` and `Page=1` in the first request — Workday builds a cache/index
2. Retrieve page 1 first (this is the slowest page)
3. Use the **same** `As_Of_Entry_DateTime` on all subsequent pages
4. Change **only** the page number between requests
5. Make requests frequently — the cache expires after ~2 hours between pages (or 30 minutes after the last page)
6. If expired, re-request page 1 to rebuild the cache

**Cache expiry error:** `"Processing error occurred. Page 1 must be requested first."`

---

## 12. Percentage Behaviour

Workday **multiplies decimal values by 100** for percentage fields.

**Example:** Sending `<bsvc:Percent>.08</bsvc:Percent>` results in 8% displayed in the UI.

This applies to:
- Percentage-based allowance plans (Request_Compensation_Change)
- Goal payout bands (Put_Goal_Payout_Band)
- Percentage-based packages in offers (Offer_Request)

**Rule:** Send the decimal representation (0.08 for 8%), not the percentage value (8).

---

## 13. Common Web Service Operation Types

| Operation Type | Description |
|----------------|-------------|
| **Get** | Retrieves data from Workday |
| **Put** | Creates or updates data in Workday (synchronous, individual records) |
| **Import** | Loads large documents with many lines into Workday (asynchronous) |
| **Bulk Import** | Processes many small documents into Workday asynchronously |
| **Submit** | Creates or updates data using a relevant business process |

---

## 14. Common Patterns from API Guides

### Auto_Complete and Run_Now Flags

```xml
<bsvc:Business_Process_Parameters>
    <bsvc:Auto_Complete>true</bsvc:Auto_Complete>
    <bsvc:Run_Now>true</bsvc:Run_Now>
</bsvc:Business_Process_Parameters>
```

- `Auto_Complete=true` bypasses approval/review/to-do steps and disables notifications
- `Run_Now=true` processes the transaction synchronously before returning the response
- `Auto_Complete` will not auto-complete a required action step where the value is not provided

### Business Process Alignment

**Critical pattern:** The business process definition in Workday must align with the web service request.

- If the BP has a step (e.g. Assign Pay Group), populate that data in the request **or** add a condition rule to skip (e.g. `External Load = N`)
- If populating a subprocess in the request (e.g. role assignments), add that step to the BP definition
- Misalignment causes BP events to stay "in progress" or data to be missing

### Security: "Task Not Authorised" Pattern

The most common web service error:

```
Processing error occurred. The task submitted is not authorized.
```

**Resolution checklist:**
1. Run the **View Security for Securable Item** report for the web service operation
2. Check the Business Process Security Policy for the relevant business process
3. Verify the ISU has **unconstrained access** to the Initiating Action
4. If constrained access, verify access to the required organisations
5. Activate any security changes

### Finding Reference IDs

- **Integration IDs report** — search by business object to find Reference ID types and values
- **View Reference IDs** report — search by business object
- **Related actions on an object** — Integration IDs > View IDs
- **Custom reports** — use Report Data Sources containing `Reference_ID_Value` field

### Mass Cancel/Rescind for Bad Loads

When incorrect data is loaded:
- **Mass Cancel Business Processes** — when the BP event is still in progress
- **Mass Rescind Business Processes** — when the BP event is complete
- Security: Business Process Administrator domain in the System functional area

After cancel/rescind, rerun the corrected web service requests.

### File Attachment Pattern

For operations supporting file attachments:

```xml
<wd:Business_Process_Attachment_Data>
    <wd:File_Name>document.pdf</wd:File_Name>
    <wd:File>[base64-encoded content]</wd:File>
    <wd:Content_Type>[MIME type]</wd:Content_Type>
</wd:Business_Process_Attachment_Data>
```

- File content must be **base64-encoded**
- Content_Type values can be found via Integration IDs report, business object "Mime Type"
- Expect large payloads when including attachments in Get responses

### Skip Sub-Process Pattern

To skip a subprocess step in the business process:

```xml
<wd:Business_Sub_Process_Parameters>
    <wd:Skip>1</wd:Skip>
</wd:Business_Sub_Process_Parameters>
```

### Do_Not_Replace_All Pattern

Some web services support `Do_Not_Replace_All="true"` at section level to prevent overwriting data sections not included in the request.

### Worktag Population

Worktags are populated differently depending on the web service:

- **Generic worktag reference** (e.g. Import Accounting Journal, Import Budget):
  ```xml
  <wd:Worktags_Reference>
      <wd:ID wd:type="Custom_Worktag_3">Sales</wd:ID>
  </wd:Worktags_Reference>
  ```

- **Dedicated worktag elements** (e.g. Import Payroll Input, Import Reported Time Blocks):
  ```xml
  <wd:Cost_Center_Reference>
      <wd:ID wd:type="Cost_Center_Reference_ID">Office of the CEO</wd:ID>
  </wd:Cost_Center_Reference>
  <wd:Custom_Worktag_03_Reference>
      <wd:ID wd:type="Custom_Worktag_3">Sales</wd:ID>
  </wd:Custom_Worktag_03_Reference>
  ```

**Important:** ID types are case-sensitive and may vary between tenants for custom worktags.

### Import Web Service Batching

- Batch at least 1,000 entries per Import request
- Never call Import once per record — this creates thousands of background jobs causing severe performance degradation
- Test in a non-production tenant to find the optimal batch size

---

## 15. Error Messages

### Error Response Structure

Errors return HTTP 500 with a `<SOAP-ENV:Fault>` element containing `<faultcode>` and `<faultstring>`.

### Common Error Patterns

| Faultcode | Faultstring | Cause / Solution |
|-----------|-------------|------------------|
| `ns0:Server` | "No service at endpoint..." | Verify the endpoint URL (check for typos in path) |
| `SOAP-ENV:Server.error` | "Customer id was not specified" | Append tenant name to username: `ISU_name@tenant` |
| `SOAP-ENV:Client.authenticationError` | "invalid username or password" | Check credentials; ensure `username@tenant` format |
| `SOAP-ENV:Client.validationError` | "Request service version has reached its end of life" | Update to a currently supported API version |
| `SOAP-ENV:Client.validationError` | "Invalid request service version" | Include the leading `v` (e.g. `v22.1` not `22.1`) |
| `SOAP-ENV:Client.validationError` | "Invalid request" | Verify tenant name in URL and valid operation name |
| `SOAP-ENV:Client.validationError` | "Invalid ID value. 'X' isn't a valid ID value for type = 'Y'" | Supply a valid Reference ID value for the specified type |
| `SOAP-ENV:Client.validationError` | "Processing error occurred. Page 1 must be requested first." | Paging cache expired — re-request page 1 |
| `SOAP-ENV:Client.validationError` | "Reduce the number of instances returned..." | Add request criteria, response filters, or date ranges to reduce the result set below 1,000,000 |
| `SOAP-ENV:Client.validationError` | "The task submitted is not authorized" | Check security configuration (see Section 14) |
| `SOAP-ENV:Client.validationError` | "Multiple Element Contents... contain data where only one is allowed by mutex" | Mutually exclusive elements both populated (e.g. Request_References AND Request_Criteria) |

---

## 16. Rich Text Fields in WWS

Rich Text fields are indicated as `RichText` in the API documentation. Content must be valid HTML markup with XML-escaped special characters.

**Two approaches:**

1. **HTML with XML escaping:**
   ```xml
   <bsvc:Description>&lt;p&gt;Expenses &amp;lt; $40,000&lt;/p&gt;</bsvc:Description>
   ```

2. **CDATA:**
   ```xml
   <bsvc:Description><![CDATA[ Expenses < $40,000 ]]></bsvc:Description>
   ```

### Supported HTML Markup

| Element | Properties |
|---------|------------|
| `b`, `i`, `u` | (none) |
| `li` | `style` |
| `ul`, `ol` | (none) |
| `a` | `href`, `target` |
| `font` | `color`, `face`, `size` |
| `p` | `align` |
| `span` | `id`, `style` |
| `div` | `style` |
| `br` | (self-closing, no closing tag) |

Workday validates HTML markup in the tenant to avoid formatting issues if invalid HTML is submitted.
