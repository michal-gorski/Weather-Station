# Custom Reports & Calculated Fields — Integration Reference

> Extracted from Workday Admin Guides (Manage Workday pp 508-570; Reporting & Analytics pp 37-42, 149-156, 271-301) and practitioner experience. Scoped to what integration consultants need when building or supporting integrations that consume custom reports or use calculated fields for field overrides.

---

## 1. Report Performance — Highest to Lowest Impact

Follow this order when building or tuning a custom report that feeds an integration (RaaS, EIB, Studio RaaS call, DT, connector).

| Priority | Action | Why |
|----------|--------|-----|
| 1 | **Pick the most restrictive data source** | A larger data source always hurts performance. Manually filtering a big source down to match a smaller one gives the same data but is *not* optimised. Avoid the heavy ones (e.g. *All Business Process Transactions*, *All Active and Terminated Workers*) — use refined or role-specific alternatives. |
| 2 | **Use indexed data sources and indexed fields** | Indexed data sources are built for aggregation/filtering on large volumes. Run *View Indexed Fields for Data Source* to find indexed fields and prefer them. **Caution for integrations:** indexed data sources have a refresh delay — Workday may take several hours (nonproduction: weekly; production: nightly or weekly) to reflect recent changes. Do not use indexed data sources when integrations need real-time or near-real-time data. Prefer standard data sources for integrations. |
| 3 | **Keep calculated fields simple** | Multi-level calculated fields (referencing other calc fields several levels deep) can be "crippling" on reports with tens/hundreds of thousands of rows. Try subfilters and related objects *before* reaching for calculated fields. In evaluate expressions, put the most likely condition first so Workday stops testing early. |
| 4 | **Order and simplify filters** | Put the filter that removes the most instances first so later filters process fewer rows. Keep filter logic simple. Prompt for the actual object (e.g. *Worker*) rather than a text value (e.g. *Employee ID*) — instance prompts are faster. |
| 5 | **Choose the right security group** | User-Based or Unconstrained Role-Based security performs best. Constrained Role-Based takes a performance hit. Intersection security groups are the worst. This matters most when the report feeds an integration (ISU security evaluation runs on every row). |
| 6 | **Only include needed fields** | Make the first field a simple text or indexed field. Leading with an instance object slows the report unless custom sorting is applied. |
| 7 | **Define sorting explicitly** | Sort on simple data types (text, date, numeric). If you do not set sorting, Workday still sorts on the first column, which is often inefficient. Complex or multi-instance sorts cost more. |
| 8 | **Shorten XML override names** | For web-service-enabled reports used in high-volume integrations, long element names add up to millions of extra characters, inflating output size and processing time. Use Column Heading Override XML Alias on the Columns tab. |
| 9 | **Profile before you tune** | Use *Edit Report Log Settings* + *View Report Log* (replaces the older *Test Report Performance*) to get high-level and field-level timings. Target the actual bottleneck. |

---

## 2. Data Sources, Business Objects & Fields

### Business Objects

Workday stores data in **business objects**. A business object has **fields** (columns) and **instances** (rows). Related business objects are linked through single-instance or multi-instance fields.

Key tasks for exploring the data model:

| Task/Report | Purpose |
|-------------|---------|
| **Business Object Details** | Lists fields, related business objects, data sources, and reports using a business object |
| **Report Fields** | Lists all Workday-delivered and calculated fields with their business object and type |
| **Report Fields and Values** (related actions on a worker) | Shows every available field with its current value for a specific instance — useful for discovering field names |
| **Data Sources** | Lists all data sources filtered by business object, category, or index type |

### Data Sources

Every report must have a data source. The data source determines the **primary business object (PBO)** and the available fields.

**Data source characteristics (prefer in this order for integrations):**

| Characteristic | Description | When to use |
|---------------|-------------|-------------|
| **Filtered** | Built-in filters that limit instances (e.g. *Workers by Organization*) | Default choice for most integrations — returns a manageable set |
| **Focused** | Returns instances for a specific security group (e.g. *My Direct Reports*) | When the integration runs as a specific role |
| **Indexed** | Optimised for aggregation/filtering on large volumes | **Not recommended for integrations** — refresh delay means data may be hours/days stale |
| **Unfiltered** | Returns all instances (e.g. *All Workers*) | Avoid — use a filtered alternative |

> **Integration rule:** Do not use indexed data sources for integrations unless the business accepts stale data. Production indexed data sources refresh nightly or weekly; nonproduction refresh weekly. Use standard (non-indexed) data sources instead.

### Fields

- Fields are secured by security domains — the ISU must have access to both the data source and every field used
- **Authorized Usage** on a field's related actions shows where it can be used (Default Areas = everywhere)
- Field types: Boolean, Numeric, Text, Single Instance, Multi-Instance

---

## 3. Advanced Reports

Advanced reports are the only custom report type relevant to integrations. They support:

- Multiple levels of headings and subtotals
- Related business objects (RBOs) — access fields from related objects without calculated fields
- Subfilters for secondary filtering on related instances
- Web service enablement (RaaS)
- Up to 9 levels of grouping
- Summarization (Sum, Average, Min, Max, Count)
- Composite reporting (subreports)

### Creating an Advanced Report (Summary)

1. **Create Custom Report** — select Advanced type, pick data source
2. **Columns tab** — add fields from PBO and RBOs; set Column Heading Override and XML Alias
3. **Sort tab** — define explicit sorting on simple data types; optionally enable outlining
4. **Filter tab** — add filters (most restrictive first); use subfilters for RBO filtering
5. **Prompts tab** — add prompts for dynamic parameters (integration attributes often map to these)
6. **Output tab** — configure output format
7. **Advanced tab** — check **Enable As Web Service** for RaaS
8. **Share tab** — share with ISU or appropriate security group

### Column Configuration for Integrations

| Setting | Integration impact |
|---------|-------------------|
| **Column Heading Override** | Controls the element name in XML/JSON output; prevents label changes from breaking integrations |
| **Column Heading Override XML Alias** | The actual XML element name in web service output; must be unique; keep short for high-volume reports |
| **Group Column Heading / XML Alias** | Controls the wrapper element for multi-instance RBO fields |
| **Format** | Controls decimal precision in exports |
| **Options** | Sum/Average/Count/Min/Max for aggregated fields |

### Subfilters

Subfilters apply additional conditions to related business object instances *after* the main filter runs. When testing:
- Workday shows first 10 results
- Filters apply to all instances, then first 10 are returned
- Subfilters apply to those 10 filtered instances

---

## 4. Reports as a Service (RaaS)

RaaS enables advanced and search reports as web services. This is the primary mechanism for integrations to consume report data.

### Output Formats

| Format | Integration use |
|--------|----------------|
| **Workday XML** | Studio integrations (RaaS call in assembly), SOAP integrations. Provides full fidelity including WIDs and instance references |
| **Simple XML** | Simpler integrations or Excel refresh. Flattens single/multi-instance to strings; semicolon-separates multi-instance values |
| **CSV** | EIB, flat-file integrations. Add `&bom=true` for UTF-8 BOM if Excel will open it. Column order may differ from report definition. Group headings are lost |
| **JSON** | REST-based system-to-system integrations |
| **RSS** | Monitoring feeds — rarely used for integrations |
| **GData** | Google gadget integrations — rarely used |

### RaaS URL Pattern

```
https://<host>/<tenant>/<report_owner>/<Report_Name>?<prompt>=<value>&format=<format>
```

- Prompts use the **Label for Prompt XML Alias** from the Prompts tab
- Single-instance prompt values: `<prompt>%21WID=<WID>`
- Multi-instance prompt values: `<prompt>%21WID=<WID_1>!<WID_2>`
- Boolean/text prompt values: `<prompt>=<value>`

### RaaS Namespace

```
urn:com.workday.report/Report_Name
```

- Does not change when report name or owner changes
- Can be manually edited, but Workday does not verify uniqueness
- If editing, all consuming integrations must be updated

### RaaS Limits

- SOAP/REST from tenanted host: **6-hour timeout**
- From WCP API Gateway (api.workday.com): **5-minute timeout**
- Maximum **1 million rows** per report execution
- Report owner username must not contain backslash (`\`)

### Important: Copy Standard Reports Before Enabling as Web Service

Before enabling a standard (Workday-delivered) report as a web service, **copy it to a custom report** first. If Workday updates the standard report in a future release, it could break your integration. Enable the custom copy as the web service instead.

---

## 5. Workday Query Language (WQL)

WQL is a SQL-like alternative to RaaS for data extraction. Returns JSON only.

### When to Use WQL vs RaaS

| Factor | WQL | RaaS |
|--------|-----|------|
| Output formats | JSON only | CSV, JSON, XML, Simple XML, RSS, GData |
| GROUP BY | Yes | No |
| Pagination | Yes (10K rows/page) | No |
| Max rows | 1 million | 1 million |
| Timeout (tenanted) | 30 minutes | 6 hours |
| Timeout (WCP Gateway) | 5 minutes | 5 minutes |
| Persisted definition | No (query string only) | Yes (report definition in Workday) |
| Audit trail | No | Yes |
| Cross-tenant portability | Yes (change URL) | No (must migrate report) |
| Global business object fields | No | Yes |
| SOAP support | No | Yes |

### WQL Syntax Quick Reference

```sql
PARAMETERS param1 = value1, param2 = value2
SELECT field1, field2, aggregation(field3)
FROM dataSourceAlias (dataSourceFilter = filterAlias, filterParam = value)
WHERE ON relatedBusinessObject rboField = value
WHERE field1 = value AND field2 IN (wid1, wid2)
GROUP BY field1
HAVING count() > 100
ORDER BY field1 ASC
LIMIT 500
```

### WQL Key Points for Integrations

- Register API client using **Register API Client for Integrations** task; select **System** scope
- WQL honours security — the API client's refresh token user must have access to the data source and fields
- Related business object fields use curly bracket notation: `dependents{age}`
- WHERE ON clauses (for RBO filtering) must come before WHERE clauses
- Cache expires after 30 minutes; force refresh with `offset=0`
- Convert existing reports to WQL using the **Convert Report to WQL** report
- WQL REST API endpoints: `GET /data`, `POST /data` (for queries > 2048 chars), `GET /dataSources`, `GET /dataSources/{ID}/fields`

---

## 6. Calculated Fields

Calculated fields are configurable field definitions associated with a business object. They are used in:
- Custom reports (as columns, filters, or prompts)
- Integrations (field overrides for connectors, EIBs, and Document Transforms)
- Business process condition rules
- Scheduled recurring processes

### Report-Specific vs Tenant-Wide

| Scope | When to use | Security domain |
|-------|-------------|-----------------|
| **Report-specific** | Single report/integration; limited scope | Private Calculated Field Management |
| **Tenant-wide** | Reused across reports, BPs, integrations | Custom Field Management |

- Convert report-specific to tenant-wide: use **Convert Calculated Field for Report** (only if it does not depend on other report-specific fields)
- Convert tenant-wide to report-specific: use **Convert Calculated Field** (only if used in a single report)
- View hierarchy: Related Actions > Custom Report > **View Calculated Field Hierarchies**

### Calculated Field Functions Reference

#### Performing Calculations

| Function | Description | Integration use case |
|----------|-------------|---------------------|
| **Arithmetic Calculation** | Add, subtract, multiply, divide on currency/numeric fields. Follows PEMDAS. | Calculate derived amounts (e.g. daily rate from annual salary) for field overrides |
| **Count Related Instances** | Count instances of an RBO matching a condition | Count dependents, open positions, or events in a period |
| **Date Difference** | Difference between two dates in days/months/years (rounded down) | Calculate tenure, age, or days since an event |
| **Increment or Decrement Date** | Add/subtract days/months/years/time to a date | Calculate probation end date, certification expiry window |
| **Sum Related Instances** | Sum a numeric/currency field across RBO instances matching a condition | Total benefit costs, expense line items, days off |
| **Text Length** | Character count including spaces | Identify fields that will truncate during integration output |

#### Retrieving & Transforming Data

| Function | Description | Integration use case |
|----------|-------------|---------------------|
| **Evaluate Expression** | Sequential if/then/else on boolean conditions; returns first true match | Map Workday statuses to vendor-specific codes |
| **Evaluate Expression Band** | Like Evaluate Expression but returns grouped instances | Group workers by seniority band for vendor file |
| **Extract Single Instance** | Pull one instance from a multi-instance field based on condition + sort | Get latest performance review, primary benefit election |
| **Extract Multi-Instance** | Filter/combine multi-instance fields (Subset, Union, Intersection, Except) | Filter events by date range, combine related instances |
| **Aggregate Related Instances** | List all instances of a field on an RBO (deduped) | List all job profiles across positions in an org |
| **Lookup Related Value (LRV)** | Return a field from a related business object; promotes it to the PBO for filtering/sorting/grouping | Get manager email when reporting on workers; chain LRVs to bridge non-directly-related objects |
| **Lookup Value as of Date** | Return a field's value at a specific point in time | Detect data changes between two dates for delta integrations |
| **Lookup Hierarchy** | Navigate a hierarchy and return a node at a specific level/name | Get cost centre at level 3 for payroll file |
| **Lookup Hierarchy Rollup** | Roll up data along a hierarchy for matrix reports | Drill-down on org hierarchies |
| **Lookup Organization** | Determine a worker's org level/node | Get department or division for output file |
| **Lookup Organizational Roles** | Determine role assignments for a worker or org | Get expenses representative, facilities manager |
| **Lookup Range Band** | Determine which configured range a value falls in | Classify compensation as "Highly Compensated" or not |
| **Lookup Field with Prompts** | Supply prompt values for Workday-delivered fields with built-in prompts | Access parameterized fields in reports |
| **Lookup Date Rollup** | Aggregate dates into fiscal/calendar/weekly periods | Group data by quarter or week for trending reports |
| **Lookup Translated Value** | Return a text field value in a specified language | Output localised values for multi-country integrations |

#### Formatting & Constants

| Function | Description | Integration use case |
|----------|-------------|---------------------|
| **Concatenate Text** | Join text fields with delimiters | Build composite keys, formatted names (Last, First) |
| **Convert Currency** | Convert amounts between currencies using tenant rates | Normalise multi-currency data to a single currency |
| **Convert Text to Number** | Parse numeric text to a number | Enable calculations on text-stored values |
| **Format Date** | Extract/format part of a date as text. **Note:** `YYYY` = week year; use `yyyy` for calendar year | Format dates for vendor-specific layouts |
| **Format Number** | Format a number as text with symbols/precision | Produce vendor-expected numeric formats |
| **Format Text** | Change case (upper/lower/proper) or replace delimiters | Normalise text for vendor systems |
| **Substring Text** | Extract text by position, delimiter, or between delimiters | Parse composite fields (e.g. extract code from "Code - Description") |
| **Build Date** | Construct a date from components (year/month/day fields or literals) | Derive first/last day of month/year for filtering |
| **Date Constant** | Static date/time value | Reference date for as-of calculations |
| **Numeric Constant** | Static number | Multiplier, rolling window (e.g. 3 months), threshold |
| **Text Constant** | Static text | Labels, status values for evaluate expressions |
| **Prompt for Value** | Prompt user for a value at runtime | Dynamic parameters for scheduled integration runs |
| **True/False Condition** | Boolean evaluation with operators (=, >, <, in list, etc.) | Filter flags, eligibility checks, conditional logic |

### Calculated Field Best Practices for Integrations

1. **Keep nesting shallow.** Deeply nested calculated fields (CF referencing CF referencing CF) multiply evaluation time across every row. Flatten where possible.
2. **Use Evaluate Expression efficiently.** Conditions evaluate sequentially — put the most common/likely condition first and Workday stops at the first true match.
3. **Use proper Boolean logic.** When combining AND/OR conditions in True/False Condition fields, always use parentheses: `A AND (B OR C)` is different from `(A AND B) OR C`.
4. **Prefer subfilters and RBO fields over calculated fields** when the data is already available through a related business object on the report's data source.
5. **LRV chaining** to bridge non-directly-related business objects: create an LRV on the intermediary object first, then a second LRV from your PBO to reach the target field.
6. **Watch for `YYYY` vs `yyyy`** in Format Date masks — `YYYY` is week year (can return wrong year in late December), `yyyy` is calendar year.
7. **Return Zero/Blank on Error:** enable these options on Arithmetic, Date Difference, Build Date, and Convert Text to Number fields to prevent integration failures from null data.
8. **Security propagation:** the ISU must have access to *all* fields inside a calculated field. If any component field is inaccessible, the calculated field returns 0 (numeric/currency) or blank.
9. **Test incrementally** in sandbox. Use **Calculated Field Exception Audit** and **Report Specific Calculated Field Exception Audit** to verify configuration.
10. **Audit before changing.** Run **Calculated Field Usage Hierarchy** to see all downstream impacts before modifying a tenant-wide calculated field — changes affect every report and integration that uses it.

### Useful Reports for Calculated Field Management

| Report | Purpose |
|--------|---------|
| **All Calculated Fields** / **Calculated Fields Defined** | Find existing calculated fields to reuse before creating new ones |
| **Calculated Field Exception Audit** | Find errors in tenant-wide calculated fields |
| **Report Specific Calculated Field Exception Audit** | Find errors in report-specific calculated fields |
| **Calculated Field Usage Hierarchy** | Understand downstream impacts before changing a calculated field |
| **Recently Updated Calculated Fields** | Track changes to calculated fields |
| **Maintain Calculated Fields** | View and manage all tenant-wide calculated fields; convert to report-specific |
| **Maintain Calculated Fields for Report** | View and manage report-specific fields; convert to tenant-wide |
| **View Calculated Field** (related actions) | Inspect a specific calculated field's definition |
| **View Calculation Hierarchy** (related actions) | Check for self-referencing or circular dependencies |

---

## 7. Indexed Data Sources — Integration Warning

Indexed data sources are powerful for reporting but **problematic for integrations**:

- **Production tenants:** refresh nightly or every Monday (depending on retroactive period selection)
- **Nonproduction tenants (Impl/Sandbox):** refresh weekly
- Reports using indexed data sources **do not support effective dates** other than the current moment
- Cannot filter on calculated fields in indexed mode
- Cannot filter on an indexed object as a related business object (advanced reports)

**Recommendation:** Use standard (non-indexed) data sources for all integration reports unless the business explicitly accepts stale data and the performance benefit of indexing is required.

---

## 8. Security Considerations for Integration Reports

- The **Integration System User (ISU)** must be a member of security groups that have access to:
  - The data source
  - Every field used in the report (including all component fields inside calculated fields)
  - The **Custom Report Creation** and **Manage: All Custom Reports** domains (for report access)
- **Security group type impact on performance** (fastest to slowest):
  1. User-Based
  2. Unconstrained Role-Based
  3. Constrained Role-Based
  4. Intersection (worst)
- If the ISU cannot see a field, calculated fields return 0 or blank *silently* — no error is raised
- **Workday Query Language** requires access to the **Workday Query Language** domain in the System functional area

---

*Sources: Workday Admin Guide — Manage Workday (pp 508-570), Workday Admin Guide — Reporting & Analytics (pp 37-42, 149-156, 271-301), practitioner experience.*
