# File Handling Reference

When a user provides files as part of a case, ticket, or task, read them all proactively. Do not wait for the user to ask.

## Binary File Reading

| Format | Library | Install |
|--------|---------|---------|
| PDF (.pdf) | pypdf or PyPDF2 | `py -m pip install pypdf` |
| Word (.docx) | python-docx | `py -m pip install python-docx` |
| Excel (.xlsx/.xls) | openpyxl | `py -m pip install openpyxl` |

Use `py` launcher on Windows to find Python. Fall back to the full path from pip's output if `py` fails.

## Reading Approach

- Read ALL provided files regardless of format. Do not skip files
- For large documents (60+ page PDFs), read in chunks. Summarise key findings as you go
- Cross-reference between documents. Vendor documentation often has internal inconsistencies (different URLs, conflicting instructions). Flag discrepancies
- Excel files may have multiple sheets. Always check all sheets, not just the first one. Use openpyxl to list sheet names first

## Excel Files

See `excel-handling.instructions.md` for the full approach to Workday-exported Excel files, including non-tabular layout handling, common pitfalls, and CSV conversion patterns.
