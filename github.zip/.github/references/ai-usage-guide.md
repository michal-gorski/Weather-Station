# AI Usage Guide — AMS Integrations

> **Audience**: AMS Integration Consultants. This is internal guidance — do not share with customers.

---

## Experience Level and Intended Use

This tooling is built for consultants who already have solid Workday integration experience. It assumes you can critically evaluate the output — spot incorrect API calls, catch bad design patterns, and recognise when a suggested approach does not fit the customer's scenario.

- **Experienced consultants** should review all AI output before acting on it. Treat it as a first draft from a colleague who does not know the customer, not as a finished deliverable.
- **Less experienced consultants** may use the tooling to learn and work faster, but any code, design, or customer-facing output they produce with AI assistance **must be reviewed by a more experienced consultant** before it reaches a customer or production environment.
- **AI does not replace architectural thinking.** It can generate code, suggest patterns, and draft responses, but it cannot make design decisions. Choosing the right integration approach, understanding the customer's Workday configuration, and anticipating production edge cases remain the consultant's responsibility.

The risk scales with experience. A senior consultant who misses an AI error will usually catch it during testing. A less experienced consultant may not recognise the error at all. Plan your review process accordingly.

---

## Customer Communication

### Do Not Proactively Mention AI

Do not proactively tell customers that you used AI to produce code, analysis, or responses. This applies to all communication channels — tickets, emails, calls, and documents.

If a customer asks directly whether AI was used, be honest but brief. Do not volunteer it unprompted. We are early in our usage of it and are still formulating our processes.

### Own Everything You Send

Every response you send to a customer — whether code, configuration advice, or a written explanation — is **your** response. You are accountable for it.

> **The most important rule in this guide:** AI makes you faster, not smarter. Read what it produces with healthy scepticism, not blind trust. You will almost always find something that is not what you or the customer intended — that is normal and expected, but only if you actually look.

Before sending anything AI-assisted:

1. **Read it with scepticism** — treat AI output the way you would treat code from an unknown contributor in a pull request. Question the assumptions, check the logic, and verify that it matches the customer's actual scenario. Do not trust it because it looks polished or compiles cleanly
2. **Verify accuracy** — AI can produce plausible but incorrect answers. Cross-check facts against Workday documentation, Community posts, or tenant behaviour
3. **Read it in your voice** — if it doesn't sound like something you would naturally write, rewrite it. AI-generated text can be overly formal, verbose, or generic. Customers know your style; a sudden shift is noticeable
4. **Question the approach** — AI solves the problem you asked about, not necessarily the problem the customer has. Step back and ask: is this the right approach? Does it handle the customer's actual scenario? Does it miss edge cases that experience would catch?
5. **Test the solution** — AI-generated code must go through the same testing process as hand-written code. There are no shortcuts here. See the [deployment checklist](instructions/ams-delivery.instructions.md)

### The False Confidence Trap

AI output looks polished, compiles cleanly, and reads confidently. This is dangerous. A well-formatted wrong answer is harder to spot than an obviously broken one.

Watch for these signs that you're trusting AI output too much:

- You're sending code to a customer within minutes of generating it
- You can't explain what a section of the code does without re-reading it
- You're copy-pasting responses with only minor edits
- You feel like you "probably don't need to test this one" because it looks right
- You're not checking whether the AI's assumptions about the customer's Workday configuration are correct

**If any of these apply, stop and slow down.** The time AI saved you should go directly into understanding, verifying, and testing the output. That is where the real value is: same delivery time, higher quality. Not faster delivery with unchecked quality.

### Common Pitfalls

| Risk | Example | Mitigation |
|------|---------|------------|
| Hallucinated Workday behaviour | "Use the `Get_Workers` operation to retrieve pay group history" (no such operation) | Verify against Workday Community or tenant |
| Overly confident wrong answers | "This will definitely resolve the issue" for an untested suggestion | Test before asserting. Use hedging language if uncertain |
| Generic phrasing | "I hope this helps! Let me know if you have any questions" | Write like yourself, not a chatbot |
| Leaking AI patterns | Bullet-heavy responses with no personality, or phrases like "Here's a comprehensive overview" | Read it back — would you actually say this? |
| Excessive em-dashes (—) | "The integration — which handles payroll — failed during the merge step — causing the file to be empty" | Em-dashes are an AI tell. Most people use commas, brackets, or separate sentences. Replace them before sending |

---

## Estimates and Time Savings

### Do Not Reduce Estimates

AI-assisted productivity gains should **not** reduce the estimates you provide to customers at this time. Standard estimating guidelines still apply.

### Reinvest Time Savings

Any time saved through AI usage should go back into:

- **Understanding the output** — this is the first and most important reinvestment. Read it, trace it, question it. If you skip this, AI is making you worse, not better
- **Improving the solution** — better error handling, edge case coverage, cleaner code
- **More thorough testing** — additional test cases, regression tests, end-to-end verification
- **Better documentation** — more detailed build notes, clearer design documents
- **Adding value** — proactive recommendations, identifying related issues, improving maintainability
- **Improving AMS-AI-Config** — adding more training reference data to improve the results and help the next person

The goal is higher quality delivery, not faster billing.

---

## Model Selection

Choose the right model for the task. Model names and availability are subject to change.

| Model | Best For |
|-------|----------|
| **Claude Opus 4.6** | Complex analysis, large file review, multi-file refactoring, integration design, debugging difficult issues |
| **GPT 5.4** | Straightforward code generation, simple Q&A, formatting, boilerplate |
| **Claude Sonnet 4.6** | General coding tasks, moderate complexity analysis, code review |

### Guidelines

- **Default to Sonnet or GPT** for routine work
- **Use Opus** when the task genuinely requires deep reasoning: complex debugging, architectural decisions, large codebase analysis
- Don't leave Opus running for simple tasks like formatting or renaming
- If you're unsure, start with a default model and escalate to Opus only if the output quality is insufficient

---

## General Best Practices

1. **AI is a tool, not a replacement for expertise.** You are the integration consultant. AI assists — you decide
2. **Never paste customer data (PII, credentials, tenant-specific config) into external AI tools.** GitHub Copilot in VS Code is approved for use. Public tools (ChatGPT web, Claude web) must not receive customer data
3. **Review every suggestion.** Accept AI output critically, not automatically
4. **Learn from the output.** If Copilot shows you a pattern you haven't seen before, understand it. Next time you'll know it without AI
5. **The output is always wrong until you've proven it right.** Treat AI output like code from an unknown contributor in a pull request: read it carefully, question the assumptions, test the edge cases. The fact that it compiled or looks plausible means nothing
6. **Contribute back.** If you discover a useful pattern or a Copilot mistake, share it with the team. Add to the knowledge base where appropriate
