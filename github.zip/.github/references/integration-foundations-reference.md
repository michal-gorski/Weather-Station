# Integration Foundations Reference

Foundational knowledge for selecting the right Workday integration technology and understanding how connectors work. Use this when choosing between EIB, Connector, Studio, Orchestrate, or API approaches.

## 1. What Are Workday Integrations

Workday integrations enable you to exchange data efficiently between Workday and external endpoints. They support both inbound (importing data into Workday) and outbound (exporting data from Workday) scenarios. Integrations can run ad hoc or on a schedule, and can complete most tasks in bulk that you can perform individually in Workday.

Business benefits include saving time and effort when transferring data between applications, avoiding manual re-entry of data, and enabling regular exchange of large volumes of data in specific formats. Key use cases include:

| Use Case | Description |
|---|---|
| Account provisioning | Synchronise hires and terminations with external applications (e.g. Active Directory) automatically |
| Payroll, tax, and benefits processing | Send worker data on a schedule to external payroll services and benefits providers |
| Bulk import tasks | Load data for large numbers of objects (e.g. mass manager reassignments) |

## 2. Integration Technology Selection

### Questions to Consider

Before selecting a technology, evaluate:

| Question | Considerations |
|---|---|
| Does a Workday-delivered integration template support your use case? | If yes, using that template simplifies building the integration significantly |
| Do you need to import/export data regularly, or infrequently? | Most integrations can be configured to run on a schedule |
| Can your organisation's workers build integrations using the selected technology? | Workday provides customer training for EIB, some Connectors, and Studio |

### Technology Comparison

| Technology | Description | Best For | Limitations |
|---|---|---|---|
| **Inbound EIB** | Tool for building simple integrations that load data into Workday. Available in-tenant. Can use an inbound web service as a data source, or generate a spreadsheet for data entry by workers without Workday access. | One-time bulk data loads; automating multistep data entry (e.g. Hire BP) | Supports only 1 data source per EIB |
| **Outbound EIB** | Tool for building simple integrations that export data from Workday. Available in-tenant. Uses 1 Custom Report or outbound web service as a data source. Can run on schedule or from a BP step. | Simple scheduled exports; ad hoc data extracts | Supports only 1 data source (Custom Report or web service) per EIB |
| **Template-Based Integrations** (specific vendor) | Pre-built integrations for specific services and vendors (e.g. Salesforce.com). Workday preconfigures the template for the specific endpoint it supports, including the vendor's required file format. | Integrating with a supported vendor endpoint — the best solution when the template exists | Each template supports a single dedicated vendor; cannot repurpose for other endpoints even with similar use cases. More complex to configure than EIB |
| **Template-Based Connectors** (generic data type) | Pre-built integrations that export/import data of a specific type (e.g. Worker, Organisation) in Workday-defined XML format. Broad range of data fields. Some support additional report field output. Outbound connectors can use Document Transformation to convert XML to target format. | When no vendor-specific template exists but a data-type connector covers your scope | Only additional data sources are report fields. More complex to configure than EIB |
| **Orchestrate for Integrations** | Web-based, low-code, drag-and-drop development environment (Orchestration Builder). Available from the Workday Developer Site. No downloads required. Data encrypted in transit and at rest. Extensible through custom logic, third-party APIs, and Orchestrate Expression Language. | Automating business processes; real-time event-driven interactions; complex workflows without code; high-volume data handling | Separate from your Workday tenant. Requires Orchestrate-specific training |
| **Workday Studio** | Eclipse-based IDE for building custom integrations that follow the same template-based model as Connectors. Integrations reside in your Workday tenant and can access data from any WWS operation. Can run on schedule or from a BP step. | Complex custom integrations; scenarios requiring full flexibility; developers with Studio training | Separate from tenant. Requires Studio-specific training. Generally takes longer to build than templates, orchestrations, or connectors |
| **Workday Web Services (WWS) API** | SOAP API supporting several thousand Workday operations. Provides programmatic access to most Workday functionality through XML document exchange. | External systems needing broad access to Workday data; teams using non-Workday development tools | Requires non-Workday development expertise and infrastructure |
| **Workday REST API** | REST API providing access to a limited number of Workday operations. Supports smaller transactions than WWS. | Lightweight external integrations; smaller transaction volumes | Limited operation coverage. Requires non-Workday development expertise and infrastructure |

## 3. Security and Tenant Setup

### Integration System User (ISU)

All non-EIB integrations require an associated Integration System User (ISU) account. ISUs enable you to give an integration Get and Put access to only the security domains it needs to run.

### Edit Tenant Setup - Integrations

The **Edit Tenant Setup - Integrations** task enables you to:

- Disable integration subscription notifications for all integrations in your tenant
- Require that Studio integrations include source code (recommended for supportability)

### Integration Process Event Business Process

Workday provides the **Integration Process Event** business process definition (in the Integration functional area) to control how an integration runs:

**Inbound integration flow:**
1. Initiate
2. Retrieve file from external endpoint
3. Fire (load data into Workday)

**Outbound integration flow:**
1. Initiate
2. Send approval request to designated worker
3. After approval, fire (extract data from Workday)
4. Send data file to external endpoint

### Integration Business Process Step

The **Integration** business process step type enables you to launch an integration from any business process that supports it. Check the business process definition to confirm support. Example: adding an integration step to the Complete Form I-9 business process to launch an E-Verify integration.

## 4. Integration Reports

| Report | Description |
|---|---|
| **View Integration System** | Displays all integration systems (EIB, Connector, Orchestrate, Studio, etc.) that you have created |
| **View Integration Template** | Displays all integration templates that Workday provides, enabling you to find the template you need |
| **Integration Events** | Summary of integration events in process or completed, with status details for each event |
| **Integration Exception Audit** | Critical errors and warnings with suggestions to resolve problems |

## 5. Workday Connectors Overview

### Two Types of Connectors

1. **End-to-end Connectors** — support a specific named third-party application or service. When deployed, they support the third-party application with no additional coding required.
2. **Connectors** — pre-built integrations that address most of the integration effort. They import and export data in a Workday-defined file format, requiring transformation to match the external endpoint's format.

### Key Principles

- All connectors require some level of tenant configuration and testing — each customer has specific mapping requirements and endpoint configurations
- Each integration template provides a framework containing **integration services**, comprised of **integration attributes** and **maps**, that define specific connection points
- Many templates have **factory settings** for common definitions and requirements to reduce complexity
- Browse available templates using the **Integration Template Catalog** report (task: View Integration Template)

### Available Categories

- Benefits
- HCM
- Workday Payroll
- Third-Party Payroll
- Financials
- Student

### Audit Reports Warning

Workday commonly attaches audit reports to integration events for troubleshooting. These are for **human use only**. Output, format, and accessibility are subject to change at any time. **Never use audit files within integration processing or logic.**

## 6. Connector Catalogues Summary

### Benefits Connectors

| Connector | Description |
|---|---|
| Benefits Connector (Generic) | Configurable export of benefits-related HR, compensation, and deduction data to any provider not in the named catalogue |
| Named Benefits Connectors | Workday maintains connectors for specific providers across Medical, Dental, Vision, Life & Disability, Flexible Spending Accounts, COBRA Administration, and Retirement Savings categories (see Workday Community for full provider list) |

### Financials Connectors

| Connector | Description |
|---|---|
| Accounting Journal Connector | Imports accounting journal data from external endpoints in Workday-defined format |
| Ad Hoc Bank Transaction Connector | Imports ad hoc bank transaction data in Workday-defined format |
| AMEX Remittance | Generates and exports American Express Remittance files from credit card secure environment |
| Bank Fee Statement Connectors | Imports bank fee statements in ASC X12 EDI 822, ISO 20022 camt.86 V1/V2, or Workday XML format |
| Bank Statement Load Integrations | Imports bank statements (BAI2, BTRS, ISO 20022, MT940/942 natively; others via Workday-defined format) |
| Currency Exchange Rate Connector | Imports currency exchange rates in Workday-defined format |
| Customer Credit Card Payments | Connects to CyberSource for customer credit card authorisation and processing |
| Customer Payment Lockbox | Imports BAI lockbox data files in Workday-defined format |
| DAS2 Integration | Generates DAS2 audit files from accounting entries for French tax authorities |
| EDI Supplier Integrations | Exchanges data with suppliers in ASC EDI X12 810, 850, 855, and 856 formats |
| Electronic Invoice Connector | Exports electronic invoicing data in XML format |
| Electronic Payments | Connects to financial institution for inbound and outbound payment processing |
| Expense Credit Card Transactions | Imports credit card data (AMEX, Citibank CCF, Bank of America VISA, MasterCard CDF3, Visa VCF4.4) |
| FEC Integration | Generates FEC audit files for French tax authorities |
| Financial Management Connector for Salesforce | Exchanges sales data between Salesforce.com and Workday |
| GoBD Integration | Generates audit files for German tax authorities (GoBD compliance) |
| Inventory Label Data Integrations | Exports inventory label data in Workday-defined format for external label printing |
| Payment Acknowledgment | Imports ISO 20022 payment acknowledgment files for status tracking |
| SAF-T Integrations | Generates audit files for OECD SAF-T tax compliance |
| Supplier Punchout | Connects to external suppliers for procurement |
| Tax ID Integration | Validates tax IDs using the European VIES service |
| Third-Party Payments Integration | Generates audit files of payments/payees for third-party payment declarations to tax authorities |
| Travel Booking Inbound Connector | Imports travel booking records from third-party travel providers |

### HCM Connectors

| Connector | Description |
|---|---|
| Account Provisioning Integration | Exports worker profiles and provisioning groups in SCIM format |
| Account Provisioning Connector | Exports worker profiles and provisioning groups in Workday XML format |
| Affordable Care Act (ACA) Connectors | Submits IRS Form 1094-C and 1095-C data |
| AngelPoints | Creates/modifies/deletes AngelPoints accounts based on worker status changes |
| Assign Organizations Inbound Connector | Imports organisation assignment data |
| Core Connector: Background Check Order (Inbound) | Imports background check information for a person |
| Core Connector: Background Check Order (Outbound) | Exports background check requests |
| Core Connector: Competency Model | Exports new/changed competency model data in configurable XML |
| Core Connector: Job Postings | Exports new/changed job postings in configurable XML |
| Core Connector: Job Profile and Job Family | Exports new/changed job profile and family data in configurable XML |
| Core Connector: Job Requisitions | Exports new/changed job requisitions in configurable XML |
| Core Connector: Location | Exports new/changed location data in configurable XML |
| Core Connector: Organization | Exports new/changed organisation data in configurable XML |
| Core Connector: Positions | Exports new/changed position data in configurable XML |
| Core Connector: Worker | Exports worker changes in configurable XML or non-configurable CSV format |
| Core Connector: Worker for LMS Outbound | Exports worker/job/location/organisation/talent data for Learning Management Systems |
| Directory Service | Connects to LDAP and Active Directory servers |
| E-Verify Integration | Verifies employment eligibility via US Citizenship and Immigration Services |
| Inline Assessment | Connects to third-party assessment vendors for external career site candidates |
| Kenexa Connector | Exports organisation, location, job profile, and job family data to Kenexa |
| Kronos Workforce Timekeeper Outbound | Exports worker data to Kronos Workforce Timekeeper |
| Medicare Integrations | Exchanges coordination of benefits files with Centers for Medicare & Medicaid Services |
| Okta Integration | Sends event-based notifications of employee changes to Okta |
| Organization Inbound Connector | Imports new/changed/inactivated organisation data |
| Salesforce.com Chatter Integration | Posts Workday events to Salesforce.com Chatter |
| Salesforce.com Worker Sync | Connects to Salesforce.com for account provisioning |
| Skillsoft Integration | Imports licensed courseware from Skillsoft as external digital courses |
| Social Security Number Verification Service | Generates data file for SSN verification with Social Security Administration |
| Talent Profile Inbound Connector | Imports updates to certifications, competencies, and completed trainings |
| Unistaff Connectors | Exchanges data with Unistaff for Russian Federation data privacy requirements |

### Student Connectors

| Connector | Description |
|---|---|
| Education Test Result Inbound Connector | Imports test results in Workday XML for tests not supported by other connectors |
| National Student Clearinghouse Connectors | Sends enrolment, degree, and graduation data to NSC |
| SPEEDE External Transcript Inbound | Imports student transcripts from NSC SPEEDE service |
| Student Admissions Connectors | Imports test results for ACT, AP, GMAT, GRE, PERT, SAT, TOEFL (separate template per test) |
| Student Financial Aid Connectors | Imports/exports data for Alternative Loans, COD, ISIRs, TSM/FAH |
| Student Financials Connectors | Sends refund data to Transact; generates IRS Form 1098-T data |
| Student Outbound Connector | Exports student status/profile changes in Workday XML |
| Student Records Connectors | Exports transcript data in Workday XML |
| Student Recruiting Connectors | Imports student prospects from ACT Enroll service |
| Student Transaction Log Outbound Connector | Exports XML transaction records matching specified criteria |
| The Common Application Inbound Integration | Imports first-year applicant data from The Common Application |

### Third-Party Payroll Connectors

| Connector | Description |
|---|---|
| Payroll Effective Change Interface (PECI) | Exports payroll-related HR/compensation/benefits data in XML with effective-dated sequence |
| Worker Effective Change Interface (WECI) | Captures full stack of worker data changes including corrections, rescinds, indirect, retroactive, and future-dated transactions |
| Payroll Interface (PICOF) | Exports payroll-related HR/compensation/benefits data in XML format |
| External Payroll Results Inbound | Imports data from external payroll endpoint to payroll results |
| Import External Payslips | Imports employee payslips from an external payroll endpoint |
| External Payroll Documents | Imports external payslips, tax documents, and other payroll documents |

### Workday Payroll Connectors

| Connector | Description |
|---|---|
| ADP Check Print | Exports payroll/payslip data to ADP for check and pay advice printing |
| Ceridian Check Print Service | Exports payroll/payslip data to Ceridian for check printing or full banking services |
| Check Printing Connector | Connects to regional banks not using Ceridian format; customisable output |
| Electronic Income Withholding Order Integrations | Exchanges EIWO records/acknowledgments with Federal OCSE portal |
| Electronic Payments | Connects to company bank for inbound/outbound payment processing |
| HM Revenue & Customs Incoming Notifications | Receives P6/P6B, P9 tax and SL1/SL2 student loan notifications from HMRC DPS |
| HM Revenue & Customs RTI Integration | Sends Full Payment Submission (FPS) files to HMRC RTI |
| HM Revenue & Customs RTI Employer Payment Summary | Sends Employer Payment Summary (EPS) files to HMRC RTI |
| Payment Acknowledgment | Imports ISO 20022 payment acknowledgments for status tracking |
| Payment Connector | Connects to company bank for outbound payment processing |
| Payroll Journal Outbound Connector | Exports journal entries with payroll accounting details |
| Service Canada ROE | Generates ROE files for ESDC upload; imports ROE status files |
| Tax Filing (Canada T4, T4A, RL-1, RL-2) | Generates Canadian tax filing data for CRA/Revenue Quebec |
| Tax Filing (USA) | Exports periodic, quarterly, and annual tax data to ADP or Ceridian |
| Time Off Inbound and Payroll Input Connectors | Connects to external time/attendance applications (e.g. Kronos) |
| UK Civil Service Pension Files | Generates data files for Civil Service pension scheme administrator |
| Worker Time Block Inbound Connector | Imports time block data from external time/attendance applications |
| Worksite Reporting | Generates MWR files for US Bureau of Labor Statistics |
