# Adding a New Domain

Follow this checklist when adding a new functional domain (e.g. Identity, Benefits, Financials) to AMS-AI-Config.

## Files to Create

1. **Domain reference folder**: `skills/integration-design-skill/references/domains/<domain>/`
2. **Integration guide**: `<domain>-integration-guide.md` in the domain folder. Covers:
   - Overview and key concepts
   - Integration type decision matrix (which connector/approach for which scenario)
   - Common patterns and anti-patterns
3. **Deep-reference files**: One per connector or pattern (e.g. `account-provisioning-reference.md`). Covers:
   - Detailed configuration
   - Troubleshooting
   - Known issues and workarounds

## Files to Update

4. **Auto-load triggers** (if applicable): If the domain has detectable signals (like `peci:` namespace for payroll), add detection rules to an existing instruction file or create a new `instructions/<domain>.instructions.md` with an `applyTo` pattern
5. **copilot-instructions.md**: Add the domain's knowledge contribution target to the Knowledge Contribution routing table
6. **Review checklists** (if applicable): Add a domain-specific checklist under `skills/integration-review-skill/references/` if the domain has unique review criteria

## Conventions

- Match the style and structure of the payroll domain as a reference (`domains/payroll/`)
- Use anonymised/fictional data in all examples
- Keep the integration guide concise: decision matrix and key patterns, not a textbook
- Deep-reference files can be longer but should be scannable with clear headings

## Approach: Extracting from Workday PDFs

When the source material is a large Workday PDF (e.g. Admin Guide), follow this pipeline:

### 1. Extract from PDF directly (not via markdown conversion)

Bulk PDF-to-markdown converters produce bleed between sections and encoding corruption. Use **PyMuPDF** (`fitz`) for page-by-page text extraction instead:

- Identify the exact page range for the target section (use the PDF TOC page numbers)
- Extract pages as plain text using `page.get_text("text")`
- Merge pages, then find section boundaries by heading text (not by page number alone — page headers can mislead)

### 2. Clean the extracted text

- Fix encoding artefacts (`â€™` → `'`, `â€¢` → `•`, `Â` removal)
- Strip page headers (e.g. `| Financials Connectors | 637`)
- Strip copyright/confidentiality boilerplate
- Remove XML schema blocks longer than ~15 lines (replace with a note)
- Collapse excessive blank lines

### 3. Split by connector/subsection

- Identify subsection headings (connector names on their own line)
- Split into individual text blocks per connector
- This gives you clean, correctly-bounded raw content

### 4. Curate into cluster files (critical step)

Do **not** add raw extracted files to the repo. They are too large and noisy for AI context. Instead, curate into **3–6 thematic cluster files** (~15–25KB each):

- Group related connectors by use case (e.g. banking, procurement, tax compliance)
- Extract: setup overviews, concepts, key decisions, troubleshooting, FAQs
- Drop: raw XML/JSON schemas, field-by-field tables, verbatim click-by-click steps, page references
- Target: content a consultant needs for pattern recognition and decision support, not content they'd look up in the Workday docs directly

### 5. Size targets

| File type | Target size | Purpose |
|-----------|------------|---------|
| Integration guide | 5–10 KB | Decision matrix, connector catalog, when-to-use |
| Cluster reference | 15–25 KB | Setup, concepts, troubleshooting for grouped connectors |
| Instruction file | 3–5 KB | Signal detection and routing table |

Total domain footprint should be **~100–150 KB**. If significantly larger, the content needs further curation.

### Tools

- **PyMuPDF** (`pip install pymupdf`) — PDF text extraction
- Python 3.x with `re`, `pathlib` — cleaning and splitting
- Subagents — parallel curation of cluster files from cleaned raw content
