---
description: "Use when building, reviewing, or debugging Workday payroll integrations (PECI, PICOF, WECI). Covers connector selection, pay group setup, field override conventions, scheduling, change detection, and common payroll patterns."
applyTo: "**/assembly.xml,**/*.xsl"
---

# Payroll Integration Patterns

## Detecting Payroll Context

When this instruction loads, check whether the current file or conversation involves a payroll integration. **Read the appropriate deep-reference file immediately** if any of these signals are present:

### PECI signals (read `peci-reference.md`)
- The assembly.xml or XSL contains the `peci:` namespace (`xmlns:peci=`)
- The assembly.xml references a PECI integration template or PECI-related DIS/RaaS
- The user mentions PECI, "Payroll Effective Change", effective-dated payroll changes, LSRD, staffing event codes (HIR, TERM, DTA, PCI, PCO, PGI, PGO, LOA, RFL), or entry-dated vs effective-dated
- The XSL processes `peci:Worker` or `peci:Effective_Change` elements

### PICOF signals (read `picof-reference.md`)
- The assembly.xml or XSL contains the `pi:` namespace (`xmlns:pi=`)
- The assembly.xml references a Payroll Interface connector template
- The user mentions PICOF, "Payroll Interface", PI connector, or top-of-stack payroll data
- The XSL processes `pi:` prefixed elements

### WECI signals (read `weci-reference.md`)
- The user mentions WECI, "Worker Effective Change Interface", contingent worker payroll extract, or HCM-focused change interface
- The assembly.xml or XSL references a WECI integration template

### DCoD signals (read `dcod-reference.md`)
- The user mentions DCoD, "Data Changes on Demand", on-demand payroll data, or API-driven payroll extract
- The user asks about PECI vs DCoD comparison

### General payroll signals (read `payroll-integration-guide.md`)
- The user asks about payroll integration design, PECI vs PICOF selection, or pay group setup
- The user mentions third-party payroll, or payroll connector selection

### Payroll setup and operations signals (read `payroll-setup-and-operations-reference.md`)
- The user mentions third-party payroll organisations, pay groups, earnings/deductions setup, external vendor mapping
- The user mentions Global Payroll Hub, Integration Command Center (ICC), Event-Driven Integration, Configurable Output
- The user mentions payroll reconciliation, payroll errors collaboration, external payroll documents, payroll results inbound
- The user mentions external payslips, payslip REST API, tax documents REST API, inbound/outbound notifications
- The user mentions local payroll data, additional payroll data, callback for external payroll

## Auto-Load Reference Files

| Signal | Reference file to read |
|---|---|
| `peci:` namespace detected, or user mentions PECI / effective-dated payroll | `.github/skills/integration-design-skill/references/domains/payroll/peci-reference.md` |
| `pi:` namespace detected, or user mentions PICOF / Payroll Interface | `.github/skills/integration-design-skill/references/domains/payroll/picof-reference.md` |
| User mentions WECI / contingent workers / HCM change interface | `.github/skills/integration-design-skill/references/domains/payroll/weci-reference.md` |
| User mentions DCoD / Data Changes on Demand / on-demand payroll | `.github/skills/integration-design-skill/references/domains/payroll/dcod-reference.md` |
| Payroll design question, connector selection, or pay group setup | `.github/skills/integration-design-skill/references/domains/payroll/payroll-integration-guide.md` |
| Third-party payroll setup, ICC, EDI, reconciliation, notifications, external docs/results | `.github/skills/integration-design-skill/references/domains/payroll/payroll-setup-and-operations-reference.md` |

---

## PECI vs PICOF Quick Reference

| Criterion | Use PECI | Use PICOF |
|-----------|----------|-----------|
| Effective-dated history needed | Yes | No |
| CSV output required | No (XML only) | Yes |
| Grid available | Required | Not needed |
| Population >250k per pay group | No | Yes |
| Event-Driven Integration (EDI) | Supported | Not supported |
| Merge files across pay groups | Supported | Not supported |
| Integration Command Centre | Supported | Not supported |
| Contingent workers | Neither — use WECI | Neither — use WECI |

---

## Pay Group Setup Patterns

- Create future pay periods before the year begins
- Set custom org membership rules to semidynamic (or enable Dynamic Membership Rule Evaluation Optimisation)
- Each pay group should map to one payroll company organisation type
- If pay group is in multiple organisations, set the Payroll Company Organisation Type attribute
- Do not exceed 250,000 active employees per pay group (PECI limit)

## Change Detection Patterns

### PECI
- **Primary runs** automatically select change detection method based on period status:
  - "Not Yet Started" → all effective changes
  - "In Progress" → incremental (since LSRD)
- **Ad hoc runs** use launch parameters to control detection
- Enable Transaction Log for performance improvement on large populations
- LSRD lookback recommendation: 2 months (primary), 6 months (ad hoc)

### PICOF
- Enable Transaction Log service (not enabled by default)
- Without Transaction Log, PICOF scans all workers — poor performance on large populations
- Use "Extract All Payee Data" for initial seeding (cannot combine with Transaction Log)

## Field Override Conventions

- Test calculated field overrides using a Custom Report (Advanced type, Worker from Prompt data source)
- Add Effective Date and Entry Date runtime prompts to match the event under test
- Avoid calculated fields with >8 hierarchy levels (performance impact)
- Use the Report field first; only create a calculated field override when the standard field does not meet requirements

## Scheduling Best Practices

- Tie PECI runs to pay periods — do not run more than once daily unless using Frequent Integration Runs
- For frequent runs (up to 4x/day): enable Transaction Log + Effective Stack Sync services
- Primary runs update LSRD automatically; ad hoc runs do not
- PECI primary runs require only 2 launch parameters: Pay Group + Pay Period Selection Option
- Workday terminates integrations exceeding 2 hours

## Error Handling for Payroll Integrations

- Set Required Field Validation and Max Length Validation attributes based on vendor tolerance:
  - **Include** (default): warnings only, worker included — suitable for lenient vendors
  - **Omit - Report Warning**: warning generated, worker excluded — suitable for strict validation
  - **Abort**: error generated, integration aborts — use only when data quality is critical
- For PECI: disable Override Integration Event Field attribute when uploading external payroll errors
- Vendor must use `Put_Integration_Event_Error_Message_Set` web service to return errors

## Common Anti-Patterns

| Anti-Pattern | Why It's Wrong | Correct Approach |
|-------------|----------------|-----------------|
| Running full snapshot PECI to capture missing OTPs | Full snapshot disables Transaction Log; misses deletions | Use Primary Run or ad hoc with change detection |
| Not enabling Transaction Log on PICOF | Scans all workers every run — very slow | Always enable Transaction Log service |
| Setting LSRD too recently for ad hoc | Misses changes entered before LSRD | Use 6-month lookback for ad hoc runs |
| Using PECI for CSV output | PECI only outputs XML | Use PICOF for CSV; apply XSLT document transformation if format needs reshaping |
| Referencing "Is Manager" report field | Poor performance | Use Role field in Position Data Section; set Organisation Role for Position attribute to "Manager" |
| Referencing "Terminated (based on report date)" | Poor performance | Use "Terminated" report field instead |
