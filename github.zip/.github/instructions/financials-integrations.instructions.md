---
description: "Use when building, reviewing, or debugging Workday financials integrations. Covers banking, payments, procurement (EDI/punchout), journals, tax compliance (ELSTER, FEC, SAF-T, GoBD, DAS2), and other financials connectors."
applyTo: "**/assembly.xml,**/*.xsl"
---

# Financials Integration Patterns

## Detecting Financials Context

When this instruction loads, check whether the current file or conversation involves a financials integration. **Read the appropriate reference file** from `skills/integration-design-skill/references/domains/financials/` if any of these signals are present:

### Banking and payments signals
- The user mentions bank statements, BAI2, MT940, MT942, CAMT.053, bank connectivity, Kyriba, positive pay, payment files, payment connector, lockbox, EBICS
- The assembly.xml references a bank statement, payment, or bank connectivity integration template
- The XSL processes banking-related elements or payment file formats

### Procurement and supplier signals
- The user mentions EDI, EDI 810, EDI 850, EDI 855, EDI 856, punchout, cXML, supplier invoices, electronic invoicing, UBL
- The assembly.xml references an EDI connector or punchout integration template

### Journal and GL signals
- The user mentions accounting journal, journal import, journal lines, financial journal, payroll journal export, GL integration
- The assembly.xml references an accounting journal or financial journal connector

### Tax and compliance signals
- The user mentions ELSTER, FEC, GoBD, SAF-T, DAS2, VAT return, tax filing, tax ID validation, VIES, 1099
- The assembly.xml references a tax-related integration template

### Other financials signals
- The user mentions currency exchange rates, credit card transactions, MasterCard CDF3, Visa VCF4, travel booking, PSA connector, Salesforce financial connector, inventory labels, contract management, ad hoc bank transactions
- The user asks about financials connector selection or financials integration design

## Auto-Load Reference Files

| Signal | Reference file to read |
|--------|----------------------|
| General financials design / connector selection | `financials-integration-guide.md` |
| Bank statements, payments, lockbox, bank connectivity, EBICS, credit cards, exchange rates, ad hoc transactions, bank fees | `banking-and-payments-reference.md` |
| EDI (810/850/855/856), punchout, cXML, electronic invoicing, supplier invoices | `procurement-reference.md` |
| Accounting journal import, financial journal lines, payroll journal export | `journals-and-gl-reference.md` |
| ELSTER, FEC, GoBD, SAF-T, DAS2, tax ID validation, VIES | `tax-compliance-reference.md` |
| PSA, travel booking, Salesforce financial sync, inventory labels, contract management, third-party payments | `other-financials-reference.md` |

All reference files are located at: `skills/integration-design-skill/references/domains/financials/`
