---
description: Use when reading, converting, or processing Excel (.xlsx/.xls) files. Covers the recommended approach for handling Workday-exported Excel files, avoiding common pitfalls with PowerShell modules, and extracting data from non-tabular layouts.
applyTo: "**/*.xlsx,**/*.xls"
---

# Excel File Handling

AMS consultants regularly export Workday security configurations, report definitions, and data extracts as Excel files. These need to be read and analysed accurately.

## Tooling

- **Always use Python with `openpyxl`** to read `.xlsx` files — it is the most reliable cross-environment option
- Do NOT rely on the PowerShell `ImportExcel` module — it frequently fails due to OneDrive path conflicts, module installation scope issues, and PowerShell 5.1 quirks on consultant laptops
- If `openpyxl` is not installed, install it with `py -m pip install openpyxl` or the full Python path (e.g. `& "C:\Users\...\python.exe" -m pip install openpyxl`)
- Use `py` launcher on Windows to find Python; fall back to the full path from pip's `[notice]` output if `py` fails

## Reading Excel Files

### Non-tabular Workday exports

Workday exports (security group views, report definitions, integration system configs) are **not** tabular CSVs. They use a key-value layout with section headers, merged cells, and multi-line cell values. The standard pattern:

```python
import openpyxl

wb = openpyxl.load_workbook(filepath, data_only=True)  # data_only=True to resolve formulas
for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
    for row in ws.iter_rows(values_only=False):
        vals = [(c.coordinate, c.value) for c in row if c.value is not None]
        if vals:
            print(vals)
wb.close()
```

Key points:
- **Do NOT use `read_only=True`** for Workday exports — it skips cells in non-contiguous ranges and returns incomplete data
- Use `values_only=False` to get cell coordinates, which helps understand the layout
- Multi-line values in Workday exports use `\n` (newline within a cell), not separate rows
- Always iterate all sheets — Workday report definition exports have multiple tabs (Columns, Sort, Filter, Prompts, Output, Share, Advanced)

### Tabular data

For standard tabular Excel files (data extracts, mapping sheets):

```python
import openpyxl

wb = openpyxl.load_workbook(filepath, data_only=True)
ws = wb.active
headers = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
for row in ws.iter_rows(min_row=2, values_only=True):
    record = dict(zip(headers, row))
    # process record
wb.close()
```

### Converting to CSV

When converting Excel to CSV for further processing:

```python
import openpyxl, csv, os

wb = openpyxl.load_workbook(filepath, data_only=True)
for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
    out_name = f"{base_name}__{sheet_name}.csv" if len(wb.sheetnames) > 1 else f"{base_name}.csv"
    with open(out_name, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        for row in ws.iter_rows(values_only=True):
            writer.writerow(row)
wb.close()
```

- Use `newline=''` in the `open()` call to prevent double line breaks on Windows
- Use `encoding='utf-8'` for consistency
- When a workbook has multiple sheets, suffix the CSV filename with `__{SheetName}` to avoid overwriting

## Common Pitfalls

| Pitfall | Fix |
|---|---|
| `read_only=True` returns empty/partial data | Use `data_only=True` without `read_only` |
| PowerShell `Import-Excel` not found / OneDrive path error | Switch to Python openpyxl |
| `pip` not on PATH in PowerShell | Use `py -m pip` or full Python executable path |
| Merged cells show value only in top-left cell | Check adjacent cells; openpyxl returns `None` for merged-away cells |
| Workday export looks like 1 row when it has 30+ | You used `read_only=True` — see above |
| stderr noise from pip notices treated as error | PowerShell marks any stderr as error; ignore `[notice]` lines about pip upgrades |
