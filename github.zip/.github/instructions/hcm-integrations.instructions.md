---
description: "Use when building, reviewing, or debugging Workday HCM connectors. Covers Core Connectors (Worker, Positions, Location, Organization, Job Postings, Requisitions, Background Check), Directory Service, Account Provisioning, E-Verify, LinkedIn RSC, Kronos, Absence Calendar, and other HCM integrations."
applyTo: "**/assembly.xml,**/*.xsl"
---

# HCM Integration Patterns

## Detecting HCM Context

When this instruction loads, check whether the current file or conversation involves an HCM connector. **Read the appropriate reference file** from `skills/integration-design-skill/references/domains/hcm/` if any of these signals are present:

### Worker data signals
- The user mentions Core Connector Worker, CC:Worker, CCW, Global Worker, Directory Service, LMS Outbound, Core Connector Positions, Core Connector Location, Core Connector Organization
- The assembly.xml references a Core Connector worker, position, location, or organization integration template
- The user asks about worker extracts, worker selection criteria, data sections for worker data

### Recruiting and talent signals
- The user mentions job postings, job requisitions, job profiles, job families, candidate outbound, background check, competency model
- The user mentions LinkedIn RSC, LinkedIn Recruiter System Connect, Kenexa, inline assessments, talent profile inbound
- The assembly.xml references a recruiting or talent connector template

### Identity and provisioning signals
- The user mentions account provisioning, Okta integration, E-Verify, SSN verification, Equifax verification, image upload, worker photos
- The assembly.xml references an account provisioning or identity connector template

### Time, absence and third-party signals
- The user mentions absence calendar, Google Calendar integration, Outlook calendar, Worker Time Block, Kronos, time tracking connector
- The user mentions AngelPoints, Skillsoft, Medicare, Unistaff, ACA, Affordable Care Act
- The user mentions Organization Inbound, Assign Organizations Inbound, Salesforce Worker Sync, Salesforce Chatter

## Auto-Load Reference Files

| Signal | Reference file to read |
|--------|----------------------|
| General HCM connector selection / design | `hcm-integration-guide.md` |
| Core Connector Worker, Global Worker, Positions, Location, Organization, LMS, Directory Service | `hcm-worker-data-reference.md` |
| Job Postings, Requisitions, Profiles, Candidates, Background Check, LinkedIn, Kenexa, Assessments, Talent Profile | `hcm-recruiting-and-talent-reference.md` |
| Account Provisioning, Okta, E-Verify, SSN Verification, Equifax, Image Upload | `hcm-identity-and-provisioning-reference.md` |
| Absence Calendar, Time Block, Kronos, AngelPoints, Skillsoft, Medicare, ACA, Unistaff, Organizations Inbound, Salesforce | `hcm-time-absence-and-third-party-reference.md` |

All reference files are located at: `skills/integration-design-skill/references/domains/hcm/`
