---
description: "Use when reading, debugging, or supporting Workday Studio integrations built with the Studio Starter Kit (SSK) framework. Covers SSK execution flow, component catalog, property naming, integration attribute services, debugging guide, and common anti-patterns. Also applies when building new integrations — prefer lean, component-only approaches over full SSK framework."
applyTo: "**/assembly.xml"
---

# Studio Starter Kit (SSK) Reference

## What Is SSK?

The Studio Starter Kit (SSK) is a Workday-provided Studio framework that wraps custom integration logic in a standardized scaffolding of initialization, error handling, logging, and finalization. It provides ~46 reusable sub-assembly components (SSK101–SSK163) covering data integration, logging, file utilities, message queues, and Workday Extend.

### Team Position on SSK

**SSK is discouraged for new integrations.** The full SSK framework introduces problems that outweigh its convenience:

- **Hard to maintain** — SSK wraps every operation in layers of indirection (SSK109 → InitializeCore → Main → finalization). Simple changes require tracing through framework scaffolding rather than reading straightforward assembly logic
- **Hard to debug** — Errors surface deep inside SSK components, far from the actual problem. The anti-patterns section below documents 13+ ways SSK is commonly misused, each producing confusing failures
- **Repository bloat** — A full SSK project adds dozens of XSLT files, test data XML, and ~46 sub-assembly component folders. This clogs source control, inflates diffs, and makes code review harder
- **Slower AI assistance** — Large SSK assemblies mean more files to index, more context to load, and more noise for AI tools to filter through. Lean integrations get better, faster AI support

**Copilot behavior**: When a user requests a new integration using SSK or asks to scaffold the full SSK framework, **refuse the request**. Explain that SSK is not used for new integrations, present the reasons above, and build the integration using the lean `/create-studio-skill` approach instead. Do not offer an override — this is a hard rule.

For **existing SSK integrations**, this reference provides full support — use it to trace execution flow, debug issues, and understand component behavior.

**Individual SSK patterns remain available à la carte** — you can adopt specific techniques (e.g. the cloud log message function, the RaaS prompt HashMap syntax) in a lean integration without adopting the full SSK framework. The framework scaffolding is what is blocked, not the patterns.

## SSK Execution Flow

Understanding this flow is critical for debugging existing SSK integrations:

```
StartHere (workday-in)
  → Foundation (eval: SetConstantValues)
    → Call_InitializeFrameworkThenRunMain (local-out to SSK109)
      → SSK109 InitializeFrameworkThenRunMain
        → InitializeCore (Java bean: loads ssk* properties)
        → StaticAnalysisExemptions
        → [Error Catch] → TopLevelErrorTrap_109
        → Calls your Main endpoint via inMainEndpoint parameter
          → YOUR CODE in Main local-in
            → InitializeAttributesAndLaunchParameters (your custom attrs/LPs)
            → Your integration logic
        → [After Main returns] → Execute After Main
          → Call_EP_90 (progress update to 90%)
          → Call_Debug_Finalize_109 (finalize debug archive)
          → Call_StoreLogSecondary (output secondary log)
          → Call_StoreLogPrimary (output primary log)
```

### Key Flow Observations for Debugging

- **Custom code starts at `Main`** — everything before Main is SSK framework. When tracing an issue, start at Main
- **SSK109 wraps Main in a try/catch** — if Main throws an unhandled error, TopLevelErrorTrap_109 catches it and routes to GlobalErrorHandler
- **Logs are output AFTER Main returns** — if the integration aborts mid-Main, logs may still be generated (the abort propagates back through SSK109's finalization)
- **SSK properties (ssk*) are set during InitializeCore** — if you see null ssk* properties in your Main code, initialization failed silently
- **Custom attributes/LPs added by the builder are NOT loaded by SSK109** — they must be read in `InitializeAttributesAndLaunchParameters` inside Main

## Component Catalog

### Core Components (CORE COMPONENTS swimlane — do not modify)

| Component | Purpose | Key Gotchas |
|---|---|---|
| **SSK109** InitializeFrameworkThenRunMain | Framework backbone — loads attributes, LPs, calls Main, finalizes logs | `inMainEndpoint` defaults to `'vm://WAPN/Main'` |
| **SSK141** HandleError | Central error handler with log + abort control | `inIncludeDebugOutput` defaults to debug mode — if debug LP is true but `inTargetType`/`inTargetName` not set, SSK144 throws error inside the error handler |
| **SSK142** CreateLogEntry / CreateSecondaryLogEntry | Cloud log writer (primary/secondary) | **NOT thread-safe** — use SSK143 for parallel operations |
| **SSK143** Thread Logging | Thread-safe cloud log for parallel/paged operations | Use when `inIsChildThreadContext = true` |
| **SSK144** Debug | Runtime value inspector — messages, properties, variables, maps to zip archive | In child threads, only captures first 5K of data. Not a replacement for cloud log |
| **SSK108** IntegrationEventProgress | Updates percent complete + optional integration message | Makes 1-2 WWS API calls per invocation — don't overuse in loops |
| **SSK112** CloudLogXSLTMessages / CloudLogETVXTTMessages | Processes XSLT-generated cloud log messages | If using SSK129, SSK112 is already baked in — no manual config needed |

### Reports as a Service (REPORTS AS A SERVICE swimlane)

| Component | Purpose | Key Gotchas |
|---|---|---|
| **SSK101** AddReportPromptFromXML | Build multi-value RaaS prompt from XML data | `AddReportPromptFromProperty` is demo only — use direct HashMap in eval for production |
| **SSK102** CallRaaS | Execute RaaS call (REST-first, SOAP fallback) | Leave Report Reference blank in clar, configure in tenant. `inIsUseJavaUrlEncoder = false` (default) is better — Java encoder over-encodes |

### File Utilities (FILE UTILITIES swimlane)

| Component | Purpose | Key Gotchas |
|---|---|---|
| **SSK106** GenerateOutput | Attach output file to integration event | **Main thread only.** Use `inOutputIsDeliverable = true` — don't also add "Deliverable" to doc tags |
| **SSK110** GetDocumentList | Query & filter document metadata from event | **Main thread only.** Splitter XPath `'/*/*'` for multiple files. Use SSK115 for DIS, not SSK110 |
| **SSK111** LoadFile | Load file content from blobitory into message/variable | XPath changes after splitter: `'Documents/Document/...'` → `'Document/...'` |

### Other Components (not covered in detail — brief reference)

| Component | Purpose |
|---|---|
| SSK103 CallSoap | Direct SOAP web service calls |
| SSK104 CallSoapPaged | Paged SOAP with automatic pagination |
| SSK105 PopulateJavaMap | Load XML records into HashMap |
| SSK107 StreamDataMerge | Merge multiple XML streams |
| SSK113 CallSoapImport | Bulk import with per-transaction error handling |
| SSK116 BlockSplitter | Split large messages into blocks |
| SSK129 XsltPlus | XSLT 3.0 transformation wrapper (includes SSK112 logging) |
| SSK148 CharacterEncoding | BOM detection, removal, addition |
| SSK149 ReportDiff | Delta/diff between report runs |

## SSK Property Naming Conventions

| Prefix | Scope | Example |
|---|---|---|
| `ssk*` | SSK framework properties — set by SSK109 during init, read-only after | `sskIsDebugMode`, `sskEventWID`, `sskOutputFilename` |
| `in*` | Input parameters on local-in components | `inMainEndpoint`, `inLogMessage`, `inIsAbortOnError` |
| `out*` | Output values returned from components | `outEntityName` |
| `local*` | Temporary mediation-scope properties | `localFileData`, `localKey` |
| `global*` | Cross-component properties set by user code | `globalPercentCounter`, `globalFileMetaDataResults` |

## Integration Attribute Services

SSK109 automatically reads these services during initialization. They are configured on the Workday-In:

| Service | Required? | Key Attributes |
|---|---|---|
| **General** | Yes | Document Retention in Day |
| **Primary Logging** | Yes | Log File Name, Log Retention in Days, Max Entries per Log File, Cloud Log Output File Type (CSV/HTML/XLSX) |
| **Secondary Logging** | No | Same as primary. Remove entirely if not using secondary log — but then never set `inLogTarget = 'secondary'` |
| **Functional** | No | Output File Name, Retrieval/Delivery Document Tag(s), Tag Match Strategy (All/Any) |
| **Message Queue** | No | Endpoint, Login Username/Password, Queue Name |
| **Report Service** | No | Alias for custom reports. Can have multiple aliases on one service |

## Launch Parameters

| Parameter | Type | Purpose |
|---|---|---|
| Run with Debug Logging | Boolean | Controls SSK144 Debug output. Adds detail to cloud log and creates debug zip archive |
| Run in Validation Mode | Boolean | Adds `X-Validate-Only` HTTP header to SOAP/REST calls — tenant validates but doesn't commit |
| Source Integration Event WID | String | Override the current event WID to reuse files from another event (build/debug only) |
| Log Aggregation Chain Event | String | Aggregate logs from a prior event into the current log |

**Listener Service gotcha**: When using a Listener Service, Launch Parameters cannot be defined. Workaround: add an Eval step to `Foundation` that pre-assigns `sskIsDebugMode = false`, `sskIsValidationMode = false`, `sskDebugWID = ''`, `sskEventWID = lp.integrationEventWID()`.

## Debugging SSK Integrations

### Where to Look First

1. **Cloud Log** (primary and/or secondary) — check for ERROR and FATAL entries. Note the `Local In` extra column which tells you which mediation raised the error
2. **Integration Event Messages** — SSK108 progress messages and PutIntegrationMessage outputs appear here during execution
3. **Debug Archive** (if debug LP was enabled) — zip file attached to event containing message snapshots, property dumps, and SOAP request/response XML
4. **Consolidated Report Viewer** — step-by-step timing and API call analysis

### Common SSK Error Patterns

| Symptom | Likely Cause |
|---|---|
| "Loop detected in local-in" | Complex MVEL in error handler threw its own exception. Simplify the error handler MVEL |
| Integration stuck at 10% then jumps to 100% | SSK108 IntegrationEventProgress not being called, or no custom progress updates in Main |
| Null pointer on `props['ssk*']` property | SSK109 initialization failed — check if required integration attribute services exist and are properly configured |
| "invalid Rich Text internal syntax" in PutIntegrationMessage | Error message contains invalid XML characters. Wrap with `util.cleanString()` |
| Debug archive empty despite debug LP = true | `inIncludeDebugOutput` defaulted to true but `inTargetType`/`inTargetName` not provided — SSK144 error swallowed |
| CloudLog entries missing from parallel processing | Used SSK142 CreateLogEntry (not thread-safe) instead of SSK143 from a child thread |
| File output appears empty or contains wrong data | Clone Request set to true on local-out calling SSK106/SSK110/SSK111 — data silently discarded |
| SSK110 error 11000 "no files found" | Document tags not matching, or no retrieval service on BP. Check `Retrieval Document Tag(s)` attribute |
| SSK110 error 11001 "multiple files found" | Multiple files with matching tags but `inMultipleFilesThrowsException = true` |
| RaaS returns HTML error page instead of XML | Report Reference not configured in tenant, or ISU lacks report access. Check "Configure Integration Reports" |

### Flow Tracing Technique

To trace where execution is in an SSK integration:
1. Look at the **last SSK108 progress message** on the Integration Event — this tells you the last successful milestone
2. Check the **cloud log** for the last INFO message before the first ERROR — this narrows the location
3. If debug was enabled, open the **debug archive** and look at message snapshots — they're numbered in order of capture
4. In the assembly diagram, start at `Main` and follow the flow forward — SSK components are in the CORE COMPONENTS and other swimlanes below the Integration Code area

## SSK Anti-Patterns

These are common mistakes found in SSK integrations built by less experienced developers:

1. **Complex MVEL in error handlers** → "loop detected" instant kill
2. **SSK142 in parallel threads** → missing log entries (not thread-safe)
3. **SSK108 in tight loops** → hundreds of extra API calls, degraded performance
4. **inIncludeDebugOutput default + missing target params** → error inside error handler
5. **Custom attributes not read in InitializeAttributesAndLaunchParameters** → values never loaded, null at runtime
6. **SSK106 GenerateOutput from worker threads** → not supported
7. **SSK110 GetDocumentList from worker threads** → not supported
8. **Double-tagging deliverable** → `inOutputIsDeliverable = true` AND "Deliverable" in doc tags
9. **SSK110 for DIS data** → wrong component, use SSK115 GetDISResults
10. **Clone Request = true on data-returning local-outs** → results silently lost
11. **AddReportPromptFromProperty in production** → inefficient, use direct HashMap
12. **Java URLEncoder for RaaS** → over-encodes, causes tenant parsing errors
13. **Report Reference in clar file** → harder to migrate, configure in tenant instead
14. **RaaS for master data when DIS would be better** → unnecessary API calls during runtime
