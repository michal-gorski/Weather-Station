# AMS-AI-Config

Teaches GitHub Copilot how to build and support Workday integrations. Add it as a workspace folder alongside your integration projects and Copilot gains naming standards, error-handling patterns, coding conventions, and domain knowledge.

**Covers:** Studio (assembly, MVEL, XSLT, Java beans, SSK, AUnit testing), Orchestrate (Maya), payroll connectors (PECI/PICOF/WECI/DCoD), financials connectors (banking, procurement, journals, tax compliance), HCM connectors (worker data, recruiting, identity/provisioning, time/absence), integration foundations (technology selection, connector concepts), integration security (certificates, encryption, WS-Security, mutual authentication, ciphers), web services (WWS, SOAP, Integration IDs, paging), custom reports and calculated fields, naming conventions, integration lifecycle (deployment, monitoring, log files, troubleshooting), glossary, and Excel handling.

> **Before committing to `main`:** Consult **Andy Quinn** or **Andrew Hylands**. Fork to iterate independently.

> **Required reading:** [AI Usage Guide](.github/references/ai-usage-guide.md) — customer communication rules, disclosure, quality expectations, responsible use.

> **Your responsibility:** Read what AI produces with healthy scepticism, not blind trust. You will almost always find something that does not match what you or the customer intended. See the [AI Usage Guide](.github/references/ai-usage-guide.md) for the full framework.

---

## Who This Is For

This tool is designed for **experienced Workday integration consultants** — people who can look at the output, recognise what is wrong, and fix it. It accelerates work you already know how to do. It does not teach you how to do it.

- **AI output is never perfect.** It will produce plausible code, confident explanations, and reasonable-looking designs that contain errors. The consultant is expected to review everything thoroughly before using it.
- **Less experienced consultants may use it**, but their work must be reviewed by a more senior consultant before it goes to a customer or into production. This is non-negotiable.
- **It does not replace good architecture and design.** The thinking — understanding requirements, choosing the right approach, anticipating edge cases — is still yours. AI can help you execute a design faster, but it cannot make the design decisions for you.

---

## Contents

- [Prerequisites](#prerequisites)
- [Setup](#setup)
- [What to Expect from Copilot](#what-to-expect-from-copilot)
- [How to Get the Best Results](#how-to-get-the-best-results)
- [What Loads Automatically](#what-loads-automatically)
- [Skills](#skills)
- [Troubleshooting](#troubleshooting)
- [Updating](#updating)
- [Repo Structure](#repo-structure)

---

## Prerequisites

Install the following before starting:

| Software | Download | Notes |
|---|---|---|
| **GitHub Desktop** | [Download GitHub Desktop](https://desktop.github.com/download/) | Required for cloning repos and managing branches. Includes bundled Git used by the auto-update task. |
| **Python 3** | [Windows](https://www.python.org/downloads/windows/) · [macOS](https://www.python.org/downloads/macos/) | Required by Copilot for reading PDFs, Excel files, and Word documents. Install the latest stable release. |
| **VS Code** | [Download VS Code](https://code.visualstudio.com/) | Install the **GitHub Copilot** and **GitHub Copilot Chat** extensions from the Extensions marketplace. |

> **GitHub guidelines:** Follow the team's [GitHub Guidelines](https://kainossoftwareltd.sharepoint.com/sites/KainosWorkdayIntegrations/SitePages/400%20Completed%20Solutions/402%20Github%20Guidelines.aspx) for branching, commit messages, and repository conventions.

---

## Setup

Request a GitHub Copilot licence via JIRA if you don't have one.

> **⚠️ CRITICAL — Sign in to GitHub Copilot:** Open the Chat pane in VS Code and sign in to your GitHub account. **Enterprise data protection only applies when you are signed in.** Without it, prompts and file contents may be processed outside the enterprise boundary. This is a strict requirement when working with customer data.

### Clone and create a workspace

1. Clone this repo locally (use GitHub Desktop)
2. Open VS Code
3. **File > Add Folder to Workspace** > select your integration project folder
4. **File > Add Folder to Workspace** > select this `AMS-AI-Config` folder
5. **File > Save Workspace As** > save the `.code-workspace` file for easy re-opening

VS Code workspaces let you keep multiple project folders open in a single window. This is how AMS-AI-Config loads its instructions — it must be a folder in your workspace, not just a cloned repo sitting on disk.

### Add a temporary working folder

Create a local folder (e.g. `_working` or `temp`) and add it to your workspace. Use it for:

- Integration output files (CSV, XML, flat files) for analysis
- Tenant configuration exports (security groups, integration systems, report definitions)
- Vendor specifications, sample payloads, file layouts
- Anything you want Copilot to see but that should **never be committed to Git**

Keep this folder outside any Git repository — somewhere temporary like your Downloads folder works fine.

Instructions and references load automatically based on the files you open.

> **Auto-update:** A background task runs `git pull --ff-only` every time you open this workspace. The first time, VS Code asks you to **Allow** automatic tasks — click Allow. See [Updating](#updating).

---

## What to Expect from Copilot

When AMS-AI-Config is in your workspace, Copilot behaves differently:

- **It asks before editing.** Before making file changes, it checks whether you're on AMS, implementation, or internal work, and confirms you're on a working branch. This happens once per conversation.
- **It asks before generating.** It checks what stage you're at and what you need before producing output. You get a short assessment first, with the option to expand.
- **It follows our standards.** Assembly patterns, MVEL rules, XSLT conventions, naming, error handling, and payroll patterns are all loaded automatically based on the files you open.
- **It defaults to UK English.** Generated text uses UK spelling by default (for example behaviour, organisation, prioritise), unless you ask for another variant.
- **It flags uncertainty.** Workday is proprietary. When Copilot isn't confident about a Workday-specific fact, it says so rather than guessing.
- **It reminds you to review.** After the first deliverable in a conversation, it reminds you that AI output needs human verification before sharing with a customer.
- **It can search the Workday developer docs.** Copilot connects to an indexed copy of the public Workday developer documentation via an MCP server. It can look up REST API endpoints, orchestration components, authentication patterns, and other narrative docs — and cite the source URL. It knows not to use this for SOAP operation detail (it directs you to the public SOAP reference instead) or for tenant-specific configuration.
- **It won't use SSK for new builds.** SSK is blocked for new integrations. Copilot builds lean, component-only integrations instead.
- **It won't always follow its own rules.** LLMs follow instructions probabilistically, not deterministically. Rules near the top of short files get better compliance than rules buried at the bottom of long ones. Post-task steps (commit messages, diagram checks) are the most likely to be skipped. If Copilot forgets something, remind it. This is a known limitation, not a bug in the config.

All behaviour rules are in `.github/copilot-instructions.md`. You don't need to read it, but it's there if you're curious.

---

## How to Get the Best Results

### Use Plan mode first

**Start in Plan mode** for anything non-trivial. Copilot outlines its approach before writing files. You review, adjust, then switch to Agent mode to execute. Start your prompt with:

> *"Work back and forth with me. Start with your open questions and an outline before writing the plan."*

### Front-load context

Copilot works with what it can see. Add relevant material to your workspace:

- **Workday config exports** — security groups, integration systems, report definitions. Export as Excel, drop into a folder, tell Copilot to convert to CSV and analyse
- **Vendor specs** — file layouts, API docs, sample payloads. PDFs, Word docs, and Excel files are all readable (Copilot uses Python libraries to extract content)
- **Similar integrations** — even poor ones. Tell Copilot what's good and what's not about them

### Be specific

| Instead of | Try |
|---|---|
| *"Make a new integration"* | *"Create a Studio integration called INT_ContractCW_Inbound that retrieves a CSV from GetEventDocuments, splits rows, and calls Contract_Contingent_Worker (Staffing v46.0). Skip bad rows. Here is the CSV layout: [columns]"* |
| *"Fix this"* | *"This PECI integration isn't picking up compensation changes for workers in the UK Monthly pay group. What should I check?"* |
| *"Help with MVEL"* | *"How do I access a multi-instance launch parameter in MVEL and iterate over the values?"* |

### Example prompts

**Review:** *"Review this assembly.xml for convention violations"* · *"Compare this XSLT to xsl-standards and flag issues"*

**Build:** *"Add error handling to this mediation following our patterns"* · *"Add an OAuth 2.0 client credentials flow to this integration"*

**Troubleshooting:** *"Should I use PECI or PICOF for a CSV payroll feed to an external provider?"* · *"I need to parse a fixed-width text file in Studio"*

**Orchestrate:** *"This orchestration is timing out at 60 minutes. How do I split it into Controller/Processor?"* · *"What expression do I use to check if a SOAP response is a fault?"*

**Design (Plan mode):** `/integration-design-skill` *"We need a payroll integration to an external provider. Here is the vendor's file spec: [attached]."*

---

## What Loads Automatically

Domain knowledge loads in two ways: by **file type** (when you open a matching file) and by **keyword** (when you mention a relevant topic in conversation). You don't need to do anything special. Just open your project files or ask about a topic.

| Domain | Triggers (files or keywords) | What loads |
|---|---|---|
| **Studio** | `assembly.xml`, `assembly-diagram.xml`, or mentioning Studio, assembly, mediation, transport, route | Assembly patterns, element catalog, MVEL reference, diagram guide |
| **AUnit testing** | Mentioning AUnit, unit test, mock data, @AssemblyTest, @ComponentMethod, JUnit | AUnit testing reference (project setup, mock data, test classes, debugging) |
| **XSLT** | Any `.xsl` file, or mentioning XSLT, stylesheet, transformation | XSLT coding standards, streaming, ETV/XTT, JSON handling, performance rules |
| **Payroll** | Mentioning PECI, PICOF, WECI, payroll, pay group, pay component | Payroll connector patterns and field handling |
| **Orchestrate** | Any `.orchestration` / `.suborchestration` file, or mentioning Orchestrate, Maya, Batch Loop | Orchestrate components, expression language, runtime limits, Controller/Processor patterns |
| **Java beans** | Any `.java` file, or mentioning custom bean, cc:custom | Java bean standards and project configuration |
| **Custom reports** | Mentioning RaaS, WQL, custom report, calculated field, data source | Custom reports and calculated fields reference |
| **Excel** | Any `.xlsx` / `.xls` file, or mentioning Excel, spreadsheet | Excel handling guidance (Python openpyxl) |
| **Workday Developer Docs** | Asking about REST API endpoints, orchestration components, authentication, or Workday developer documentation | Searches the indexed public Workday docs via MCP and returns cited passages with source URLs |

**File handling:** Copilot reads PDFs (pypdf), Word docs (python-docx), and Excel files (openpyxl) via the terminal. Drop them into your workspace. They'll be read automatically without prompting.

---

## Skills

Skills are specialist workflows you trigger with a slash command. Use Plan mode when invoking them.

| Skill | Command | Use for |
|---|---|---|
| **Create Studio Integration** | `/create-studio-skill` | New Studio integration from scratch (includes MVEL guidance) |
| **Integration Design** | `/integration-design-skill` | Discovery questionnaires, design docs, integration type selection (early stage — limited functionality, not well tested) |
| **Integration Review** | `/integration-review-skill` | Portfolio or single integration review against AMS standards |
| **Unit Test** | `/unit-test-skill` | Populate the Kainos unit test Excel template with test cases from the conversation |
| **Customer Guide** | `/customer-guide-skill` | Generate a branded customer-facing guide document (Word template) |
| **GitHub Title and Commit Text** | `/github-title-skill` | ASCII-safe GitHub title, commit subject, and commit description |
| **Build & Release Note** (AMS) | `/build-release-note-skill` | Build notes for production deployments (HTML, text, Word template fill) |
| **Resolution Notes** (AMS) | `/resolution-notes-skill` | Standard ticket resolution notes, with Build and Release note aware output |
| **Add Domain** | `/add-domain-skill` | Add a new knowledge domain or cross-cutting reference to AMS-AI-Config |

For existing integrations, just open the files — references load automatically.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Rules not loading | Confirm `AMS-AI-Config` is visible in the Explorer sidebar |
| Slash command missing | Type `/` in chat and look for the skill name |
| Wrong conventions applied | Check `applyTo` patterns in `.instructions.md` frontmatter |

---

## Updating

A VS Code task runs `git pull --ff-only` automatically every time you open the workspace.

**First time only — two prompts:**

1. **"Allow automatic tasks?"** — click **Allow**. VS Code remembers this per workspace.
2. **Git Credential Manager sign-in** — authorise with GitHub. Cached after first use.

After that, updates happen silently on every workspace open.

**Notes:**
- Uses GitHub Desktop's bundled `git.exe` (falls back to standalone Git if available)
- Conflicting local changes cause the pull to skip silently (`--ff-only`) — no work lost
- Only pulls this repo, not other workspace folders

---

## Repo Structure

Everything lives under `.github/`:

| Folder | What it contains | How it's used |
|---|---|---|
| `instructions/` | `.instructions.md` files with `applyTo` frontmatter | **Auto-loaded** by Copilot when you open matching files (e.g. `assembly.xml`, `.xsl`, `.orchestration`). No action needed. |
| `references/` | Detailed reference docs (expression language, calculated fields, AI usage guide, file handling) | **Loaded on demand** when Copilot needs deeper detail, or when you ask about a topic they cover. |
| `skills/` | Slash-command skill definitions (`SKILL.md` + supporting files) | **Invoked manually** via `/skill-name` in chat. Each skill has its own folder. |
| `copilot-instructions.md` | Top-level rules that apply to every conversation | **Always loaded.** Collaboration style, pre-edit checks, epistemic humility, skills routing. |

The `.vscode/` folder contains `mcp.json`, which connects Copilot to the hosted Workday developer docs index. This loads automatically — no setup needed.

To add or update knowledge, edit the appropriate file under `.github/` and push. The auto-pull ensures everyone picks up changes on next workspace open.

To add a new functional domain (e.g. Identity, Benefits), use `/add-domain-skill` in chat.
