---
name: add-domain-skill
description: "Add a new knowledge domain or cross-cutting reference to AMS-AI-Config. Covers the full pipeline from source material through extraction, gap assessment, curation, and routing. Use when adding domain-specific connector knowledge (e.g. Benefits, Student, Identity) or cross-cutting reference topics (e.g. security, operations, services)."
argument-hint: "Describe the domain or topic to add, and the source material (PDF pages, documents, or other references)"
---

# Add a Domain or Reference to AMS-AI-Config

This skill guides the full pipeline for adding new knowledge to AMS-AI-Config: assess gaps, extract from source material, curate into right-sized reference files, and wire up routing so Copilot loads the content at the right time.

## Prerequisites

This skill edits AMS-AI-Config directly. Before starting:

1. **Confirm you are on a working branch** — never commit domain changes directly to `main`. If the user is on `main`, stop and ask them to create a branch first.
2. All changes should go through a pull request for review.

## When to Use

- Adding a new functional domain (e.g. Benefits, Student, Identity)
- Adding a cross-cutting reference topic (e.g. security, operations, services)
- Extracting content from Workday Admin Guide PDFs or other source material
- The user supplies their own reference material (documents, notes, knowledge base exports)

## Two Output Types

### Domain-specific references

For connector clusters tied to a Workday functional area (HCM, Payroll, Financials, etc.):

| File | Location | Purpose |
|------|----------|---------|
| Integration guide | `skills/integration-design-skill/references/domains/<domain>/<domain>-integration-guide.md` | Decision matrix, connector catalogue, when-to-use |
| Cluster references | Same folder, one per theme | Setup, concepts, troubleshooting for grouped connectors |
| Instruction file | `instructions/<domain>-integrations.instructions.md` | Signal detection keywords → routing to cluster files |

### Cross-cutting references

For topics that span all domains (security, web services, glossary, etc.):

| File | Location | Purpose |
|------|----------|---------|
| Reference file | `references/<topic>-reference.md` | Single reference covering the topic |

No instruction file or integration guide needed — routing is handled directly by the Skills & References table in `copilot-instructions.md`.

## Step 0: Determine Output Type

Before doing any extraction work, ask the user whether the content should be added as a **skill** or a **reference**. Use `vscode_askQuestions`:

**Question:** "Should this be added as a skill or a reference?"

**Options:**
- **Skill** — "A repeatable workflow or procedure the AI should follow step-by-step (e.g. create a Studio integration, generate a build note, run a design session)"
- **Reference** — "Domain knowledge the AI should load as context when a topic comes up (e.g. connector setup guides, security certificates, web service patterns)"
- **Not sure** — "Help me decide"

**If the user picks "Not sure", guide them:**

| Choose **Skill** when... | Choose **Reference** when... |
|--------------------------|------------------------------|
| The content describes a **process** with steps to follow | The content describes **facts, concepts, or configuration** to know about |
| The AI should **do something** when invoked (generate output, run an interview, create files) | The AI should **draw on this knowledge** when answering questions or reviewing code |
| It has a clear trigger: "generate a...", "create a...", "run a..." | It has topic triggers: mentioning a connector, technology, or concept |
| Examples: build notes, design sessions, unit test generation | Examples: payroll connectors, security certificates, web service patterns |

Skills live under `skills/<name>/SKILL.md` and are invoked manually. References live under `references/` or `domains/` and are loaded automatically by keyword triggers.

## Step 1: Gap Assessment

Before extracting or curating anything, check what already exists (for references) or check for similar existing skills (for skills):

1. Search existing files in `references/` and `domains/` for overlapping content
2. If the topic is already well covered, skip it and tell the user
3. If partial coverage exists, note which sections are gaps and curate only those
4. This step saves significant time — several PDF sections can be skipped entirely when existing references are comprehensive

## Step 2: Extract from Source Material

### From Workday PDFs

Use **PyMuPDF** (`fitz`) for page-by-page text extraction. Do not use bulk PDF-to-markdown converters — they produce section bleed and encoding corruption.

```python
import fitz
doc = fitz.open(r'path/to/Admin-Guide.pdf')
with open(r'output.txt', 'w', encoding='utf-8') as f:
    for i in range(start_page_0indexed, end_page_0indexed):
        f.write(doc[i].get_text('text'))
```

- Identify exact page ranges from the PDF table of contents
- Pages are 0-indexed in PyMuPDF (PDF page 221 = index 220)
- Source material may come from multiple PDFs (e.g. Admin Guide - Integrations, Admin Guide - Authentication and Security)

### From user-supplied material

The user may provide their own reference material: documents, notes, knowledge base exports, or structured content. Apply the same curation standards (step 3) regardless of source format.

## Step 3: Clean the Extracted Text

- Fix encoding artefacts (`â€™` → `'`, `â€¢` → `•`, `Â` removal, `â€"` → `—`)
- Strip page headers (e.g. `| Financials Connectors | 637`)
- Strip copyright/confidentiality boilerplate (`©20XX Workday, Inc.`)
- Remove XML/JSON schema blocks longer than ~15 lines (replace with a note)
- Collapse excessive blank lines

### Batch cleaning script pattern

```python
import re, pathlib

def clean(text):
    replacements = {
        'â€™': "'", 'â€˜': "'", 'â€œ': '"', 'â€\x9d': '"',
        'â€¢': '•', 'â€"': '—', 'â€"': '–', 'Â': '',
    }
    for old, new in replacements.items():
        text = re.sub(re.escape(old), new, text)
    text = re.sub(r'\n\s*©20\d{2} Workday.*?\n', '\n', text)
    text = re.sub(r'\n\s*Workday Proprietary.*?\n', '\n', text)
    text = re.sub(r'\|[^|]+\|\s*\d{3,4}\s*\n', '', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip() + '\n'
```

## Step 4: Curate into Output Files (critical step)

Do **not** add raw extracted files to the repo. They are too large and noisy for AI context.

### For skills

Create `skills/<skill-name>/SKILL.md` with:

- YAML frontmatter: `name`, `description`, `argument-hint`
- Clear "When to Use" section
- Step-by-step workflow the AI should follow
- Any interview questions to ask the user (use `vscode_askQuestions`)
- Output format and templates
- Match the structure of existing skills (e.g. `create-studio-skill`, `build-release-note-skill`)

Skills are typically 5–15 KB. They describe **what the AI should do**, not background knowledge.

### For domain-specific references

Curate into **3–6 thematic cluster files** (~15–25 KB each):

- Group related connectors by use case (e.g. banking, procurement, tax compliance)
- Extract: setup overviews, concepts, key decisions, troubleshooting, FAQs
- Drop: raw XML/JSON schemas, field-by-field tables, verbatim click-by-click steps, page references
- Target: content a consultant needs for pattern recognition and decision support

Also create the **integration guide** (5–10 KB): decision matrix, connector catalogue, common patterns.

### For cross-cutting content

Curate into a **single reference file** (15–25 KB):

- Focus on concepts, configuration steps, decision matrices, supported algorithms/options
- Include cross-references to related files (e.g. "OAuth setup → `integration-services-reference.md`")
- Drop verbose examples and content the user would look up in Workday docs directly

### Size targets

| File type | Target size | Purpose |
|-----------|------------|---------|
| Skill | 5–15 KB | Step-by-step workflow the AI follows when invoked |
| Integration guide | 5–10 KB | Decision matrix, connector catalogue, when-to-use |
| Cluster reference | 15–25 KB | Setup, concepts, troubleshooting for grouped connectors |
| Cross-cutting reference | 15–25 KB | Single-topic reference spanning all domains |
| Instruction file | 3–5 KB | Signal detection and routing table |

Domain-specific footprint should be **~100–150 KB** total. Cross-cutting references are standalone.

## Step 5: Create the Instruction File (domain-specific references only)

For domain-specific content, create `instructions/<domain>-integrations.instructions.md` with this structure:

```markdown
---
description: "Use when building, reviewing, or debugging Workday <domain> integrations. Covers <list of connectors/topics>."
applyTo: "**/assembly.xml,**/*.xsl"
---

# <Domain> Integration Patterns

## When This File Loads

This file auto-loads when editing assembly.xml or XSL files. It provides signal detection and routing to domain-specific reference files.

## Signal Detection

| Signal | Likely connector | Reference |
|--------|-----------------|-----------|
| `keyword-or-namespace` | Connector Name | `domains/<domain>/cluster-file.md` |
| ... | ... | ... |

When you detect these signals, load the referenced file for detailed guidance.

## Key Patterns

<Brief domain-wide patterns, anti-patterns, and decision rules — 3-5 KB max>
```

## Step 6: Update Routing (every time)

These files must be updated after adding any new content:

### 1. `copilot-instructions.md` — Skills & References table

Add a row to the table under `## Skills & References`. This is the **primary routing mechanism** — it tells Copilot when to load the reference file.

```markdown
| **Topic name** | trigger keyword 1, trigger keyword 2, ... | `filename.md` |
```

### 2. `copilot-instructions.md` — Knowledge Contribution routing

Add a line under the Knowledge Contribution section so new user-shared knowledge gets routed to the correct file:

```markdown
   - Topic description → `filename.md`
```

### 3. `copilot-instructions.md` — Skills list (skills only)

Add a line under the `Skills (invoked manually):` section:

```markdown
- `/skill-name` — one-line description of what the skill does
```

### 4. `README.md` — Covers line

Update the `**Covers:**` line to include the new topic. Keep it concise — add a brief phrase, not a paragraph.

## Conventions

- Match the style and structure of existing domains as a reference (e.g. `domains/payroll/`, `domains/financials/`)
- Use anonymised/fictional data in all examples
- Keep the integration guide concise: decision matrix and key patterns, not a textbook
- Cluster/reference files can be longer but should be scannable with clear headings
- Use UK English spelling throughout

## Tools

- **PyMuPDF** (`pip install pymupdf`) — PDF text extraction. Use `py` launcher on Windows (not `python`)
- Python 3.x with `re`, `pathlib` — cleaning and splitting
- Subagents — parallel curation of multiple cluster files from cleaned raw content
