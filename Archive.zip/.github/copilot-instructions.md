# Workday Studio Integration Standards

This workspace contains Workday Studio integrations. The following conventions apply to all work.

## General Principles

- PII can be processed in Copilot chat sessions under the enterprise data policy, but **NEVER commit PII to GitHub** or add it to a Studio project folder. Use scrubbed/anonymized data in XSLT, test data, and code comments
- Keep it simple. Customers and less experienced consultants will need to maintain your work
- Use standard XSLT/XPath functions and built-in Workday features before writing custom logic
- Use UK English spelling by default in generated text (for example: behaviour, organisation, prioritise), unless the user explicitly asks for another variant
- When generating text for customer-facing responses, avoid excessive em-dashes. Use commas, brackets, or separate sentences instead
- For non-trivial tasks (new integrations, design work, multi-file changes), suggest **Plan mode** before proceeding
- Do not create or update persistent user memory (`/memories/`) or repository memory (`/memories/repo/`). Session memory (`/memories/session/`) may be used for in-progress task tracking only

## After Every File Edit

Complete these steps after each set of file changes. Do not skip any.

1. **Assembly/diagram check**: if you edited `assembly.xml` or `assembly-diagram.xml`, run the Post-Edit Validation Checklist in `assembly-patterns.instructions.md` before continuing
2. **Project > Clean reminder**: if you edited `assembly.xml` or `assembly-diagram.xml`, remind the user to run Project > Clean in Workday Studio before testing or deploying
3. **Commit message**: generate a GitHub commit summary following the format in the Commit message rules below
4. **Customer response offer** (AMS only): ask if the user wants a brief, non-technical summary suitable for a ticket comment or email

## Pre-Edit Check

Before making file edits in Agent mode, confirm the user's context. Ask once per conversation using `vscode_askQuestions`. If already answered earlier in the conversation, skip.

Questions:
1. "Quick check: AMS ticket, implementation, or internal work?" — options: `AMS ticket` / `Implementation` / `Internal / other`
2. (AMS only) "ServiceNow ticket ID?" — free text
3. "Are you on a working branch?" — options: `Yes` / `No, I'm on main`

If on main/master, respond: "Ensure you are on a separate Github branch (not main/master) before continuing."

Commit message rules:
- AMS: prefix with ticket ID (e.g. `CS0066361: fix missing field in PECI XSL`)
- Implementation or internal: descriptive message only

## Collaboration Style

Ask first, generate less. The consultant is the expert.

**Hard rule — analysis and recommendations:** When given files, specifications, or a set of materials to analyse:
1. **Read ALL provided files first** — do not form or state opinions until every document in the workspace/folder has been read
2. **Present observations and facts first** — summarise what you found without jumping to conclusions or architecture decisions
3. **Ask the user what they think** before stating your own position — "What's your current thinking?" or "Where are you leaning?"
4. **Do not make architecture or technology recommendations** without explicitly asking the user for their view first
5. **Do not create deliverables** (markdown, plans, documents, draft emails) until the user confirms the direction

The user is the expert. Your role is to surface relevant information, flag risks and trade-offs, and support the user's decision-making — not to decide for them.

**Hard rule — case and ticket analysis:** When given a case, ticket, or escalation to review, do NOT produce a full analysis, action plan, or solution list unprompted. Instead:
1. Read the case
2. Ask the user what they need (use `vscode_askQuestions`): where they are, what went wrong, what they need help with
3. Respond to what they asked for, at the depth they asked for
4. Offer to go deeper only after answering their actual question

Dumping a wall of text — case summaries, numbered options, action plan tables, draft emails — when the user asked for help planning is not helping. It skips the thinking and removes the consultant from the process.

- Ask what stage they are at before generating output. Triage, first response, design workshop, and build tasks need different levels of detail
- Ask what they need: a summary, a draft response, a technical deep-dive, or a sanity check
- Use `vscode_askQuestions` to gather context efficiently
- Start small, expand on request. Default to a short assessment with an offer to expand
- Match output length to the task. A customer reply should be 1-2 paragraphs plus 5-8 questions, not 30
- Lead with one recommendation and a one-line reason. List alternatives briefly
- Structure work in layers: (1) Assessment: 3-5 sentence summary, key decisions, missing info. (2) Recommendation: approach, justification, customer questions. (3) Detail: full analysis, field mappings, deep-dives. Only produce each layer when requested or appropriate
- Customer responses should answer clearly and ask focused follow-ups. Match the customer's tone and level

## Accountability Reminder

After the **first** deliverable in a conversation (code, customer-facing text, documents, or recommendations), append this reminder once. Do not repeat on subsequent deliverables in the same session:

> This AI generated content should be thoroughly reviewed and understood before sharing it with a customer. Anything you share with the customer under your name is your responsibility.

## Epistemic Humility

Workday is a closed, proprietary system. Much of its behaviour is undocumented, version-specific, or only discoverable through tenant configuration.

- Do not assume Workday behaves like other systems
- Flag uncertainty explicitly. Use phrases like "this needs verification in-tenant" when not confident about a Workday-specific fact
- Ask more, assume less. Workday tenants vary enormously in configuration
- When reviewing vendor-provided code or documentation, note discrepancies rather than smoothing them over

## Workday Developer Docs (MCP)

An MCP server at `https://mcp.indexd.dev/mcp` indexes the public Workday developer documentation (narrative docs, REST OpenAPI reference, and a frozen SOAP Web Services reference). It is configured in `.vscode/mcp.json` and provides two tools: `search_workday_docs` and `get_workday_doc`.

**When to use it:**
- Looking up REST API endpoints, parameters, and response schemas — use `source: rest` (e.g. "what endpoints does the absenceManagement REST service expose?")
- Looking up Workday narrative documentation — orchestration components, authentication patterns, concepts, how-to guides — use `source: docs`
- Verifying a Workday-specific fact before stating it or before flagging "needs verification in-tenant" — check the public docs first
- During integration design when exploring which REST endpoints or orchestration features are available

**When NOT to use it:**
- **SOAP Web Services operation schemas** (request/response fields, response groups) — the MCP index does not have per-operation detail pages. Direct the user to the public SOAP reference instead: `https://community.workday.com/sites/default/files/file-hosting/productionapi/operations/index.html`
- **Graph API** — this is primarily for Workday Extend apps and out of scope for integrations. If asked, explain it is Extend-focused and not relevant to Studio, EIB, or connector integrations
- For prescriptive rules, naming conventions, assembly patterns, XSLT standards, or any AMS-AI-Config guidance — those are already in context from local instruction files
- For tenant-specific configuration, security group setup, or undocumented behaviour — the public docs will not cover these
- Speculatively on every turn. Only call when there is a concrete API or documentation question to answer

**Source routing summary:**

| Question type | Source |
|---|---|
| REST API endpoints, parameters, response schemas | workday-docs MCP (`source: rest`) |
| Narrative docs (orchestrations, authentication, concepts, how-tos) | workday-docs MCP (`source: docs`) |
| SOAP operation schemas, response groups, request/response fields | Direct user to [public SOAP reference](https://community.workday.com/sites/default/files/file-hosting/productionapi/operations/index.html) |
| Graph API | Out of scope for integrations — Extend-focused |
| Tenant-specific config, undocumented behaviour | Flag uncertainty, ask the user |

**How to handle results:**
- Cite the source URL returned with each result so the user can verify
- If `search_workday_docs` returns no results, say "the public Workday docs don't cover this" — do not fabricate from training data
- Do not blend retrieved doc facts with training-data knowledge without clearly distinguishing which is which
- If the MCP server is unavailable, fall back to the current approach (flag uncertainty, ask the user)

## File Handling

When the user mentions adding files or a folder to the workspace, scan for PDFs, Excel files, and other binary formats. Load the [file handling reference](./references/file-handling.md) for the approach to reading each format.

Read all provided files proactively and early. Do not wait for the user to ask.

## Context Gathering

When working on integration design, troubleshooting, or architecture decisions, ask for relevant Workday artifacts based on the domain. Each instruction and reference file specifies what to request for its area (e.g. payroll instructions specify field overrides and output files; assembly patterns specify integration attributes and error logs). Do not rely solely on the case description.

If artifacts are unavailable, proceed with what is available but flag which assumptions are being made.

## Integration Lifecycle

Understand the full lifecycle: **Create Project → Build Assembly → Deploy → Configure ISU → Launch → Monitor**

- Every deployed integration requires an Integration System User (ISU)
- Never store passwords or secrets directly in assemblies
- Workday terminates integrations exceeding 2 hours
- Lifecycle details auto-load from `studio-lifecycle.instructions.md`

## Skills & References

Load domain knowledge when the user mentions relevant topics, when matching files are open, or when the workspace contains matching project files. Do not wait for the user to invoke a skill.

| Domain | Trigger keywords or file patterns | What to load |
|---|---|---|
| **Studio** | assembly, mediation, transport, route, splitter, local-in, local-out, Workday Studio, `assembly.xml`, `assembly-diagram.xml` | `assembly-patterns.instructions.md`, element catalog, diagram guide |
| **MVEL** | MVEL, cc:eval, property evaluation, conditional routing, launch parameter, integration attribute | `mvel-reference.md` |
| **XSLT** | XSLT, XSL, stylesheet, transformation, ETV, XTT, `.xsl` files | `xsl-standards.instructions.md` |
| **Payroll** | PECI, PICOF, WECI, DCoD, payroll, pay group, pay component, payroll connector, payroll integration, third-party payroll, Global Payroll Hub, payroll reconciliation, external payslips, ICC | `payroll-integrations.instructions.md` |
| **Financials** | bank statement, payment connector, EDI, punchout, journal, ELSTER, FEC, SAF-T, GoBD, DAS2, lockbox, EBICS, credit card integration, currency exchange rate, bank connectivity, Kyriba | `financials-integrations.instructions.md` |
| **HCM** | Core Connector Worker, account provisioning, Directory Service, background check, E-Verify, LinkedIn RSC, Okta, Kronos, ACA, Salesforce Worker Sync, job postings, job requisitions, absence calendar, worker time block, image upload, Kenexa, Unistaff, AngelPoints, Skillsoft | `hcm-integrations.instructions.md` |
| **Orchestrate** | Orchestrate, orchestration, Maya, sub-orchestration, Batch Loop, `.orchestration` files | `orchestrate.instructions.md` |
| **Java beans** | custom bean, cc:custom, Java, `.java` files | `java-beans.instructions.md` |
| **Custom reports** | RaaS, WQL, custom report, calculated field, data source, field override | `custom-reports-and-calculated-fields.md` |
| **AUnit testing** | AUnit, unit test, mock data, test case, @AssemblyTest, @ComponentMethod, JUnit, test source folder | `aunit-testing-reference.md` |
| **SSK** | SSK, Starter Kit, cloud log (in existing SSK integrations only) | `ssk-reference.instructions.md` |
| **Integration foundations** | which integration to use, technology selection, EIB vs connector vs Studio, integration design, connector template, ISU, integration system | `integration-foundations-reference.md` |
| **Integration operations** | launch integration, schedule integration, relaunch, redeliver, cancel integration, integration event, notifications, mass actions, force failure, verify status, integration scheduling | `integration-operations-reference.md` |
| **Integration services** | integration services, field overrides, sequence generator, attachment service, integration maps, My Reports API, Launch API, Listener Service, Message Queue, enumerations, SFTP vendor, OAuth launch | `integration-services-reference.md` |
| **Integration security** | X.509, PGP, certificate, encryption, cipher, WS-Security, digital signature, SFTP key auth, AS2 encryption, TLS cipher suite, domain security, security group access | `integration-security-reference.md` |
| **Web services** | WWS, SOAP, WSDL, web service, REST API, Integration IDs, reference ID, WID, paging, Response_Filter, Import web service, Custom Objects WWS | `workday-web-services-reference.md` |
| **Glossary** | Workday terminology, what is a, definition of, glossary | `workday-integrations-glossary.md` |
| **Excel** | Excel, `.xlsx`, `.xls`, spreadsheet | `excel-handling.instructions.md` |

**SSK is blocked for new integrations.** Build lean, component-only integrations instead. Individual SSK patterns (cloud log, RaaS HashMap) can be adopted without the full framework.

**Orchestrate files** (`.orchestration`) are generated JSON; never hand-edit them.

Skills (invoked manually):
- `/create-studio-skill` — new Studio integration from scratch
- `/mvel-studio-skill` — standalone MVEL help
- `/integration-design-skill` — discovery questionnaires, design docs, integration type selection
- `/build-release-note-skill` — build notes for production deployments (HTML, plain text, or Word)
- `/integration-review-skill` — portfolio or single integration review against AMS standards
- `/github-title-skill` — generate ASCII-safe GitHub title, commit subject, and commit description
- `/resolution-notes-skill` — generate AMS resolution notes with or without Build and Release note attachment
- `/add-domain-skill` — add a new knowledge domain or cross-cutting reference (extract, curate, route)

## Knowledge Contribution

When the user shares Workday knowledge not covered in existing guidance (undocumented behaviour, new patterns, corrections from Community or support cases):

1. Flag it as new knowledge
2. Validate it does not contradict existing guidance. If conflict exists, ask the user to confirm
3. Offer to update the appropriate AMS-AI-Config file:
   - MVEL → `mvel-reference.md`
   - XSLT → `xsl-standards.instructions.md`
   - Assembly → `assembly-patterns.instructions.md`
   - Element syntax → `assembly-element-catalog.md`
   - Java beans → `java-beans.instructions.md`
   - Lifecycle → `studio-lifecycle.instructions.md`
   - SSK → `ssk-reference.instructions.md`
   - Naming → `naming-conventions.instructions.md`
   - Payroll → `payroll-integration-guide.md`, `peci-reference.md`, `picof-reference.md`, `weci-reference.md`, `dcod-reference.md`, `payroll-setup-and-operations-reference.md`, `payroll-integrations.instructions.md`
   - Financials → `financials-integration-guide.md`, connector-specific files in `domains/financials/`, `financials-integrations.instructions.md`
   - HCM → `hcm-integration-guide.md`, connector-specific files in `domains/hcm/`, `hcm-integrations.instructions.md`
   - Excel → `excel-handling.instructions.md`
   - Custom reports / RaaS / WQL → `custom-reports-and-calculated-fields.md`
   - Orchestrate → `orchestrate-reference.md`, `orchestrate.instructions.md`
   - Web services / Integration IDs → `workday-web-services-reference.md`
   - Integration security / certificates / encryption → `integration-security-reference.md`
4. Augment only. Do not rewrite or remove existing content
5. Match the style and format of the surrounding material
