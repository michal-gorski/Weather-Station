---
description: "Use when discussing, debugging, or building Workday Orchestrate (Maya) integrations. Covers orchestration components, expression language (complete global and member function reference), runtime limits, Batch Loop patterns, sub-orchestration design, Controller/Processor pattern, error handling, authentication/credentials, monitoring/debugging, deployment lifecycle, and .orchestration file format. Triggers on mentions of Orchestrate, Orchestration Builder, Maya, .orchestration files, Batch Loop, sub-orchestration, Trigger Integration, orchestration expression language, or Dev Site."
applyTo: "**/*.orchestration,**/*.suborchestration"
---

# Workday Orchestrate (Maya)

## Auto-Load Reference

When the user discusses Orchestrate topics, **read the reference file** for detailed patterns:

| Task | Reference file to read |
|---|---|
| Any Orchestrate work: components, expressions, loops, error handling, limits, debugging, authentication, deployment, monitoring | `.github/references/orchestrate-reference.md` |

Read with `read_file` before answering Orchestrate questions.

## Key Principles

- **Orchestrate is distinct from Studio** — different platform, different expression language, different runtime constraints. Do not apply Studio/MVEL advice to Orchestrate or vice versa
- `.orchestration` and `.suborchestration` files are **generated JSON** — never hand-edit them. All changes must be made through the Orchestration Builder UI in the Workday tenant
- Copilot can **read and analyse** orchestration files to understand flow, diagnose issues, and suggest changes, but the user must apply changes in the UI
- When suggesting changes, provide **step-by-step Orchestration Builder UI instructions** with exact reference names, expression values, and configuration settings
- For non-trivial Orchestrate work (new orchestrations, architecture changes, batch processing), suggest **Plan mode** first
- **Source code backup is mandatory** — after production deployment, export the app from Dev Site, unzip, and commit to the customer's GitHub repo. This is the only backup outside of Workday Developer Cloud

## When to Recommend Orchestrate vs Studio

| Scenario | Recommendation |
|---|---|
| Simple API calls, document processing, data routing | Orchestrate |
| Complex multi-step with branching and error handling | Orchestrate |
| Fixed-width file parsing | Orchestrate (math-based field extraction with sub-orchestrations works well) |
| Binary file processing, PDF handling | Studio (Java beans) |
| XSLT 3.0 transformations with streaming | Studio (XSLT+) |
| Legacy integrations already in Studio | Keep in Studio unless rewrite justified |
| Need process time > 60 min for a single operation | Studio (2-hour limit) or Orchestrate with Controller/Processor pattern (Trigger Integration) |
| Large volume SOAP/API calls (>10K records) | Orchestrate with Controller/Processor pattern — ~2.2x faster than Studio |

> Note: fixed-width parsing previously recommended Studio, but working examples demonstrate it can be handled in Orchestrate via sub-orchestration decomposition.

## Critical Runtime Facts

- **CallSubflow (sub-orchestration) shares the parent's process and 60-min timer.** It does NOT create a separate process. Confirmed by testing.
- **Trigger Integration creates a separate process** with its own 60-min timer. Use the Controller/Processor pattern for large-volume work.
- **RaaS execution time is excluded** from the process time limit (creates a checkpoint).
- **Non-production timeout is 45 min** (2700000ms), not 60 min. Plan for this during testing.
- **`.asXML()` crashes on non-XML responses.** Use `.toString()` when the response format is uncertain.
- **`isSuccess` is only available on action steps** (StoreDocument, SendWorkdayApiRequest, etc.) — NOT on CreateValues.
- **Branch scoping:** Steps inside a `BranchOnConditions` branch are NOT upstream from after the branch converges. You cannot use `data.<StepInsideBranch>.<field>` after the branch — you get "There is no upstream component with id X". Place referencing steps inside each branch instead.
- **ConditionalOutputs continues execution** — after the error handler fires, the next sequential step runs even if the previous step failed. Guard downstream success steps with `data.<Step>.isSuccess` conditions.
- **Global Error Handler** — every orchestration should have one. Output `data._orchestration.processingError.message()` and `data._orchestration.processingError.locationPath()` so failures are diagnosable from integration messages alone.
- **Use "Workday Integration System" template** (not regular "Integration System") when you need Trigger Integration.
- **Sandbox/Production cache updates take ~15 minutes** — Implementation tenants update in ~1 minute.

## Expression Language Quick Reference

The full expression language reference (all global and member functions) is in the reference file. Key reminders:

- **This is NOT MVEL** — Orchestrate has its own expression language
- String interpolation: `s"prefix_${expr}_suffix"`
- Template placeholders: `{{expression}}` and `{{#if(condition)}}...{{/if}}`
- Boolean chaining: `.is2xxStatusCode().not().or(response.isSoapFault())`
- Data references: `data.<StepName>.<field>`, `data.<Loop>.item`, `data.Start.<Input>`
- Error context: `data._orchestration.processingError.message()` (global), `data._group_<Name>.processingError.message()` (loop body), `data.<Step>.processingError.message()` (step)

## Deployment Checklist

When an Orchestrate integration goes to production:

1. Verify all integration attributes are configured on the production tenant
2. ISU has correct security group membership (View/Modify on required domains)
3. Credential stores are configured (OAuth, AWS, etc.)
4. Global error handler is present on every orchestration
5. Test on Sandbox with production-like data
6. Promote through levels: Implementation → Sandbox → Production
7. Wait ~15 minutes for cache update after production promotion
8. **Export app source from Dev Site → unzip → commit to customer's GitHub repo**
