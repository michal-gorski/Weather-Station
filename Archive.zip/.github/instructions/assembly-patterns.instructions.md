---
description: "Use when editing, reviewing, or creating Workday Studio assembly.xml files. Covers assembly diagram layout, error handling patterns, mediation structure, MVEL expression standards, property assignment, integration attributes, and setAbort patterns."
applyTo: "**/assembly.xml,**/assembly-diagram.xml"
---

# Assembly.xml Patterns for Workday Studio

## Auto-Load Reference Files

When working on assembly.xml, **read the following reference files as needed** — do not wait for the user to invoke a skill:

| Task | Reference file to read |
|---|---|
| Adding, modifying, or reviewing assembly components (mediations, transports, steps) | `.github/skills/create-studio-skill/references/assembly-element-catalog.md` |
| Writing or debugging MVEL expressions, cc:eval blocks, property evaluations, conditional routing | `.github/skills/mvel-studio-skill/references/mvel-reference.md` |
| Working with OAuth, REST APIs, HTTP-out, Bearer tokens, JSON responses, or splitter patterns | `.github/skills/create-studio-skill/references/oauth-rest-patterns.md` |
| Creating or debugging Java custom beans, cc:custom steps, project config for beans, third-party JARs | `.github/instructions/java-beans.instructions.md` |
| Updating assembly-diagram.xml after structural changes | `.github/skills/create-studio-skill/references/assembly-diagram-guide.md` |

Read the relevant file(s) with `read_file` before making changes. Multiple files may apply to a single task.

## Assembly Version

- Default version for new integrations: **2025.21** (`<cc:assembly id="WorkdayAssembly" version="2025.21">`)
- When creating a new integration, ask the user which version to target if not specified
- All projects within a collection must use the same assembly version

## Examples

No example integrations are included yet. When examples are added under `.github/examples/`, identify the functional domain and check for relevant patterns before creating new integrations.

## Assembly Diagram Layout

### Private Keys and Secrets — Proactive Check

When opening, reviewing, or editing a Studio project, **scan for private keys, certificates, and secrets** in the project file tree (`WSAR-INF/`, `ws/`, root folder). Flag any of these file types immediately:

- `.jks`, `.p12`, `.pfx`, `.keystore` (Java keystores)
- `.pem`, `.key`, `.der`, `.cer`, `.crt` containing private key material (check for `-----BEGIN PRIVATE KEY-----` or `-----BEGIN RSA PRIVATE KEY-----` or `-----BEGIN ENCRYPTED PRIVATE KEY-----`)
- `.pgp`, `.gpg`, `.asc` (PGP private key rings)
- Hardcoded passwords or secrets in `assembly.xml` property values

**If detected, warn the user:**

> Private key / certificate detected in the project files. Storing private keys in the Studio project is a security risk — they are committed to source control and cannot be rotated without redeployment. Use the **Integration Attachment Service** instead: attach the key file to the integration system in-tenant, retrieve it at runtime via `GetIntegrationSystems` + streaming XSLT + `base64-decode`, and reference it with `mctx:vars/variableName`. See the Integration Attachment Service section below for the full pattern.

Public certificates used solely for truststores (containing only the server's public cert, not the client's private key) are acceptable in `WSAR-INF/` but should still be flagged with a note suggesting the attachment service for easier rotation.

- Arrange components so messages flow **left-to-right** and **top-to-bottom**
- Break assembly into logical sub-assemblies using `local-in` and `local-out` transports — aids readability and permits isolated unit testing
- Group related components using **swimlanes** to separate functional areas
- Name every swimlane and fill in the Description property with detailed documentation
- Nest swimlanes to organize complex patterns: horizontal outer swimlane (vertical flow), vertical inner swimlanes for error handlers, sync-mediation responses, and route destinations
- **Error handler vertical swimlane convention**: Every error-catching `cc:async-mediation` (e.g. `CatchGetAttributesError`) must be placed in an **unnamed vertical swimlane** directly below the processing component whose `cc:send-error` routes to it. This creates a clear visual column showing each component paired with its error handler. Use `orientation="VERTICAL"` with `name=""`. Place the processing component first, error handler second. Nest this vertical swimlane inside the parent sub-assembly swimlane. If a processing mediation and a transport both route errors to the same handler, include all three in the vertical swimlane
- Use swimlane collapsing to focus on relevant sections during development
- Add **notes** to individual components explaining important/complex processing, especially routing steps and "Execute When" conditions
- Do not have arrows that cross each other or other components — bend them around if necessary
- Add more HTTP-out or Workday-out transports if it simplifies the layout rather than routing all messages to one transport

### Diagram Maintenance (assembly-diagram.xml)

When adding or removing components in `assembly.xml`, the companion `assembly-diagram.xml` must also be updated:

- **visualProperties**: Every component needs a `<visualProperties x="..." y="...">` entry with coordinates that place it logically in the diagram
- **swimlanes**: New components must be added to the appropriate `<swimlanes>` element via `<elements href="assembly.xml#ComponentId"/>`
- **connections**: Route connections (`type="routesTo"` or `type="routesResponseTo"`) must be added or updated to reflect the new routing in `assembly.xml`
- **@mixed index shifts**: Some components (e.g. `send-error` within the assembly root) are referenced by positional XPath like `assembly.xml#//@beans/@mixed.1/@mixed.N/@mixed.3`. Inserting or removing an element at the assembly level shifts **all** subsequent `@mixed` indices by ±2 (one for the element, one for its adjacent whitespace text node). Recalculate all affected references when modifying the element order
- **Do NOT guess @mixed indices** — open the assembly in Workday Studio or use XML DOM parsing to verify the correct positional indices after structural changes
- **Swimlane index shifts**: Swimlanes are referenced by 0-based positional index (`#//@swimlanes.N` in child elements, `//@swimlanes.N` in the root swimlane's `elements` attribute). Inserting or removing a `<swimlanes>` element shifts all subsequent indices by ±1. **Always recalculate all swimlane index references** when adding or removing swimlanes. Getting this wrong can create circular references that break the entire diagram — Studio will render only orphaned swimlanes with the rest invisible
- **Do NOT guess swimlane indices** — count from the first `<swimlanes>` element (index 0) to verify

### Mandatory Diagram Update Workflow

**NEVER rebuild `assembly-diagram.xml` from scratch.** Always start from the existing diagram and make targeted, surgical edits. Rebuilding loses all hand-tuned coordinates, anchor positions, bendpoints, and swimlane nesting — producing a broken layout that is very difficult to recover.

Follow this exact sequence when modifying `assembly.xml` components:

1. **Edit `assembly.xml` first** — add, remove, or rename components and update all routing attributes
2. **Calculate `@mixed` indices** — run the PowerShell DOM parsing script (see `assembly-diagram-guide.md`) on the **modified** `assembly.xml` to get exact positional indices for every element. Never skip this step
3. **Read the existing `assembly-diagram.xml`** in full before making any edits — understand the current structure of visualProperties, connections, and swimlanes
4. **Make surgical edits only** — apply targeted string replacements for each change:
   - Rename: find-and-replace the old component ID in all `href` attributes (visualProperties, connections source/target, swimlanes elements)
   - Add: insert new `visualProperties`, `connections`, and `swimlanes` entries at the correct positions
   - Remove: delete the specific entries for removed components
   - Re-route: update only the affected `connections` entries (source, target, or type)
   - @mixed shifts: update every `@mixed.N` reference in connections using the verified index mapping from step 2
   - Swimlane index shifts: when adding or removing `<swimlanes>` elements, recalculate every `#//@swimlanes.N` and `//@swimlanes.N` reference — count from the first swimlane (index 0) after the edit
5. **Verify completeness** — for every `routes-to` and `routes-response-to` in `assembly.xml`, confirm a matching `connections` entry exists in the diagram. For every component with an `id`, confirm a `visualProperties` entry and a `swimlanes` membership exist

**Common mistakes to avoid:**
- Forgetting to update `connections` — the diagram will render but arrows will be missing or point to wrong targets
- Forgetting to update `swimlanes` — new components will float outside their logical group. **Every new component must be added to the swimlane that contains its logically related components** (e.g. a new routing target belongs in the same swimlane as the route that references it). Orphaned components outside swimlanes are a visual defect and indicate an incomplete diagram update
- Using stale `@mixed` indices from the old assembly — causes send-error arrows to connect to the wrong components
- Adding `visualProperties` without coordinates — components render at (0,0) and pile on top of each other
- **Using wrong swimlane indices after inserting a new swimlane** — inserting before the root swimlane shifts the root's index by +1; referencing the old root index from a parent swimlane creates a circular nesting that breaks the entire diagram (only the orphaned new swimlane renders, everything else disappears)
- **Updating `assembly.xml` without updating `assembly-diagram.xml`** — when adding any new component (mediation, transport, route destination, log step), always update the diagram in the same edit session: add `visualProperties`, add `connections`, and add the component to the correct `swimlane`. Never defer diagram updates to a later step
- **Using `@route.N` or `@splitter.N` indices from the old assembly** — inserting a new `cc:route` shifts all subsequent `@route.N` by +1 (independent of `@mixed` shifts). The same applies to `cc:splitter` and `@splitter.N`. Both typed indices AND `@mixed` indices must be recalculated simultaneously

## Error Handling

### Global Error Handler (Required)

Every integration must have a global error handler linked to a `PutIntegrationMessage` step with severity `CRITICAL`:

```
is.message.severity = 'CRITICAL'
```

### Mediation Error Handlers

Set error handlers on **all processing** asynchronous and synchronous mediations. The catch/error-handler mediation (the `send-error` target) should:

1. Extract the error using MVEL:
   ```
   props['p.error.message'] = util.cleanString(context.errorMessage)
   ```
2. Cloud-log the error with a **contextual message** describing which operation failed (e.g. "Error building SOAP request for document report", not generic "Error calling custom Report")
3. Increment the error counter: `props['p.error.count'] = props['p.error.count'] + 1`
4. **Stop** — catch mediations are **terminal handlers**. They must NOT have a `routes-to` attribute pointing to a shared `PutIntegrationMessage` or `PutErrorMessage` local-out. Routing multiple catch mediations to a single shared local-out creates a spider web of diagram connections that makes the assembly unreadable. Instead, rely on the **end-of-run summary pattern** (`IsError` / `PIMError`) to report errors to the Integration Event after processing completes

**Catch mediations must NOT have `cc:send-error`**: Mediations that ARE error handlers (e.g. `CatchGetAttributesError`, `CatchBuildSOAPError`) do **NOT** get a `cc:send-error` child. If the catch mediation itself fails, the global assembly-level `cc:send-error` catches it automatically. Adding `send-error` on catch mediations creates unwanted diagram arrows and is structurally incorrect.

**Anti-pattern — shared error reporting local-out**: Do NOT create a single `PutErrorMessage` local-out and route all catch mediations to it. This produces N connections converging on one component, creating an unreadable diagram. The correct pattern is for catch mediations to be terminal (extract, log, increment counter, stop) and for the end-of-run `IsError` check to write a summary `PutIntegrationMessage` with severity `ERROR`. Errors are visible in the cloud log with full context.

**Error handlers must be co-located with their source mediation.** When adding a `cc:send-error` to a mediation, the target error-handler mediation must be created in the **same sub-assembly / swimlane** as the mediation that throws the error, placed in an unnamed vertical swimlane directly below the source component. Never route `send-error` to an existing error handler in a different sub-assembly or swimlane — this creates cross-lane arrows in the diagram, produces misleading error messages (the handler's log text describes a different operation), and makes the flow harder to trace. Always create a dedicated error handler with a contextually appropriate log message. Each catch mediation is terminal and does not route to any downstream component.

The `Handle Downstream Errors` property controls scope:
- `false` — handles only errors within the mediation's own steps
- `true` — handles errors from any downstream mediations or transports

Use `cleanString` to prevent invalid XML characters from causing "invalid Rich Text internal syntax" errors in `PutIntegrationMessage`.

### Workday-Out Failure Messages

Use the `failure-message` property on Workday-Out transports to augment error messages:

```
An error occurred while attempting to retrieve contact details for the employee with employee id @{props['employee.id']}. Additional details:
```

The original message text will be appended automatically.

### Throwing Errors

- **MVEL Validations**: Configure with expressions that throw errors when evaluating to `false`. Customize the "Validation Message"
- **XML Validation**: Validate against XSD schema. Be careful with large messages. Use "Failure Message" and "Replace Message" properties
- **Manual**: `context.setError("Description of Error", 20001)`

### Avoid "All or Nothing"

A single bad transaction must not fail the entire integration. Report the error/warning for that transaction and continue processing. Design error handling so the final Integration Event status accurately reflects what occurred.

### Terminating Processing with setAbort

```
context.setAbort(true)
```

- Flow returns to the last `local-out` without `Propagate Abort = false`
- Once using `setAbort`, set `Propagate Abort = true` on **all** `local-out` transports except where you explicitly want to intercept an abort

## Mediation Context Properties

### Naming Conventions

Prefix properties with the integration name for scoping:

```
props['intxyz.company.name']
```

Standard prefixes:
- `ia.` — integration attributes: `props['ia.include.job.code']`
- `lp.` — launch parameters: `props['lp.paygroup.wid']`
- `p.` — processing/internal properties: `props['p.error.count']`

Property names must be **meaningful and unabbreviated**. Descriptive names reduce maintenance cost.

### Property Assignment Rules

Always use strongly typed properties:

```
// CORRECT — typed literals
props['pi.count'] = 0
props['pi.enabled'] = true
props['ia.full.extract'] = intsys.getAttributeAsBoolean('Full Extract')

// WRONG — string types
props['pi.count'] = '0'
props['pi.enabled'] = 'true'
```

- Use `null` instead of `''` (empty string) for empty values
- Do not store data in Java constructs, properties, or variables unnecessarily

### Default Values Pattern

```
props['ia.account.type'] = (intsys.getAttribute('Account type') == empty) ? 'Corporate' : intsys.getAttribute('Account type')
```

## Accessing Integration Attributes

The Workday-In transport creates the `intsys` MVEL helper automatically.

```
// Simple type
props['ia.account.id'] = intsys.getAttribute('Account ID')

// Boolean type
props['ia.include.federal.w4'] = intsys.getAttributeAsBoolean('Include Federal W-4')

// Reference type (single instance)
props['ia.profile.type'] = intsys.getAttributeReferenceData('Business Contact Profile Type', 'Communication_Usage_Type_ID')

// Integration Map
intsys.getMap('mapName').get('key')
```

In XSLT, declare the `is` namespace and call via XPath:

```xml
xmlns:is="java:com.workday.esb.intsys.xpath.ParsedIntegrationSystemFunctions"
is:getIntegrationAttributeValue('Entity Name')
```

## Message Merging

**Always use aggregators** for merging messages — never string concatenation or MVEL write approaches:

- Use `xml-content-collater` for merging XML messages
- Use `message-content-collater` for merging plain text messages
- Wrap the aggregator in a **sub-assembly** for flexibility: control collation and batching via properties exposed as sub-assembly parameters
- Call with `collate=true, batch=false` to add messages, then `collate=true, batch=true` on the last message

**Why**: Aggregators read each message once and write once, with minimal memory. String concatenation and MVEL-based writes cause exponential memory growth and can cause heap failures at scale (observed in production with 100+ file merges).

### Performance benchmarks (merging 100x two 100K-record files)

| File type | Approach | Time (s) | Notes |
|---|---|---|---|
| Text | Aggregator | **16** | Minimal memory |
| Text | Write with MVEL | 247 | Gradual excess memory build-up |
| Text | String concatenation | 182 | Gradual excess memory build-up |
| XML | Aggregator | **22** | Minimal memory |
| XML | Streaming copy | 350 | Acceptable but slower |
| XML | In-memory copy | 550 | Significant memory + GC pressure |
| XML | Write with MVEL | 270 | Very high memory vs aggregator |

### Performance benchmarks (merging 100x 10K-record files into 1M-record document)

| File type | Approach | Time (s) | Notes |
|---|---|---|---|
| Text | Aggregator | **9.7** | Minimal memory |
| Text | String concatenation | 133 | Acceptable for small merges |
| Text | Write with MVEL | 256 | Significant memory + GC activity |
| XML | Aggregator | **14** | Minimal memory |
| XML | In-memory copy | — | **Heap failure** |
| XML | Write with MVEL | — | **Heap failure** |

Source: [Workday Community — Merging and Aggregating Messages](https://community-content.workday.com/en-us/kits-and-tools/products/platform-and-product-extensions/integrations/merging-and-aggregating-messages.html)

## Data Initialization Service (DIS)

- DIS generates XML documents before Studio runs — **DIS runtime does not count against the 2-hour Studio limit**
- Use `doc-iterator` to process DIS partial files; specify document tags as comma-separated: `"Data - Partial,MyServiceName"`
- For large volumes, process files in parallel using the parallel processing pattern
- Use XSLT 3.0 streaming for transforming DIS output
- DIS files are retained for 60 days; max document size is 500 MB compressed
- Use `Retrieve Technical Files` and `Generate DIS Performance Summary` related actions for troubleshooting

## Byte Order Mark (BOM) Handling

- Most assembly processing assumes UTF-8 without BOM
- Java cannot automatically detect UTF-8 BOMs or produce UTF-8 files with BOMs
- Use the community `bomHandling` custom beans (RemoveBOM/AddBOM) for reliable BOM processing
- RemoveBOM: detects and strips BOM, transcodes to UTF-8; handles files with or without BOM
- AddBOM: prepends appropriate BOM bytes for the target encoding
- Both beans stream-process messages (supports up to 15 GB)

## Integration Attachment Service

- Attach files (XSLT, CSV, ZIP) to an integration system so administrators can update without redeploying Studio code
- File content is returned base64-encoded in `Get_Integration_Systems` response
- **Do NOT use `parts[0].xpath` or `parts[0].xstream`** to retrieve file contents (1 MB limit) — use streaming XSLT instead
- Use `base64-decode` component to convert encoded content, setting the correct MIME type
- For XSLT files: set the XSLT+ URL property to `mctx:vars/variableName`

### End-to-end Studio pattern

The typical flow to consume an attachment in Studio is:

1. **GetIntegrationSystems** component retrieves the integration system configuration, including base64-encoded attachment content
2. **Streaming XSLT** extracts the base64 string for the target service name (avoids the 1 MB `parts[]` limit)
3. **base64-decode** component converts the base64 text to the actual file content
4. Component that consumes the decoded file (XSLT+, splitter, etc.)

### Streaming XSLT to extract attachment content

Use this XSLT 3.0 stylesheet to extract the base64 content from the `Get_Integration_Systems` response. Pass the service name as a property (`props['service.name']`):

```xml
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xmlns:wd="urn:com.workday/bsvc"
    exclude-result-prefixes="xs"
    version="3.0">

    <xsl:param name="service.name"/>
    <xsl:mode streamable="yes" on-no-match="shallow-skip"/>
    <xsl:output omit-xml-declaration="yes" media-type="text/plain"/>

    <xsl:template match="wd:Integration_Service_Data">
        <xsl:value-of select="copy-of()
            [wd:Integration_Service_Reference/wd:ID[@wd:type='Integration_Service_Name']=$service.name]
            /wd:Integration_Attachment_Service_Data/wd:Attachment_Data/wd:File/text()"/>
    </xsl:template>
</xsl:stylesheet>
```

The output is the raw base64 string for the attachment matching `$service.name`.

### base64-decode component

- Set the **MIME type** correctly when decoding — this determines how downstream components interpret the content
- MIME type can be set dynamically with a property: `@{props['mime.type']}`
- Common MIME types: `text/xml` (XSLT), `text/csv` (CSV), `application/zip` (ZIP)

### mctx:vars — referencing decoded content from a variable

The `mctx:vars` protocol lets assembly components reference content stored in a mediation variable as though it were a file. The pattern:

1. Set the **base64-decode** output to a **variable** (e.g. `attachedXslt`)
2. In the consuming component's URL/file property, use `mctx:vars/attachedXslt`

This is most commonly used with the **XSLT+** component, where the `url` property is set to `mctx:vars/variableName` instead of a filename in `WSAR-INF/`. This causes the XSLT+ component to read the stylesheet content from the mediation variable rather than from the deployed project.

### File type examples

**XSLT attachment:**
- base64-decode with MIME type `text/xml`, output to variable (e.g. `attachedXslt`)
- XSLT+ component `url` property: `mctx:vars/attachedXslt`

**CSV / text attachment:**
- base64-decode with MIME type `text/csv` or `text/plain`
- Content is available on the message for downstream processing (splitter, XSLT, etc.)

**ZIP attachment:**
- base64-decode with MIME type `application/zip`
- Use a splitter with **unzip** strategy to iterate through files within the archive
- `util.currentFilename` returns the name of the current file in the zip during iteration

## Custom Components and Modules

- **Custom Components**: Community-built Studio components added to the palette. Import as projects, add to your collection. Current: Batch with Fallback, Messages
- **Custom Modules**: Copy/paste code templates that drop into your assembly. Configure via Window > Preferences > Workday > Assembly Editor > Modules. Available modules include blueprints (Inbound, Report REST Outbound, WS Outbound), Get Sequenced Value, Global Error Handler, Start with BP Retrieval, Start with File Retrieval, Store REST Data, WD WS Call with PagedGet

## Parent Process Integration

Report messages and documents to a packaged integration's event (e.g., CCW, PECI):

1. Create a `Business Process` launch parameter
2. Extract the WID: `props['p.parent.process.wid'] = lp.getReferenceData("Parent Process", "WID")`
3. Pass WID to `PutIntegrationMessage` via the `is.event.wid` parameter
4. Configure the BP to pass `Subject` (the parent event) as the launch parameter value at runtime

## MVEL Expression Standards

- Keep expressions small and concise — simple property assignment and computation only
- Use ternary `IF/THEN/ELSE` for simple conditionals
- Use `empty` literal to check for null, 0-length, whitespace, or boolean
- Break complex expressions into multiple simpler expressions
- When faced with heavily nested XPath or method invocations, consider XSLT, Custom Beans, or Static Methods
- **Do NOT** use `xpathF` or `parts[0].text` on large messages (1,000,000 char limit)
- **Do NOT** use `xpath` or `xpathB` in MVEL template `@if` conditions

## Local-Out Advanced Properties

The `local-out` Advanced tab settings control message and flow behavior when calling sub-assemblies:

| Property | Effect |
|---|---|
| **Clone Request = false** (default) | Message root is replaced with the sub-assembly's output. Required when the sub-assembly returns data (e.g. RaaS results, file metadata, loaded file content) |
| **Clone Request = true** | Message root is restored to what it was before the local-out call. Use when the sub-assembly has side-effects only (e.g. logging, progress updates) and you need to preserve the current message |
| **Propagate Abort = true** | If the sub-assembly calls `context.setAbort(true)`, the abort propagates back to the caller — stopping further execution |
| **Propagate Abort = false** | Abort from the sub-assembly is intercepted — execution continues in the caller after the local-out |
| **Store Message = none** | Default. No message is stored on the local-out transport |

**Common mistake**: Setting Clone Request = true on local-outs that call components returning data (reports, file loads, document lists) — the returned data is silently discarded and the pre-call message is restored, making it appear the call "did nothing".

## Thread Safety

Not all operations are safe to call from child/worker threads (ParallelSubRoutine, PagedGet parallel mode). General rules:

- **CloudLog** (the built-in `cc:cloud-log` step) is **NOT thread-safe** — do not call from parallel processing or aggregation endpoints
- **Store** steps are safe from child threads
- **Workday-Out** (SOAP) and **Workday-Out-REST** are safe from child threads
- **GetEventDocuments** and **BuildRetrievedFileMetadata** are **NOT safe** from child threads — query document metadata from the main thread before entering parallel processing
- When using the SSK framework specifically, set `inIsChildThreadContext = true` on any SSK component called from a child thread so that thread-safe logging (SSK143) is used instead of the non-thread-safe SSK142 CreateLogEntry. See `ssk-reference.instructions.md` for SSK-specific thread safety details

## Paging Decision Rules

- Use `PagedGet`/`PagedGetLocalPaging` for Workday web service operations that return paged results
- Use `is.paged.get.aggregate.*` only when full aggregation is required and result size is manageable
- Use `is.paged.get.process.endpoint` for per-page processing when datasets are large or page-level transformation is needed
- For external REST APIs, use `cc:http-out` in a loop and manage paging state (`page`, `offset`, `cursor`, `hasNext`) with typed props
- For external APIs that require a combined output, aggregate after retrieval rather than forcing one large in-memory message early
- Keep `Clone Request = false` on the `local-out` that calls `vm://wcc/PagedGet`, otherwise returned aggregated output can be discarded
- With `is.paged.get.process.endpoint`, do not assume automatic combined output; design explicit finalization/aggregation logic in the endpoint flow
- Leave `is.paged.get.store.requests = false` unless diagnostics are needed, because per-page request storage can add significant event payload overhead

### PagedGet Selection Matrix

| Need | Recommended Pattern | Why |
|---|---|---|
| Keep downstream flow unchanged with one combined payload | `vm://wcc/PagedGet` + `is.paged.get.aggregate.*` | Smallest retrofit for existing integrations that already expect a single XML message |
| Process very large datasets safely | `vm://wcc/PagedGet` + `is.paged.get.process.endpoint` | Per-page processing avoids building one large in-memory document |
| Single query for all WIDs, then per-WID retrieval | `vm://wcc/PagedGetLocalPaging` | Useful when local paging semantics are required by the operation design |

### PagedGet Minimal Safe Defaults

- Set `is.paged.get.application` and `is.paged.get.version` explicitly (avoid dynamic latest in production)
- Keep `is.paged.get.parallel = false` for initial implementation; enable only after thread-safety review
- Keep `is.paged.get.store.requests = false` for normal runs; enable only for diagnostics
- Keep `Clone Request = false` on the `local-out` that calls `vm://wcc/PagedGet`

### PagedGet Response Shape Warning

- Setting `is.paged.get.process.endpoint` disables aggregate output behavior from `is.paged.get.aggregate.*`
- If `is.paged.get.process.endpoint` is used, design explicit finalization so downstream components receive the expected message shape

### PagedGet Migration Pattern

- For existing integrations, prefer aggregate mode first to minimize change risk
- Move to `is.paged.get.process.endpoint` only when payload size, memory profile, or page-level logic requires it

## Error Handler MVEL Complexity

Keep MVEL in error handlers and error message parameters **as simple as possible**. Complex MVEL in error handlers (nested method calls, dynamic XPath, large string operations) can throw its own exception. If an error occurs inside an error handler, Studio throws a **"loop detected" error** that immediately kills the integration event. These errors are extremely difficult to troubleshoot because:
- The original error is masked
- The loop-detected error provides no context about what failed
- There is no recovery path

Use simple property reads and string concatenation (`#`) only. Extract complex values in the mediation before the error handler, not inside it.

### Error Context Properties

These properties are available inside `send-error` / error handler mediations:

| Property | Description |
|---|---|
| `context.errorMessage` | The error message text (may be null) |
| `context.getErrorMessage()` | Same as above but via method call |
| `context.errorComponentId` | Name of the mediation/component that raised the error |
| `context.errorCode` | Integer error code from the ESB (cast to String for logging) |
| `context.exception.message` | The underlying Java exception message |

Always clean error messages before writing to PutIntegrationMessage:
```
props['p.error.message'] = util.cleanString(context.errorMessage)
```

## Document Tags

Document tags control how files are routed between integration systems:

- **Deliverable**: Marks output files for pickup by Document Delivery services (SFTP, email, etc.). Set via the `is.document.deliverable` property on the Store step, or via a `Put_Integration_Event` call. In SSK integrations, use `inOutputIsDeliverable = true` on SSK106 instead
- **Retrieved**: Marks files as pre-processed input for a downstream Connector
- **Custom tags**: Use for filtering with `Retrieval Document Tag Match Strategy` (All or Any) and `Retrieval Document Tag(s)` integration attributes
- Do NOT add "Deliverable" as both a flag AND a custom document tag — this causes double-tagging issues

## XSLT in Assembly

- Always use the `xslt+` step for running XSLT
- Use XSLT 3.0 unless EIB/Document Transform compatibility is required
- Do not hardcode reference IDs or WIDs — use launch parameters, attributes, or maps
- For text output, prefer TextSchema, XML_to_CSV, or XTT steps

## XTT Map Error Handling

When XSLT uses XTT directives (`xtt:map`, `xtt:separator`, `xtt:quotes`), a `cc:xtt` step is required **after** the `cc:xslt-plus` step to process those directives. The `cc:xtt` step can capture map resolution messages via the `message-property` attribute.

### Pattern: XSLT+ with XTT Map Validation

Place `cc:xtt` immediately after `cc:xslt-plus` in the same mediation, then check for errors with a `cc:eval`:

```xml
<cc:async-mediation id="TransformOutput" routes-to="StoreOutputFile">
    <cc:steps>
        <cc:xslt-plus id="Transform" url="MyTransform.xsl"/>
        <cc:xtt id="Xtt" message-property="xtt.messages"/>
        <cc:eval id="CheckXttErrors">
            <cc:expression>if (props['xtt.messages'] != empty &amp;&amp; (props['xtt.messages'].hasError() || props['xtt.messages'].hasCritical())) { props['p.error.count'] = props['p.error.count'] + 1 }</cc:expression>
        </cc:eval>
    </cc:steps>
    <cc:send-error id="SendErrorTransform" routes-to="CatchTransformError"/>
</cc:async-mediation>
```

After the store step, add a conditional `PutIntegrationMessage` to report map errors to the integration event:

```xml
<cc:local-out id="PIMXttErrors" execute-when="props['xtt.messages'] != empty &amp;&amp; (props['xtt.messages'].hasError() || props['xtt.messages'].hasCritical())" endpoint="vm://wcc/PutIntegrationMessage">
    <cc:set name="is.message.severity" value="'ERROR'"/>
    <cc:set name="is.message.summary" value="'XTT map resolution errors detected. Unmapped values found in source data. Review the integration maps.'"/>
</cc:local-out>
```

This lean approach (inline check + conditional PIM) is preferred for single-file integrations. It replaces the heavier pattern of iterating individual ETVInfo messages with a custom Java bean, which is only justified for multi-file or high-volume integrations where per-record error detail is essential.

### ETVInfoCollection API

The `message-property` attribute on `cc:xtt` stores an `ETVInfoCollection` object with these methods:

| Method | Returns | Description |
|---|---|---|
| `hasError()` | boolean | True if any ERROR severity messages exist |
| `hasCritical()` | boolean | True if any CRITICAL severity messages exist |
| `hasWarning()` | boolean | True if any WARNING severity messages exist |
| `getSummary(info, numTargets)` | String | Summary text for a specific ETVInfo, showing up to N target WIDs |
| `getTargetWIDs(info)` | Collection | WIDs of records affected by a specific ETVInfo |

Individual message iteration (accessing each ETVInfo separately) requires a custom Java bean wrapping the generic `Iterator` for MVEL 1.3 compatibility. **Avoid this complexity unless per-message detail is required.**

### xtt:map Reference Structure

When using `xtt:map` in XSLT to look up integration map values, the reference element **must include both a WID and a typed Reference ID**:

```xml
<xtt:map name="My Map Name" default="UNMAPPED">
  <wd:ID wd:type="WID"><xsl:value-of select="WID_Field"/></wd:ID>
  <wd:ID wd:type="Reference_Type_ID"><xsl:value-of select="ID_Field"/></wd:ID>
</xtt:map>
```

Omitting the WID causes a `NullPointerException` in the `cc:xtt` step. Always include both ID types in the reference structure, matching the pattern used in Document Transform integrations.

Wrap `xtt:map` lookups in a guard condition when the source value may be empty:

```xml
<xsl:if test="normalize-space(ID_Field) != ''">
  <xtt:map name="My Map">...</xtt:map>
</xsl:if>
```

## Data Transformation Rules

**All data transformations must be done in XSLT, not in write steps or MVEL property chains.**

- **Do NOT use `cc:write` steps to construct or reshape XML/JSON output** — write steps are for simple static payloads (e.g. a short JSON body for a REST call with a few property substitutions). If the write step contains loops, conditionals, or structural transformation logic, move it to XSLT
- **Do NOT scatter XPath extractions across dozens of MVEL eval steps** to pull values into properties and then reassemble them in a write step or template. This pattern is fragile, hard to read, impossible to unit test, and creates maintenance nightmares
- **XSLT is always preferred** for mapping, filtering, restructuring, or reformatting data — it is declarative, testable in isolation, clearly visible in source control diffs, and handles edge cases (namespaces, whitespace, encoding) that MVEL/write steps silently get wrong
- **Acceptable uses of `cc:write`**: constructing a small static JSON or form-encoded body for an HTTP-out call (e.g. OAuth token request, simple API payload with 2–3 property substitutions). If the payload grows beyond a few lines or needs any conditional logic, use XSLT instead
- **Acceptable uses of XPath in MVEL**: reading a single value for routing decisions, error messages, or control flow (e.g. `props['p.worker.count'] = xpathF(...)` for a count check). Extracting more than 3–4 values from a message for transformation purposes is a sign that XSLT should be used instead

## Post-Edit Validation Checklist

**After every assembly.xml or assembly-diagram.xml change — whether editing, creating, or reviewing — run through this checklist before presenting the result to the user.**

### Assembly Validation

- [ ] Every `routes-to` and `routes-response-to` target exists as a component `id` in the assembly
- [ ] Every processing `cc:async-mediation` and `cc:sync-mediation` has a `cc:send-error` child (except catch/error-handler mediations)
- [ ] Every `cc:send-error` routes to an error-handler mediation in the **same sub-assembly / swimlane** — never cross lanes to reuse another flow's error handler
- [ ] A global error handler exists at the assembly level, linked to a `PutIntegrationMessage` step with severity `CRITICAL`
- [ ] No `cc:write` steps are performing data transformation (loops, conditionals, structural reshaping) — those belong in XSLT
- [ ] No scattered XPath-to-property extraction chains used for transformation — use XSLT instead
- [ ] No hardcoded reference IDs or WIDs — use launch parameters, integration attributes, or integration maps
- [ ] No private keys, PGP keys, keystores, truststores, or secrets stored in the project (`WSAR-INF/`, `ws/`, or any other folder). If a private key or certificate file is detected, **flag it as a security risk** and recommend the **Integration Attachment Service** pattern instead — attach the key/certificate to the integration system in-tenant so it can be rotated without redeployment and is never committed to source control
- [ ] Property names use correct prefixes (`ia.`, `lp.`, `p.`) and are meaningful/unabbreviated
- [ ] XSLT steps use `xslt+` (not legacy XSLT step) and target XSLT 3.0 unless EIB/DT compatibility is required
- [ ] `local-out` Clone Request setting matches intent — `false` when expecting return data, `true` for side-effect-only calls
- [ ] `Propagate Abort` is set correctly on all `local-out` transports when `setAbort` is in use
- [ ] No thread-unsafe operations (`cc:cloud-log`, `GetEventDocuments`) called from child/parallel threads
- [ ] No XML comments anywhere in assembly files — use component Description properties and notes instead

### Diagram Validation

- [ ] Every component with an `id` in `assembly.xml` has a `visualProperties` entry in `assembly-diagram.xml`
- [ ] Every component is assigned to a `swimlanes` element — no orphaned components floating outside swimlanes
- [ ] Error-handler mediations and their downstream `local-out` transports are in the **same swimlane** as the mediation whose `send-error` routes to them — never place error handlers in a different swimlane from their source
- [ ] Error-catching mediations are in **unnamed vertical swimlanes** (`orientation="VERTICAL"`, `name=""`) directly below the processing component they catch — not floating separately or grouped at the bottom of the assembly
- [ ] Every `routes-to` and `routes-response-to` in `assembly.xml` has a matching `connections` entry in the diagram
- [ ] All `@mixed` indices in `connections` href attributes match the actual positional indices in the current `assembly.xml` (not stale from a previous version)
- [ ] All `@route.N` and `@splitter.N` typed indices match the actual positional indices — inserting a new `cc:route` or `cc:splitter` shifts all subsequent typed indices by +1
- [ ] All `swimlanes` index references (`#//@swimlanes.N`, `//@swimlanes.N`) are correct — count from 0 after any insertion/removal
- [ ] No circular swimlane nesting — a swimlane must not reference itself or create a cycle through its parent chain
- [ ] `visualProperties` coordinates are sensible — no components at (0,0) piled on top of each other
- [ ] No XML comments in `assembly-diagram.xml` — causes EMF parser `getSelectionService()` null errors

### Completion Steps

After passing the checklist, follow the **After Every File Edit** steps in `copilot-instructions.md`.
