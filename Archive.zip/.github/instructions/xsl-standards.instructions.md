---
description: "Use when writing, reviewing, or debugging XSLT/XSL stylesheets for Workday integrations. Covers XSLT 2.0/3.0 coding standards, streaming patterns, performance rules, header comments, output formatting, ETV/XTT attributes, Document Transformation connector patterns, integration maps for code translation, and unit testing for EIB, Document Transform, and Studio transformations."
applyTo: "**/*.xsl"
---

# XSLT Standards for Workday Integrations

## Version Selection

- **Studio**: Use XSLT 3.0 with the **XSLT+ component** (not legacy XSLT). XSLT+ supports streaming, always uses file-backed managed data, and is the recommended step for all assemblies
- **EIB / Document Transform**: Use XSLT 2.0. EIB and Document Transform use Saxon 9.1.0.8 and do not support XSLT 3.0 features
- **XSLT 1.0 must not be used**
- Turn off the XSL Validator in Studio when developing XSLT 3.0 (spurious errors from unrecognized XSLT 3/XPath 3 features)

### Saxon Version by Assembly Version

| Assembly Version | Saxon Version |
|---|---|
| 19.0 and earlier | Saxon-B 9.1.0.8 |
| 20.0 to 2017.04 | EE 9.4 |
| 2017.05+ | EE 9.7.0.12 |

When upgrading assembly versions, rigorously test XSLTs — behavior changes between Saxon versions.

## Namespaces

- Define XML namespaces for the input document (e.g., `xmlns:wd="urn:com.workday.report/ReportName"`)
- Define a `this` namespace for local functions: `xmlns:this="urn:this-stylesheet"`
- Include an `out` namespace for text output: `xmlns:out="http://www.workday.com/integration/output"`
- For XSLT 3.0 maps: `xmlns:map="http://www.w3.org/2005/xpath-functions/map"`
- For integration mapping functions: `xmlns:is="java:com.workday.esb.intsys.xpath.ParsedIntegrationSystemFunctions"` and `xmlns:tv="java:com.workday.esb.intsys.TypedValue"`

## XSLT+ Component Parameter Types

The XSLT+ step automatically passes MediationContext properties as `xsl:param` when their Java types match:

| Java Type | XSLT Type |
|---|---|
| `java.lang.String` | `string` |
| `java.lang.Integer` | `integer` |
| `java.lang.Float` | `float` |
| `java.lang.Double` | `double` |
| `java.lang.Boolean` | `boolean` |
| `com.workday.esb.StringList` | `string` (newline-separated) |
| `org.w3c.dom.Node` | `item()` (use with care — DOM stored in memory) |

Properties with names not valid as XSLT parameters are skipped with a log warning.

## Program Header Comments

Every XSLT must include a file information header before the transformation entry point:

```xml
<!-- File Information
     Filename: XT-Sample.xsl
     Developed by: Developer Name
     Last update: 2026.04.11
     Last updated by: Developer Name

     Update Log:
     2026.04.11 AB Description of change
-->
```

Include a documentation block describing the XSLT implementation, data source type (report, API, COF), and processing approach. Include a scrubbed sample of input XML (no PII).

## Constants

Define constants before the main transformation entry point:

```xml
<xsl:variable name="NEWLINE"      select="'&#13;&#10;'"/>
<xsl:variable name="SEPARATOR"    select="','"/>
<xsl:variable name="BLANK"        select="'&#x20;'"/>
```

## Output Structure

- Begin processing with a generic match on the root element (`<xsl:template match="/">`)
- Call named templates for header records, data rows, and different record types
- When creating text output, wrap in XML using the `out` namespace to facilitate debugging:

```xml
<xsl:template name="Worker-Record">
    <out:worker>
        <!-- output fields here -->
    </out:worker>
</xsl:template>
```

## Data Types & Variables

### Use Decimals, Not Doubles

- Doubles (IEEE 64-bit) are subject to precision and rounding inaccuracies
- Use `xsd:decimal(node)` and validate with `castable as xsd:decimal`
- Beware: `fn:number(node)` returns a double

### Strongly Typed Variables

Create variables inline with `select` and `as` attributes:

```xml
<!-- CORRECT: inline, strongly typed -->
<xsl:variable name="isEnabled" select="xsd:boolean($property.enabled.param)" as="xsd:boolean"/>
<xsl:variable name="aDateValue" select="xsd:date($property.date.param)" as="xsd:date"/>

<!-- WRONG: content constructor creates text node, degrades performance -->
<xsl:variable name="isEnabled">
    <xsl:value-of select="$property.enabled.param"/>
</xsl:variable>
```

### Do NOT Use Loops in Variable Declarations

This creates a sequence of single-character text nodes causing performance degradation and memory pressure at high volumes:

```xml
<!-- WRONG -->
<xsl:variable name="pad">
    <xsl:for-each select="1 to $padLength">
        <xsl:value-of select="$chr"/>
    </xsl:for-each>
</xsl:variable>
```

## Performance Rules

- **Do NOT use `//` in selector statements** — forces evaluation of every node in the document. Use explicit paths
- **Do NOT use recursive template calls for padding** — use `string-join()` or `substring(concat(value, $padding), length)`:

```xml
<!-- Non-recursive padding function -->
<xsl:function name="this:pad-right" as="xs:string">
    <xsl:param name="value" as="xs:string"/>
    <xsl:param name="width" as="xs:integer"/>
    <xsl:param name="char" as="xs:string"/>
    <xsl:value-of select="substring(string-join(($value, for $i in 1 to $width return $char), ''), 1, $width)"/>
</xsl:function>
```

Or use `StringUtils.leftPad/rightPad` in a preceding MVEL eval step instead of XSLT padding.

- **Sort with correct data types**: `<xsl:sort select="xsd:date(wd:Start_Date)"/>`
- Prefer XSLT functions over templates for complex logic (returning sequences of atomic values, node restructuring)
- Do not leave unused variables, functions, or templates in transformations
- Do not hardcode reference IDs or WIDs — use launch parameters, attributes, or maps
- Avoid Java/Saxon extension functions in EIB and Document Transform XSLTs — they prevent external testing and are not portable
- **Assume non-streaming XSLT may use 10x the XML document's disk size in memory** — design with streaming for large documents

### Decimal Rounding Fix

`format-number()` has known precision issues with repeating decimals. Use this pattern:

```xml
<xsl:value-of select="format-number(round($value * 100) div 100, '##0.00')"/>
```

### Character Set Conversion

To change the output character encoding, set the MIME type on the XSLT step Output property:

```
text/plain; charset=ISO-8859-1
```

### Date Arithmetic

```xml
<!-- Add one day -->
<xsl:value-of select="($date) + 1 * xs:dayTimeDuration('P1D')"/>

<!-- Subtract 30 days -->
<xsl:value-of select="($date) - 30 * xs:dayTimeDuration('P1D')"/>
```

### Max/Min Date Values

Cast to `xs:date()` when using `min()`/`max()` to avoid sequence comparison errors:

```xml
<xsl:value-of select="max(for $d in wd:Dates/wd:Date return xs:date($d))"/>
```

### Regular Expressions

Common regex patterns for `replace()`, `matches()`, `tokenize()`:

```xml
<!-- Remove unprintable characters -->
<xsl:value-of select="replace($value, '[&#x00;-&#x1F;&#x7F;]', '')"/>

<!-- Rearrange date from YYYY-MM-DD to MM/DD/YYYY -->
<xsl:value-of select="replace($date, '(\d{4})-(\d{2})-(\d{2})', '$2/$3/$1')"/>

<!-- Match Unicode letters only -->
<xsl:value-of select="matches($value, '^[\p{L}]+$')"/>
```

## XSLT 3.0 Streaming Patterns

When using XSLT 3.0, leverage streaming for large documents. Only the current node is kept in memory.

### Mode Declarations

```xml
<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>
<xsl:mode streamable="no" name="in-memory"/>
```

- `shallow-skip` ignores unmatched nodes but applies templates to children
- Named `in-memory` mode for processing copied nodes

### Copy-Of Pattern

Use `copy-of()` to access multiple child nodes (streaming only allows one child reference):

```xml
<xsl:template match="peci:Compensation_Summary_in_Pay_Group_Frequency">
    <xsl:apply-templates select="copy-of()" mode="in-memory"/>
</xsl:template>

<xsl:template match="peci:Compensation_Summary_in_Pay_Group_Frequency" mode="in-memory">
    <!-- Can now access multiple children -->
    <Base_Pay><xsl:value-of select="peci:Total_Base_Pay"/></Base_Pay>
    <Currency><xsl:value-of select="peci:Currency"/></Currency>
</xsl:template>
```

Only copy the minimum necessary into memory.

### Accumulators

Use accumulators to store values when streaming forward (you cannot look back):

```xml
<xsl:accumulator name="emp.id" streamable="yes" as="xs:string" initial-value="''">
    <xsl:accumulator-rule match="peci:Employee_ID/text()" select="."/>
</xsl:accumulator>
```

- Use `/text()` in match to avoid breaking streaming rules
- Read values with `accumulator-before()` or `accumulator-after()`
- Accumulators support counting (`$value + 1`) and running totals

### Maps for Grouping

```xml
<xsl:accumulator name="comp.plan.map" as="map(xs:string,xs:integer)" initial-value="map{}" streamable="yes">
    <xsl:accumulator-rule match="peci:Compensation_Plan/text()">
        <xsl:variable name="current" select="if (map:contains($value, .)) then map:get($value, .) else 0"/>
        <xsl:sequence select="map:put($value, xs:string(.), $current + 1)"/>
    </xsl:accumulator-rule>
</xsl:accumulator>
```

## ETV and XTT — Element Transformation, Validation, and XML-to-Text

ETV (Element Transformation and Validation) and XTT (XML To Text) are **standard Workday features** available in Studio and Document Transformations. They are processed by dedicated assembly steps that run after your XSLT, transforming and validating the XML output using attributes you embed in your XSLT.

**Important**: ETV/XTT attributes are processed by the Workday runtime only. They will **not work in local testing tools** like Oxygen XML Editor. Test ETV/XTT output by deploying and running in a Workday tenant.

### Namespaces

```xml
xmlns:etv="urn:com.workday/etv"    <!-- ETV: validation + XML transformation -->
xmlns:xtt="urn:com.workday/xtt"    <!-- XTT: XML-to-text conversion (CSV, fixed-width, etc.) -->
```

XTT supports all ETV attributes plus text formatting. When using both steps together, namespace controls which step processes each attribute — `etv:` attributes are processed by the ETV step, `xtt:` attributes pass through ETV and are processed by XTT.

### When to Use ETV vs XTT

- **ETV only**: Output is XML — use for validation (required fields, maxLength, enumeration) and transformation (date/number formatting, integration maps)
- **XTT only**: Output is text (CSV, fixed-width, EDI) — XTT includes all ETV functionality plus text conversion
- **ETV + XTT together**: Use ETV inside a splitter/aggregator loop for per-record validation, then XTT after aggregation for text conversion and footer totals

### Key Advantage

Both ETV and XTT use **streaming** — they can process arbitrarily large documents with constant memory. This makes them safe to apply outside splitter/aggregator loops, unlike XSLT which should be applied to smaller chunks for large volumes.

### Attribute Processing Order

When multiple attributes are on the same element, they are applied in this order:

1. **Data extraction**: `attribute`, `launchParameter`, `sequencedValue`, `number`
2. **Integration Map**: `map` (with `direction` and `mapReferenceID`)
3. **Formatting**: `numberFormat`, `dateFormat`, `dateTimeFormat`
4. **Number addition**: `addNumber`
5. **Truncation**: `truncate` + `maxLength`
6. **Validation**: `required`, `minLength`, `maxLength`, `enumeration`

Only one of `attribute`, `launchParameter`, `sequencedValue`, or `number` should be on a single element.

### Validation Attributes

```xml
<!-- Required field -->
<SSN etv:required="true">
    <xsl:value-of select="wd:SSN"/>
</SSN>

<!-- Max length with truncation -->
<City etv:maxLength="30" etv:truncate="true">
    <xsl:value-of select="wd:Municipality"/>
</City>

<!-- Enumeration validation -->
<Status etv:enumeration="Active,Inactive,Terminated">
    <xsl:value-of select="wd:Status"/>
</Status>

<!-- Custom validation message (from XSLT logic) -->
<xsl:if test="not(matches($ssn, '^\d{3}-\d{2}-\d{4}$'))">
    <SSN etv:message="SSN format is invalid" etv:severity="error">
        <xsl:value-of select="$ssn"/>
    </SSN>
</xsl:if>
```

### Validation Message Control

```xml
<!-- Set target (employee name) and severity for all child validation messages -->
<Employee etv:target="{$EmpName}" etv:targetWID="{$EmpWID}" etv:severity="error">
    <!-- All validation failures within this element will reference the employee -->
    <First_Name etv:required="true"><xsl:value-of select="wd:First_Name"/></First_Name>
    <Last_Name etv:required="true"><xsl:value-of select="wd:Last_Name"/></Last_Name>
</Employee>
```

Severity values: `info`, `warning`, `error`, `critical`. Default is `error`.

### Reusable Classes

Define attribute groups once, apply to many elements:

```xml
<etv:class etv:name="decimal" etv:numberFormat="##,##.00"
    etv:decimalSeparator="," etv:groupingSeparator="."/>
<etv:class etv:name="date" etv:dateFormat="dd/MM/yyyy"/>
<etv:class etv:name="requiredDecimal" etv:class="decimal" etv:required="true"/>

<Salary etv:class="decimal"><xsl:value-of select="wd:Amount"/></Salary>
<Hire_Date etv:class="date"><xsl:value-of select="wd:Hire_Date"/></Hire_Date>
```

Classes inherit — `requiredDecimal` inherits all attributes from `decimal` and adds `required="true"`.

### Date and Number Formatting

```xml
<!-- Date formatting (Java patterns) -->
<Birth_Date etv:dateFormat="dd/MM/yyyy">1960-03-24</Birth_Date>
<!-- Output: 24/03/1960 -->

<!-- DateTime with timezone conversion -->
<Last_Update etv:dateTimeFormat="dd/MM/yyyy:HH:mm:ss" etv:timezone="EST">
    2010-11-18T02:57:22.019-08:00
</Last_Update>
<!-- Output: 18/11/2010:05:57:22 (adjusted from PST to EST) -->

<!-- Number formatting -->
<Salary etv:numberFormat="##,###.00">10000</Salary>
<!-- Output: 10,000.00 -->

<!-- European decimal/grouping separators -->
<Amount etv:numberFormat="##,###.00" etv:decimalSeparator="," etv:groupingSeparator=".">
    10000
</Amount>
<!-- Output: 10.000,00 -->

<!-- Implied decimal (scale) for fixed-width formats -->
<Amount etv:numberFormat="0000000000" etv:scale="2">12345.67</Amount>
<!-- Output: 0001234567 -->
```

### Integration System Access

ETV can pull values directly from integration attributes, launch parameters, maps, and sequence generators:

```xml
<!-- Integration attribute value -->
<Cost_Center etv:attribute="Cost Center"/>

<!-- Launch parameter value -->
<Company etv:launchParameter="Company"/>

<!-- Sequence generator -->
<Batch_Number etv:sequencedValue="Document Number"/>

<!-- Integration map (internal → external) -->
<Gender etv:map="Gender">
    <xsl:copy-of select="wd:Gender_Reference"/>
</Gender>

<!-- Integration map reverse (external → internal) -->
<Account_Type etv:direction="in" etv:map="Account Type">Checking</Account_Type>

<!-- Map with fallback to reference ID when map is empty -->
<Emp_Type etv:map="Employee Type" etv:mapReferenceID="Employee_Type_ID">
    <xsl:copy-of select="wd:Worker_Type_Reference"/>
</Emp_Type>
```

### Counting and Summing (for footers/trailers)

```xml
<Records>
    <xsl:for-each select="wd:Report_Entry">
        <Record etv:incrementNumber="recCount" etv:addNumber="totalAmt">
            <xsl:value-of select="wd:Amount"/>
        </Record>
    </xsl:for-each>
</Records>
<Footer>
    <Record_Count etv:number="recCount"/>     <!-- outputs: 150 -->
    <Total_Amount etv:number="totalAmt"/>      <!-- outputs: 45230.50 -->
</Footer>
```

Use `etv:setNumber` to reset a counter (e.g. for sub-totals per group). Use `etv:omit="true"` on elements that should be processed for counting but not included in output.

### Setting Mediation Properties from ETV/XTT

ETV/XTT can set mediation context properties during processing. Useful for passing computed values (e.g. record counts, flags) to downstream assembly steps in Studio integrations:

```xml
<!-- Set a string property -->
<FileType etv:setProperty="p.file.type">
    <xsl:value-of select="wd:File_Type"/>
</FileType>

<!-- Set a boolean property (from element content or attribute logic) -->
<HasErrors etv:setBoolean="p.has.errors">
    <xsl:value-of select="$errorCount > 0"/>
</HasErrors>
```

These properties are then accessible in MVEL via `props['p.file.type']` and `props['p.has.errors']`.

### XTT Text Output Formatting

#### CSV Output

```xml
<Document xtt:separator="&#xD;&#xA;" xtt:quotes="csv">
    <xsl:for-each select="wd:Report_Entry">
        <Row xtt:separator=",">
            <First_Name><xsl:value-of select="wd:First_Name"/></First_Name>
            <Last_Name><xsl:value-of select="wd:Last_Name"/></Last_Name>
            <Amount><xsl:value-of select="wd:Amount"/></Amount>
        </Row>
    </xsl:for-each>
</Document>
```

`xtt:quotes` values: `"csv"` (quote when value contains comma/newline/quote/leading-trailing spaces), `"always"`, `"never"`, `"pipe-delimited"`. Use `xtt:quoteWhenMatches` with a regex for custom delimiters.

#### Fixed-Width Output

```xml
<Row>
    <First_Name xtt:fixedLength="20"><xsl:value-of select="wd:First_Name"/></First_Name>
    <Last_Name xtt:fixedLength="30"><xsl:value-of select="wd:Last_Name"/></Last_Name>
    <Amount xtt:fixedLength="12" xtt:align="right" xtt:paddingCharacter="0">
        <xsl:value-of select="wd:Amount"/>
    </Amount>
</Row>
```

`xtt:align`: `"left"` (default) or `"right"`. `xtt:paddingCharacter` defaults to space.

#### Start/End Tags (for EDI and other formats)

```xml
<Segment xtt:startTag="ISA*" xtt:endTag="~&#xD;&#xA;">
    <!-- segment content -->
</Segment>
```

### Accessing ETV/XTT Messages in Assembly

Messages are stored in a mediation context property (configurable on the ETV/XTT step). Access them via:

```
// In MVEL — get message count
props['etv.messages'].size()

// Get messages as XML (for audit files or PutIntegrationMessage)
props['etv.messages'].toXML()

// Iterate messages
for (msg : props['etv.messages']) {
    msg.getSummary();
    msg.getSeverity();
    msg.getTarget();
    msg.getTargetWID();
}
```

The `xtt.messages` property name is similarly configurable on the XTT step.

### Truncation Reporting

Control how truncation is reported via `etv:reportTruncation`:

- `"none"` — truncate silently (default)
- `"attribute"` — adds `etv:truncated="true"` to the element (useful for audit file XSLTs)
- `"warning"` / `"error"` / `"info"` / `"critical"` — generates a validation message
- Combine: `"attribute,warning"` — both attribute and message

### Field Length Calculation

By default, `maxLength` counts characters. For multi-byte encodings where the target system counts bytes:

```xml
<Field etv:truncate="true" etv:fieldLengthCalculation="bytes:utf-8" etv:maxLength="6">
    Straße
</Field>
<!-- Output: Straß (ß = 2 bytes in UTF-8, so 6 bytes = 5 characters here) -->
```

## Document Transformation Connector

Document Transformation (DT) transforms the XML output of a Connector integration (e.g. PICOF, Core Connector, Benefits Connector) into the format required by a third-party system. It applies an XSLT transformation followed by ETV/XTT processing in a single step — no Studio project, no assembly.xml, no Java.

### When to Use Document Transformation

- The source data comes from a **Connector** integration (PICOF, PECI, Core Connector, Benefits Connector, etc.)
- The transformation is a single-step reshape: XML → CSV, fixed-width, EDI, or restructured XML
- Delivery is to a single endpoint (SFTP, HTTPS) via Integration Delivery Service
- No complex multi-step orchestration, conditional branching, or API callouts are needed

**Do NOT use DT when** you need multiple API calls, complex error handling with retries, conditional routing, or multi-step processing — use Studio instead.

### How DT Works

1. A Connector integration generates Workday XML output and tags it (default tag: `Deliverable`)
2. The DT integration system is added as a **subprocess step** on the Connector's business process
3. DT picks up documents matching its **Input Document Tags** attribute
4. DT applies the **attached XSLT** (via Integration Attachment Service)
5. The XSLT output is processed through **ETV then XTT** (both are built-in — no separate assembly steps needed)
6. The result is tagged with **Output Document Tags** and delivered by the Integration Delivery Service

### Setup Steps

1. **Create Integration System** → template = `Document Transformation`
2. **Configure Integration Attributes**:
   - **Input Document Tags** — tags to search for (default: `Deliverable`)
   - **Output Document Tags** — tags to apply to transformed output
   - **Output Encoding** — e.g. `UTF-8`, `ISO-8859-1`. Overrides encoding in XSLT
   - **Multiple Input Documents** — process all documents matching tags (for multi-file scenarios)
   - **Carry Forward Input Tags** — adds input tags to output document alongside Output tags
   - **Audit Validation Messages** — attach complete ETV/XTT validation messages per event
   - **Integration Document Retention** — days to keep output files
3. **Create ISU** with Get and Put access to Integration Event security domain
4. **Set up Sequence Generators** (if using `etv:sequencedValue`)
5. **Attach XSLT** via `Configure Integration Attachment Service`
6. **Configure Integration Maps** for all code translation tables
7. **Add as subprocess** on the source Connector's business process

### Code Translation: Integration Maps, NOT XSLT Choose Blocks

**For code translation (mapping Workday values to external system codes), always use Integration Maps with `etv:map`/`xtt:map` — never hardcode translations in XSLT `<xsl:choose>` blocks.**

Integration Maps are:
- **Maintained in the tenant UI** — business users or configurators can update mappings without touching code
- **Transportable** — maps move between environments via Integration System configuration
- **Auditable** — map changes are tracked in Workday audit
- **Reusable** — the same map can be referenced from multiple elements

XSLT choose blocks for code translation are:
- Hardcoded in the stylesheet — every change requires a code deploy
- Error-prone at scale — 37+ lookup tables with hundreds of entries become unmaintainable
- Not portable — mappings are buried in code instead of configuration

#### Pattern: Simple Value Translation

```xml
<!-- In XSLT: emit the Workday reference, let ETV/XTT apply the map -->
<Gender xtt:map="Gender">
    <xsl:copy-of select="wd:Gender_Reference"/>
</Gender>
```

The integration map "Gender" is configured on the integration system with entries like:
- `Female` → `2`, `Male` → `1`, `Not Declared` → `0`

ETV/XTT resolves the Reference ID from the Workday XML, looks it up in the map, and replaces the element content with the external value.

#### Pattern: Text-to-Text Translation

```xml
<!-- When the source is a text value, not a Reference ID -->
<Marital_Status xtt:map="Marital Status">
    <xsl:value-of select="wd:Marital_Status"/>
</Marital_Status>
```

#### Pattern: Map with Fallback

```xml
<!-- If map is empty (not configured), use Reference ID as fallback -->
<Contract_Type xtt:map="Contract Type" xtt:mapReferenceID="Contract_Type_ID">
    <xsl:copy-of select="wd:Contract_Type_Reference"/>
</Contract_Type>

<!-- If map is empty, use a literal default -->
<Country xtt:map="Country" xtt:mapAlternateValue="ES">
    <xsl:copy-of select="wd:Country_Reference"/>
</Country>
```

#### Pattern: Empty Input Handling

```xml
<!-- Apply map even when input is empty (maps to a default) -->
<Status xtt:map="Status" xtt:mapAppliedOnEmptyInput="true">
    <xsl:value-of select="wd:Status"/>
</Status>
```

#### Pattern: Reverse Map (External → Internal)

```xml
<!-- Convert external code to Workday value (for inbound scenarios) -->
<Account_Type etv:direction="in" etv:map="AccountType">Checking</Account_Type>
<!-- Output: C -->
```

#### Pattern: Map with Severity Control

Unmapped values generate validation messages. Control severity with `etv:severity`/`xtt:severity`:

```xml
<!-- WARNING for unmapped gender (non-blocking) -->
<Gender xtt:map="Gender" xtt:severity="warning">
    <xsl:copy-of select="wd:Gender_Reference"/>
</Gender>

<!-- ERROR for unmapped contract type (blocking) -->
<Contract_Type xtt:map="Contract Type" xtt:severity="error">
    <xsl:copy-of select="wd:Contract_Type_Reference"/>
</Contract_Type>
```

### DT Integration Attribute Access in XSLT

To access integration attribute values inside XSLT logic (not just for ETV/XTT processing), use `xsl:param` with the prefix `attr_` and underscores for spaces:

```xml
<xsl:param name="attr_Root_Organization"/>
<xsl:param name="attr_Full_Extract"/>
```

Multi-valued attributes are returned as a comma-separated list.

### DT-Specific XSLT Patterns

#### Semicolon-Delimited CSV (e.g. ADP SmartPay)

```xml
<Employee xtt:endTag="&#xD;&#xA;">
    <Data xtt:separator=";">
        <Client_Code><xsl:value-of select="$clientCode"/></Client_Code>
        <Employee_Number><xsl:value-of select="wd:Employee_ID"/></Employee_Number>
        <First_Name><xsl:value-of select="wd:First_Name"/></First_Name>
        <Gender xtt:map="Gender">
            <xsl:copy-of select="wd:Gender_Reference"/>
        </Gender>
        <!-- Empty positional fields still need the element for correct semicolons -->
        <Reserved1/>
        <Reserved2/>
    </Data>
</Employee>
```

**Critical for positional CSV**: every column must have an element, even if empty. A missing element means a missing separator, which shifts all subsequent columns.

#### Multiple Record Types Per Worker

When a file format requires multiple CSV rows per worker (e.g. main record + one row per dependent + one row per cost centre):

```xml
<xsl:for-each select="wd:Worker">
    <!-- Main record -->
    <MainRecord xtt:endTag="&#xD;&#xA;">
        <Data xtt:separator=";">
            <!-- primary key + personal data fields -->
        </Data>
    </MainRecord>
    <!-- Dependent records (one per family member) -->
    <xsl:for-each select="wd:Dependents/wd:Dependent">
        <DependentRecord xtt:endTag="&#xD;&#xA;">
            <Data xtt:separator=";">
                <!-- same primary key + dependent data fields -->
            </Data>
        </DependentRecord>
    </xsl:for-each>
</xsl:for-each>
```

### DT Limitations

- XSLT 2.0 only (Saxon 9.1.0.8) — no XSLT 3.0 features, no streaming, no accumulators
- No multi-step processing — one XSLT, one ETV/XTT pass
- No conditional routing or error-recovery branching
- No API callouts or HTTP requests
- No Java custom beans
- Cannot split into multiple output files (unless using Multi Document Transformation)
- ETV/XTT attributes are processed by Workday runtime only — they do not execute in local testing tools

### Multi Document Transformation (MDT)

When a single DT is almost sufficient but you need:
- **Multiple input documents** (e.g. merge data from two connectors)
- **Multiple output files** (e.g. separate files per company or per record type)
- **Dynamic file naming** (e.g. include date or company code in filename)

Use MDT (set **Multiple Input Documents** attribute to true). Each input document is processed independently by the same XSLT, and **Carry Forward Input Tags** can differentiate outputs.

## Cloud Log Message Functions (SSK Only)

The following cloud log message functions are **only available in SSK-based Studio integrations** that include the SSK112 XSLT function library. They are NOT available in standard (non-SSK) Studio projects. In standard Studios, use `<xsl:message>` with plain text or use ETV/XTT attributes for cloud log output.

### ssk:createMessage (XSLT function) — SSK only

Requires these namespace declarations:
```xml
xmlns:tube="java:com.capeclear.mediation.impl.cc.MediationTube"
xmlns:ctx="java:com.capeclear.mediation.MediationContext"
xmlns:ssk="urn:com.workday.custom.ssk.common"
```

And this static parameter + include at the bottom of the stylesheet:
```xml
<xsl:param name="sskXsltLibMessage" as="xs:string"
    select="ctx:getProperty(tube:getCurrentMediationContext(),'sskXsltLibMessage')" static="yes"/>

<!-- At bottom of stylesheet, after all templates -->
<xsl:include _href="{$sskXsltLibMessage}"/>
```

**All arguments must be string type or the XSLT will fail.**

| Permutation | Syntax |
|---|---|
| Summary only | `<xsl:message select="ssk:createMessage('Summary')"/>` |
| Level + Summary | `<xsl:message select="ssk:createMessage('Level', 'Summary')"/>` |
| Level + Summary + Details | `<xsl:message select="ssk:createMessage('Level', 'Summary', 'Details')"/>` |
| + Reference ID | `<xsl:message select="ssk:createMessage('Level', 'Summary', 'Details', 'RefID')"/>` |
| All 8 fields | `<xsl:message select="ssk:createMessage('Level', 'Summary', 'Details', 'RefID', 'RecordNum', 'LocalIn', 'ErrorCode', 'SupportData')"/>` |

For the 8-argument form, pass empty string `''` for unused fields.

### cl:createMessage (Java function) — SSK only

Identical arguments, uses `xmlns:cl="com.workday.custom.myInt.ssk112"` namespace. Replace `ssk:` with `cl:` and omit the `<xsl:include>`. The `cl` namespace must match your project's Java package (e.g. `com.workday.custom.int1234.ssk112`).

### ETV/XTT Messages (available in all Studios)

ETV/XTT validation attributes are a standard Workday Studio feature (not SSK-specific). Use them on output elements for cloud log messages:
```xml
<xsl:element name="Field" xtt:required="true" xtt:severity="error"
    xtt:message="Validation failed" xtt:targetID="{$refID}">
    <xsl:value-of select="$value"/>
</xsl:element>
```

Requires `xmlns:xtt="urn:com.workday/xtt"` namespace. Only 3 fields available: message, severity, targetID.

### Cloud Log Fields Reference

The cloud log supports these fields. The ETV/XTT attributes work in all Studios. The `ssk:createMessage` argument positions apply only to SSK projects:

| Field | ssk:createMessage arg (SSK only) | ETV/XTT attribute (all Studios) |
|---|---|---|
| Level (debug/info/warn/error/fatal) | 1st | `xtt:severity` |
| Message Summary | 2nd | `xtt:message` |
| Message Details | 3rd | — |
| Reference ID | 4th | `xtt:targetID` |
| Record Number | 5th | — |
| Local In | 6th | — |
| Error Code | 7th | — |
| Support Data | 8th | — |

## Function & Template Documentation

Include comments for all functions and templates:

```xml
<!--
    Function: this:toLower
    Description: Converts alpha characters to lower case
    Parameters:
        stringValue: Value to be converted to lower case
-->
<xsl:function name="this:toLower">
    <xsl:param name="stringValue" as="xs:string"/>
    <!-- implementation -->
</xsl:function>
```

## Identity Transform (Selective Node Override)

XSLT 3.0 provides a clean identity transform pattern using `on-no-match="shallow-copy"`:

```xml
<xsl:mode streamable="yes" on-no-match="shallow-copy"/>

<!-- Override only the specific nodes you need to change -->
<xsl:template match="wd:Status">
    <wd:Status>
        <xsl:value-of select="if (. = 'A') then 'Active' else 'Inactive'"/>
    </wd:Status>
</xsl:template>
```

All unmatched nodes pass through unchanged. This replaces the verbose XSLT 2.0 identity template pattern.

## Normalize Namespaces

When XML from different sources uses varying namespace prefixes, normalize to the standard Workday namespace:

```xml
<xsl:template match="*">
    <xsl:element name="wd:{local-name()}" namespace="urn:com.workday/bsvc">
        <xsl:apply-templates select="@* | node()"/>
    </xsl:element>
</xsl:template>
```

## Working Days Calculation

XSLT function to count weekdays between two dates (excludes Saturday and Sunday):

```xml
<xsl:function name="this:working-days" as="xs:integer">
    <xsl:param name="start" as="xs:date"/>
    <xsl:param name="end" as="xs:date"/>
    <xsl:variable name="days" select="days-from-duration($end - $start)"/>
    <xsl:variable name="weeks" select="$days idiv 7"/>
    <xsl:variable name="remainder" select="$days mod 7"/>
    <xsl:value-of select="$weeks * 5 + min(($remainder, 5))"/>
</xsl:function>
```

## Integration Mapping Functions in XSLT

Declare the integration system namespace and typed-value namespace:

```xml
xmlns:is="java:com.workday.esb.intsys.xpath.ParsedIntegrationSystemFunctions"
xmlns:tv="java:com.workday.esb.intsys.TypedValue"
```

**Text-to-text map lookup:**

```xml
<xsl:value-of select="is:getIntegrationMapValue('MapName', string($externalValue))"/>
```

**Reverse map lookup (text-to-business object):**

```xml
<xsl:variable name="lookup" select="is:integrationMapReverseLookup('MapName', string($externalValue))"/>
<xsl:value-of select="tv:getReferenceData($lookup[1], 'Reference_ID_Type')"/>
```

**Reusable wrapper functions** — drop these into your XSLT for cleaner map lookups with fallback to the original value:

```xml
<!-- Text-to-text map lookup with fallback -->
<xsl:function name="this:ApplyMap">
    <xsl:param name="mapName"/>
    <xsl:param name="externalValue"/>
    <xsl:variable name="internalValue"
        select="is:getIntegrationMapValue(string($mapName), string($externalValue))"/>
    <xsl:value-of select="if ($internalValue) then $internalValue else $externalValue"/>
</xsl:function>

<!-- Text-to-business-object reverse lookup with fallback -->
<xsl:function name="this:ApplyReverseMap">
    <xsl:param name="mapName"/>
    <xsl:param name="externalValue"/>
    <xsl:param name="referenceId"/>
    <xsl:variable name="lookup"
        select="is:integrationMapReverseLookup(string($mapName), string($externalValue))"/>
    <xsl:value-of select="if (count($lookup) != 0)
        then tv:getReferenceData($lookup[1], string($referenceId))
        else $externalValue"/>
</xsl:function>
```

> These Java extension functions work in Studio but NOT in EIB or Document Transform. For EIB/DT, use MDT's pure-XSLT helper functions or pass map data as stylesheet parameters.

## JSON in Studio

Three methods are available for working with JSON in Studio, in order of preference:

### 1. Studio JSON Components (preferred)

**JSON-to-XML** — converts JSON input to XML. Properties control the output element naming:

| Property | Description | Default |
|---|---|---|
| Root Element Name | Root element for the generated XML | `root` |
| Nested Array Name | Element name for unnamed JSON arrays | `entry` |
| Nested Object Name | Element name for unnamed JSON objects | `data` |

Example — JSON input:
```json
[{"firstName": "Joe", "lastName": "Evans"}, {"firstName": "John", "lastName": "Smith"}]
```
Produces:
```xml
<root>
  <entry><data><firstName>Joe</firstName><lastName>Evans</lastName></data></entry>
  <entry><data><firstName>John</firstName><lastName>Smith</lastName></data></entry>
</root>
```

**XML-to-JSON** — converts XML to JSON. From 2021R1:

- **Optional Schema mode**: set "Ignore Schema" to convert without an XSD. Types are inferred (re-occurring sibling elements → arrays, parseable numbers → numbers, parseable booleans → booleans, all others → strings)
- **Attribute support**: set "Ignore Attributes" to false to include XML attributes in the JSON output. Each element becomes an object with a `value` field and attribute fields

### 2. XSLT 3.0 functions

XSLT 3.0 provides `json-to-xml()` and `xml-to-json()` functions:

```xml
<!-- Convert JSON to XML for processing -->
<xsl:variable name="json-as-xml" select="json-to-xml(unparsed-text('input.json'))"/>

<!-- Convert XML back to JSON -->
<xsl:value-of select="xml-to-json($map-element)"/>
```

The `json-to-xml()` output uses elements named `map`, `array`, `string`, `number`, `boolean`, `null` with optional `key` attributes. Use standard XSLT processing to reshape the intermediate XML as needed.

### 3. MVEL (small messages only)

For small JSON messages, use MVEL with `org.json.JSONObject`:

```
props['json.msg'] = new org.json.JSONObject(message.rootPartAsText)
message.setRootPartAsText(org.json.XML.toString(props['json.msg'], 'root'), 'text/xml')
```

**Warning**: `message.rootPartAsText` loads the entire message into memory. Do not use on large messages — use Studio components or XSLT 3.0 instead.

## Multi Document Transformation (MDT)

MDT is a deployed Studio integration that processes multiple input/output documents using only XSLT — no custom Studio code. Consider MDT when:

- You need multiple input sources or multiple output files
- EIB or Document Transform is _almost_ sufficient but needs dynamic file naming or complex logging
- You want to avoid writing Studio assembly code

MDT should NOT be used when web service calls, conditional data retrieval, or non-XSLT logic is required.

## EBCDIC Conversions

XSLT functions for EBCDIC signed-number conversion:

```xml
<!-- EBCDIC to decimal: '1234N' → -12345 -->
<xsl:function name="this:EBCDIC-to-decimal">
    <xsl:param name="in-value"/>
    <xsl:variable name="positive" select="('{','A','B','C','D','E','F','G','H','I')"/>
    <xsl:variable name="negative" select="('}','J','K','L','M','N','O','P','Q','R')"/>
    <xsl:variable name="last" select="substring($in-value, string-length($in-value))"/>
    <xsl:variable name="rest" select="substring($in-value, 1, string-length($in-value) - 1)"/>
    <xsl:choose>
        <xsl:when test="index-of($positive, $last)">
            <xsl:value-of select="number(concat($rest, index-of($positive, $last) - 1))"/>
        </xsl:when>
        <xsl:when test="index-of($negative, $last)">
            <xsl:value-of select="number(concat($rest, index-of($negative, $last) - 1)) * -1"/>
        </xsl:when>
        <xsl:otherwise><xsl:value-of select="number($in-value)"/></xsl:otherwise>
    </xsl:choose>
</xsl:function>
```

## Unit Testing

- Create AUnit tests for complex XSLT logic in Studio integrations
- Use scrubbed/anonymized test data — **NEVER** use customer data
- Run all existing unit tests after any XSLT change to catch regressions
- Debug XSLTs in OxygenXML: avoid `mctx:` URL protocol and Java extension functions (pass values as stylesheet parameters instead)

## EIB-Specific Guidance

- Use calculated fields and report writer as first choice for data translation, filtering, and logic
- XSLT should primarily be a data formatting tool
- Always test XSLT outside of Workday before uploading to EIB configuration
- Avoid Java or Saxon extension functions — they cannot be used in Document Transform or EIB

## Integration Attributes in XSLT

Declare the `is` namespace and call from XPath:

```xml
xmlns:is="java:com.workday.esb.intsys.xpath.ParsedIntegrationSystemFunctions"

<xsl:value-of select="is:getIntegrationAttributeValue('Entity Name')"/>
```

Prefer passing values as stylesheet parameters over using Java extension functions.

## Unit Testing

- Create AUnit tests for complex transformation logic in Studio integrations
- Use scrubbed data for test documents — NEVER use customer data
- Run all unit tests after any XSLT change to verify no regressions

## Studio XSLT Validation Workarounds

Studio's validator may incorrectly flag XSLT 3.0 / XPath 3.0 features. Workarounds:
1. **Per-XSLT**: Project Properties → Validation → Add Exclude Group for specific files/directories
2. **Per-project**: Project Properties → XSLT Validation → XPath Problems → set "Incorrect XPath syntax" to Ignore
3. **Per-workspace**: Preferences → XML → XSL → Validation → set "Incorrect XPath syntax" to Ignore

Prefer per-integration settings so other developers inherit them automatically.

## Additional Rules

- Always use the `xslt+` step for running XSLT in Studio
- For text output, prefer TextSchema, XML_to_CSV, or XTT steps. If using XSLT, handle delimiter escaping and use efficient padding functions
- When using `mctx://` protocol, avoid unnecessary re-parsing. Consider composite documents over mctx for ease of development

## Local XSLT Testing with Saxon

Always use the **Workday Studio Saxon EE 9.7** JARs for local testing — not Oxygen or any other Saxon version — as this matches the exact engine Workday Studio uses at runtime.

### Saxon command
```powershell
java -cp "$env:LOCALAPPDATA\WD\studio\plugins\com.workday.sh.sa.saxonee.core_2024.39.75\lib\saxonee-9.7.jar;$env:LOCALAPPDATA\WD\studio\plugins\com.workday.sh.sa.saxonee.core_2024.39.75\lib\wdsaxonee.jar" net.sf.saxon.Transform "-s:test\input.xml" "-xsl:test\MyTransform_test.xsl" "-o:test\output.xml"
```

### Stubbing `intsys:` extension functions
`intsys:` functions (e.g. `getIntegrationMapValue`) require a live Workday tenant and cannot run locally. To test locally, create a `_test.xsl` copy of the production XSL with two changes:

1. Replace the Java namespace binding with a dummy URI:
```xml
<!-- Before -->
xmlns:intsys="java:com.workday.esb.intsys.xpath.ParsedIntegrationSystemFunctions"
<!-- After -->
xmlns:intsys="urn:stub"
```

2. Replace every `intsys:` call with a suitable passthrough:
```xml
<!-- Before -->
<xsl:value-of select="intsys:getIntegrationMapValue($mapName, string($internalValue))"/>
<!-- After — passthrough, map lookups will return empty for local test -->
<xsl:value-of select="string($internalValue)"/>
```

Always `grep` for `intsys:` in the file before stubbing to ensure all calls are replaced.

### PII in test data
- Never commit real worker XML to Git — always use scrubbed/anonymised test data
- Add a `.gitignore` to the `test/` folder with `*.xml` to prevent accidental commits of test data files
