---
description: "Use when discussing Workday Studio integration lifecycle including deployment, ISU configuration, launching, monitoring, troubleshooting, connections, Cloud Explorer, process monitor, and consolidated reports. Covers the full path from project creation through to production monitoring."
---

# Studio Integration Lifecycle

This reference covers the operational lifecycle of a Workday Studio integration — from project creation through deployment, configuration, launch, and monitoring.

## Lifecycle Overview

```
Create Project → Build Assembly → Deploy to Workday → Configure ISU → Launch → Monitor
```

Each stage has specific requirements. When advising users on any of these stages, reference the appropriate section below.

## 1. Project Creation

### Assembly Project Setup

1. In Studio: **File > New > Workday Assembly Project**
2. Project names must not contain spaces
3. Select **Workday Runtime** as target runtime
4. Choose configuration: Assembly, Assembly (with Java support), or Custom
5. Specify a Collection name (defaults to project name)

### Collections

- Collections package and deploy multiple projects together
- A project always belongs to at least 1 collection and can belong to multiple
- All projects in a collection **must** have the same assembly version
- Manage via **Workday > Manage Collections** in Studio

### Assembly Version

- Default version for new integrations: **2025.21**
- When creating a new integration, ask the user which version to target if not specified
- The version in `<cc:assembly id="WorkdayAssembly" version="...">` should match the Workday release

## 2. Connections

### Adding Connections

Studio connections are managed at: **Windows > Preferences > Workday > Connections**

| Field | Description |
|-------|-------------|
| Name | Unique connection name (Studio provides Sandbox/Production defaults) |
| URL | Workday environment URL |
| Group | Optional grouping |
| Auth | Basic Auth (username/password) or OAuth 2.0 |

- All connection names must be unique
- Studio does **not** save username/password across sessions
- Use **Test Connection** to verify before deploying
- OAuth 2.0 requires a registered API client; users enrolled in MFA must use OAuth

### Connection Groups

Organize connections into groups for management. Groups can be filtered out of the Cloud Explorer and Deploy pages.

### Import/Export

Connections can be exported to and imported from XML files for sharing across environments.

## 3. Deployment

### Prerequisites

- Assembly project must be complete and free of validation errors
- Security: **Integration Build** and **Integration Configure** domains required

### Deploying

1. Right-click assembly project in Project Explorer
2. Select **Deploy to Workday**
3. Choose target Workday environment and collection
4. Click **Finish**

### What Gets Deployed

Studio deploys a **CLAR** (CLoud ARchive) to the Workday Cloud Repository containing:
- All artifacts: `assembly.xml`, XSLT files, Text Schema files
- Compiled Java code and third-party Java libraries
- CLARs are stored encrypted — **never** store passwords or secrets directly in assemblies

### Redeployment

- Deploying an integration does not affect its Workday configuration (ISU, scheduling, notifications)
- You can redeploy freely without reconfiguring the integration system in Workday
- The Cloud Repository only stores the latest version per collection

### Stale Compiled Classes

Studio can deploy **stale `.class` files** even when the Problems view shows zero errors and deployment reports success. The runtime then fails with `Unresolved compilation problems` or `BeanInstantiationException` because the deployed `.class` file contains embedded Eclipse error stubs from a previous failed compile.

**Always run Project > Clean before deploying** if:
- You recently added/removed Java source files or dependencies
- You switched assembly versions or updated the Workday Runtime target
- The integration fails at launch with `Unresolved compilation problems` despite no visible errors in Studio

A successful deploy does **not** guarantee the compiled bytecode is current — Eclipse may package outdated build output without recompiling.

### Deployment Errors

| Error | Resolution |
|-------|------------|
| Permission to deploy denied | User needs Modify permissions in Integration Build domain |
| Deploy denied (delivery/retrieval service) | Needs Put permission in Business Process Administration, Manage: Business Process Definitions, or iLoad Web Services |
| SOAP fault: validation error | Verify SOAP request contains valid elements — reimport WSDLs if needed |

## 4. Integration System Configuration

### Integration System User (ISU)

Every Studio integration requires an ISU for authentication and web service calls.

**To assign an ISU:**
1. In Cloud Explorer, expand the cloud server and collection
2. Right-click the integration
3. Select **Assign Integration System User**
4. Select an ISU from the list

### Security Groups

Studio requires membership in at least one of these security groups:

| Group | Purpose |
|-------|---------|
| Deploy | Deploy integrations to the Cloud Repository |
| Launch | Launch integrations from Studio |
| Business Process | Launch integrations as part of business processes |

### Additional Security

- **Integration Event** domain — required for launching and monitoring
- **Integration Security** domain — required for ISU assignment
- Configure appropriate security groups following your client's security model
- See naming conventions for ISU, ISSG, ISSS, SBSG naming patterns

## 5. Launching

### From Studio

1. In Cloud Explorer, expand cloud server and collection
2. Right-click integration → **Launch Integration** → **Launch**
3. Process Monitor tab shows status

### Launch Configurations

Create reusable launch configs via **Run > Run Configurations**:

| Option | Description |
|--------|-------------|
| Launch In | Target Workday environment |
| Collection | Collection containing the integration |
| Project | Specific project |
| Workday-In | Entry transport name |
| Launch Parameters | Runtime parameters for the integration |

### Launch URLs

- Copy launch URLs for REST-based triggering: right-click integration → **Copy Launch URL**
- These URLs can be used by third-party REST clients with basic authentication

### Launch Methods in Workday

Integrations can be launched via:
- Manual launch from Studio or Workday
- Scheduled as an automatic event
- Triggered as part of a business process
- Invoked remotely via Workday Web Service

## 6. Monitoring & Troubleshooting

### Process Monitor

The Process Monitor view displays integration execution status. Key features:

| Action | Description |
|--------|-------------|
| Refresh | Refresh the view manually or enable auto-refresh |
| View Log File | Display log output for a process |
| View Request Message | See the request message that triggered the integration |
| View Consolidated Report | Open performance/flow analysis |
| Cancel Process | Stop a running integration |
| Copy Process ID | Copy the integration event ID |

### Log File Types

From 2020R2 onwards, log files are no longer automatically attached to integration events. Use the **Retrieve Log Files** button on the integration event to download them.

| Log file | Format | Contents |
|---|---|---|
| **Request Log** | XML | The `Launch_Integration` web service request that triggered the event |
| **Server Log** | Text | Runtime messages from the Studio engine and `Log` components. Contains Saxon/JScape version info, Java stack traces for transport errors, XSLT/XPath errors, and custom component exceptions. Also captures `System.out` and `System.err` from custom Java code |
| **Consolidated Report** | XML | Structured execution data: timing, components called, error details, profiling |
| **Profile Log** | CSV | Component-level timing and memory statistics (same data as the profiling-log section in the consolidated report) |

### Consolidated Report XML Structure

The consolidated report XML contains these key sections:

| Section | Content |
|---|---|
| `job-integration` | Who launched, start/end time, duration in milliseconds |
| `profiling-log` | CSV of all components with time and memory stats |
| `assembly-integration/log` | Ordered list of every component called, including internal Studio processes |

**Component source path format** — When a component is inside a parent container (e.g. async-mediation), the source path follows the pattern `container.request.index.component`:

```xml
<!-- "Write" step, first component inside WriteWorkerRequest mediation -->
<event type="STEP" source="WriteWorkerRequest.request.0.Write"
       application-name="Logging_Example" event-type="COMPLETED"
       start-time="2020-08-03T13:33:24.788Z" duration-ms="0"
       component="WriteStep"/>
```

**Sub-assembly calls** — the `application-name` changes to the sub-assembly name:

```xml
<!-- Parent assembly calling sub-assembly -->
<event type="TRANSPORT" source="StoreFile" application-name="Logging_Example"
       event-type="COMPLETED" duration-ms="543"
       endpoint="vm://Logging_Example_Shared/StoreFile"/>

<!-- Inside the sub-assembly -->
<event type="TRANSPORT" source="Logging_Example_Shared.local-in.StoreFile"
       application-name="Logging_Example_Shared" event-type="COMPLETED"/>
```

**Internal Studio components** — have `application-name="wcc"` (e.g. PagedGet, GetIntegrationSystems).

**Error detection** — when a component fails, `event-type` is `ERROR_RAISED` and a `failure-message` node contains the error detail.

### Consolidated Report Viewer

The Consolidated Report Viewer provides detailed analysis of integration execution:

- **Timing**: Duration of each step
- **Memory usage**: Memory consumption per step
- **Call counts**: Number of invocations per step
- **Web service calls**: Summary of all Workday API calls
- **Error highlighting**: Integration errors flagged in context

#### Key Consolidated Report Features

| Feature | Purpose |
|---------|---------|
| Events Log | Chronological log of integration events |
| Profile Log | Performance profiling (time zone: PST) |
| Replay | Replay assembly execution in the Assembly Editor |
| Link with Editor | Click report nodes to highlight corresponding assembly elements |
| Annotate | Overlay report annotations on the assembly diagram |
| View in Workday | Open integration event details in the Workday UI |
| Save As | Save consolidated report to workspace for offline analysis |

### Integration Event Statuses

| Status | Meaning |
|--------|---------|
| Completed | All processing succeeded |
| Completed with Warnings | Processing succeeded but warnings were reported |
| Completed with Errors | Processing completed but errors occurred — **developer must investigate** |
| Failed | Integration could not execute (launch failure) |

- Workday terminates integrations that exceed **2 hours** execution time
- It is the developer's responsibility to handle "Completed with errors" appropriately

### Common Connection Errors

| Error | Resolution |
|-------|------------|
| Credentials failed | Check username/password; tenant names are case-sensitive |
| Tenant not available | Verify tenant URL in browser: `https://host/tenant/ccx/cc-cloud-repo/collections` |
| IP address failed | Your IP is not authorized — contact System Administrator |
| Access to My Reports denied | ISU lacks permission for the report — contact System Administrator |
| Permission to launch denied | Need Put permission in Integration Event, Integration Build, or Integration Debug |

### HTTP Transport Debugging

When diagnosing HTTP(S) communication issues between Studio and a remote server:

**Preferred approaches (in order):**

1. **Studio debugger** — set breakpoints before and after the HTTP-out transport. Inspect the message body, headers (`message.getHeader()`), and attachments in the Assembly Debug view. Use conditional breakpoints when the transport is called in a loop
2. **Zip and attach** — zip messages and attach them to the integration event for post-run inspection
3. **Logging web proxy** (Charles Proxy, Fiddler) — reveals the exact bytes on the wire. Only option that shows the precise HTTP request/response

**How HTTP requests are constructed from the mediation message:**

- Request body ← current message root part
- Request headers ← message headers (set via `set-headers` or `message.setHeader()`)
- Multipart attachments ← non-root message parts and their headers

The HTTP response is mapped back the same way: response body → message root part, response headers → message headers.

**Avoid** writing HTTP content to the server log in production — heavy performance overhead and server log truncation can lose data.

### Troubleshooting Workflow

1. Check the **Process Monitor** for the integration event status
2. Open the **Consolidated Report** for step-by-step execution analysis
3. Use **View Log File** for detailed error messages
4. Use **Link with Editor** to correlate errors to specific assembly components
5. Check **View Request Message** to verify the triggering message was correct
6. For connection issues, test the connection from **Windows > Preferences > Workday > Connections**

### Common Runtime Errors

**Stale message headers causing WWS failures:**

Headers from external HTTP calls (e.g. `content-encoding: gzip`) persist on the mediation message. When a subsequent Workday web service call (e.g. `PutIntegrationMessage`) is invoked, these stale headers are forwarded automatically, causing errors such as:

```
Workday Out transport encountered problem sending to endpoint...
java.io.IOException: Incomplete output stream
```

**Fix:** Clear headers before calling Workday web services:
- MVEL: `message.removeAllHeaders()`
- Or use `set-headers` to explicitly unset problematic headers

**Unexpected runtime error during build:**

Usually caused by the **Build Automatically** flag being unchecked (Project > Build menu), meaning code changes are not compiled into the CLAR at deployment time. Fix: enable Build Automatically and run **Project > Clean** to clear cached build artefacts.

## 7. DIS vs RaaS Decision Guide

When an integration needs data from a custom report, choose between DIS (Data Initialization Service) and RaaS (Reports-as-a-Service):

| Criterion | Use DIS | Use RaaS |
|---|---|---|
| Data volume | Large master data sets | Targeted/filtered data |
| Runtime counting | DIS runs before Studio — does NOT count against 2-hour limit | RaaS runs during Studio — counts against 2-hour limit |
| Prompts driven by Studio logic | Not supported (prompts wired to LPs/attributes at config time) | Required — prompts can be built dynamically from API results or computed values |
| Multiple report calls | Inefficient (DIS runs once per launch) | Can call multiple reports with different prompts in the same event |
| Prompt values from LP | Supported — wire LPs to DIS prompts in config | Supported — build HashMap in MVEL |

**Rule of thumb**: Use DIS for large, predictable data pulls. Use RaaS when prompt values must be calculated at runtime.

## 8. Report Service Configuration Best Practice

- **Do NOT** configure the Report Reference for the Alias in the Studio clar file
- Leave it blank, deploy, then configure the reports to the aliases in the tenant using the **Configure Integration Reports** related action
- This makes migrations between tenants cleaner — the report WID differs between impl and production, and leaving it blank in the clar avoids hardcoding tenant-specific values
- Multiple report aliases can be set up on a single report-service (no need for multiple services)

## 9. Document Retention

- Retention period uses ISO 8601 duration format: `'P30D'` = 30 days, `'P7D'` = 7 days
- Set via the `Document Retention in Day` integration attribute on the Workday-In. In SSK integrations, this can also be overridden per-file via the `inDocumentRetentionPeriod` parameter on SSK106 GenerateOutput
- Log files and output files can have different retention periods
