# Integration Operations Reference

Covers the day-to-day operational tasks for managing integrations in the Workday tenant: launching, scheduling, monitoring events, notifications, relaunch/redeliver, mass actions, and troubleshooting stuck integrations.

---

## 1. Launching Integrations

### Prerequisites

- Security: **Integration Event** domain in the Integration functional area.

### Steps (Condensed)

1. Access the **Launch / Schedule Integration** task.
   - You cannot select an integration system with critical errors.
2. (Optional) Select the **Organisation** for manual launches.
3. (Optional) Specify a **Request Name** (Workday uses this as the Integration Name).
4. Specify required **launch parameter** values on the Integration Criteria tab.
5. Select the **Run Frequency** (Run Now, Run on Schedule, Monthly Recurrence, etc.).

### Organisation and Integration System Context

| Field | Behaviour |
|-------|-----------|
| Owning Organisation | Displays when you associate the integration with an organisation. Select the organisation or its subordinates when you are a member or have an organisational role. |
| Organisation By Type | Displays when the integration has no associated organisation. Select any organisation you are a member of or have a role in. |
| Integration System Context | Limits access based on organisation or academic unit. Does not override pre-existing security prerequisites. |

> **Note:** For scheduled integrations, Workday ignores the Organisation field value and bases the organisation on the Integration Process Event.

### Launch Parameters

To configure a launch parameter based on a report or calculated field, specify a Value Type of **Determine Value at Runtime**.

### Priority and Scheduling Best Practices

- When multiple integrations share the same scheduled run time, Workday prioritises them based on the priority configuration on the **Edit Tenant Setup – Integrations** task.
- To avoid bottlenecks and performance issues, use start times **beyond the beginning of the hour**.

---

## 2. Scheduling

### Schedule Ownership

When you schedule an integration, **you own the schedule**. The schedule runs under the permissions of the person who created it.

### Scheduling Around Weekly Service Updates

See [Section: Integration Schedules and Weekly Service Updates](#integration-schedules-and-weekly-service-updates) below for detailed behaviour.

### Example: Schedule for Last Day of Each Calendar Quarter

| Field | Value |
|-------|-------|
| Integration | (Your connector, e.g. Quarterly Accounting Journal Results) |
| Organisation | Leave blank |
| Run Frequency | Monthly Recurrence |
| Months | March, June, September, December |
| Day(s) of the Month | Last Day of the Month |
| Start Time | Outside business hours (e.g. 11:55 PM PST) |
| Start Date | Last day of the current quarter |
| End Date | 1 year from end of this quarter |

> **Time zone note:** If you have opted in to the time zones feature and do not use an ISU, Workday uses the user's local time zone.

---

## 3. Cancelling an In-Progress Integration

### Prerequisites

- Security: **Integration Event**, **Integration Build**, or **Integration Debug** domains.

### Supported Integration Types

You can cancel these integration types while in progress:

- Core Connector: Global Worker
- Core Connector: Worker
- Integrations using Data Initialisation Service (DIS)
- Inbound EIBs (except on the Data Load step)
- Kenexa Foundation Data
- Outbound EIBs
- WPN – ACH IAT Payment (Enhanced Performance)
- Consolidated Business Forms Printing
- DocuSign
- EIB Generate Spreadsheet
- Workday E-Signature

### Steps

1. Access the **Integration Events** or **Process Monitor** report and find the integration event.
2. From related actions: **Background Process > Abort**.
3. Confirm cancellation. Integrations that finish quickly can invalidate your cancellation request.

### Result

Workday:
- Changes the background process status to **Aborted**.
- Changes associated business process events to **Failed**.
- Attaches an integration message explaining that the current user aborted the integration (audit trail).

---

## 4. Relaunching

### Prerequisites

- Security: **Integration Event**, **Integration Build**, or **Integration Debug** domains.

### How It Works

- Workday sets the launch parameters and Organisation automatically from the previous integration event.
- Run Frequency is set to **Run Now**.
- Available regardless of event status (Completed, Failed, Processing).
- You cannot change launch parameters of subsequent integration BP steps.

### Conditions That Prevent Relaunch

| Condition | Detail |
|-----------|--------|
| Event age | More than 30 days old |
| Deleted system | The associated integration system was deleted |
| Critical errors | The integration system has critical exceptions |
| No security | You lack permissions to launch the integration system |
| Not launchable | The integration cannot be run using Launch/Schedule Integration task |
| Already relaunched | A user previously relaunched the integration or it is a relaunch event itself |

### Steps

1. Access **Integration Events** or **Process Monitor**.
2. Related actions: **Integration Event > Relaunch Integration Event**.
3. Confirm or modify Request Name, Organisation, and Integration Criteria.

---

## 5. Redelivering Documents

### When to Use

- The integration ran successfully but document delivery failed.
- You need to redeliver the document for any reason.

### Behaviour

- Uses the same transport settings as the current document delivery configuration (cannot override).
- Workday appends a **subordinate process** (for EIBs) or **subsequent process** (for Integration Process Events).
- Does **not** update the event status.
- Does **not** restart any subsequent business process steps.
- Available regardless of event status (Failed, Processing, etc.).

### Conditions That Prevent Redelivery

- The event is more than 30 days old.
- The files to redeliver no longer exist.
- The EIB configuration or document delivery configuration was deleted.
- The EIB configuration or document delivery configuration has critical exceptions.
- You lack security permissions to redeliver.

### Steps

1. Access **View Integration Events** and find the event.
2. Related actions: **Integration Event > Redeliver Document**.

---

## 6. Mass Actions on Integration Events

### Overview

Use the **Mass Action on Integration Events** report to relaunch, redeliver, or abort multiple integration events in bulk.

### Conditions for Each Action

| Action | Conditions |
|--------|-----------|
| **Relaunch** | Integration system has no error messages; current user can launch/schedule; not previously relaunched or a relaunch event itself |
| **Redeliver** | Event is less than 30 days old; system/delivery config exists without critical exceptions; security permissions present; file exists; delivered fewer than 5 times |
| **Abort** | Event is currently processing; integration type supports cancellation |

### Force Failure

- Available only after the integration has been running for **at least 2 hours**.
- **Only partially fails** the integration process — not the whole process.
- Marks the integration as failed but does **not** stop any jobs currently running in the runtime.

### Gradual Retrigger Behaviour

When you relaunch or redeliver in bulk, Workday does **not** launch all integrations simultaneously. It gradually retriggers integration events in the background.

### Auditing Mass Actions

Use the **View Mass Actions on Integration Events** report to filter by when a relaunch or redelivery was made. The report shows:
- Events redelivered, waiting to redeliver, and events Workday could not redeliver.
- Events relaunched, waiting for relaunch, and events Workday could not relaunch.

---

## 7. Viewing Integration Events

### Prerequisites

- Security: **Integration Event** domain.

### Integration Events Report

Filter by:
- Integration System
- By Person (who launched)
- Status
- Sent After / Sent Before dates

### View Background Request Tabs

| Tab | Contents |
|-----|----------|
| **Integration Details** | Parent business process event, integration system, initiator, initiation time. Links to View Consolidated Report and Logs / View Performance Logs. |
| **Process Info** | Technical Details area with Process IDs for each child process (used by Workday Support for troubleshooting). |
| **Output Files** | Output and audit files generated by the event. |
| **Messages** | Message details generated during the integration event. |
| **Child Processes** | Details about each child process in the event. |

### Consolidated Report and Logs

The "View Consolidated Report and Logs" link is **not available** when:
- The consolidated report has expired.
- The consolidated report is larger than 10 MB.
- The consolidated report does not exist.
- You deleted the integration.

### Verify Status

Use when an integration event status has been **processing for hours or days**:

1. Related actions on the integration event: **Integration Event > Verify Status**.
2. Workday refreshes the status:

| Scenario | Result |
|----------|--------|
| Event actually failed | Status changes to **Failed** with a message. Also fails events in progress for more than **7 days**. |
| Event still in progress, queued, or temporarily suspended during service update | Message displayed; status unchanged. |
| Workday cannot locate the integration | Message displayed; status unchanged. |
| Verification feature not running | Message displayed; status unchanged. |

### Tenanted ISU Account: Verify Status

Workday provides a built-in ISU account called **Verify Status** that verifies integration event statuses in the background at regular intervals. ISUs have inherent permissions to the Integration Process security domain.

> **Tip:** Enable the **Do Not Allow UI Sessions** option on the Workday account associated with the ISU to prevent it from signing in through the interface.

---

## 8. Auditing Integration Events

### Prerequisites

- Security: **Integration Build** domain.

### What You Can Audit

Outbound integrations — view the transmission data for troubleshooting and general reporting.

### Two Output Formats

| Format | Description |
|--------|-------------|
| Original transmission format | XML, CSV, or fixed-width flat files |
| Readable HTML version | Tabular format for functional users |

### Availability and Retention

- Audit files become available after the integration extracts and transforms data.
- Files are automatically deleted at the end of the configured **retention period**.
- Anyone with security permission to view integration event data can view audit files.

### Steps

1. Access **Integration Events** and find the event.
2. Select the event link to open **View Background Process**.
3. Select the **Output Files** tab.
4. Open the original transmission file and/or the readable HTML version.

---

## 9. Retrieving Technical Files

### Prerequisites

Security in the Integration functional area:
- **Integration Build**
- **Integration Event**

### File Types

| Type | Description |
|------|-------------|
| **Event Document Files** | Data for any documents available to the integration event. Displayed in the Messages tab. |
| **Other Technical Files** | Documents belonging to the reference ID of the parent integration event. Sorted in a zip folder by document tag and sent to **My Tasks**. |
| **Static Schema Files** | Versioned static schema files for DIS. Displayed in the Messages tab. |

### Steps

1. Access the **Integration Events** report and select an event.
2. Related actions: **Integration Event > Retrieve Technical Files**.
3. Select the file type to retrieve.

---

## 10. Integration Notifications

### Prerequisites

- Security: **Integration Build** domain.

### Trigger Types

| Trigger | Description |
|---------|-------------|
| **Trigger on Launch** | Fires when the integration launches. |
| **Trigger on Status** | Fires on one or more selected statuses (see below). |

**Valid statuses for notification triggers:**

- Aborted
- Completed
- Completed With Errors
- Completed With Warnings
- Failed
- Not Run due to Exceptions on Future Process
- Processing

**Invalid statuses (do not select):**

- Initiated
- Purged
- Queued
- Skipped
- Throttled

### Service Update Window Behaviour

When you configure a notification to trigger on launch for an outbound EIB and schedule the integration during the weekly service update window, Workday sends the notification **after** the service update completes.

### Conditions and Rules

Select a rule from the list or configure a new rule. Example: notify the integration administrator when an event fails, launches, or terminates.

### Repeat On

Select a related instance. Workday generates separate notifications for each instance of that field.

Example: Select "Launch Parameters" — Workday generates one notification per launch parameter.

### Recipients

| Type | Description |
|------|-------------|
| **By Person** | Sends to the worker who launches the integration. |
| **Groups** | Active user-based security group that receives the notification in Workday. |
| **Email Addresses** | External email addresses (outside Workday). |

### Message Content

Configure **Subject** and **Body** using a combination of:
- **Text** — static text
- **External Field** — a report field or calculated field

Workday automatically includes a link to the integration event in the notification.

**Example subject configuration:**

| Element | Value |
|---------|-------|
| Text | "Event" |
| External Field | Integration Event |
| Text | "Was Launched." |

### Output Documents Attachment

Available for:
- Payroll Effective Change Interface (PECI)
- Payroll Interface Connector (PICOF)
- Worker Effective Change Interface (WECI)

Users running the integration require **View** access to applicable security domains:
- Reports: Pay Calculation Results for Pay Group (Results) – CAN
- Reports: Pay Calculation Results for Pay Group (Results) – FRA
- Reports: Pay Calculation Results for Pay Group (Results) – UK
- Reports: Pay Calculation Results for Pay Group (Results) – USA

### Preview

Click **Preview** to send a sample notification. The sample contains **field names, not values**. Workday sends this using the routing rule for general notifications configured in the Alerts section on **Edit Tenant Setup – Notifications**.

---

## 11. Deleting Integrations and EIBs

### Prerequisites

| Integration Type | Required Security |
|------------------|-------------------|
| Connector or Studio | Integration Build domain + the integration-specific domain (e.g. Integrations: Cash Management) |
| EIB | Integrations: EIBs domain |

### Steps

1. Access the **View Integration System** report.
2. Related actions: **Integration System > Delete**.
3. Select the **Confirm Delete** check box.

### Result

Workday deletes any **scheduled future processes** for that integration system.

---

## 12. Integration Message Components and Error Handling

### Message Severity Levels

| Severity | Example | Processing Behaviour | Event Status |
|----------|---------|---------------------|--------------|
| **INFO** | "Initiated process." | Processing continues. | Completed |
| **WARNING** | "Value 123-456-78910 is too long for Phone Number and is truncated." | Processing continues. | Completed with warnings |
| **ERROR** | "Errors during data load. See report for details." | Processing continues unless maximum allowable errors reached. | Completed with errors |
| **CRITICAL** | "Unable to complete integration processing." | Processing stops. | Failed |

### Message Components

| Component | Description |
|-----------|-------------|
| **Context** | Identifies the source of the problem (e.g. worker name, integration map). |
| **Condition** | Describes the error condition (e.g. invalid data, empty map values). |
| **Requirement** | Specifies valid values or conditions that must be met. |
| **Response** | Provides a suggested resolution. |

### Field Truncation

Workday truncates fields when the endpoint field size is smaller than the corresponding Workday field. If no other errors are found, Workday reports a **warning**, continues processing, and transmits the data.

### Inbound vs Outbound Error Processing

| Type | Behaviour |
|------|-----------|
| **Inbound** | Processes the entire batch. On error: generates message, skips the failed transaction, continues processing remaining transactions. Transactions without errors execute successfully. |
| **Outbound** | On error: does not transmit any data, but fully processes the file to produce a comprehensive error report. |

### Message Limits

- Maximum **500 error messages** before processing stops.
- Maximum **500 warnings** (at 500, Workday issues a final warning).

---

## 13. Integration Event Statuses

| Status | Description |
|--------|-------------|
| **Aborted** | An integration administrator stopped the integration event. |
| **Completed** | Background process completed with no warning or error messages. |
| **Completed with errors** | Completed with one or more error messages but no critical messages. Indicates a troubleshootable issue. |
| **Completed with warnings** | Completed with one or more warning messages but no critical or error messages. |
| **Failed** | Nonrecoverable critical error prevented completion. For Workday-delivered integrations, may indicate a product defect or service issue. |
| **Not Run due to Exceptions on Future Process** | Could not run because the integration has critical exceptions (e.g. EIB or schedule owner has insufficient security). |
| **Processing** | The background process is currently running. |

---

## Integration Schedules and Weekly Service Updates

Workday enters service update mode **30 minutes before** the Weekly Service Update. Integration behaviour depends on timing:

| Scenario | Impact |
|----------|--------|
| Starts and completes before tenant enters service update mode | No impact. |
| Starts before service update mode but does not complete before the update begins | Workday restarts the integration after the update completes (with exceptions — see below). |
| Scheduled to start after tenant enters service update mode | Does not start at the scheduled time; starts after the update completes. |

### Integrations That Are NOT Restarted After Update

If the integration encounters one of these conditions after the service update completes, Workday does not restart it:
- Error: "Your job has been Terminated automatically by Workday as it couldn't finish by the start of our maintenance window."
- 529 error code.
- Schedule run frequency was set to **Run Once in the Future**.
- Uses one of these templates: ADP PayForce, Daily Digest, DocuSign, EBICS Configuration and Transmission, ESignature, Google Spreadsheet Export, Professional Profile Resume Parsing, WPN – AMEX Remittance v2 (any region).

### Best Practices — Schedule Outside the Update Window When:

- An inbound integration updates data in Workday (may attempt to reload data on restart).
- The integration uses dynamic date fields relying on a specific execution day.
- The integration creates a file expected at a certain time by an external process.
- The integration updates or sends data outside Workday (may resend on restart).

### API Behaviour During the Update

- New inbound API calls **fail** during the service update.
- In-process inbound API requests **fail** when the update begins.
- HTTP response codes: **503 Service Unavailable** or **500 Internal Server Error**.

| Request Type | HTTP Code | Response Body |
|--------------|-----------|---------------|
| SOAP | 500 | "Service unavailable" |
| RaaS | 500 (relabelled to 503 in body) | "503: Service unavailable" |

### Recommended Mitigations

- Implement caching.
- Rerun API calls after the service update completes.
- Configure an **exponential back-off retry** mechanism.
