# Integration Security Reference

Covers certificate management (X.509 and PGP), encryption and signing for integration transport protocols, WS-Security XML signatures, domain security for web services, and supported cryptographic algorithms.

> **Cross-references — the following topics are covered elsewhere:**
>
> - SFTP vendor validation table and basic SFTP troubleshooting → `integration-services-reference.md`
> - OAuth 2.0 bearer token authentication for API access → `integration-services-reference.md`
> - SOAP headers, endpoint URL format, username@tenant auth → `workday-web-services-reference.md`
> - ISU setup, security groups for Studio, deployment → `studio-lifecycle.instructions.md`
> - Launching, scheduling, event monitoring → `integration-operations-reference.md`
> - ISSG/SBSG/UBSG naming conventions → `naming-conventions.instructions.md`

---

## 1. Domain Security for Web Service Operations

Every web service operation is secured by a domain security policy. Integration System Users (ISUs) must belong to security groups that grant Get or Put access to the relevant domains.

- **Get access** → grants View access to reports and tasks in that domain
- **Put access** → grants View *and* Modify access to reports and tasks in that domain

### Steps to Determine Required Domain Access

1. Review the Workday Web Services API Documentation on Workday Community.
2. For each web service, record which operations your integration will use.
3. For each element in each operation, check the parameters list for subelements secured by separate domains. Look for the **Security Note**:
   > *Security Note: This element is secured according to the security policy for the \<domain name\> domain.*
4. Run the **View Security for Securable Item** report.
5. Search for each web service operation. Record the security domain that secures it. If no domain is listed, a business process secures the operation — check the business process security policy instead.
6. Add the ISU account to a security group with Get or Put access to each required domain.

---

## 2. X.509 Certificates in Workday

Workday supports X.509 certificates for AS2 transport, SFTP key authentication, SAML authentication, Google Cloud Storage authentication, web service token authentication, and ACA/AIR connector integrations.

Workday periodically scans for certificates expiring in **30, 15, 7, or fewer than 7 days** and sends email notifications. To receive these:
- Select **Enable Security Emails** on Edit Tenant Setup - Security
- The user must have a valid work email address
- The user must have Modify access on the **Security Administration** domain

### Create X.509 Public Key

**Purpose:** Upload a trading partner's public certificate for use with AS2, SAML authentication, or web service token authentication.

**Security:** Security Administration domain (System functional area).

**Requirements:**
- Certificate must be in **PEM format**
- Must include `-----BEGIN CERTIFICATE-----` and `-----END CERTIFICATE-----` headers

**Steps (condensed):**
1. Obtain the X.509 public key certificate text from your external partner.
2. Access the **Create x509 Public Key** task.
3. Paste the certificate text (including BEGIN/END headers) into the Certificate field.

### Create X.509 Private Key Pair

**Purpose:** Generate an RSA 2048-bit key pair for AS2 transport, SFTP key authentication, or SAML authentication.

**Security:** Security Administration domain (System functional area).

> **Best practice:** Create private key pairs in the **Production tenant**. Sandbox refreshes weekly from Production — if you create a key in Sandbox, your trading partner would need a new public key every week.

**Key details:**
- Generates RSA-2048 format only
- Expiration date visible in the **Valid To** field of the View x509 Private Key Pair report
- Optional: select **Do Not Allow Regeneration** to prevent accidental regeneration of critical keys
- Private key is stored but never viewable

**Output formats:**
- **Public Key** — use for AS2 signature and SAML logout
- **RSA-SSH Formatted Key** — use for SFTP key authentication

**SSH key format note:** Workday outputs the RSA-SSH public key in **SSH2 format**. If the external server requires OpenSSH format, convert using an external tool (e.g. PuTTYgen).

### Regenerate Expired X.509 Private Key Pair

**Security:** Security Configuration domain (System functional area).

Regenerate before expiry to prevent failures in AS2, SFTP, SAML authentication, and solutions migration.

**Steps (condensed):**
1. Run the **View x509 Private Key Pair** report and select the key pair.
2. Related action → x509 Private Key Pair → **Regenerate Key Pair**.
3. Confirm, then send the new public key to the trading partner.

### Create Third-Party X.509 Key Pair

**Purpose:** Import key pairs from an external certificate authority (e.g. IRS for ACA/AIR connector integrations).

**Security:** Security Administration domain (System functional area).

> **Limitation:** Third-party X.509 key pairs cannot be used for SAML SSO.

**Certificate requirements:**
- Must not be expired
- Must be PEM encoded
- Must be a single certificate (not a certificate chain)
- Must include BEGIN/END CERTIFICATE headers with all dash characters

**Private key requirements:**
- Must be in **PKCS8 format**
- Must be PEM encoded
- Must not include extraneous characters (e.g. stray newlines)
- Must include BEGIN/END PRIVATE KEY (or ENCRYPTED PRIVATE KEY) headers

### Load Externally Generated Private Key (Google Cloud Storage)

**Purpose:** Load an externally generated RSA X.509 private key for GCS authentication only.

**Security:** Security Administration domain (System functional area).

- Generate the RSA X.509 private key from Google Cloud Storage
- Must be PEM format with `.pem` extension
- Access the **Create Private Key** task and paste the key text
- Only use this task for GCS authentication; for all other purposes, use Create x509 Private Key Pair

---

## 3. PGP Certificates in Workday

Workday supports PGP (Pretty Good Privacy) encryption for Cloud Connect, Studio, and EIB integration files. Workday uses an OpenPGP-compatible cryptographic library (Bouncy Castle) supporting **PGP 5.0 and later** (RFC 4880 compliant). PGP 2.6.x is not officially supported, though Workday has maintained backward compatibility in practice.

### Create PGP Public Key

**Purpose:** Upload a trading partner's PGP public key to encrypt outbound files or verify inbound signatures.

**Security:** Security Administration domain (System functional area).

**Requirements:**
- The PGP certificate must be **self-signed using SHA-256**
- Certificate text must include the full `-----BEGIN PGP PUBLIC KEY BLOCK-----` and `-----END PGP PUBLIC KEY BLOCK-----` markers

**Steps (condensed):**
1. Obtain the PGP public key from your trading partner.
2. Access the **Create PGP Public Key** task.
3. Paste the certificate text into the Certificate field.
4. Associate the public key with the outbound integration or EIB.

### Create PGP Private Key Pair

**Purpose:** Generate a PGP key pair for decrypting inbound files or digitally signing outbound files.

**Security:** Security Administration domain (System functional area).

- Private key is stored but never viewable
- Send the public key portion to your trading partner

> **Best practice:** As with X.509, create PGP private key pairs in the **Production tenant**. Sandbox keys are removed during the weekly refresh, requiring your trading partner to reapply the public key each week.

### Regenerate Expired PGP Private Key Pair

**Security:** Security Configuration domain (System functional area).

PGP private key pairs have built-in expiration dates (visible in the **Valid To** field of the View PGP Private Key Pair report).

**Steps (condensed):**
1. Run the **View PGP Private Key Pair** report and select the key pair.
2. Related action → PGP Private Key Pair → **Regenerate Key Pair**.
3. Confirm, then send the new public key to the trading partner.

### PGP Key Expiry Monitoring

Workday scans for PGP certificates expiring at **30, 15, 7, and fewer than 7 days** before expiry and generates email notifications. The same prerequisites apply as for X.509 expiry notifications:
- **Enable Security Emails** on Edit Tenant Setup - Security
- Valid work email address in Workday contact information
- Modify access on the **Security Administration** domain

---

## 4. Encryption and Signing by Transport Protocol

### X.509 for Encryption and Digital Signatures

X.509 certificates use a public key/private key pair. The two primary uses:

- **Encryption:** The intended recipient creates an X.509 certificate and shares the public key with the sender. The sender encrypts with the public key; the recipient decrypts with the private key.
- **Digital signatures:** The sender creates an X.509 certificate and signs with the private key. The recipient verifies the signature using the sender's public key.

### AS2 Transport Protocol

To configure AS2 encryption and digital signatures for outbound integrations:

1. **Trading partner** generates an X.509 certificate and sends you the public key.
2. **Load the partner's public key** into Workday (Create x509 Public Key task).
3. **Create your own X.509 Private Key Pair** in Workday.
4. **Associate both** with the AS2 file transport protocol for the connector or EIB.
5. **Send your public key** to the trading partner.

When the integration launches:
- Workday **encrypts** the file with the partner's public key
- Workday **signs** the file with your private key
- The partner **decrypts** with their private key and **verifies** the signature with your public key

> **Limitation:** Workday does not support AS2 decryption or signature verification for inbound files.

### SFTP Key Authentication

**Outbound (Workday sends files):**
1. Create an X.509 Private Key Pair in Workday.
2. Send the **RSA-SSH Formatted Key** to the trading partner for their authorized_keys file.
3. Associate the private key pair with the SFTP transport.

**Key format considerations:**
- Workday outputs **SSH2 format**; convert to OpenSSH format externally if required by the partner
- Workday generates **RSA-2048 only**; RSA-4096 keys from third-party tools (e.g. PuTTY) are possible but not recommended by Workday

**Inbound (Workday retrieves files):**
1. Obtain the trading partner's RSA public key.
2. Associate it with the transport protocol for the connector or EIB.

### PGP for File Encryption and Signing

| Feature | Direction | Key Type to Use | Workday Role |
|---|---|---|---|
| PGP Encryption | Outbound | PGP Public Key (partner's) | Sender |
| PGP Signing | Outbound | PGP Private Key Pair (yours) | Sender |
| PGP Decryption | Inbound | PGP Private Key Pair (yours) | Recipient |
| PGP Signature Verification | Inbound | Not supported | — |

> **Note:** Digital signatures and integrity checks can only be applied to *encrypted* integration files.

**PGP output options** (configured on the integration delivery):
- Decrypted file name
- File format: PGP or ASCII Armoured
- Message integrity check (optional)
- PGP 2.6.x compatibility mode (optional)

### Complete Key Type Reference

| Feature | Workday Role | Key Type | Public Key Format |
|---|---|---|---|
| AS2 Encryption (Outbound) | Sender | X.509 Public Key | — |
| AS2 Signature (Outbound) | Sender | X.509 Private Key Pair | Public Key |
| AS2 Decryption/Verification | Not supported | — | — |
| SFTP Key Authentication | Sender/Recipient | X.509 Private Key Pair | RSA-SSH Formatted Key |
| SAML Sign-In | Recipient | X.509 Public Key | — |
| SAML Logout | Sender | X.509 Private Key Pair | Public Key |
| Web Service X.509 Token Auth | Recipient | X.509 Public Key | — |
| Google Cloud Storage Auth | Sender | X.509 Private Key (from GCS) | — |
| ACA/AIR Connector | Recipient | X.509 Third-Party Key Pair | — |

> **Encryption requirement:** Integrations using unencrypted transport protocols (email, FTP) often require PGP encryption. This requirement can be overridden for EIBs but not for connectors.

---

## 5. WS-Security XML Signatures

Digitally sign SOAP requests for web service authentication using X.509 certificates.

### Setup Steps (Condensed)

1. **Create an X.509 Private Key Pair** in Workday (or load a third-party certificate).
2. Access the **Configure Web Service Security** task.
3. Select the Integration System User whose security profile the web service requests should use.
4. To enable **RSA-based authentication**: assign an X.509 Public Key that verifies the signature on inbound requests.
5. To enable **SAML authentication**: configure the SAML Identity Provider, Identity Provider's Public Key, and optional Holder-of-Key Public Key.
6. Enable on the tenant via **Edit Tenant Setup - Security**.

> **Recommendation:** Workday recommends **exclusive canonicalization** for web service requests that use X.509 authentication.

### Supported Signature Algorithms

| Algorithm | URI | Supported | Recommended |
|---|---|---|---|
| DSA-SHA1 | `xmldsig#dsa-sha1` | No | No |
| HMAC-SHA1 | `xmldsig#hmac-sha1` | No | No |
| RSA-SHA1 | `xmldsig#rsa-sha1` | Yes | No |
| RSA-SHA256 | `xmldsig-more#rsa-sha256` | **Yes** | **Yes** |
| RSA-SHA384 | `xmldsig-more#rsa-sha384` | Yes | No |
| RSA-SHA512 | `xmldsig-more#rsa-sha512` | Yes | No |

The signature value must be the signed result of the `SignedInfo` element.

### Supported Digest Algorithms

| Algorithm | URI | Supported | Recommended |
|---|---|---|---|
| SHA1 | `xmldsig#sha1` | Yes | No |
| SHA256 | `xmlenc#sha256` | **Yes** | **Yes** |
| SHA384 | `xmlenc#sha384` | Yes | No |
| SHA512 | `xmlenc#sha512` | Yes | No |

The digest value must be the hashed result of the entire SOAP envelope.

### Supported Transform Algorithms

| Transform | URI | Supported |
|---|---|---|
| Enveloped Signature | `xmldsig#enveloped-signature` | Yes |
| Base64 | `xmldsig#base64` | No |
| XPATH | `REC-xpath-19991116` | No |
| XPATH2 | `xmldsig-filter2` | No |
| XSLT | `REC-xslt-19991116` | No |

### Supported Canonicalization Methods

| Method | URI | Supported | Recommended |
|---|---|---|---|
| INCLUSIVE | `REC-xml-c14n-20010315` | Yes | No |
| INCLUSIVE_WITH_COMMENTS | `REC-xml-c14n-20010315#WithComments` | Yes | No |
| EXCLUSIVE | `xml-exc-c14n` | **Yes** | **Yes** |
| EXCLUSIVE_WITH_COMMENTS | `xml-exc-c14n#WithComments` | **Yes** | **Yes** |

---

## 6. X.509 Authentication Supported Algorithms

These algorithms apply specifically to X.509 token authentication for web service requests (as distinct from the WS-Security signature algorithms above).

### Digest Methods

| Method | URI | Supported |
|---|---|---|
| SHA256 | `xmlenc#sha256` | Yes |
| SHA512 | `xmlenc#sha512` | Yes |
| SHA1 | `xmldsig#sha1` | No |
| RIPEMD160 | `xmlenc#ripemd160` | No |

### Signature Methods

| Method | URI | Supported |
|---|---|---|
| RSA_SHA256 | `xmldsig-more#rsa-sha256` | Yes |
| RSA_SHA1 | `xmldsig#rsa-sha1` | Yes |
| DSA_SHA1 | `xmldsig#dsa-sha1` | No |
| HMAC_SHA1 | `xmldsig#hmac-sha1` | No |

### Transform Methods

| Method | URI | Supported |
|---|---|---|
| ENVELOPED | `xmldsig#enveloped-signature` | Yes |
| BASE64 | `xmldsig#base64` | No |
| XPATH | `REC-xpath-19991116` | No |
| XPATH2 | `xmldsig-filter2` | No |
| XSLT | `REC-xslt-19991116` | No |

### Canonicalization Methods

| Method | Supported | Recommended |
|---|---|---|
| INCLUSIVE | Yes | No |
| INCLUSIVE_WITH_COMMENTS | Yes | No |
| EXCLUSIVE | Yes | Yes |
| EXCLUSIVE_WITH_COMMENTS | Yes | Yes |

---

## 7. Supported SFTP Ciphers and Algorithms

### SFTP Ciphers — Document Delivery and Retrieval

Workday supports these cipher families for SFTP in the Document Delivery and Retrieval service:

- **AES** — aes128-cbc, aes128-ctr, aes192-cbc, aes192-ctr, aes256-cbc, aes256-ctr
- **AES-GCM** (Document Delivery/Retrieval only) — aes128-gcm@openssh.com, aes256-gcm@openssh.com
- **Blowfish** — blowfish-cbc, blowfish-ctr
- **Twofish** — twofish-cbc, twofish192-cbc, twofish192-ctr, twofish256-cbc, twofish256-ctr
- **Serpent** — serpent128-cbc, serpent128-ctr, serpent192-cbc, serpent192-ctr, serpent256-cbc, serpent256-ctr
- **3DES** — 3des-cbc, 3des-ctr
- **Other** — arcfour, arcfour128, arcfour256, cast128-cbc, cast128-ctr, idea-cbc, idea-ctr
- **SSH host key algorithms** (RFC-8308) — rsa-sha2-256, rsa-sha2-512, ssh-rsa
- **None** (no encryption)

### SFTP Ciphers — Studio SFTP-Out (Assembly Versions Before 2020.09)

Reduced cipher set for the Studio SFTP-Out component on older assembly versions:

- 3des-cbc, aes128-ctr, aes192-ctr, aes256-ctr, blowfish-cbc, None

> **Performance note:** Workday recommends performing encryption on the **Delivery service** rather than on the Studio SFTP-Out component.

### TLS Versions

| Direction | Minimum TLS Version |
|---|---|
| Inbound integrations | TLS 1.2 and later |
| Outbound integrations | TLS 1.2 and later |

### TLS Cipher Suites

Workday enables approximately 40 cipher suites by default, covering **DHE, ECDH, and ECDHE** key exchange families with **AES-128/256** in **CBC and GCM** modes, plus a small number of legacy suites (3DES, RC4). Anonymous (`DH_anon`, `ECDH_anon`) and NULL cipher suites are disabled by default.

**SHA-1 decommissioned for inbound:** Workday no longer supports these cipher suites for inbound integrations:

- `TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA`
- `TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA`
- `TLS_RSA_WITH_AES_128_CBC_SHA`
- `TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA`
- `TLS_RSA_WITH_AES_256_CBC_SHA`

### SFTP Key Exchange (KEX) Algorithms

- diffie-hellman-group1-sha1
- diffie-hellman-group14-sha1
- diffie-hellman-group14-sha256
- diffie-hellman-group16-sha512
- diffie-hellman-group-exchange-sha1
- diffie-hellman-group-exchange-sha256
- ecdh-sha2-nistp256
- ecdh-sha2-nistp384
- ecdh-sha2-nistp521

### Server Host Key Algorithms

- ecdsa-sha2-nistp256
- ecdsa-sha2-nistp384
- ecdsa-sha2-nistp521
- rsa-sha2-256
- rsa-sha2-512
- ssh-ed25519

### MAC Algorithms

**Document Delivery/Retrieval and Studio SFTP-Out:**
- hmac-md5, hmac-md5-96
- hmac-sha1, hmac-sha1-96
- hmac-sha2-256, hmac-sha2-256-96
- hmac-sha2-512, hmac-sha2-512-96
- None

**Document Delivery/Retrieval only:**
- hmac-sha2-256-etm@openssh.com
- hmac-sha2-512-etm@openssh.com

## 8. Mutual Authentication (Mutual TLS)

Mutual authentication (also called mutual SSL, dual authentication, or two-way authentication) requires both client and server to present certificates. Only **outbound** mutual authentication from Workday is currently supported.

### Certificates

- The client certificate must be owned by the Workday customer (not Workday)
- The server certificate must be provided by the external endpoint
- Self-signed certificates may be accepted depending on the server's trust configuration

### Keystores and Truststores

| Store | Contains | Purpose |
|---|---|---|
| **Keystore** | Client's private and public key | Presented to the server to prove identity |
| **Truststore** | Server's certificate | Verifies the server is a known, trusted endpoint |

### Creating a Truststore

Import the server's certificate (provided to you) into a new truststore:

```
keytool -importcert -file ServerCert.cer -keystore truststore.jks
```

You will be prompted for a password to protect the truststore.

### Creating a Keystore

Generate a key pair and create a keystore:

```
keytool -genkeypair -alias Workday -storepass <keystore-password> -keypass <key-password> -keyalg RSA -keystore keystore.jks
```

Export the public key to share with the server:

```
keytool -exportcert -alias Workday -storepass <keystore-password> -keystore keystore.jks -file client-public.cer
```

### Studio HTTPS Configuration

Configure mutual auth on the HTTP-out transport's HTTPS properties:

| Property | Value |
|---|---|
| Keystore File | Path to `keystore.jks` in `WSAR-INF/` |
| Key Password | Password for the private key |
| Truststore File | Path to `truststore.jks` in `WSAR-INF/` |
| Truststore Password | Password for the truststore |

**Note:** Store the keystore and truststore files in the project's `WSAR-INF/` directory so they deploy with the integration. Use integration attributes or credential storage for passwords — do not hardcode them.

### Converting Certificate Formats

If the server provides a `.pem` or OpenSSH format certificate, convert it before importing:

```
# PEM to DER
openssl x509 -outform der -in certificate.pem -out certificate.der

# Import DER into truststore
keytool -importcert -file certificate.der -keystore truststore.jks
```

Tools like **KeyStore Explorer** provide a GUI alternative to keytool for managing keystores and truststores.
