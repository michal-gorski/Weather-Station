# Integration Services Reference

Covers the configuration of integration services (attributes, maps, field overrides, sequence generators, attachments) and the REST APIs for programmatic integration access (My Reports, Launch, Listener, Message Queue).

**Scope boundaries:**
- For accessing integration attributes/maps from MVEL in Studio → see `assembly-patterns.instructions.md`
- For ETV/XTT map usage and code translation in XSLT → see `xsl-standards.instructions.md`
- For launching, scheduling, and monitoring from the tenant UI → see `integration-operations-reference.md`
- For technology selection and connector concepts → see `integration-foundations-reference.md`
- For deployment from Studio and Process Monitor → see `studio-lifecycle.instructions.md`

---

## 1. Template-Based Integration Setup

Condensed steps for setting up any template-based integration:

| Step | Task / Action | Notes |
|------|--------------|-------|
| 1 | Create Integration System (from template) | Requires Integration Build + Integration Configure domains |
| 2 | Configure Integration Services | Enables optional services; required services are read-only |
| 3 | Configure Integration Attributes | Set values for both optional and required attributes |
| 4 | Configure Integration Maps | Map internal values to external values |
| 5 | Set up field overrides | Connector approach (Integration Field Override Service) or DIS approach (Extended Fields) |
| 6 | Configure Integration Sequence Generators | Counter mechanism for batch/document numbers |
| 7 | Configure Integration Transaction Log | Select Workday transactions for monitoring (optional) |
| 8 | Create Integration Notifications | Alert on events, errors, completions (optional) |
| 9 | Maintain Integration System Documents | Attach design docs, usage notes, change logs (optional) |
| 10 | Create Integration Business Process | Required for BP-triggered integrations |
| 11 | Add integration step to BP | Optional — launch from a business process step |
| 12 | Configure delivery/retrieval | Set Up Integration Delivery or Set Up Integration Retrieval |
| 13 | Configure security (ISU, domains) | Grant data access to the Integration System User |

**Security prerequisites:** Integration Build and Integration Configure domains in the Integration functional area.

---

## 2. Create Integration System

### Prerequisites

- Access the **Maintain Integration Tags** task (security: Integration Reports domain) and define any tags to apply.
- Any person defined as a contact must already exist in Workday.
- Security: Integration Build and Integration Configure domains.

### Key Fields

| Field | Description |
|-------|-------------|
| Template | Select a Workday-delivered integration template |
| Integration Tags | Apply one or more tags (max 256 characters each). Useful for reporting and filtering |
| Contacts | Associate workers (e.g. consultant, internal project lead) for discoverability |
| Comment | Free-form description for a contact |

### Integration Subscriptions

Subscriptions allow an integration to subscribe to business processes and transaction events, and send SOAP notifications to an external endpoint when those events complete.

**Setup:**
1. Create an integration using the **Subscriber_integration** template (or any template without Transaction Log service).
2. Integration System → **Edit Subscriptions** → subscribe to specific BP types and/or transaction events.
3. Configure an external endpoint URL. The endpoint must implement the `Receive_Notification` operation from the Notification WSDL, or be a REST endpoint that parses the SOAP XML.
4. Authentication: **WS-Security only** — header-based auth is not supported.

**What the notification contains (`Notification_Data` → `Event_Data`):**

| Element | Description |
|---|---|
| `Event_Reference` | BP event WID (Transaction_LogObject) |
| `Event_Name` | Human-readable event name (e.g. "Hire Employee Event") |
| `Notification_Trigger` | Trigger type (e.g. "Completed") |
| `Event_Completion_Date` | Timestamp of BP completion |
| `Event_Effective_Date` | Effective date of the change (optional) |
| `Tenant_Name` | Tenant name |
| `System_ID` | Integration system ID |
| `Transaction_Target_Reference` | The business object(s) the event applies to (0..*) |

**Transaction_Target_Reference** contains a Descriptor and multiple IDs with type attributes. For worker-targeted BPs (Hire, Terminate, Change Job), the target is the Worker and may include both `WID` and `Employee_ID`. For other BP types, the target varies (e.g. Job Application for an Offer Event, Organisation for a Reorg). The notification does **not** contain the actual business data (name, address, job details, etc.) — only event metadata and target references.

**Typical usage pattern:**
1. External system (middleware) receives the SOAP notification.
2. Parses `Transaction_Target_Reference` for the target's Employee_ID or WID.
3. Calls back to Workday (RaaS or Get_Workers) to retrieve the actual worker data.
4. Forwards the data to the target system.

**Key constraints:**
- Only available on integrations whose template does **not** include a Transaction Log service.
- Notifications are best-effort: if two consecutive deliveries fail, Workday disables the endpoint and records the error.
- Re-enable via Integration System → Edit Subscriptions → clear **Disable Endpoint**.
- Run **Integration Exception Audit** (with Warnings selected) to find all disabled subscriptions.
- Rescinds do **not** trigger subscriptions. A scheduled reconciliation (full file or delta) is needed to catch rescinds.
- Mass events (e.g. EIB-driven bulk hires) trigger individual notifications per subscribed event. The external system should implement a queueing strategy to handle bursts and batch callbacks to Workday.

**When to use subscriptions vs BP integration step + Orchestrate:**

If Orchestrate is available, a BP integration step + Orchestrate is generally preferred:
- No external middleware or SOAP endpoint needed — everything runs within Workday.
- Worker reference is passed directly as a launch parameter (no callback round-trip).
- Standard integration events and monitoring.
- Subscriptions require: external endpoint → callback to Workday → forward to target (three hops vs one).

Subscriptions are appropriate when:
- An external middleware or ESB is already in place and needs to be the orchestrator.
- Orchestrate/Studio is not available for the customer.
- The target system's middleware needs to control the data fetch and transformation.

**Source:** [Notification WSDL — Receive_Notification operation](https://community.workday.com/sites/default/files/file-hosting/productionapi/Notification/v46.1/Receive_Notification.html); [Workday Community — Real Time Data to External Systems via Integration Subscriptions](https://community.workday.com/node/574513).

---

## 3. Integration Sequence Generators

### Purpose

Enable integrations to generate a unique, sequenced number each time they run. Used for batch numbers, document IDs, and filenames.

**Important:** If concurrent requests generate sequence numbers very close together, Workday may produce non-consecutive (skipped) numbers.

### Setup

1. As a related action on the integration system: Integration System → **Configure Integration Sequence Generators**.
2. Configure the generator options.
3. Specify Last Sequence ID values.
4. Optionally restrict to specific environments.

### Configuration Options

| Option | Description |
|--------|-------------|
| **Increment Sequence ID By** | Non-zero value by which the sequence increases each generation |
| **Padding** | Number of digits in the sequence. Recommended ≥ 6. If 0 or blank, the sequence increases indefinitely |
| **Sequence ID Format** | Text string with special variables: `[seq]`, `[day]`, `[month]`, `[year]`, plus date/time patterns (e.g. `[yyyy][MM][dd]`) |
| **Restart Frequency** | Reset interval: Day, Month, or Year. Leave blank for no reset. Include the time period in the format to ensure uniqueness |
| **Restart Number** | Initial value when restarting |
| **Time Zone Usage** | Alternate time zone for restart interval (default: PST/PDT) |
| **Sequence ID Overflow Behaviour** | `Allow Overflow with Truncated Sequences` (truncates leading digit) or `Automatically Ignore Padding` (exceeds padding) |
| **Low Volume** | Select to prevent gaps in sequences — use only for low-volume integrations |
| **Last Sequence Used** | Manually set the last sequence number (e.g. continuing from a previous system) |
| **Last Date Used** | Used with Restart Frequency to determine whether to restart |

### Format Example

```
Sequence ID Format: [yyyy][MM][dd]_[Seq]_ER-GMS.csv
Increment: 1, Padding: 0, Restart: none

Result: 20180201_3_ER-GMS.csv, 20180215_4_ER-GMS.csv
```

### Overflow Notifications

Workday sends overflow warnings to:
1. Override Tenant Setup Overflow Notification Group (if configured on the generator).
2. Default Sequence Generator Notification Group (from Edit Tenant Setup – System).
3. Workday default overflow notification security groups.

### Access in Integrations

- **XSLT:** Use `etv:sequencedValue` to retrieve the generated value.
- **Studio MVEL:** Access via integration attribute or `intsys` properties (covered in `assembly-patterns.instructions.md`).

---

## 4. Integration Field Overrides

### For Connectors

Field overrides add custom data to connector output files by mapping report fields or calculated fields to named output fields.

**Prerequisites:**
- Integration system based on a connector template.
- Calculated field or report field based on the **Worker** business object.
- Confirm the field returns expected values by running a custom report as the ISU against All Workers.

**Setup Steps:**

1. Integration System → **Configure Integration Services** → add a row in Custom Integration Services → select an Integration Field Override Service (or create one).
2. When creating: name the service, select the business object, add one row per field with a name.
3. Integration System → **Configure Integration Field Overrides** → map each field to a report field in the Override External Field prompt.
4. For eligibility: add a Boolean report/calculated field to define which workers to include.
5. Test security: Integration Field Override → **Test Security for Document Field Overrides**.

**Result:** Custom fields appear in an `ADD` record on a separate line in the output file. By default, Workday includes them only when values change.

**Integration maps for custom fields:** Create maps with the naming format `ADD-<FieldName>` and configure Internal/External value mappings.

### For DIS (Data Initialisation Service)

Used with integrations that have a DIS, such as:
- Core Connector: Worker (with Worker Data Initialisation Service enabled)
- Payroll Effective Change Interface (PECI)
- Worker Effective Change Interface (WECI)

**Key differences from Connector approach:**
- Supports **Parameters** (Global and Document-level) as well as Field Overrides and **Extended Fields**.
- Parameters can source from: runtime report/calculated fields, integration attributes, or launch parameters.
- Extended Fields have explicit Data Type and Reference ID Type configuration.

### DIS Operations and Constraints

**How DIS executes:**
1. Data population is defined using the data source and filters
2. Population is separated into **partitions**
3. One XML file is created per partition (parallelised)
4. Optionally, XML files are merged into a single file
5. XML files are stored in the **Blobitory**
6. Studio reads and processes the files

**Advantages:**
- DIS runtime does **not** count against the Studio 2-hour limit
- Files are persisted in the Blobitory (available for reprocessing)
- Nested data hierarchies via document builders (not easily achievable with RaaS or field overrides)
- Data retrieval is typically faster than SOAP/REST/RaaS

**Limits — configuration:**

| Constraint | Limit |
|---|---|
| Root data sources | 1 per DIS |
| DIS services per integration | No limit |
| Sub-document levels | No limit |
| Effective date | Current effective date and entry moment only |

**Limits — runtime:**

| Constraint | Limit |
|---|---|
| DIS document size | 500 MB compressed |
| Partition timeout | 2 hours |
| File retention | 60 days |
| Base64 / Image data types | Not supported with Custom DIS |

**Security:**
- The ISU must have the report shared with it
- Report fields and calculated fields require **View** access, evaluated against ISU security
- DIS population uses the same contextual security as report data sources — items excluded by security are silently omitted

### Processing DIS Files in Studio

**Without transformation** (simplest approach):
- Use a Cloud Collection Template integration with a DIS and delivery service
- Only works if DIS is configured to produce a **single merged file**

**With transformation** (Studio required):
- Use a **doc-iterator** (splitter with document iteration strategy) to process individual DIS partition files
- If the output requires aggregation across the full data set (e.g. sums, counts), merge the partition files first
- Use **XSLT 3.0 with streaming** for memory-efficient transformation of large DIS files

### Extended Fields — Validation Rules

| Report Field Type | Boolean | Currency | Date | Date Time | Numeric | Text | Instances (Plural) |
|---|---|---|---|---|---|---|---|
| **Boolean** | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ | ✗ |
| **Currency** | ✓ | ✓ | ✗ | ✗ | ✓ | ✓ | ✗ |
| **Date** | ✓ | ✗ | ✓ | ✓ | ✗ | ✓ | ✗ |
| **Date Time** | ✓ | ✗ | ✓ | ✓ | ✗ | ✓ | ✗ |
| **Numeric** | ✓ | ✗ | ✗ | ✗ | ✓ | ✓ | ✗ |
| **Text** | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ | ✗ |
| **Instances (plural)** | ✓ | ✗ | ✗ | ✗ | ✗ | ✓ | ✓ |

For instances cast to text, Workday uses the **display ID** in the integration output. You must select a Reference ID Type for plural instance fields, or Workday includes no reference IDs.

---

## 5. Integration Attachment Service

### Purpose

Attach data-mapping documents (typically XSLT files) to a custom integration without redeploying from Studio. This enables tenant-side updates to transformation logic.

### Setup

1. View Integration System → select the custom integration.
2. Integration System → **Configure Integration Services**.
3. In Custom Integration Services, add a row → Create → **Integration Attachment Service**.
4. Integration System → **Configure Integration Attachment Service** → select the attachment.

### Key Constraints

- Each integration attachment service supports **only one attachment**.
- To attach multiple files, create multiple integration attachment services.
- Works with both Cloud Integration Template-based integrations and Studio-deployed integrations.

### Studio Benefit

Update XSLT or data-mapping documents directly in the Workday tenant without redeploying the Studio project. Useful for:
- Hot-fixing transformation logic in production.
- Allowing functional consultants to update mappings without Studio access.

### Get_Integration_Systems response structure

Attachment content is returned base64-encoded within the `Get_Integration_Systems` response:

```xml
<wd:Integration_Service_Data wd:WID="..." wd:Enabled="1">
  <wd:Integration_Service_Reference wd:Descriptor="Attach XSLT">
    <wd:ID wd:type="WID">...WID value...</wd:ID>
    <wd:ID wd:type="Integration_Service_Name">Attach XSLT</wd:ID>
  </wd:Integration_Service_Reference>
  <wd:Integration_Attachment_Service_Data>
    <wd:Attachment_Data>
      <wd:File_ID>INTEGRATION_SERVICE_ATTACHMENT-6-29</wd:File_ID>
      <wd:File>PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZ...</wd:File>
      <wd:FileName>WorkerMapping.csv</wd:FileName>
    </wd:Attachment_Data>
  </wd:Integration_Attachment_Service_Data>
</wd:Integration_Service_Data>
```

### Updating an attached file

1. Execute **Edit Integration Service Attachment**.
2. Select the file to update.
3. Delete the existing attachment and upload the new version.

The Integration Service Attachment name always matches the name of the associated file. If you create a new attachment with the same name as one already in the tenant, there is no way to differentiate between them.

### Retrieving attachment content in Studio

**Do not** use `parts[0].xpath` or `parts[0].xstream` to read attachment content — both have a 1 MB limit. Use the streaming XSLT pattern documented in `assembly-patterns.instructions.md` under "Integration Attachment Service" to extract the base64 string, then decode with the `base64-decode` component.

For XSLT attachments, reference the decoded content from the XSLT+ component using `mctx:vars/variableName` — see `assembly-patterns.instructions.md` for the full pattern.

---

## 6. Integration Custom Objects

### Purpose

Associate Custom Objects in Workday with Custom Object aliases defined in a Studio integration.

### Setup

1. Access the integration system.
2. Integration System → **Configure Custom Objects**.
3. For each alias without a default Custom Object, select a Custom Object from the prompt.
4. For each alias with a default, optionally select **Override** to replace it.

**Security:** Integration Build and Integration Configure domains.

---

## 7. Supporting Documentation

### Purpose

Attach design documents, usage notes, and change logs to an integration system for future maintenance and support.

### Steps

1. As a related action on the integration: Integration System → **Maintain Integration System Documents**.
2. Select and attach the documents.

Documents display on the integration system view, providing background information for anyone maintaining the integration.

---

## 8. Change Transport Protocols (Bulk)

### Purpose

View and edit transport configurations for multiple protocols as a single action. Useful during endpoint migrations or mass address changes.

### Tasks

| Task | Scope |
|------|-------|
| **Maintain Email Protocols For Integration Systems** | Email address, configuration location |
| **Maintain Transport Protocols for Integration Systems** | Transport protocol, configuration location, address |
| **Maintain Amazon Simple Storage Service for Integration Systems** | Bucket, region, access key ID, secret access key |

### Key Points

- These tasks **only display protocols you have security access to**.
- For S3: cannot update KMS Key Alias and Region via this task.
- Shared transport protocols (Use Existing) require access to the owning integration system to modify.
- Security: Integration Configure domain, plus edit access to the domain securing the integration.

---

## 9. Disable Integration Subscriptions

### Mechanism

Set the HTTP header `x-disable-subscriptions` to `1` in the request to disable all integration subscriptions for that web service call.

### Key Rules

- When set to `1`, **all** subscriptions are disabled — you cannot disable individual subscriptions.
- Default value is `0` (subscriptions enabled).
- This applies to outbound WWS calls made by the integration.

### How to Set

**In Studio:** Use the `set-headers` component before the web service call:
```
x-disable-subscriptions: 1
```

**In Java:**
```java
HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
httpCon.setRequestProperty("x-disable-subscriptions", "1");
```

### Tenant-Level Disable

Alternatively, the **Edit Tenant Setup – Integrations** task has a **Disable Integration Subscriptions** checkbox that disables subscriptions tenant-wide. Ensure this is unchecked if external endpoint notifications are configured.

---

## 10. Enumerations

### Purpose

Restrict an attribute value to a set of literal values (e.g. cost centre codes, status values). Defines constants for use in integration design.

### Where Used

- Launch parameters
- Integration attributes
- Integration maps

### Tenant Tasks

| Task | Purpose |
|------|---------|
| Create Integration Enumeration Definition | Define a new enumeration |
| Edit Integration Enumeration Definition | Modify values |
| Delete Integration Enumeration Definition | Remove an enumeration |
| View Integration Enumeration Definition | Inspect existing enumerations |

### Creating in Studio vs Tenant

| Method | Behaviour |
|--------|-----------|
| Define in Studio | Deploys the enumeration definition to the tenant with the integration |
| Reference from Studio | Points to an existing enumeration already defined in the tenant |
| Create via tenant task | Uses Create Integration Enumeration Definition, independent of Studio |

### Sharing Across Integrations

One integration defines the enumeration; other integrations reference it. This avoids duplication and ensures consistency.

---

## 11. SFTP/FTP Endpoint Vendor Reference

### Validated Vendors

Workday validates integration transports with each update against these vendors:

| Vendor | Version | SFTP | FTP (Passive) | FTPSI (Passive) | FTPSE (Passive) |
|--------|---------|------|---------------|-----------------|-----------------|
| GlobalSCAPE EFT Server | Enterprise (1.82) | ✓ | ✓ | — | — |
| Microsoft FTP Service | 7.5 | — | ✓ | — | — |
| WS_FTP | 7.5 | ✓ | ✓ | — | — |
| Cygwin with SSHD | — | ✓ | ✓ | — | — |
| OpenSSH | 4.3/5.1 | ✓ | ✓ | ✓ | ✓ |
| VSFTPD | 2.0.1 | ✓ | ✓ | ✓ | ✓ |

### Support Policy

- **Validated vendor:** Workday can internally reproduce issues, test fixes, and runs automated testing each service update.
- **Non-validated vendor:** Integrations may work fine, but troubleshooting SFTP issues falls to the customer and their vendor. Workday support is limited to issues under their direct control.

### Common SFTP Troubleshooting

| Symptom | Resolution |
|---------|------------|
| Unable to locate IP by hostname | Verify hostname and DNS settings |
| Connection reset | Allow Workday IP on firewall; verify cipher/SSH protocol configuration |
| Incorrect filename/filepath | Use full directory path (not relative); add trailing `/` as needed |
| Timeout exception | Verify IP address is correct; confirm endpoint is reachable |
| Directory not found | Verify file directory is correct and file exists |
| Packet size exceeded | Configure SSH protocol properly; reduce packet size |
| Write error / permission denied | Clear "Use Temp File" checkbox on delivery/retrieval; verify edit/rename permissions |
| Channel request failure | SSH services may be disabled on the server; check SSH logs and restart |

---

## 12. My Reports API

### Purpose

Retrieve integration output documents directly via REST. Access files produced by integrations from the My Reports repository.

### URI Format

```
{host_URL}/ccx/cc-blobitory/{tenant_name}/{collection}/{document_ID}
```

### Authentication

- **Basic Auth:** `username@tenant_name` with password.
- **OAuth 2.0:** Bearer access token (see Section 16).
- Include header: `X-Tenant: {tenant_name}`

### Repository Structure

- **Repository:** One per tenant.
- **Collection:** One or more per repository, each with a unique name. Specified by the integration that created the document.
- **Document:** Actual data files produced by integrations. Each has a unique auto-generated `document_ID`.

### Operations

| Operation | URI | Response |
|-----------|-----|----------|
| GET document | `…/cc-blobitory/{tenant}/{collection}/{document_ID}` | Returns the document content |
| GET metadata | `…/cc-blobitory/{tenant}/{collection}/{document_ID}.atom` | Returns XML with: expiration date, published date, last update, title, file size, encryption/compression status, owner |
| GET collection | `…/cc-blobitory/{tenant}/{collection}` | Lists documents in the collection |

### Finding the Document ID

| Method | Description |
|--------|-------------|
| Integration IDs report | Look up the document ID from the integration event |
| Get_Event_Documents WWS | Web service operation returns document references |
| Custom report | Write a report to expose document IDs |

---

## 13. Integration Launch API

### Purpose

Launch Studio integrations remotely via REST. Simpler and more event-based than using SOAP (Put_Integration_Event).

### URI Format

```
{host_URL}/ccx/cc-cloud-repo/launches/{collection}/{integration_name}/{workday_in_id}?{launch_params}
```

### Authentication

- **Basic Auth:** `username@tenant_name` with password.
- **OAuth 2.0:** Bearer access token (recommended — see Section 16).
- Include header: `X-Tenant: {tenant_name}`

### Security

| ISU Configuration | Required Permissions |
|-------------------|---------------------|
| ISU assigned to integration | Calling user must be in a security group that grants permission to launch the integration |
| No ISU assigned | Calling user must be in security groups granting permission to launch **and** access all data APIs used by the integration |

### Cloud Repository Hierarchy

```
Cloud Repository (one per tenant)
  └── Collection (unique name)
       └── Integration (unique name + workday_in_id)
```

### Operation

| Method | URI Pattern | Description |
|--------|-------------|-------------|
| GET | `…/cc-cloud-repo/launches/{collection}/{integration}/{workday_in_id}?{params}` | Launches the integration with optional launch parameters |

### Launch Parameters

Append launch parameters as query string parameters: `?param_name=value&param2=value2`

---

## 14. Listener Service API

### Purpose

POST custom messages to a Studio integration that has the Listener Service enabled. External systems send event notifications or data payloads that the Studio integration is built to recognise and process.

### URI Format

```
{host_URL}/ccx/cc-cloud-repo/launches/{collection}/{integration_name}/{workday_in_id}
```

### Authentication

- **Basic Auth:** `username@tenant_name` with password.
- **OAuth 2.0:** Bearer access token (recommended — see Section 16).
- Include header: `X-Tenant: {tenant_name}`

### Security

Same as Launch API — depends on whether an ISU is assigned to the integration system.

### Operation

| Method | URI Pattern | Description |
|--------|-------------|-------------|
| POST | `…/cc-cloud-repo/launches/{collection}/{integration}/{workday_in_id}` | Posts a custom message to the integration |

### Use Cases

- External system event notifications (e.g. file-ready signals, webhook callbacks).
- Posting structured data for the Studio integration to process.
- The Studio integration must be built to parse and act on the message format.

---

## 15. Message Queue API

### Purpose

Studio integrations enqueue messages; external systems retrieve and process them. Provides ordered delivery and exactly-once processing.

### URI Format

```
{host_URL}/ccx/wd-queue/{queue_name}
```

### Authentication

- **Basic Auth:** `username@tenant_name` with password.
- Security: Message Queue (segmented) domain access plus the Message Queue Segment.
- Include header: `X-Tenant: {tenant_name}`

### Operations

| Method | URI | Description |
|--------|-----|-------------|
| GET | `…/wd-queue?xsd` | Retrieve the API XML schema |
| GET | `…/wd-queue/` | List all queues in the tenant |
| GET | `…/wd-queue/{queue}/fresh?maxMessages=nnn` | Retrieve up to `nnn` unretrieved messages (default: 100) |
| GET | `…/wd-queue/{queue}/messages/{message_number}` | Retrieve a specific message |
| POST | `…/wd-queue/{queue}` (with message body) | Enqueue a message. Returns the message URI with its sequence number |
| PUT | `…/wd-queue/{queue}/` | Create a named queue |
| DELETE | `…/wd-queue/{queue}/messages/{message_number}` | Delete a specific message |

### Key Characteristics

- **Ordered delivery:** Messages are retrieved in sequence order.
- **Exactly-once processing:** Each message is delivered only once via the `fresh` endpoint.
- **Auto-create:** POST to a non-existent queue creates it automatically.
- **Capacity limits:** Subject to tenant-level capacity and data retention limits.
- Does **not** implement WS-ReliableMessaging.

### Response Behaviour

- If no messages exist on the queue: returns an empty XML document.
- If the queue does not exist: returns HTTP 404.

---

## 16. OAuth 2.0 Bearer Token Authentication

### When to Use

When launching integrations programmatically (Launch API or Listener API) and you want OAuth 2.0 instead of Basic Auth. Workday recommends OAuth for increased security.

### Setup Steps

#### 1. Register an API Client

| Setting | Value |
|---------|-------|
| Client Grant Type | Authorization Code Grant |
| Support PKCE | Selected |
| Access Token Type | Bearer |
| Redirection URI | A valid redirect (e.g. `https://example.com`) |
| Grant Administrative Consent | Selected |
| Scopes | Implementation, Integration, System, Tenant Non-Configurable |

Record: **Client ID**, **Authorization Endpoint**, **Token Endpoint**.

#### 2. Generate PKCE Values

Use a PKCE code generator to produce:
- **Code Verifier** (random string)
- **Code Challenge** (SHA-256 hash of the verifier, base64url-encoded)

#### 3. Obtain Authorization Code

Construct the URL:
```
{Authorization Endpoint}?client_id={Client ID}&response_type=code&code_challenge={Challenge}&code_challenge_method=S256
```

Open in a browser, approve access. Extract the `code` parameter from the redirect URL.

#### 4. Exchange for Bearer Token

POST to the Token Endpoint:
```
POST {Token Endpoint}
Content-Type: application/x-www-form-urlencoded

grant_type=authorization_code
code={Authorization Code}
client_id={Client ID}
code_verifier={Code Verifier}
redirect_uri={Redirect URI}
```

Response returns `access_token` (bearer token) and `token_type: Bearer`.

#### 5. Use the Token

Include in API calls:
```
Authorization: Bearer {access_token}
X-Tenant: {tenant_name}
Content-Type: text/plain; charset=utf-8
```

### Token Lifecycle

- Bearer tokens expire after a period defined by the tenant configuration.
- Re-obtain by repeating steps 3–4 when the token expires.
- Store tokens securely; never commit to source control.

---

## Quick Reference: API Endpoint Patterns

| API | Base Path | Method | Purpose |
|-----|-----------|--------|---------|
| My Reports | `/ccx/cc-blobitory/{tenant}/{collection}/{doc_id}` | GET | Retrieve integration output documents |
| Launch | `/ccx/cc-cloud-repo/launches/{collection}/{integration}/{wid}` | GET | Launch a Studio integration |
| Listener | `/ccx/cc-cloud-repo/launches/{collection}/{integration}/{wid}` | POST | Send a message to a Listener-enabled integration |
| Message Queue | `/ccx/wd-queue/{queue_name}` | GET/POST/PUT/DELETE | Manage queued messages |

**All APIs require:**
- Authentication (Basic Auth or OAuth 2.0 Bearer Token)
- `X-Tenant: {tenant_name}` header
- Tenant-specific host URL (varies by data centre — refer to Workday Data Centers on Community)
