# AUnit Testing Reference

AUnit is Workday Studio's built-in unit testing framework, extending JUnit. It allows testing assembly logic locally without deploying to a tenant.

Source: [Workday Community — AUnit Quick Start Guide](https://community-content.workday.com/en-us/kits-and-tools/products/platform-and-product-extensions/integrations/aunit-quick-start-guide.html) and related sub-pages.

## When to use AUnit

- Simulating vendor endpoints locally (essential on VCR where external access is blocked)
- Testing XSLT transformations with sample data (CSV → XML, XML → CSV, etc.)
- Debugging integrations with Custom Object services
- Validating change detection and error handling paths
- Regression testing after XSLT or assembly changes

## Project setup

### Add JUnit Library

1. Right-click the project in Project Explorer
2. Select **Add JUnit Library**

This adds the JUnit library that AUnit extends. Not needed if the project already has AUnit tests (e.g. SSK-based projects).

### Create source and test folders

AUnit requires a **test source folder** for Java test classes, separate from the assembly source:

1. Right-click the project → **Properties** → **Java Build Path** → **Source** tab
2. Click **Add Folder** → create a new folder (e.g. `test`) → select it
3. The folder appears in Project Explorer alongside the assembly source

**Recommended folder structure:**

```
MyProject/
├── assembly.xml
├── assembly-diagram.xml
├── WSAR-INF/
│   └── (XSLT files, etc.)
├── ws/
│   └── test/
│       ├── Get_Integration_Systems_Response.xml
│       ├── Launch_Integration_Response.xml
│       └── (sample vendor data files)
└── test/                          ← test source folder
    └── com/workday/myproject/
        └── SampleTestCase.java
```

## Mock data

AUnit tests run locally and need mock data to simulate the tenant environment.

### Required mock files

| File | Purpose | Location |
|---|---|---|
| `Get_Integration_Systems_Response.xml` | Integration attributes, maps, attachment services | `ws/test/` |
| `Launch_Integration_Response.xml` | Launch parameters, event context | `ws/test/` |
| Sample vendor data (CSV, XML, JSON, etc.) | Input data for transformation testing | `ws/test/` or `test/` |
| Sample RaaS/WWS responses | Mock Workday API responses | `ws/test/` |

### How to obtain mock data

1. **Create a minimal Studio assembly** with the required attributes, maps, and launch parameters
2. **Deploy** the minimal assembly to a tenant (sandbox or GMS)
3. **Configure** attributes, maps, and report services in the tenant
4. **Get the Integration System WID** from the tenant (View Integration System → WID in URL or related actions)
5. **Call `Get_Integration_Systems`** with the WID and save the response as `ws/test/Get_Integration_Systems_Response.xml`
6. **Build a `Launch_Integration` request** matching the launch parameters and save the response as `ws/test/Launch_Integration_Response.xml`

**Important:** Remove all PII from generated mock files before committing to source control.

Quick alternative: copy mock files from an existing AUnit project (e.g. Workday's AUnit101 sample) and adapt.

## Writing test classes

### Basic test class structure

```java
import com.workday.aunit.annotations.AssemblyTest;
import com.workday.aunit.annotations.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import junit.framework.TestCase;

@AssemblyTest(project = "MyProjectName")
public class SampleTestCase extends TestCase {

    protected MediationContext ctx = null;

    /**
     * Runs before each test method.
     * Loads mock integration system and launch event data.
     */
    public void setUp() throws Exception {
        this.setIntegrationSystem("ws/test/Get_Integration_Systems_Response.xml");
        this.setIntegrationLaunchEvent("ws/test/Launch_Integration_Response.xml");
    }

    /**
     * Test CSV-to-XML conversion in the ProcessData mediation.
     * Starts execution at the ProcessData async-mediation.
     */
    @ComponentMethod(value = "ProcessData")
    public void testProcessData() throws Exception {
        // Load sample CSV onto message root part
        this.setMessagePart(0, "test/SampleData.csv", "text/csv");
    }
}
```

### Key annotations

| Annotation | Purpose |
|---|---|
| `@AssemblyTest(project = "Name")` | Declares the class as an AUnit test for the named project |
| `@ComponentMethod(value = "MediationName")` | Test method starts execution at the specified mediation/async |

### Key methods

| Method | Purpose |
|---|---|
| `this.setIntegrationSystem("path")` | Load mock `Get_Integration_Systems` response |
| `this.setIntegrationLaunchEvent("path")` | Load mock `Launch_Integration` response |
| `this.setMessagePart(index, "path", "mimeType")` | Set message part content from a file |
| `ctx.getProperty("propName")` | Read a mediation context property |

### Common MIME types for `setMessagePart`

| Type | MIME |
|---|---|
| CSV | `text/csv` |
| XML | `text/xml` |
| JSON | `application/json` |
| Plain text | `text/plain` |

## Running and debugging tests

### Run a single test

- Open the test Java file → right-click the test method name → **Debug As** → **AUnit Test**
- Or: Project Explorer → expand test source folder → right-click the test class → **Debug As** → **AUnit Test**

### Run all tests

- Right-click the test source folder or a specific package → **Debug As** → **AUnit Test** to run all tests in that scope

### Debugging

- Set **breakpoints** on assembly components (e.g. XSLT+, mediation steps) before launching the test
- Studio stops at breakpoints, allowing inspection of:
  - **Message Root Part** — the current message content at that step
  - **Properties** — mediation context properties
  - **Variables** — mediation variables
- Use **Step Over** (F6) to advance through assembly steps
- The **Debug perspective** provides message inspection, variable views, and console output
- Relaunch previous debug sessions from the Debug perspective without re-navigating to the test class

### Benefits over deploy-and-test cycle

- No deployment required — test locally
- Works on VCR (no external network access needed)
- Breakpoints show intermediate state at each assembly step
- Catch regressions immediately after code changes

## Enhanced test patterns

### AssertAfter — validating output

Use `AssertAfter` to validate the message content after a component executes, ensuring transformations produce expected output:

```java
@ComponentMethod(value = "ProcessData")
public void testProcessDataWithValidation() throws Exception {
    this.setMessagePart(0, "test/SampleData.csv", "text/csv");
    // After execution, assert on the output
}
```

Compare actual output against expected output using DOM-based comparisons or string matching.

### Mocking endpoints — Action.Type enum

Mock external endpoints (HTTP, web service calls) using `Action.Type`:

| Action | Behaviour |
|---|---|
| `Action.Type.continue_to_next` | Skip the component and continue to the next step |
| `Action.Type.invokeTerminate` | Simulate a failure at this component |
| `Action.Type.mock_exception` | Inject an exception to test error handling paths |

This is essential for testing integrations that call external vendor endpoints — mock the HTTP-out or WS call with `continue_to_next` and provide sample response data instead.

## Best practices

- **Scrub all PII** from mock data files before committing
- **Test each mediation independently** — use `@ComponentMethod` to start at specific points
- **Keep mock data minimal** — only include the attributes, maps, and fields the integration actually uses
- **Run AUnit tests after every assembly or XSLT change** to catch regressions
- **Name test classes descriptively** — match the mediation or scenario being tested (e.g. `TestProcessDataCsvConversion`, `TestErrorHandlingPath`)
- **Store mock data conventionally** — use `ws/test/` for integration system/launch data and `test/` for vendor sample data
