# AMS-AI-Config

This repository teaches GitHub Copilot how to build Workday integrations the way our team builds them — following our naming standards, error-handling patterns, and coding conventions. When a developer opens a Workday project alongside this folder in VS Code, Copilot can review their work, generate code, and answer questions with integration-specific knowledge it would not otherwise have.

**Current coverage:**
- **Standalone XSLTs** — transformations used in EIB, Document Transform, and Multi-Document Transform integrations
- **Workday Studio** — full assembly design, MVEL expressions, Java custom beans, deployment lifecycle, and monitoring

The net effect is faster, more consistent integration delivery with fewer review cycles.

### Getting Started (for developers)

Add this repo as a workspace folder alongside your integration projects to enable the customizations.

## Setup

1. Clone this repo locally
2. Open VS Code
3. **File → Add Folder to Workspace** → select your Studio integration folder
4. **File → Add Folder to Workspace** → select this `AMS-AI-Config` folder
5. Both folders should now be visible in the Explorer sidebar
6. **File → Save Workspace As** → save for easy re-opening next time

## What's Included

### Always-On Instructions (every interaction)
- General principles (no PII in code or test data, keep it simple for maintainability, prefer built-in Workday features over custom logic, consider Orchestrate before writing new XSLTs)
- Error handling requirements (global handler, mediation error patterns, `context.errorMessage`, cleanString)
- MVEL best practices (MVEL 1.3, Expression vs Template Capable, `#` concatenation, typed properties, `empty` literal)
- Property assignment rules (typed literals, null over empty string)
- XSLT version guidance (3.0 with XSLT+ for Studio, 2.0 for EIB/DT, MDT consideration)
- Integration lifecycle awareness (deployment, ISU, launch, monitoring)

### File-Specific Instructions (auto-loaded)

| File | Activates when editing | Content |
|------|----------------------|---------|
| `xsl-standards` | Any `.xsl` file | XSLT coding standards, XSLT+ component, Saxon version table, streaming, padding functions, date arithmetic, decimal rounding, regex, JSON with XSLT 3.0, MDT, EBCDIC, identity transform, namespace normalization, integration mapping functions, unit testing |
| `assembly-patterns` | `assembly.xml` | Diagram layout, swimlanes, mediation structure, error handling, message merging, DIS patterns, BOM handling, Integration Attachment Service, custom components/modules, parent process integration |
| `java-beans` | `assembly.xml`, `.java` files | When to use beans, annotations, MediationContext API, assembly integration, project configuration, third-party JARs, HTTP/PDF/fixed-width patterns |
| `naming-conventions` | On-demand (naming tasks) | Tenant object naming, technology abbreviations, property prefixes |
| `studio-lifecycle` | On-demand (deploy/launch/monitor) | Deployment, ISU config, launching, monitoring, troubleshooting |

When editing `assembly.xml`, Copilot also **auto-loads** the following reference files — no skill invocation needed:

| Reference | Content |
|-----------|---------|
| Element Catalog | Exact XML syntax for every `cc:` and `cloud:` element: transports (Workday, HTTP, FTP, SFTP, email), mediations, flow control (route, splitter, aggregator), 30+ step types, JSON components (JSON-to-XML, XML-to-JSON, JSON Transformer), XSLT+ with parameter types and schema validation, integration services, and prepackaged subassemblies |
| MVEL Reference | 22-section guide: property access, typed literals, `cleanString`, `intsys`/`lp`/`da` helpers, date formatting, string manipulation, control flow (`@if`/`@foreach`), HashMap patterns, JSON handling, splitter counts, custom Java/JARs, type discovery, URI encoding, troubleshooting |
| Java Beans Guide | Bean anatomy, `@Component`/`@ComponentMethod` annotations, `cc:custom` integration, project config, third-party JARs, 3 production patterns (HTTP header control, PDF processing, fixed-width parsing) |
| OAuth / REST Patterns | Client Credentials flow, Bearer token, JSON handling, conditional routing |
| Assembly Diagram Guide | `@mixed` indexing, connections, swimlanes, add/remove/rename checklists |
| Annotated Stub Template | Full commented assembly.xml starter template used by the `/create-studio-skill` |

### MVEL Skill (on-demand)
Type `/mvel-studio-skill` in Copilot Chat followed by your question:
- `/mvel-studio-skill how do I access a multi-instance launch parameter?`
- `/mvel-studio-skill what's the syntax for a HashMap?`
- `/mvel-studio-skill how do I format a date?`

### Studio Creation Skill (on-demand)
Type `/create-studio-skill` in **Plan mode** when creating a brand-new Studio integration from scratch:
- `/create-studio-skill create a new Studio that calls a REST API with OAuth 2.0`
- `/create-studio-skill create an outbound integration that posts CSV to a vendor SFTP`

> **Note:** For editing or reviewing *existing* integrations, just open `assembly.xml` — the references load automatically. Reserve `/create-studio-skill` for greenfield builds.

## Example Prompts

- *"Review this assembly.xml for convention violations"*
- *"Add error handling to this mediation"*
- *"Create a new Studio integration that posts CSV to a vendor REST API"*
- *"Add an OAuth 2.0 token flow to this integration"*
- *"Add a file header to this XSL"*
- *"What should I name this new integration system?"*
- *"Help me write an MVEL expression to get integration attributes"*
- *"The http-out component won't set Content-Length correctly — how do I fix this?"*
- *"I need to parse a fixed-width text file in Studio"*

## Defaults

- **Assembly version**: `2025.21` — Copilot will ask which version to target when creating new integrations
- **XSLT version**: 3.0 for Studio, 2.0 for EIB/Document Transform
- **Workday terminates** integrations exceeding 2 hours

## Updating

Edit files under `.github/`, commit, and push. Team members pull — changes take effect immediately.

## Troubleshooting

- **Rules not loading?** Confirm `AMS-AI-Config` is visible in the Explorer sidebar as a workspace folder
- **Slash command missing?** Type `/` in chat and look for `mvel-studio-skill`
- **Wrong conventions?** Check `applyTo` patterns in the `.instructions.md` frontmatter

## Contributing Knowledge

Copilot will detect when you share new Workday Studio knowledge during a conversation (undocumented behaviour, community tips, support case findings). If the knowledge is new and doesn't conflict with existing guidance, Copilot will offer to add it to the appropriate reference file — keeping the knowledge base growing without overwriting existing content.

Target files by topic:

| Topic | File |
|-------|------|
| MVEL patterns | `mvel-reference.md` |
| XSLT techniques | `xsl-standards.instructions.md` |
| Assembly patterns | `assembly-patterns.instructions.md` |
| Element syntax | `assembly-element-catalog.md` |
| Java bean patterns | `java-beans.instructions.md` |
| Lifecycle/deployment | `studio-lifecycle.instructions.md` |
| Naming rules | `naming-conventions.instructions.md` |
