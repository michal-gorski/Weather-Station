# Workday Studio Integration Standards

This workspace contains Workday Studio integrations. The following conventions apply to all work.

## General Principles

- Before starting a new XSLT transformation, consider whether Workday Orchestrate is more appropriate
- NEVER use personally identifiable information (PII) in XSLT, test data, or code comments. Use scrubbed/anonymized data
- Keep it simple — code is not a contest. Customers and less experienced consultants will need to maintain your work
- Do not reinvent the wheel — use standard XSLT/XPath functions and built-in Workday features before writing custom logic
- After making file changes, generate a short GitHub commit summary and message describing what was changed

## Error Handling

Error handling is critical. Integrations must provide sufficient error messages for end users to diagnose and resolve issues without developer assistance.

### Required Patterns

- **All integrations must have a global error handler** linked to a `PutIntegrationMessage` step with severity `CRITICAL`
- **Set error handlers on all asynchronous and synchronous mediations** — extract the error, report it via `PutIntegrationMessage`, then trap or rethrow as appropriate
- Use this MVEL to extract error details: `props['p.error.message'] = util.cleanString(context.errorMessage)`
  - `cleanString` prevents invalid XML characters from causing "invalid Rich Text internal syntax" errors in `PutIntegrationMessage`
- **Never build "all or nothing" integrations** — a single bad transaction must not fail the entire integration. Report the error/warning for that transaction and continue processing
- Think through what "Completed", "Completed with Errors", and "Completed with Warnings" mean for your integration and design error handling accordingly

### Terminating Processing

- Use `context.setAbort(true)` to terminate processing — flow returns to the last `local-out` without `Propagate Abort = false`
- Once using `setAbort`, set `Propagate Abort = true` on all `local-out` transports except where you explicitly want to intercept an abort

## MVEL Best Practices

- Workday uses **MVEL 1.3** — not MVEL 2.x
- Two MVEL property types exist: **Expression Capable** (plain MVEL, no `@{}`) and **Template Capable** (must wrap in `@{}`)
- Use `#` for string concatenation (not `+` which risks numeric addition)
- Keep expressions small and concise — simple property assignment and computation only
- Use ternary `IF/THEN/ELSE` for simple conditionals: `x == true ? true : false`
- Use `empty` literal to check for null, 0-length, whitespace, or boolean: `props['value'] != empty ? props['value'] : null`
- Break complex expressions into multiple simpler expressions
- When faced with heavily nested XPath or method invocations, consider XSLT, Custom Beans, or Static Methods instead of MVEL
- When `cc:http-out` cannot set headers correctly, or when the task requires binary file handling, PDF processing, fixed-width parsing, or Java libraries — suggest a **Java custom bean** (see `java-beans.instructions.md`)
- **Do NOT** use `xpathF` or `parts[0].text` on large messages (1,000,000 char limit)
- **Do NOT** use `xpath` or `xpathB` in MVEL template `@if` conditions — parsing large documents as DOM has severe performance overhead

## Property Assignment

- Always use strongly typed context properties
- Use MVEL literal numbers and booleans, and `ParsedIntegrationSystem` typed methods:
  - `props['pi.count'] = 0` (not `'0'`)
  - `props['pi.enabled'] = true` (not `'true'`)
  - `props['ia.full.extract'] = intsys.getAttributeAsBoolean('Full Extract')`
- Use MVEL `null` literal instead of empty string `''` for empty values
- Simplicity is key — do not store data in Java constructs, properties, or variables unnecessarily

## Assembly Version

- Default assembly version for new integrations: **2025.21** (`<cc:assembly id="WorkdayAssembly" version="2025.21">`)
- When creating a new Studio integration, ask the user which version to target if not specified
- All projects within a collection must use the same assembly version

## XSLT Version Selection

- **Studio**: Always use XSLT 3.0 with the **XSLT+ component** (not legacy XSLT step) unless compatibility with EIB or Document Transform is required
- **EIB / Document Transform**: Use XSLT 2.0
- **XSLT 1.0 must not be used**
- Consider **Multi Document Transformation (MDT)** when EIB/DT is almost sufficient but needs multiple inputs, multiple outputs, or dynamic file naming — avoids writing custom Studio code
- **XSLT 1.0 must not be used**

## Integration Lifecycle

Understand the full lifecycle: **Create Project → Build Assembly → Deploy → Configure ISU → Launch → Monitor**

- Every deployed integration requires an **Integration System User (ISU)** for authentication
- The ISU must be a member of appropriate security groups (Deploy, Launch, Business Process)
- Never store passwords or secrets directly in assemblies — the CLAR is encrypted but configure sensitive values in the Workday tenant
- Workday terminates integrations that exceed **2 hours** execution time
- Use the **Consolidated Report Viewer** for step-by-step performance and error analysis
- Lifecycle details auto-load from the `studio-lifecycle` instruction when discussing deployment, ISU, launch, or monitoring topics

## Skills & References

- **Assembly & MVEL references auto-load** when editing `assembly.xml` — Copilot will read the element catalog, MVEL reference, OAuth/REST patterns, and diagram guide as needed without manual invocation
- XSL-specific standards auto-load when editing `.xsl` files
- Assembly-specific patterns auto-load when editing `assembly.xml`
- Java custom bean standards auto-load when editing `assembly.xml` or `.java` files — covers bean anatomy, MediationContext API, project configuration, and when to recommend beans over built-in components
- To **create a brand-new Studio integration from scratch**, invoke the `/create-studio-skill` skill in Plan mode — this provides the full annotated stub template
- For standalone MVEL help outside of assembly context, invoke the `/mvel-studio-skill` skill

## Knowledge Contribution

When the user shares Workday Studio knowledge during a conversation — such as undocumented behaviour, new patterns, useful techniques, or corrections from Workday Community or support cases — Copilot should:

1. **Detect** the new knowledge: if the user provides a Studio fact, pattern, or technique that is not already covered in the existing instructions, references, or skills, flag it
2. **Validate** it does not contradict existing guidance. If there is a conflict, ask the user to confirm before making changes
3. **Suggest** contributing the knowledge back by offering to update the appropriate file in AMS-AI-Config:
   - MVEL patterns → `mvel-reference.md`
   - XSLT techniques → `xsl-standards.instructions.md`
   - Assembly patterns → `assembly-patterns.instructions.md`
   - Element syntax → `assembly-element-catalog.md`
   - Java bean patterns → `java-beans.instructions.md`
   - Lifecycle/deployment → `studio-lifecycle.instructions.md`
   - Naming rules → `naming-conventions.instructions.md`
4. **Augment only** — new knowledge should be added in the appropriate section without rewriting or removing existing content
5. Keep contributed content in the same style and format as the surrounding material
