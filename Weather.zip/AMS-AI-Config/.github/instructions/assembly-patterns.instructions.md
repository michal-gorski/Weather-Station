---
description: "Use when editing, reviewing, or creating Workday Studio assembly.xml files. Covers assembly diagram layout, error handling patterns, mediation structure, MVEL expression standards, property assignment, integration attributes, and setAbort patterns."
applyTo: "**/assembly.xml"
---

# Assembly.xml Patterns for Workday Studio

## Auto-Load Reference Files

When working on assembly.xml, **read the following reference files as needed** — do not wait for the user to invoke a skill:

| Task | Reference file to read |
|---|---|
| Adding, modifying, or reviewing assembly components (mediations, transports, steps) | `.github/skills/create-studio-skill/references/assembly-element-catalog.md` |
| Writing or debugging MVEL expressions, cc:eval blocks, property evaluations, conditional routing | `.github/skills/mvel-studio-skill/references/mvel-reference.md` |
| Working with OAuth, REST APIs, HTTP-out, Bearer tokens, JSON responses, or splitter patterns | `.github/skills/create-studio-skill/references/oauth-rest-patterns.md` |
| Creating or debugging Java custom beans, cc:custom steps, project config for beans, third-party JARs | `.github/instructions/java-beans.instructions.md` |
| Updating assembly-diagram.xml after structural changes | `.github/skills/create-studio-skill/references/assembly-diagram-guide.md` |

Read the relevant file(s) with `read_file` before making changes. Multiple files may apply to a single task.

## Assembly Version

- Default version for new integrations: **2025.21** (`<cc:assembly id="WorkdayAssembly" version="2025.21">`)
- When creating a new integration, ask the user which version to target if not specified
- All projects within a collection must use the same assembly version

## Domain Examples

The `.github/examples/` directory is **scaffolding only** — no example files exist yet. Do not read or reference the examples folders for integration patterns. Once populated, identify the functional domain and check for relevant examples.

## Assembly Diagram Layout

- Arrange components so messages flow **left-to-right** and **top-to-bottom**
- Break assembly into logical sub-assemblies using `local-in` and `local-out` transports — aids readability and permits isolated unit testing
- Group related components using **swimlanes** to separate functional areas
- Name every swimlane and fill in the Description property with detailed documentation
- Nest swimlanes to organize complex patterns: horizontal outer swimlane (vertical flow), vertical inner swimlanes for error handlers, sync-mediation responses, and route destinations
- Use swimlane collapsing to focus on relevant sections during development
- Add **notes** to individual components explaining important/complex processing, especially routing steps and "Execute When" conditions
- Do not have arrows that cross each other or other components — bend them around if necessary
- Add more HTTP-out or Workday-out transports if it simplifies the layout rather than routing all messages to one transport

### Diagram Maintenance (assembly-diagram.xml)

When adding or removing components in `assembly.xml`, the companion `assembly-diagram.xml` must also be updated:

- **visualProperties**: Every component needs a `<visualProperties x="..." y="...">` entry with coordinates that place it logically in the diagram
- **swimlanes**: New components must be added to the appropriate `<swimlanes>` element via `<elements href="assembly.xml#ComponentId"/>`
- **connections**: Route connections (`type="routesTo"` or `type="routesResponseTo"`) must be added or updated to reflect the new routing in `assembly.xml`
- **@mixed index shifts**: Some components (e.g. `send-error` within the assembly root) are referenced by positional XPath like `assembly.xml#//@beans/@mixed.1/@mixed.N/@mixed.3`. Inserting or removing an element at the assembly level shifts **all** subsequent `@mixed` indices by ±2 (one for the element, one for its adjacent whitespace text node). Recalculate all affected references when modifying the element order
- **Do NOT guess @mixed indices** — open the assembly in Workday Studio or use XML DOM parsing to verify the correct positional indices after structural changes
- **Swimlane index shifts**: Swimlanes are referenced by 0-based positional index (`#//@swimlanes.N` in child elements, `//@swimlanes.N` in the root swimlane's `elements` attribute). Inserting or removing a `<swimlanes>` element shifts all subsequent indices by ±1. **Always recalculate all swimlane index references** when adding or removing swimlanes. Getting this wrong can create circular references that break the entire diagram — Studio will render only orphaned swimlanes with the rest invisible
- **Do NOT guess swimlane indices** — count from the first `<swimlanes>` element (index 0) to verify

### Mandatory Diagram Update Workflow

**NEVER rebuild `assembly-diagram.xml` from scratch.** Always start from the existing diagram and make targeted, surgical edits. Rebuilding loses all hand-tuned coordinates, anchor positions, bendpoints, and swimlane nesting — producing a broken layout that is very difficult to recover.

Follow this exact sequence when modifying `assembly.xml` components:

1. **Edit `assembly.xml` first** — add, remove, or rename components and update all routing attributes
2. **Calculate `@mixed` indices** — run the PowerShell DOM parsing script (see `assembly-diagram-guide.md`) on the **modified** `assembly.xml` to get exact positional indices for every element. Never skip this step
3. **Read the existing `assembly-diagram.xml`** in full before making any edits — understand the current structure of visualProperties, connections, and swimlanes
4. **Make surgical edits only** — apply targeted string replacements for each change:
   - Rename: find-and-replace the old component ID in all `href` attributes (visualProperties, connections source/target, swimlanes elements)
   - Add: insert new `visualProperties`, `connections`, and `swimlanes` entries at the correct positions
   - Remove: delete the specific entries for removed components
   - Re-route: update only the affected `connections` entries (source, target, or type)
   - @mixed shifts: update every `@mixed.N` reference in connections using the verified index mapping from step 2
   - Swimlane index shifts: when adding or removing `<swimlanes>` elements, recalculate every `#//@swimlanes.N` and `//@swimlanes.N` reference — count from the first swimlane (index 0) after the edit
5. **Verify completeness** — for every `routes-to` and `routes-response-to` in `assembly.xml`, confirm a matching `connections` entry exists in the diagram. For every component with an `id`, confirm a `visualProperties` entry and a `swimlanes` membership exist

**Common mistakes to avoid:**
- Forgetting to update `connections` — the diagram will render but arrows will be missing or point to wrong targets
- Forgetting to update `swimlanes` — new components will float outside their logical group. **Every new component must be added to the swimlane that contains its logically related components** (e.g. a new routing target belongs in the same swimlane as the route that references it). Orphaned components outside swimlanes are a visual defect and indicate an incomplete diagram update
- Using stale `@mixed` indices from the old assembly — causes send-error arrows to connect to the wrong components
- Adding `visualProperties` without coordinates — components render at (0,0) and pile on top of each other
- **Using wrong swimlane indices after inserting a new swimlane** — inserting before the root swimlane shifts the root's index by +1; referencing the old root index from a parent swimlane creates a circular nesting that breaks the entire diagram (only the orphaned new swimlane renders, everything else disappears)
- **Updating `assembly.xml` without updating `assembly-diagram.xml`** — when adding any new component (mediation, transport, route destination, log step), always update the diagram in the same edit session: add `visualProperties`, add `connections`, and add the component to the correct `swimlane`. Never defer diagram updates to a later step

## Error Handling

### Global Error Handler (Required)

Every integration must have a global error handler linked to a `PutIntegrationMessage` step with severity `CRITICAL`:

```
is.message.severity = 'CRITICAL'
```

### Mediation Error Handlers

Set error handlers on **all processing** asynchronous and synchronous mediations. The error handler should:

1. Extract the error using MVEL:
   ```
   props['p.error.message'] = util.cleanString(context.errorMessage)
   ```
2. Report it to the user via `PutIntegrationMessage`
3. Trap or rethrow the error as appropriate

**Exception — catch/error-handler mediations**: Mediations that ARE error handlers (e.g. `CatchGetAttributesError`, `CatchReportError`) do **NOT** get a `cc:send-error` child. They are terminal handlers — they extract, log, and increment the error counter. If the catch mediation itself fails, the global assembly-level `cc:send-error` catches it automatically. Adding `send-error routes-to="ExtractGlobalError"` on catch mediations creates unwanted diagram arrows and is structurally incorrect.

The `Handle Downstream Errors` property controls scope:
- `false` — handles only errors within the mediation's own steps
- `true` — handles errors from any downstream mediations or transports

Use `cleanString` to prevent invalid XML characters from causing "invalid Rich Text internal syntax" errors in `PutIntegrationMessage`.

### Workday-Out Failure Messages

Use the `failure-message` property on Workday-Out transports to augment error messages:

```
An error occurred while attempting to retrieve contact details for the employee with employee id @{props['employee.id']}. Additional details:
```

The original message text will be appended automatically.

### Throwing Errors

- **MVEL Validations**: Configure with expressions that throw errors when evaluating to `false`. Customize the "Validation Message"
- **XML Validation**: Validate against XSD schema. Be careful with large messages. Use "Failure Message" and "Replace Message" properties
- **Manual**: `context.setError("Description of Error", 20001)`

### Avoid "All or Nothing"

A single bad transaction must not fail the entire integration. Report the error/warning for that transaction and continue processing. Design error handling so the final Integration Event status accurately reflects what occurred.

### Terminating Processing with setAbort

```
context.setAbort(true)
```

- Flow returns to the last `local-out` without `Propagate Abort = false`
- Once using `setAbort`, set `Propagate Abort = true` on **all** `local-out` transports except where you explicitly want to intercept an abort

## Mediation Context Properties

### Naming Conventions

Prefix properties with the integration name for scoping:

```
props['intxyz.company.name']
```

Standard prefixes:
- `ia.` — integration attributes: `props['ia.include.job.code']`
- `lp.` — launch parameters: `props['lp.paygroup.wid']`
- `p.` — processing/internal properties: `props['p.error.count']`

Property names must be **meaningful and unabbreviated**. Descriptive names reduce maintenance cost.

### Property Assignment Rules

Always use strongly typed properties:

```
// CORRECT — typed literals
props['pi.count'] = 0
props['pi.enabled'] = true
props['ia.full.extract'] = intsys.getAttributeAsBoolean('Full Extract')

// WRONG — string types
props['pi.count'] = '0'
props['pi.enabled'] = 'true'
```

- Use `null` instead of `''` (empty string) for empty values
- Do not store data in Java constructs, properties, or variables unnecessarily

### Default Values Pattern

```
props['ia.account.type'] = (intsys.getAttribute('Account type') == empty) ? 'Corporate' : intsys.getAttribute('Account type')
```

## Accessing Integration Attributes

The Workday-In transport creates the `intsys` MVEL helper automatically.

```
// Simple type
props['ia.account.id'] = intsys.getAttribute('Account ID')

// Boolean type
props['ia.include.federal.w4'] = intsys.getAttributeAsBoolean('Include Federal W-4')

// Reference type (single instance)
props['ia.profile.type'] = intsys.getAttributeReferenceData('Business Contact Profile Type', 'Communication_Usage_Type_ID')

// Integration Map
intsys.getMap('mapName').get('key')
```

In XSLT, declare the `is` namespace and call via XPath:

```xml
xmlns:is="java:com.workday.esb.intsys.xpath.ParsedIntegrationSystemFunctions"
is:getIntegrationAttributeValue('Entity Name')
```

## Message Merging

**Always use aggregators** for merging messages — never string concatenation or MVEL write approaches:

- Use `xml-content-collater` for merging XML messages
- Use `message-content-collater` for merging plain text messages
- Wrap the aggregator in a **sub-assembly** for flexibility: control collation and batching via properties exposed as sub-assembly parameters
- Call with `collate=true, batch=false` to add messages, then `collate=true, batch=true` on the last message

**Why**: Aggregators read each message once and write once, with minimal memory. String concatenation and MVEL-based writes cause exponential memory growth and can cause heap failures at scale (observed in production with 100+ file merges).

## Data Initialization Service (DIS)

- DIS generates XML documents before Studio runs — **DIS runtime does not count against the 2-hour Studio limit**
- Use `doc-iterator` to process DIS partial files; specify document tags as comma-separated: `"Data - Partial,MyServiceName"`
- For large volumes, process files in parallel using the parallel processing pattern
- Use XSLT 3.0 streaming for transforming DIS output
- DIS files are retained for 60 days; max document size is 500 MB compressed
- Use `Retrieve Technical Files` and `Generate DIS Performance Summary` related actions for troubleshooting

## Byte Order Mark (BOM) Handling

- Most assembly processing assumes UTF-8 without BOM
- Java cannot automatically detect UTF-8 BOMs or produce UTF-8 files with BOMs
- Use the community `bomHandling` custom beans (RemoveBOM/AddBOM) for reliable BOM processing
- RemoveBOM: detects and strips BOM, transcodes to UTF-8; handles files with or without BOM
- AddBOM: prepends appropriate BOM bytes for the target encoding
- Both beans stream-process messages (supports up to 15 GB)

## Integration Attachment Service

- Attach files (XSLT, CSV, ZIP) to an integration system so administrators can update without redeploying Studio code
- File content is returned base64-encoded in `Get_Integration_Systems` response
- **Do NOT use `parts[0].xpath` or `parts[0].xstream`** to retrieve file contents (1 MB limit) — use streaming XSLT instead
- Use `base64-decode` component to convert encoded content, setting the correct MIME type
- For XSLT files: set the XSLT+ URL property to `mctx:vars/variableName`

## Custom Components and Modules

- **Custom Components**: Community-built Studio components added to the palette. Import as projects, add to your collection. Current: Batch with Fallback, Messages
- **Custom Modules**: Copy/paste code templates that drop into your assembly. Configure via Window > Preferences > Workday > Assembly Editor > Modules. Available modules include blueprints (Inbound, Report REST Outbound, WS Outbound), Get Sequenced Value, Global Error Handler, Start with BP Retrieval, Start with File Retrieval, Store REST Data, WD WS Call with PagedGet

## Parent Process Integration

Report messages and documents to a packaged integration's event (e.g., CCW, PECI):

1. Create a `Business Process` launch parameter
2. Extract the WID: `props['p.parent.process.wid'] = lp.getReferenceData("Parent Process", "WID")`
3. Pass WID to `PutIntegrationMessage` via the `is.event.wid` parameter
4. Configure the BP to pass `Subject` (the parent event) as the launch parameter value at runtime

## MVEL Expression Standards

- Keep expressions small and concise — simple property assignment and computation only
- Use ternary `IF/THEN/ELSE` for simple conditionals
- Use `empty` literal to check for null, 0-length, whitespace, or boolean
- Break complex expressions into multiple simpler expressions
- When faced with heavily nested XPath or method invocations, consider XSLT, Custom Beans, or Static Methods
- **Do NOT** use `xpathF` or `parts[0].text` on large messages (1,000,000 char limit)
- **Do NOT** use `xpath` or `xpathB` in MVEL template `@if` conditions

## XSLT in Assembly

- Always use the `xslt+` step for running XSLT
- Use XSLT 3.0 unless EIB/Document Transform compatibility is required
- Do not hardcode reference IDs or WIDs — use launch parameters, attributes, or maps
- For text output, prefer TextSchema, XML_to_CSV, or XTT steps
