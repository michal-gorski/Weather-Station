---
description: "Use when creating, reviewing, or debugging Java custom beans in Workday Studio integrations. Covers bean anatomy, annotations, MediationContext API, assembly.xml integration, project configuration, third-party JARs, and when to recommend beans over built-in components."
applyTo: "**/assembly.xml,**/*.java"
---

# Java Custom Beans for Workday Studio

## When to Suggest a Java Bean

Proactively suggest a Java bean when the user encounters any of these scenarios:

| Scenario | Why a bean is needed |
|----------|---------------------|
| **`cc:http-out` cannot set headers correctly** (e.g. `Content-Length: 0`) | The HTTP transport layer overwrites or corrupts certain headers. A bean using `HttpURLConnection` bypasses the transport entirely |
| **Parsing fixed-width or positional text files** | XSLT and MVEL have no built-in positional substring support for non-XML inputs. Java `String.substring()` and `BufferedReader` are purpose-built for this |
| **Extracting text or data from PDFs** | Requires a third-party library (e.g. Apache PDFBox). Cannot be done in XSLT or MVEL |
| **Splitting a multi-record PDF into individual documents** | PDFBox `Splitter` class handles page-level splitting; results stored in context variables for downstream processing |
| **Complex binary file manipulation** (ZIP internals, image processing, Excel `.xlsx` generation) | Java libraries exist for all of these; XSLT/MVEL cannot handle binary formats |
| **Calling APIs that require exact control over HTTP method, body, or streaming** | `cc:http-out` abstracts away low-level HTTP details; `HttpURLConnection` gives full control |
| **Heavy string manipulation or regex beyond MVEL 1.3 capabilities** | MVEL 1.3 has limited regex support and no `Pattern`/`Matcher`; Java provides the full `java.util.regex` API |
| **Performance-critical loops over large datasets** | MVEL is interpreted; compiled Java runs significantly faster for tight loops |
| **Integration with proprietary or niche file formats** | If a Java library exists for the format, a bean can wrap it |

**Do NOT suggest a bean when:**
- The task can be accomplished with standard XSLT, MVEL, or built-in assembly components
- The user just needs conditional routing, property manipulation, or XML transformation
- The complexity can be handled by breaking MVEL into multiple simpler `cc:eval` steps

## Bean Anatomy

### Annotations

Every bean class requires two annotations from the `com.capeclear.assembly.annotation` package:

```java
import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import static com.capeclear.assembly.annotation.Component.Type.*;

@Component(
    name = "MyBeanName",          // Display name in Studio Assembly Editor
    type = mediation,             // Always use 'mediation' for processing beans
    scope = "prototype",          // Always "prototype" — new instance per invocation
    toolTip = "Brief description" // Shown on hover in Assembly Editor
)
public class MyBeanName {

    @ComponentMethod
    public void process(MediationContext ctx) throws MediationException, IOException {
        // Bean logic here
    }
}
```

- `scope = "prototype"` is **mandatory** — singleton beans share state across invocations and cause concurrency bugs
- `type = mediation` is the standard type for processing beans used as `cc:custom` steps
- Optional icon attributes: `smallIconPath = "icons/MyBean_16.png"`, `largeIconPath = "icons/MyBean_24.png"` — place PNGs in `src/icons/`

### Method Signatures

Three valid signatures exist. **Prefer the MediationContext signature** — it is cleaner and provides direct access to all context objects:

**Preferred — MediationContext parameter:**
```java
@ComponentMethod
public void process(MediationContext ctx) throws MediationException, IOException {
    String value = (String) ctx.getProperty("p.my.property");
    ctx.setProperty("p.result", computedValue);
}
```

**Alternative — InputStream/OutputStream (legacy pattern):**
```java
@ComponentMethod
public void process(java.io.InputStream in, java.io.OutputStream out)
        throws MediationException, IOException {
    // Must obtain context manually:
    MediationContext ctx = MediationTube.getCurrentMediationContext();
    // Read from 'in', write to 'out' for message body manipulation
}
```

**Alternative — byte array (legacy pattern):**
```java
@ComponentMethod
public byte[] process(byte[] arg0) throws MediationException, IOException {
    // Message body passed as bytes, return modified bytes
    MediationContext ctx = MediationTube.getCurrentMediationContext();
    // Process arg0, return result as byte[]
    return arg0;
}
```

The InputStream/OutputStream and byte[] signatures are useful when the bean needs to directly read/write the message body (the `rootpart`). For most use cases, the MediationContext signature is sufficient because you can access message content via variables and properties.

### Static Method Pattern (MVEL invocation)

Beans can also expose **static methods** callable from MVEL `cc:eval` expressions instead of through `cc:custom`. This is useful for utility functions:

```java
public class MyUtility {
    public static String doSomething() {
        MediationContext ctx = MediationTube.getCurrentMediationContext();
        String input = (String) ctx.getProperty("p.input");
        // process...
        ctx.setProperty("p.output", result);
        return result;
    }
}
```

Called from MVEL:
```xml
<cc:eval id="CallUtility">
    <cc:expression>MyUtility.doSomething()</cc:expression>
</cc:eval>
```

The bean still needs a `<bean>` definition in `assembly.xml` and the class must be on the classpath. **Prefer `cc:custom` over static methods** — it is more visible in the assembly diagram, has proper error handler support, and does not require MVEL knowledge to maintain.

### Key Imports

```java
// Always needed
import com.capeclear.assembly.annotation.Component;
import com.capeclear.assembly.annotation.ComponentMethod;
import com.capeclear.mediation.MediationContext;
import com.capeclear.mediation.MediationException;
import static com.capeclear.assembly.annotation.Component.Type.*;

// For accessing variables (stored files, documents)
import com.capeclear.mediation.impl.DataHandlerSource;

// For InputStream/OutputStream or byte[] signature only
import com.capeclear.mediation.impl.cc.MediationTube;

// For storing results back into variables
import javax.xml.transform.stream.StreamSource;

// For large temporary data (avoids OutOfMemoryError)
import com.capeclear.capeconnect.attachments.io.FileBackedManagedData;

// For server-side logging (visible in Consolidated Report)
import com.capeclear.logger.LogControl;
import com.capeclear.logger.Logger;
```

### MediationContext API — Common Operations

```java
// Properties — read and write
String val = (String) ctx.getProperty("p.my.prop");
ctx.setProperty("p.result", someValue);
ctx.removeProperty("p.temp.value");

// Variables — read (files, documents stored with cc:copy)
DataHandlerSource dhs = (DataHandlerSource) ctx.getVariables().getVariable("v.my.file");
InputStream fileStream = dhs.getInputStream();

// Variables — check existence and remove
boolean exists = ctx.getVariables().containsKey("v.my.file");
ctx.getVariables().remove("v.temp.data");

// Variables — write (store results for downstream components)
ByteArrayOutputStream baos = new ByteArrayOutputStream();
// ... write data to baos ...
InputStream resultStream = new ByteArrayInputStream(baos.toByteArray());
StreamSource source = new StreamSource(resultStream);
ctx.getVariables().setVariable("v.output", source, "application/octet-stream");

// Variables — write large data (file-backed, avoids OutOfMemoryError)
FileBackedManagedData fbmd = new FileBackedManagedData("text/xml");
ctx.addDisposable(fbmd); // ensures cleanup after integration completes
OutputStream largeOut = fbmd.getOutputStream();
// ... write large data to largeOut ...
largeOut.close();
ctx.getVariables().setVariable("v.large.output", new DataHandlerSource(fbmd.getDataSource()), "text/xml");

// Message body — read as stream
InputStream msgBody = ctx.getMessage().getInputStream();

// Message body — read as text (convenient for small text payloads)
String bodyText = ctx.getMessage().getRootPartAsText();

// Message body — check if empty
boolean isEmpty = ctx.getMessage().isNullPart(0);

// Message body — MIME type
String mimeType = ctx.getMessage().getMimeType(0);

// HTTP response headers — read all headers from HttpURLConnection
Map<String, List<String>> responseHeaders = conn.getHeaderFields();
for (Map.Entry<String, List<String>> entry : responseHeaders.entrySet()) {
    // entry.getKey() = header name, entry.getValue() = header values
}

// Server logging — visible in Consolidated Report Viewer
Logger log = LogControl.getLogger(getClass());
log.info("Processing started");
log.error("Failed to connect", exception);

// Throw errors that Studio error handlers can catch
throw new MediationException("Descriptive error message with context");
```

### Error Handling in Beans

- **Always throw `MediationException`** for errors — this integrates with Studio's `cc:send-error` handlers
- Include sufficient detail in the exception message for end users to diagnose the issue
- Clean up resources (streams, connections) in `finally` blocks
- Do NOT silently swallow exceptions — the integration must know something failed

```java
try {
    // operation
} catch (SomeException e) {
    throw new MediationException("Failed to process file: " + e.getMessage());
} finally {
    if (connection != null) connection.disconnect();
}
```

## Assembly Integration

### Step 1 — Add `cc:custom` step inside a mediation

The `cc:custom` element references the bean by its Spring bean ID (not the class name):

```xml
<cc:async-mediation id="ProcessData" routes-to="NextStep">
    <cc:eval id="SetupBeanInputs">
        <cc:expression>props['p.my.input'] = 'some value'</cc:expression>
    </cc:eval>
    <cc:custom id="RunMyBean" ref="myBeanId"/>
    <cc:send-error routes-to="HandleError"/>
</cc:async-mediation>
```

**Attributes on `cc:custom`:**

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID (descriptive name) |
| `ref` | Yes | Spring bean ID (must match `<bean id="...">`) |
| `input` | No | `rootpart`, `variable`, `message`, `soapbody`, `attachment` |
| `input-variable` | No | Variable name when `input="variable"` |
| `output` | No | Same options as input |
| `output-variable` | No | Variable name when `output="variable"` |
| `method-name` | No | Defaults to `process` — only set if method has a different name |

When using the MediationContext signature, `input`/`output` attributes are typically omitted — the bean reads from properties and variables directly.

### Step 2 — Register the Spring bean definition

Place the `<bean>` element **between `</cc:assembly>` and `</beans>`** (never inside `<cc:assembly>`):

```xml
    </cc:assembly>

    <bean id="myBeanId" class="com.kainos.MyBeanName" scope="prototype"/>

</beans>
```

- `id` must match the `ref` attribute on `cc:custom`
- `class` is the fully qualified Java class name
- `scope="prototype"` is mandatory (matches the `@Component` annotation)

**Spring property injection** — for configurable beans, use `<property>` elements to inject values without needing MVEL setup:

```xml
<bean id="myBeanId" class="com.kainos.MyBeanName" scope="prototype">
    <property name="blockSize" value="200"/>
    <property name="targetEncoding" value="UTF-8"/>
</bean>
```

The bean must have matching setter methods or fields:
```java
private int blockSize = 100; // default
public void setBlockSize(int blockSize) { this.blockSize = blockSize; }
```

This is standard Spring XML injection — useful for beans reused across integrations with different configuration.

### Step 3 — Pass data to the bean via properties

Set properties in a `cc:eval` step before the `cc:custom` step. This keeps the bean generic and reusable:

```xml
<cc:eval id="SetupBeanInputs">
    <cc:expression>props['p.my.endpoint'] = props['p.base.url'] # '/api/resource'</cc:expression>
    <cc:expression>props['p.my.flag'] = true</cc:expression>
</cc:eval>
<cc:custom id="RunMyBean" ref="myBeanId"/>
```

The bean reads these properties via `ctx.getProperty("p.my.endpoint")`.

## Project Configuration

### Source folder structure

```
MyProject/
├── src/
│   └── com/
│       └── kainos/           (or your package)
│           └── MyBean.java
├── ws/
│   └── WSAR-INF/
│       ├── assembly.xml
│       ├── assembly-diagram.xml
│       └── lib/              (third-party JARs go here)
│           └── some-library.jar
├── .classpath
├── .settings/
│   └── org.eclipse.wst.common.component
└── WorkdayManifest.xml
```

### .settings/org.eclipse.wst.common.component

The `/src` path **must** be included as a deploy path so compiled bean classes are packaged into the CLAR:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project-modules id="moduleCoreId" project-version="1.5.0">
    <wb-module deploy-name="MyProject">
        <wb-resource deploy-path="/" source-path="/ws"/>
        <wb-resource deploy-path="/" source-path="/src"/>
    </wb-module>
</project-modules>
```

If the project was created without a bean and `/src` is missing, **add it** — without this line, the bean classes will not be included in the CLAR and will cause `ClassNotFoundException` at runtime.

### .classpath

Standard Studio `.classpath` with bean support:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<classpath>
    <classpathentry kind="src" path="src"/>
    <classpathentry kind="con" path="org.eclipse.jdt.launching.JRE_CONTAINER"/>
    <classpathentry kind="con" path="com.capeclear.wtp.ws.container">
        <attributes>
            <attribute name="org.eclipse.jst.component.nondependency" value=""/>
        </attributes>
    </classpathentry>
    <classpathentry kind="con" path="org.eclipse.jst.server.core.container/com.workday.cloud.jst.server.runtimeTarget.wdscl/Workday Runtime">
        <attributes>
            <attribute name="owner.project.facets" value="cc.ws.cloud.assembly"/>
        </attributes>
    </classpathentry>
    <classpathentry kind="output" path="build/classes"/>
</classpath>
```

### Third-party JARs

Place JAR files in `ws/WSAR-INF/lib/`. They are automatically included in the CLAR and available at runtime in the Workday cloud.

**Known working libraries:**
- Apache PDFBox (PDF splitting, text extraction, merging)
- Standard JDK libraries (`java.net.HttpURLConnection`, `java.util.regex`, `javax.xml.*`)

**Limitations:**
- Do not use libraries that require native code or JNI — Workday cloud runs in a sandboxed JVM
- Do not use libraries that spawn threads or open server sockets
- Keep JARs small — the CLAR has size limits and large CLARs slow deployment
- Test thoroughly in a sandbox tenant before production deployment

## Common Patterns

### Pattern 1 — HTTP with exact header control

When `cc:http-out` cannot set headers correctly (e.g. `Content-Length: 0` for empty-body PUT requests):

```java
@Component(name = "CustomHttpCall", type = mediation, scope = "prototype",
    toolTip = "HTTP call with exact header control")
public class CustomHttpCall {

    @ComponentMethod
    public void process(MediationContext ctx) throws MediationException, IOException {
        String endpoint = (String) ctx.getProperty("p.request.endpoint");
        String method = (String) ctx.getProperty("p.request.method");
        @SuppressWarnings("unchecked")
        Map<String, String> headers = (Map<String, String>) ctx.getProperty("p.request.headers");
        boolean sendBody = (Boolean) ctx.getProperty("p.send.body");

        byte[] bodyBytes = new byte[0];
        if (sendBody) {
            DataHandlerSource dhs = (DataHandlerSource) ctx.getVariables().getVariable("v.request.body");
            InputStream bodyStream = dhs.getInputStream();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = bodyStream.read(buf)) != -1) baos.write(buf, 0, n);
            bodyStream.close();
            bodyBytes = baos.toByteArray();
        }

        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        try {
            conn.setRequestMethod(method);
            conn.setDoOutput(true);
            conn.setFixedLengthStreamingMode(bodyBytes.length); // Exact Content-Length

            for (Map.Entry<String, String> h : headers.entrySet()) {
                conn.setRequestProperty(h.getKey(), h.getValue());
            }

            OutputStream out = conn.getOutputStream();
            if (bodyBytes.length > 0) out.write(bodyBytes);
            out.flush();
            out.close();

            int status = conn.getResponseCode();
            ctx.setProperty("http.response.status", status);

            if (status >= 400) {
                String errBody = readStream(conn.getErrorStream());
                throw new MediationException(method + " " + endpoint + " failed: " + status + " " + errBody);
            }
        } finally {
            conn.disconnect();
        }
    }

    private String readStream(InputStream in) throws IOException {
        if (in == null) return "";
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) != -1) baos.write(buf, 0, n);
        in.close();
        return baos.toString("UTF-8");
    }
}
```

Pass headers as a `LinkedHashMap` from MVEL:

```xml
<cc:eval id="SetupHeaders">
    <cc:expression>
hm = new java.util.LinkedHashMap();
hm.put("x-ms-version", "2020-10-02");
hm.put("Authorization", "Bearer " # props['p.bearer.token']);
hm.put("Content-Length", "0");
props['p.request.headers'] = hm
    </cc:expression>
    <cc:expression>props['p.request.endpoint'] = props['p.base.url'] # '/myresource'</cc:expression>
    <cc:expression>props['p.request.method'] = "PUT"</cc:expression>
    <cc:expression>props['p.send.body'] = false</cc:expression>
</cc:eval>
<cc:custom id="CustomHttpCall" ref="CustomHttpCallBean"/>
```

### Pattern 2 — PDF processing with third-party library

When processing PDFs (splitting, text extraction, merging), use Apache PDFBox. Place the JARs in `ws/WSAR-INF/lib/`:

```java
@Component(name = "PdfProcessor", type = mediation, scope = "prototype",
    toolTip = "Split and extract text from PDF")
public class PdfProcessor {

    @ComponentMethod
    public void process(MediationContext ctx) throws MediationException, IOException {
        DataHandlerSource dhs = (DataHandlerSource) ctx.getVariables().getVariable("v.input.pdf");
        PDDocument document = PDDocument.load(dhs.getInputStream());
        try {
            Splitter splitter = new Splitter();
            List<PDDocument> pages = splitter.split(document);

            for (int i = 0; i < pages.size(); i++) {
                PDDocument page = pages.get(i);
                // Extract text
                PDFTextStripper stripper = new PDFTextStripper();
                String text = stripper.getText(page);

                // Save each page as a variable for downstream processing
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                page.save(baos);
                StreamSource source = new StreamSource(new ByteArrayInputStream(baos.toByteArray()));
                ctx.getVariables().setVariable("v.page." + i, source, "application/pdf");
                page.close();
            }
            ctx.setProperty("p.page.count", pages.size());
        } finally {
            document.close();
        }
    }
}
```

### Pattern 3 — Fixed-width file parsing

When parsing positional/fixed-width text files that XSLT and MVEL cannot handle:

```java
@Component(name = "FixedWidthParser", type = mediation, scope = "prototype",
    toolTip = "Parse fixed-width text file into XML")
public class FixedWidthParser {

    @ComponentMethod
    public void process(MediationContext ctx) throws MediationException, IOException {
        DataHandlerSource dhs = (DataHandlerSource) ctx.getVariables().getVariable("v.input.file");
        BufferedReader reader = new BufferedReader(new InputStreamReader(dhs.getInputStream(), "UTF-8"));
        StringBuilder xml = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<records>\n");

        String line;
        while ((line = reader.readLine()) != null) {
            if (line.length() < 80) continue; // skip short lines
            String empId    = line.substring(0, 10).trim();
            String name     = line.substring(10, 40).trim();
            String amount   = line.substring(40, 55).trim();
            String date     = line.substring(55, 65).trim();
            String code     = line.substring(65, 80).trim();

            xml.append("  <record>\n");
            xml.append("    <employeeId>").append(escapeXml(empId)).append("</employeeId>\n");
            xml.append("    <name>").append(escapeXml(name)).append("</name>\n");
            xml.append("    <amount>").append(escapeXml(amount)).append("</amount>\n");
            xml.append("    <date>").append(escapeXml(date)).append("</date>\n");
            xml.append("    <code>").append(escapeXml(code)).append("</code>\n");
            xml.append("  </record>\n");
        }
        reader.close();
        xml.append("</records>");

        // Store as rootpart for downstream XSLT/routing
        StreamSource source = new StreamSource(
            new ByteArrayInputStream(xml.toString().getBytes("UTF-8")));
        ctx.getMessage().setSource(source);
    }

    private String escapeXml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
```

## Proven in Production

`HttpURLConnection` and standard JDK classes are confirmed working in the Workday cloud runtime. Beans using these libraries have been deployed and running in production tenants. The Workday sandbox JVM supports:

- `java.net.HttpURLConnection` — full HTTP client with exact header and streaming control
- `java.io.*` — all standard I/O classes
- `java.util.*` — collections, regex, date formatting
- `javax.xml.*` — XML parsing, transformation, XPath
- Third-party JARs in `ws/WSAR-INF/lib/` — loaded automatically at runtime

## Common Mistakes

When reviewing or creating beans, watch for and correct these patterns:

| Mistake | Why it's wrong | Fix |
|---------|----------------|-----|
| `MediationContext ctx = MediationTube.getCurrentMediationContext()` as a **field initializer** | Executes at construction time before any mediation context exists — returns null or wrong context | Move inside the `process()` method body |
| `e.printStackTrace()` in catch blocks | Errors are silently swallowed — the integration reports success when it actually failed. Stack traces go to server logs that users cannot access | Throw `new MediationException("message: " + e.getMessage())` instead |
| Missing `@Component` annotation | Bean still works via Spring but is invisible in the Studio Assembly Editor palette and lacks metadata | Always add `@Component` with name, type, scope |
| Missing `@ComponentMethod` annotation | Studio cannot identify the entry point method | Always annotate the `process()` method |
| Hardcoded URLs or credentials in Java source | Secrets are baked into the CLAR; URLs cannot be changed per environment | Read from context properties set via integration attributes or MVEL |
| Duplicate `cc:custom id` values | XML requires unique IDs — causes diagram and routing errors | Give each `cc:custom` step a unique, descriptive ID |
| `scope="singleton"` or missing scope | Shared state across concurrent invocations causes unpredictable bugs | Always use `scope="prototype"` |
| Using `String result += line` in loops | Creates a new String object per iteration — O(n²) performance for large responses | Use `StringBuilder` |
| Using `System.out.println()` for logging | Output goes to server logs users cannot access; not visible in Consolidated Report | Use `Logger log = LogControl.getLogger(getClass())` |
| **Static fields holding customer data** | The integration server may be recycled between events without teardown — static references can leak data to the next integration run | Only use static for immutable config (e.g. MIME type maps). Store all customer data in context properties or variables |
| **Returning generic types to MVEL** | MVEL 1.3 cannot resolve Java generics (`List<String>`, `Iterator<MyType>`) | Use raw types or wrap in a non-generic helper class when values will be accessed from MVEL |

## Checklist — Adding a Bean to an Existing Integration

1. [ ] Create Java source file in `src/<package>/MyBean.java`
2. [ ] Add `@Component` and `@ComponentMethod` annotations
3. [ ] Add `<cc:custom id="..." ref="beanId"/>` step inside a mediation in `assembly.xml`
4. [ ] Add `<bean id="beanId" class="com.package.MyBean" scope="prototype"/>` after `</cc:assembly>`
5. [ ] Ensure `.settings/org.eclipse.wst.common.component` includes `<wb-resource deploy-path="/" source-path="/src"/>`
6. [ ] Ensure `.classpath` includes `<classpathentry kind="src" path="src"/>`
7. [ ] If using third-party JARs, place them in `ws/WSAR-INF/lib/`
8. [ ] Update `assembly-diagram.xml` — add `visualProperties`, `connections`, and `swimlanes` entries for the new `cc:custom` component
9. [ ] Add error handling — the mediation containing the bean should have a `cc:send-error` handler
10. [ ] Test in a sandbox tenant before production deployment
