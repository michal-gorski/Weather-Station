---
description: "Use when writing, reviewing, or debugging XSLT/XSL stylesheets for Workday integrations. Covers XSLT 2.0/3.0 coding standards, streaming patterns, performance rules, header comments, output formatting, and unit testing for EIB, Document Transform, and Studio transformations."
applyTo: "**/*.xsl"
---

# XSLT Standards for Workday Integrations

## Version Selection

- **Studio**: Use XSLT 3.0 with the **XSLT+ component** (not legacy XSLT). XSLT+ supports streaming, always uses file-backed managed data, and is the recommended step for all assemblies
- **EIB / Document Transform**: Use XSLT 2.0. EIB and Document Transform use Saxon 9.1.0.8 and do not support XSLT 3.0 features
- **XSLT 1.0 must not be used**
- Turn off the XSL Validator in Studio when developing XSLT 3.0 (spurious errors from unrecognized XSLT 3/XPath 3 features)

### Saxon Version by Assembly Version

| Assembly Version | Saxon Version |
|---|---|
| 19.0 and earlier | Saxon-B 9.1.0.8 |
| 20.0 to 2017.04 | EE 9.4 |
| 2017.05+ | EE 9.7.0.12 |

When upgrading assembly versions, rigorously test XSLTs — behavior changes between Saxon versions.

## Namespaces

- Define XML namespaces for the input document (e.g., `xmlns:wd="urn:com.workday.report/ReportName"`)
- Define a `this` namespace for local functions: `xmlns:this="urn:this-stylesheet"`
- Include an `out` namespace for text output: `xmlns:out="http://www.workday.com/integration/output"`
- For XSLT 3.0 maps: `xmlns:map="http://www.w3.org/2005/xpath-functions/map"`
- For integration mapping functions: `xmlns:is="java:com.workday.esb.intsys.xpath.ParsedIntegrationSystemFunctions"` and `xmlns:tv="java:com.workday.esb.intsys.TypedValue"`

## XSLT+ Component Parameter Types

The XSLT+ step automatically passes MediationContext properties as `xsl:param` when their Java types match:

| Java Type | XSLT Type |
|---|---|
| `java.lang.String` | `string` |
| `java.lang.Integer` | `integer` |
| `java.lang.Float` | `float` |
| `java.lang.Double` | `double` |
| `java.lang.Boolean` | `boolean` |
| `com.workday.esb.StringList` | `string` (newline-separated) |
| `org.w3c.dom.Node` | `item()` (use with care — DOM stored in memory) |

Properties with names not valid as XSLT parameters are skipped with a log warning.

## Program Header Comments

Every XSLT must include a file information header before the transformation entry point:

```xml
<!-- File Information
     Filename: XT-Sample.xsl
     Developed by: Developer Name
     Last update: 2026.04.11
     Last updated by: Developer Name

     Update Log:
     2026.04.11 AB Description of change
-->
```

Include a documentation block describing the XSLT implementation, data source type (report, API, COF), and processing approach. Include a scrubbed sample of input XML (no PII).

## Constants

Define constants before the main transformation entry point:

```xml
<xsl:variable name="NEWLINE"      select="'&#13;&#10;'"/>
<xsl:variable name="SEPARATOR"    select="','"/>
<xsl:variable name="BLANK"        select="'&#x20;'"/>
```

## Output Structure

- Begin processing with a generic match on the root element (`<xsl:template match="/">`)
- Call named templates for header records, data rows, and different record types
- When creating text output, wrap in XML using the `out` namespace to facilitate debugging:

```xml
<xsl:template name="Worker-Record">
    <out:worker>
        <!-- output fields here -->
    </out:worker>
</xsl:template>
```

## Data Types & Variables

### Use Decimals, Not Doubles

- Doubles (IEEE 64-bit) are subject to precision and rounding inaccuracies
- Use `xsd:decimal(node)` and validate with `castable as xsd:decimal`
- Beware: `fn:number(node)` returns a double

### Strongly Typed Variables

Create variables inline with `select` and `as` attributes:

```xml
<!-- CORRECT: inline, strongly typed -->
<xsl:variable name="isEnabled" select="xsd:boolean($property.enabled.param)" as="xsd:boolean"/>
<xsl:variable name="aDateValue" select="xsd:date($property.date.param)" as="xsd:date"/>

<!-- WRONG: content constructor creates text node, degrades performance -->
<xsl:variable name="isEnabled">
    <xsl:value-of select="$property.enabled.param"/>
</xsl:variable>
```

### Do NOT Use Loops in Variable Declarations

This creates a sequence of single-character text nodes causing performance degradation and memory pressure at high volumes:

```xml
<!-- WRONG -->
<xsl:variable name="pad">
    <xsl:for-each select="1 to $padLength">
        <xsl:value-of select="$chr"/>
    </xsl:for-each>
</xsl:variable>
```

## Performance Rules

- **Do NOT use `//` in selector statements** — forces evaluation of every node in the document. Use explicit paths
- **Do NOT use recursive template calls for padding** — use `string-join()` or `substring(concat(value, $padding), length)`:

```xml
<!-- Non-recursive padding function -->
<xsl:function name="this:pad-right" as="xs:string">
    <xsl:param name="value" as="xs:string"/>
    <xsl:param name="width" as="xs:integer"/>
    <xsl:param name="char" as="xs:string"/>
    <xsl:value-of select="substring(string-join(($value, for $i in 1 to $width return $char), ''), 1, $width)"/>
</xsl:function>
```

Or use `StringUtils.leftPad/rightPad` in a preceding MVEL eval step instead of XSLT padding.

- **Sort with correct data types**: `<xsl:sort select="xsd:date(wd:Start_Date)"/>`
- Prefer XSLT functions over templates for complex logic (returning sequences of atomic values, node restructuring)
- Do not leave unused variables, functions, or templates in transformations
- Do not hardcode reference IDs or WIDs — use launch parameters, attributes, or maps
- Avoid Java/Saxon extension functions in EIB and Document Transform XSLTs — they prevent external testing and are not portable
- **Assume non-streaming XSLT may use 10x the XML document's disk size in memory** — design with streaming for large documents

### Decimal Rounding Fix

`format-number()` has known precision issues with repeating decimals. Use this pattern:

```xml
<xsl:value-of select="format-number(round($value * 100) div 100, '##0.00')"/>
```

### Character Set Conversion

To change the output character encoding, set the MIME type on the XSLT step Output property:

```
text/plain; charset=ISO-8859-1
```

### Date Arithmetic

```xml
<!-- Add one day -->
<xsl:value-of select="($date) + 1 * xs:dayTimeDuration('P1D')"/>

<!-- Subtract 30 days -->
<xsl:value-of select="($date) - 30 * xs:dayTimeDuration('P1D')"/>
```

### Max/Min Date Values

Cast to `xs:date()` when using `min()`/`max()` to avoid sequence comparison errors:

```xml
<xsl:value-of select="max(for $d in wd:Dates/wd:Date return xs:date($d))"/>
```

### Regular Expressions

Common regex patterns for `replace()`, `matches()`, `tokenize()`:

```xml
<!-- Remove unprintable characters -->
<xsl:value-of select="replace($value, '[&#x00;-&#x1F;&#x7F;]', '')"/>

<!-- Rearrange date from YYYY-MM-DD to MM/DD/YYYY -->
<xsl:value-of select="replace($date, '(\d{4})-(\d{2})-(\d{2})', '$2/$3/$1')"/>

<!-- Match Unicode letters only -->
<xsl:value-of select="matches($value, '^[\p{L}]+$')"/>
```

## XSLT 3.0 Streaming Patterns

When using XSLT 3.0, leverage streaming for large documents. Only the current node is kept in memory.

### Mode Declarations

```xml
<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>
<xsl:mode streamable="no" name="in-memory"/>
```

- `shallow-skip` ignores unmatched nodes but applies templates to children
- Named `in-memory` mode for processing copied nodes

### Copy-Of Pattern

Use `copy-of()` to access multiple child nodes (streaming only allows one child reference):

```xml
<xsl:template match="peci:Compensation_Summary_in_Pay_Group_Frequency">
    <xsl:apply-templates select="copy-of()" mode="in-memory"/>
</xsl:template>

<xsl:template match="peci:Compensation_Summary_in_Pay_Group_Frequency" mode="in-memory">
    <!-- Can now access multiple children -->
    <Base_Pay><xsl:value-of select="peci:Total_Base_Pay"/></Base_Pay>
    <Currency><xsl:value-of select="peci:Currency"/></Currency>
</xsl:template>
```

Only copy the minimum necessary into memory.

### Accumulators

Use accumulators to store values when streaming forward (you cannot look back):

```xml
<xsl:accumulator name="emp.id" streamable="yes" as="xs:string" initial-value="''">
    <xsl:accumulator-rule match="peci:Employee_ID/text()" select="."/>
</xsl:accumulator>
```

- Use `/text()` in match to avoid breaking streaming rules
- Read values with `accumulator-before()` or `accumulator-after()`
- Accumulators support counting (`$value + 1`) and running totals

### Maps for Grouping

```xml
<xsl:accumulator name="comp.plan.map" as="map(xs:string,xs:integer)" initial-value="map{}" streamable="yes">
    <xsl:accumulator-rule match="peci:Compensation_Plan/text()">
        <xsl:variable name="current" select="if (map:contains($value, .)) then map:get($value, .) else 0"/>
        <xsl:sequence select="map:put($value, xs:string(.), $current + 1)"/>
    </xsl:accumulator-rule>
</xsl:accumulator>
```

## Function & Template Documentation

Include comments for all functions and templates:

```xml
<!--
    Function: this:toLower
    Description: Converts alpha characters to lower case
    Parameters:
        stringValue: Value to be converted to lower case
-->
<xsl:function name="this:toLower">
    <xsl:param name="stringValue" as="xs:string"/>
    <!-- implementation -->
</xsl:function>
```

## Identity Transform (Selective Node Override)

XSLT 3.0 provides a clean identity transform pattern using `on-no-match="shallow-copy"`:

```xml
<xsl:mode streamable="yes" on-no-match="shallow-copy"/>

<!-- Override only the specific nodes you need to change -->
<xsl:template match="wd:Status">
    <wd:Status>
        <xsl:value-of select="if (. = 'A') then 'Active' else 'Inactive'"/>
    </wd:Status>
</xsl:template>
```

All unmatched nodes pass through unchanged. This replaces the verbose XSLT 2.0 identity template pattern.

## Normalize Namespaces

When XML from different sources uses varying namespace prefixes, normalize to the standard Workday namespace:

```xml
<xsl:template match="*">
    <xsl:element name="wd:{local-name()}" namespace="urn:com.workday/bsvc">
        <xsl:apply-templates select="@* | node()"/>
    </xsl:element>
</xsl:template>
```

## Working Days Calculation

XSLT function to count weekdays between two dates (excludes Saturday and Sunday):

```xml
<xsl:function name="this:working-days" as="xs:integer">
    <xsl:param name="start" as="xs:date"/>
    <xsl:param name="end" as="xs:date"/>
    <xsl:variable name="days" select="days-from-duration($end - $start)"/>
    <xsl:variable name="weeks" select="$days idiv 7"/>
    <xsl:variable name="remainder" select="$days mod 7"/>
    <xsl:value-of select="$weeks * 5 + min(($remainder, 5))"/>
</xsl:function>
```

## Integration Mapping Functions in XSLT

Declare the integration system namespace and typed-value namespace:

```xml
xmlns:is="java:com.workday.esb.intsys.xpath.ParsedIntegrationSystemFunctions"
xmlns:tv="java:com.workday.esb.intsys.TypedValue"
```

**Text-to-text map lookup:**

```xml
<xsl:value-of select="is:getIntegrationMapValue('MapName', string($externalValue))"/>
```

**Reverse map lookup (text-to-business object):**

```xml
<xsl:variable name="lookup" select="is:integrationMapReverseLookup('MapName', string($externalValue))"/>
<xsl:value-of select="tv:getReferenceData($lookup[1], 'Reference_ID_Type')"/>
```

> These Java extension functions work in Studio but NOT in EIB or Document Transform. For EIB/DT, use MDT's pure-XSLT helper functions or pass map data as stylesheet parameters.

## JSON with XSLT 3.0

XSLT 3.0 provides `json-to-xml()` and `xml-to-json()` functions:

```xml
<!-- Convert JSON to XML for processing -->
<xsl:variable name="json-as-xml" select="json-to-xml(unparsed-text('input.json'))"/>

<!-- Convert XML back to JSON -->
<xsl:value-of select="xml-to-json($map-element)"/>
```

The `json-to-xml()` output uses elements named `map`, `array`, `string`, `number`, `boolean`, `null` with optional `key` attributes.

## Multi Document Transformation (MDT)

MDT is a deployed Studio integration that processes multiple input/output documents using only XSLT — no custom Studio code. Consider MDT when:

- You need multiple input sources or multiple output files
- EIB or Document Transform is _almost_ sufficient but needs dynamic file naming or complex logging
- You want to avoid writing Studio assembly code

MDT should NOT be used when web service calls, conditional data retrieval, or non-XSLT logic is required.

## EBCDIC Conversions

XSLT functions for EBCDIC signed-number conversion:

```xml
<!-- EBCDIC to decimal: '1234N' → -12345 -->
<xsl:function name="this:EBCDIC-to-decimal">
    <xsl:param name="in-value"/>
    <xsl:variable name="positive" select="('{','A','B','C','D','E','F','G','H','I')"/>
    <xsl:variable name="negative" select="('}','J','K','L','M','N','O','P','Q','R')"/>
    <xsl:variable name="last" select="substring($in-value, string-length($in-value))"/>
    <xsl:variable name="rest" select="substring($in-value, 1, string-length($in-value) - 1)"/>
    <xsl:choose>
        <xsl:when test="index-of($positive, $last)">
            <xsl:value-of select="number(concat($rest, index-of($positive, $last) - 1))"/>
        </xsl:when>
        <xsl:when test="index-of($negative, $last)">
            <xsl:value-of select="number(concat($rest, index-of($negative, $last) - 1)) * -1"/>
        </xsl:when>
        <xsl:otherwise><xsl:value-of select="number($in-value)"/></xsl:otherwise>
    </xsl:choose>
</xsl:function>
```

## Unit Testing

- Create AUnit tests for complex XSLT logic in Studio integrations
- Use scrubbed/anonymized test data — **NEVER** use customer data
- Run all existing unit tests after any XSLT change to catch regressions
- Debug XSLTs in OxygenXML: avoid `mctx:` URL protocol and Java extension functions (pass values as stylesheet parameters instead)

## EIB-Specific Guidance

- Use calculated fields and report writer as first choice for data translation, filtering, and logic
- XSLT should primarily be a data formatting tool
- Always test XSLT outside of Workday before uploading to EIB configuration
- Avoid Java or Saxon extension functions — they cannot be used in Document Transform or EIB

## Integration Attributes in XSLT

Declare the `is` namespace and call from XPath:

```xml
xmlns:is="java:com.workday.esb.intsys.xpath.ParsedIntegrationSystemFunctions"

<xsl:value-of select="is:getIntegrationAttributeValue('Entity Name')"/>
```

Prefer passing values as stylesheet parameters over using Java extension functions.

## Unit Testing

- Create AUnit tests for complex transformation logic in Studio integrations
- Use scrubbed data for test documents — NEVER use customer data
- Run all unit tests after any XSLT change to verify no regressions

## Studio XSLT Validation Workarounds

Studio's validator may incorrectly flag XSLT 3.0 / XPath 3.0 features. Workarounds:
1. **Per-XSLT**: Project Properties → Validation → Add Exclude Group for specific files/directories
2. **Per-project**: Project Properties → XSLT Validation → XPath Problems → set "Incorrect XPath syntax" to Ignore
3. **Per-workspace**: Preferences → XML → XSL → Validation → set "Incorrect XPath syntax" to Ignore

Prefer per-integration settings so other developers inherit them automatically.

## Additional Rules

- Always use the `xslt+` step for running XSLT in Studio
- For text output, prefer TextSchema, XML_to_CSV, or XTT steps. If using XSLT, handle delimiter escaping and use efficient padding functions
- When using `mctx://` protocol, avoid unnecessary re-parsing. Consider composite documents over mctx for ease of development

## Local XSLT Testing with Saxon

Always use the **Workday Studio Saxon EE 9.7** JARs for local testing — not Oxygen or any other Saxon version — as this matches the exact engine Workday Studio uses at runtime.

### Saxon command
```powershell
java -cp "$env:LOCALAPPDATA\WD\studio\plugins\com.workday.sh.sa.saxonee.core_2024.39.75\lib\saxonee-9.7.jar;$env:LOCALAPPDATA\WD\studio\plugins\com.workday.sh.sa.saxonee.core_2024.39.75\lib\wdsaxonee.jar" net.sf.saxon.Transform "-s:test\input.xml" "-xsl:test\MyTransform_test.xsl" "-o:test\output.xml"
```

### Stubbing `intsys:` extension functions
`intsys:` functions (e.g. `getIntegrationMapValue`) require a live Workday tenant and cannot run locally. To test locally, create a `_test.xsl` copy of the production XSL with two changes:

1. Replace the Java namespace binding with a dummy URI:
```xml
<!-- Before -->
xmlns:intsys="java:com.workday.esb.intsys.xpath.ParsedIntegrationSystemFunctions"
<!-- After -->
xmlns:intsys="urn:stub"
```

2. Replace every `intsys:` call with a suitable passthrough:
```xml
<!-- Before -->
<xsl:value-of select="intsys:getIntegrationMapValue($mapName, string($internalValue))"/>
<!-- After — passthrough, map lookups will return empty for local test -->
<xsl:value-of select="string($internalValue)"/>
```

Always `grep` for `intsys:` in the file before stubbing to ensure all calls are replaced.

### PII in test data
- Never commit real worker XML to Git — always use scrubbed/anonymised test data
- Add a `.gitignore` to the `test/` folder with `*.xml` to prevent accidental commits of test data files
