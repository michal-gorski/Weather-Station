---
description: "Use when creating, naming, or renaming Workday objects including integration systems, calculated fields, custom reports, XSLT files, sequence generators, integration services, security groups, and Studio assembly components. Covers tenant naming conventions and technology type abbreviations."
---

# Naming Conventions for Workday Integrations

If the client has a sensible and consistent naming format, follow theirs. Otherwise, use these standards.

## Tenant Object Naming

| Object | Pattern | Example |
|--------|---------|---------|
| Integration System | `INT[Code] [Source] to [Dest] [Direction] [Tech]` | `INT001 WD to PMS Outbound CCW` |
| Calculated Fields | `CF [INT Code] [Name] [Type]` | `CF INT001 First and Middle Name CT` |
| Custom Reports | `CR INT[Code] [Source] to [Dest] [Report Name]` | `CR INT001 WD to PMS Contract Types` |
| XSLT Attachments | `[integration system].xsl` | `INT001 WD to PMS Outbound CCW.xsl` |
| Sequence Generators | `[integration system] SEQ` | `INT001 WD to PMS Outbound CCW SEQ` |
| Integration Services | `[integration system] [Service Type]` | `INT001 WD to PMS Outbound CCW Field Override Service` |
| Integration System Users | `[INT code] ISU` | `INT001 ISU` |
| Integration System Security Groups | `[INT code] ISSG` | `INT001 ISSG` |
| Integration System Segments | `[INT code] ISSS` | `INT001 ISSS` |
| Segment Based Security Groups | `[INT code] SBSG` | `INT001 SBSG` |
| User Based Security Groups | `[INT code] UBSG` | `INT001 UBSG` |
| Shared Calculated Fields | `CF INTSHARE [Name] [Type] on [Object]` | `CF INTSHARE Global ID EE on Worker` |

**AbbrevCode** = numeric identifier (e.g., 001, 002)
**Type** = initials of the Calculated Field type (e.g., Lookup Related Value = LRV, Concatenate Text = CT)

## Technology Type Abbreviations

| Technology | Abbreviation |
|-----------|-------------|
| Core Connector: Worker | CCW |
| Studio | Studio |
| Payroll Interface | PI |
| Payroll Effective Change Interface | PECI |
| Core Connector: Job Postings | CCJP |
| Enterprise Interface Builder | EIB |

## Mediation Context Property Naming

Prefix properties with the integration name for scoping and debuggability:

| Prefix | Usage | Example |
|--------|-------|---------|
| `ia.` | Integration attributes | `props['ia.include.job.code']` |
| `lp.` | Launch parameters | `props['lp.paygroup.wid']` |
| `p.` | Processing/internal | `props['p.error.count']` |
| `[intname].` | Integration-specific | `props['payforce.company.name']` |

Property names must be **meaningful and unabbreviated**. Descriptive names aid readability and reduce maintenance cost.
