# Annotated Studio Stub — Golden Reference Assembly

This is the complete `assembly.xml` from `AMS_New_Studio_Project_Stub`, annotated to explain every structural decision. Use this as the canonical template when creating new Studio integrations.

---

## Required Project Structure

When creating a new Studio project from scratch, the following file structure is required for Workday Studio to recognize and open the project correctly. The assembly and XSLT files must be under `ws/WSAR-INF/`, **not** a root-level `WSAR-INF/`.

```
ProjectName/
├── .project                                          # Eclipse project descriptor
├── .classpath                                        # Java classpath with Studio containers
├── WorkdayManifest.xml                               # Workday deployment manifest
├── .settings/
│   ├── cc.facet.assembly.xml                         # Assembly facet config
│   ├── cc.ws.cloud.assembly.xml                      # Cloud assembly facet config
│   ├── org.eclipse.jdt.core.prefs                    # Java compiler settings
│   ├── org.eclipse.wst.common.component              # Module component mapping
│   └── org.eclipse.wst.common.project.facet.core.xml # Installed facets
├── src/                                              # Java source (can be empty but MUST exist)
├── build/
│   └── classes/                                      # Compiled output (can be empty but MUST exist)
└── ws/
    ├── META-INF/
    │   └── MANIFEST.MF                               # JAR manifest
    └── WSAR-INF/
        ├── assembly.xml                              # Integration assembly
        ├── assembly-diagram.xml                      # Visual diagram layout
        └── *.xsl                                     # XSLT transformation files
```

### Critical `.project` Requirements

The `.project` file must include these **exact builders** (in order) and **natures** — using incorrect builder names (e.g. `com.workday.studio.builder`) will prevent Studio from recognizing the assembly:

**Builders:**
1. `com.capeclear.wtp.facet.assembly.builder`
2. `org.eclipse.jdt.core.javabuilder`
3. `com.workday.wtp.ws.cloud.assembly.builder`
4. `org.eclipse.wst.common.project.facet.core.builder`
5. `org.eclipse.wst.validation.validationbuilder`

**Natures:**
- `org.eclipse.jem.workbench.JavaEMFNature`
- `org.eclipse.wst.common.modulecore.ModuleCoreNature`
- `org.eclipse.wst.common.project.facet.core.nature`
- `com.workday.wtp.ws.cloud.assembly.nature`
- `org.eclipse.jdt.core.javanature`
- `com.capeclear.wtp.facet.assembly.nature`

### Critical `.classpath` Requirements

Must reference these containers (not `com.workday.studio.WORKDAY_STUDIO_CONTAINER`):
- `com.capeclear.wtp.ws.container` — with `<attributes><attribute name="org.eclipse.jst.component.nondependency" value=""/></attributes>`
- `org.eclipse.jst.server.core.container/com.workday.cloud.jst.server.runtimeTarget.wdscl/Workday Runtime` — with `<attributes><attribute name="owner.project.facets" value="cc.ws.cloud.assembly"/></attributes>`

### Critical `.settings/org.eclipse.wst.common.project.facet.core.xml` Requirements

Must include the Workday Runtime reference and all three facets:
- `<runtime name="Workday Runtime"/>`
- `cc.ws.cloud.assembly` version 1.0
- `java` version 1.8
- `cc.facet.assembly` version 1.0

### Critical `.settings/cc.facet.assembly.xml` Requirements

Must use `<model modelId="com.capeclear.wtp.facet.assembly.facet.AssemblyFacetInstallDataModelProvider">` as root element — NOT `<settings>` or any other tag. Contains assembly facet configuration properties.

### Critical `.settings/cc.ws.cloud.assembly.xml` Requirements

Must use `<model modelId="com.workday.wtp.ws.cloud.assembly.facet.WsCloudAssemblyFacetInstallDataModelProvider">` as root element — NOT `<settings>` or any other tag. Contains cloud assembly facet configuration including integration type (`regular.e2`) and collection membership.

### Critical `.settings/org.eclipse.wst.common.component` Requirements

Must use `id="moduleCoreId"` (not `modulecoreproject`) and include both `/ws` and `/src` source paths.

### Critical `WorkdayManifest.xml` Requirements

Must use the proper `wm:manifest` namespace (`http://www.workday.com/solution/catalog/manifest/10`), NOT a simple `<workdayManifest>` tag.

> **Copy the project scaffolding files from `AMS_New_Studio_Project_Stub`** and update names/descriptions rather than creating them from scratch.

---

## What This Integration Does

1. Extracts integration attributes into `ia.` properties
2. Calls a Workday Custom Report (RaaS) as CSV
3. Posts the CSV to an external REST API
4. Saves a CloudLog.html to the Integration Event
5. Reports errors via PutIntegrationMessage at each stage

---

## Complete Assembly (Annotated)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans
     xmlns="http://www.springframework.org/schema/beans"
     xmlns:beans="http://www.springframework.org/schema/beans"
     xmlns:atom="http://www.w3.org/2005/Atom"
     xmlns:cc="http://www.capeclear.com/assembly/10"
     xmlns:cloud="urn:com.workday/esb/cloud/10.0"
     xmlns:env="http://schemas.xmlsoap.org/soap/envelope/"
     xmlns:pi="urn:com.workday/picof"
     xmlns:wd="urn:com.workday/bsvc"
     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
```

> **Wrapper**: Every assembly.xml is a Spring beans document. The namespace declarations are standard — copy them verbatim. Only add additional namespaces if you need them (e.g. custom Java beans).

```xml
    <cc:assembly id="WorkdayAssembly" version="2025.21">
```

> **Assembly root**: `id` is always `WorkdayAssembly`. `version` should default to `2025.21` unless the user specifies otherwise. Ask the user which version to target if creating a new integration.

---

### Entry Point + Integration System Config

```xml
        <cc:workday-in id="StartHere" routes-to="GetAttributes">
            <cc:integration-system name="AMS_New_Studio_Project_Stub">
```

> **workday-in**: The single entry point. `routes-to` points to the first processing mediation. The `cc:integration-system name` must match exactly in all `vm://` endpoint URIs throughout the assembly.

```xml
                <cloud:attribute-map-service name="INT_AMS">
                    <cloud:attribute name="Endpoint">
                        <cloud:type>
                            <cloud:simple-type>text</cloud:simple-type>
                        </cloud:type>
                        <cloud:display-option>required-for-launch</cloud:display-option>
                    </cloud:attribute>
                    <cloud:attribute name="Base64_Token">
                        <cloud:type>
                            <cloud:simple-type>text</cloud:simple-type>
                        </cloud:type>
                        <cloud:display-option>display-as-password</cloud:display-option>
                        <cloud:display-option>required-for-launch</cloud:display-option>
                    </cloud:attribute>
                    <cloud:attribute name="Organization_ID">
                        <cloud:type>
                            <cloud:simple-type>text</cloud:simple-type>
                        </cloud:type>
                        <cloud:display-option>required-for-launch</cloud:display-option>
                    </cloud:attribute>
                </cloud:attribute-map-service>
```

> **Integration Attributes**: Defined here, accessed in MVEL via `intsys.getAttribute('Name')`. Best practice: extract all attributes into `ia.` properties early in the flow (see GetAttributes below) rather than calling `intsys.getAttribute()` inline on transports.

```xml
                <cloud:report-service name="INT_RS">
                    <cloud:report-alias description="CR_INT_Workday_to_API" name="CR_Custom_Report">
                        <cloud:report-reference description="CR_INT_Workday_to_API" type="WID">6d222223c4230150ba1f2e365933480c</cloud:report-reference>
                    </cloud:report-alias>
                </cloud:report-service>
```

> **Report Service**: Defines custom report aliases. The WID must be updated per tenant. Access in MVEL: `intsys.reportService.getExtrapath('CR_Custom_Report')`.

```xml
            </cc:integration-system>
        </cc:workday-in>
```

---

### Global Error Handler

```xml
        <cc:send-error id="SendError" routes-to="ExtractGlobalError"/>
        <cc:async-mediation id="ExtractGlobalError" routes-to="PutIntegrationMessage">
            <cc:steps>
                <cc:eval id="ExtractError">
                    <cc:expression>props['p.error.message'] = util.cleanString(context.errorMessage)</cc:expression>
                </cc:eval>
            </cc:steps>
        </cc:async-mediation>
        <cc:local-out id="PutIntegrationMessage" endpoint="vm://wcc/PutIntegrationMessage">
            <cc:set name="is.message.severity" value="'CRITICAL'"/>
            <cc:set name="is.message.summary" value="props['p.error.message']"/>
        </cc:local-out>
```

> **Pattern**: `send-error` at the assembly root catches any unhandled error. It routes through `ExtractGlobalError` which uses `util.cleanString(context.errorMessage)` to safely extract the full error text, then writes a CRITICAL PutIntegrationMessage. The `cleanString` call prevents invalid XML characters from causing secondary "invalid Rich Text internal syntax" errors.
>
> **Key rule**: Always extract the error via `util.cleanString(context.errorMessage)` into a property first, then pass the property to PutIntegrationMessage.

---

### Save Logs Sub-Assembly

```xml
        <cc:local-in id="SaveLogs" routes-to="SaveLogFiles"/>
        <cc:async-mediation id="SaveLogFiles" routes-to="PIMError">
            <cc:steps>
                <cc:store id="StoreLogs" input="variable" input-variable="cloud-log-content" expiresIn="P30D" title="CloudLog.html"/>
            </cc:steps>
            <cc:send-error id="SendErrorSaveLogs" routes-to="CloudlogError"/>
        </cc:async-mediation>
```

> **CloudLog storage**: `cloud-log-content` is a built-in variable containing the HTML CloudLog document. `expiresIn="P30D"` retains it for 30 days. Called via `vm://IntName/SaveLogs` from the main flow.

```xml
        <cc:local-out id="PIMError" execute-when="props['p.error.count'] > 0" routes-response-to="PIMCloudLog" endpoint="vm://wcc/PutIntegrationMessage">
            <cc:set name="is.message.severity" value="'ERROR'"/>
            <cc:set name="is.message.summary" value="'The integration has completed with errors. Please see the CloudLog.html document for further information'"/>
        </cc:local-out>
        <cc:local-out id="PIMCloudLog" endpoint="vm://wcc/PutIntegrationMessage">
            <cc:set name="is.message.severity" value="'INFO'"/>
            <cc:set name="is.message.summary" value="'The integration has completed'"/>
        </cc:local-out>
        <cc:local-out id="CloudlogError" endpoint="vm://wcc/PutIntegrationMessage">
            <cc:set name="is.message.severity" value="'ERROR'"/>
            <cc:set name="is.message.summary" value="'Could not save log'"/>
        </cc:local-out>
```

> **End-of-run status**: After storing logs, checks `p.error.count`. If > 0, writes an ERROR PIM. Then always writes an INFO PIM. This gives "Completed" vs "Completed with Errors" status on the Integration Event. `CloudlogError` is the error handler for the store step itself.
>
> **execute-when**: The `PIMError` local-out only fires when the condition is true. When false, flow skips to `routes-response-to` (PIMCloudLog).

---

### Main Flow — Initialization

```xml
        <cc:async-mediation id="GetAttributes" routes-to="CallGetReport">
            <cc:steps>
                <cc:eval id="SetProps">
                    <cc:expression>props['p.error.count'] = 0;
props['ia.endpoint'] = intsys.getAttribute('Endpoint');
props['ia.base64.token'] = intsys.getAttribute('Base64_Token');
props['ia.organization.id'] = intsys.getAttribute('Organization_ID')</cc:expression>
                </cc:eval>
            </cc:steps>
            <cc:send-error id="SendErrorGetAttributes" routes-to="CatchGetAttributesError"/>
        </cc:async-mediation>
```

> **Initialization pattern**: First mediation extracts all integration attributes into `ia.` prefixed properties and initializes counters. This provides: early failure if attributes are missing, debuggable property values in the context, a single source of truth for attribute values.
>
> **MVEL**: Multiple statements separated by semicolons. Last statement doesn't need one. Numeric literal `0` not string `'0'`.

---

### Main Flow — Call Chain

```xml
        <cc:local-out id="CallGetReport" store-message="none" routes-response-to="CallSendFileToAPI" endpoint="vm://AMS_New_Studio_Project_Stub/GetReport"/>
        <cc:local-out id="CallSendFileToAPI" store-message="none" routes-response-to="CallSaveLogs" endpoint="vm://AMS_New_Studio_Project_Stub/SendFileToAPI"/>
        <cc:local-out id="CallSaveLogs" store-message="none" endpoint="vm://AMS_New_Studio_Project_Stub/SaveLogs"/>
```

> **Orchestration pattern**: The main flow chains sub-assembly calls via `routes-response-to`. Each `local-out` calls a sub-assembly and routes its response to the next. `store-message="none"` prevents intermediate messages being stored on the Integration Event. The last call (`CallSaveLogs`) has no `routes-response-to` — the flow ends there.

---

### Get Report Sub-Assembly

```xml
        <cc:local-in id="GetReport" routes-to="InvokeReport"/>
        <cc:async-mediation id="InvokeReport" routes-to="CallCustomReportAsCSV">
            <cc:steps>
            </cc:steps>
            <cc:send-error id="SendErrorInvokeReport" routes-to="CatchReportError"/>
        </cc:async-mediation>
        <cc:workday-out-rest id="CallCustomReportAsCSV" routes-response-to="LogReportResult" extra-path="@{intsys.reportService.getExtrapath('CR_Custom_Report')}?format=csv"/>
        <cc:async-mediation id="LogReportResult">
            <cc:steps>
                <cc:cloud-log id="Success" level="info" message="Successfully retrieved report contents"/>
            </cc:steps>
        </cc:async-mediation>
```

> **Wrapper mediation pattern**: `InvokeReport` wraps the transport call with an error handler. Even though its `cc:steps` is empty, the `send-error` catches errors thrown by the downstream `workday-out-rest`. Without this, transport errors would bubble up to the global handler as CRITICAL instead of being handled gracefully.
>
> **RaaS call**: `intsys.reportService.getExtrapath('alias')` returns the URL path for the custom report. `?format=csv` requests CSV output.

---

### Send File Sub-Assembly

```xml
        <cc:local-in id="SendFileToAPI" routes-to="SetHeaders"/>
        <cc:async-mediation id="SetHeaders" routes-to="APIPostCSV">
            <cc:steps>
                <cc:set-headers id="SetHeaders">
                    <cc:remove-headers/>
                    <cc:add-headers>
                        <cc:add-header name="Authorization" value="Basic @{props['ia.base64.token']}"/>
                    </cc:add-headers>
                </cc:set-headers>
            </cc:steps>
            <cc:send-error id="SendErrorSetHeaders" routes-to="CatchAPIPostError"/>
        </cc:async-mediation>
        <cc:http-out id="APIPostCSV" routes-response-to="LogAPIPostResult" endpoint="@{props['ia.endpoint'] + '/rest/uploads/' + props['ia.organization.id']}" http-method="POST">
            <cc:rest-binding/>
            <cc:http-basic-auth/>
        </cc:http-out>
        <cc:async-mediation id="LogAPIPostResult">
            <cc:steps>
                <cc:cloud-log id="Success" level="info" message="Successfully wrote message to Vendor"/>
            </cc:steps>
        </cc:async-mediation>
```

> **Header pattern**: Always `<cc:remove-headers/>` before `<cc:add-headers>` to clear any inherited headers. Values reference `ia.` properties extracted in GetAttributes, not inline `intsys.getAttribute()` calls.
>
> **http-out**: `<cc:rest-binding/>` sends raw body. The endpoint uses `ia.` properties for the URL. `<cc:http-basic-auth/>` adds Basic auth from integration attributes (separate from the header-based token in this example).

---

### Error Handler Mediations

```xml
        <cc:async-mediation id="CatchGetAttributesError">
            <cc:steps>
                <cc:eval id="ExtractError">
                    <cc:expression>props['p.error.message'] = util.cleanString(context.errorMessage)</cc:expression>
                </cc:eval>
                <cc:cloud-log id="CloudLog" level="error" message="Unable to get attributes and set props" message-details="@{props['p.error.message']}"/>
                <cc:eval id="IncError">
                    <cc:expression>props['p.error.count'] = props['p.error.count'] + 1</cc:expression>
                </cc:eval>
            </cc:steps>
        </cc:async-mediation>
```

> **Standard error handler pattern** (repeat for every functional error handler):
> 1. **Extract** the error with `util.cleanString(context.errorMessage)` into `p.error.message`
> 2. **Log** to CloudLog with the cleaned message — use `@{props['p.error.message']}` in `message-details`
> 3. **Increment** the error counter
>
> The `message` attribute is a plain-text summary unique to each handler. The `message-details` provides the full error text. This pattern ensures processing continues (no abort) while accumulating error state.
>
> **Apply this exact pattern** to `CatchReportError`, `CatchAPIPostError`, and any other error handlers you add.

---

## Structural Rules

1. **Component order in the XML does not affect routing** — routing is determined by `routes-to` and `routes-response-to` attributes. However, keep components logically grouped for readability
2. **Every processing mediation must have a `cc:send-error`** as its last child — this routes errors to a catch/error-handler mediation
3. **Catch/error-handler mediations do NOT have `cc:send-error`** — they are terminal handlers (extract, log, increment counter). If the catch mediation itself fails, the global assembly-level `cc:send-error` catches it automatically. Adding `send-error routes-to="ExtractGlobalError"` on catch mediations creates unwanted diagram arrows and is structurally incorrect
4. **`cc:send-error` IDs must be unique and descriptive** — convention: `SendError` + purpose (e.g. `SendErrorGetAttributes`)
5. **Sub-assembly `vm://` URIs must exactly match** the `cc:integration-system name` and `cc:local-in id`
6. **The global `cc:send-error`** must be a direct child of `cc:assembly` (sibling of `cc:workday-in`)
7. **`store-message="none"`** on `cc:local-out` prevents intermediate messages cluttering the Integration Event
