# Assembly Diagram Guide

The `assembly-diagram.xml` file is a companion to `assembly.xml` that controls the visual layout in Workday Studio's graphical editor. When you add, remove, or rename components in `assembly.xml`, this file must be updated in sync.

---

## Critical Rule: Never Rebuild From Scratch

**NEVER regenerate `assembly-diagram.xml` from scratch.** Always read the existing file in full, then apply targeted, surgical edits for only the components that changed. Rebuilding from scratch loses all hand-tuned coordinates, anchor positions, bendpoints, swimlane nesting, and connection layout — producing a broken diagram where components pile on top of each other.

**Mandatory update sequence:**
1. Finish all `assembly.xml` edits first
2. Run the `@mixed` index verification script (see below) on the **modified** `assembly.xml`
3. Read the existing `assembly-diagram.xml` in full
4. Apply only the necessary changes: rename hrefs, add/remove visualProperties, add/remove/re-target connections, update `@mixed` indices, update swimlane membership
5. Verify every `routes-to` and `routes-response-to` in `assembly.xml` has a matching connection in the diagram

---

## Formatting Rules

- **Do NOT include XML comments** in `assembly-diagram.xml` — Studio's EMF parser does not handle them, causing `getSelectionService()` null errors or layout corruption
- **File must be UTF-8 without BOM** — PowerShell 5.1's `-Encoding UTF8` adds a BOM by default, which breaks Studio's EMF parser. Use `[System.IO.File]::WriteAllText(path, content, (New-Object System.Text.UTF8Encoding($false)))` instead
- **Use CRLF line endings** (`\r\n`) — matching Studio's own output format on Windows
- **Use 2-space indentation** (not 4-space) to match Studio's own output format
- **Every component must have a `visualProperties` entry** — a minimal diagram with only the assembly root reference but no visual properties causes `getSelectionService()` errors because Studio cannot build its editing domain
- **Do NOT include connections for catch/error-handler mediations** back to `ExtractGlobalError` — catch mediations are terminal and have no `send-error` child, so there is no connection to draw
- **Only include connections that correspond to actual `routes-to` or `routes-response-to` attributes** in `assembly.xml` — do not fabricate connections for implicit fallback (e.g. the global error handler catching a mediation)

---

## Document Structure

```xml
<?xml version="1.0" encoding="UTF-8"?>
<wdnm:Diagram xmlns:wdnm="http://workday.com/studio/editors/notation">
  <element href="assembly.xml#WorkdayAssembly"/>

  <!-- visualProperties for each component -->
  <!-- connections for each route -->
  <!-- swimlanes for grouping -->
</wdnm:Diagram>
```

The file has three sections: **visualProperties**, **connections**, and **swimlanes**.

---

## Visual Properties

Every component in `assembly.xml` that has an `id` attribute needs a `visualProperties` entry with x/y coordinates:

```xml
<visualProperties x="167" y="130">
    <element href="assembly.xml#GetAttributes"/>
</visualProperties>
```

- `x` and `y` are pixel coordinates on the diagram canvas
- The `href` references the component by `assembly.xml#ComponentId`
- Components without coordinates will render at position (0,0) or may be invisible

### Special case: send-error at assembly root

The global `cc:send-error` (direct child of `cc:assembly`) doesn't have a stable `id`-based reference. It uses a positional XPath via `@mixed` indices:

```xml
<visualProperties x="40" y="214">
    <element href="assembly.xml#//@beans/@mixed.1/@mixed.3"/>
</visualProperties>
```

This means: *in the `beans` root element → child node at index 1 (the `cc:assembly`) → child node at index 3 (the `send-error`).

---

## @mixed Index System

The `@mixed` notation is an EMF (Eclipse Modeling Framework) XPath that addresses nodes by their position in the **mixed content** of an element. This includes both element nodes AND whitespace text nodes.

### How to count @mixed indices

Given this assembly.xml structure:

```xml
<cc:assembly id="WorkdayAssembly">        ← @mixed.1 in beans
[whitespace text node]                     ← @mixed.0 in assembly
    <cc:workday-in id="StartHere"/>        ← @mixed.1 in assembly
[whitespace text node]                     ← @mixed.2 in assembly
    <cc:send-error id="SendError"/>        ← @mixed.3 in assembly
[whitespace text node]                     ← @mixed.4 in assembly
    <cc:async-mediation id="ExtractGlobalError"/>  ← @mixed.5 in assembly
[whitespace text node]                     ← @mixed.6 in assembly
    <cc:local-out id="PutIntegrationMessage"/>     ← @mixed.7 in assembly
```

Every line break / indentation between elements creates a text node. So elements alternate with text nodes: element at odd indices, text at even indices (typically).

### Why this matters

When you **insert a new element** into `assembly.xml` between existing elements, you shift all subsequent `@mixed` indices by **+2** (one for the new element, one for its whitespace text node). When you **remove an element**, they shift by **-2**.

**Every `@mixed` reference in `assembly-diagram.xml` must be recalculated after structural changes.**

### How to verify @mixed indices

Use XML DOM parsing with whitespace preservation:

```powershell
$doc = New-Object System.Xml.XmlDocument
$doc.PreserveWhitespace = $true
$doc.Load("path/to/assembly.xml")
$assembly = $doc.DocumentElement.ChildNodes[1]  # cc:assembly is @mixed.1 in beans
for ($i=0; $i -lt $assembly.ChildNodes.Count; $i++) {
    $n = $assembly.ChildNodes[$i]
    if ($n.NodeType -eq 'Element') {
        Write-Output ("mixed.{0}: <{1}> id={2}" -f $i, $n.LocalName, $n.GetAttribute('id'))
    }
}
```

**Never guess `@mixed` indices.** Always verify with DOM parsing or by opening the project in Workday Studio.

### Inner @mixed references

Send-error elements inside mediations use nested `@mixed` paths:

```xml
<source href="assembly.xml#//@beans/@mixed.1/@mixed.17/@mixed.3"/>
```

This means: `beans` → `assembly` (mixed.1) → `GetAttributes` mediation (mixed.17) → `send-error` (mixed.3 within the mediation).

The inner `@mixed.3` is typically stable within a mediation (steps=mixed.1, text=mixed.2, send-error=mixed.3) unless you add or remove children of the mediation element itself.

---

## Connections

Connections represent the arrows on the diagram. There are two types:

### routesTo

```xml
<connections type="routesTo" sourceAnchorX="1.0" sourceAnchorY="0.5" targetAnchorX="0.0" targetAnchorY="0.5">
    <source href="assembly.xml#ExtractGlobalError"/>
    <target href="assembly.xml#PutIntegrationMessage"/>
</connections>
```

### routesResponseTo

```xml
<connections type="routesResponseTo" sourceAnchorX="0.75" sourceAnchorY="1.0" targetAnchorX="0.38" targetAnchorY="0.5">
    <source href="assembly.xml#CallSendFileToAPI"/>
    <target href="assembly.xml#CallSaveLogs"/>
</connections>
```

### Anchor coordinates

- `sourceAnchorX/Y` — where the arrow leaves the source component (0.0–1.0, relative to component bounds)
- `targetAnchorX/Y` — where the arrow enters the target component (0.0–1.0)
- `(0,0)` = top-left, `(1,1)` = bottom-right
- Typical patterns: right side exit `(1.0, 0.5)`, left side entry `(0.0, 0.5)`, bottom exit `(0.5, 1.0)`, top entry `(0.5, 0.0)`

### send-error connections

Connections from `send-error` elements use positional `@mixed` references for the source:

```xml
<connections type="routesTo" ...>
    <source href="assembly.xml#//@beans/@mixed.1/@mixed.17/@mixed.3"/>
    <target href="assembly.xml#CatchGetAttributesError"/>
</connections>
```

---

## Swimlanes

Swimlanes group components visually. They can be nested.

### Top-level swimlane (container)

```xml
<swimlanes x="15" y="11" name="Integration Name" orientation="VERTICAL" elements="//@swimlanes.1 //@swimlanes.5 //@swimlanes.6 //@swimlanes.3 //@swimlanes.2"/>
```

The `elements` attribute lists child swimlanes by their index (0-based from the first `<swimlanes>` element).

### Named swimlane

```xml
<swimlanes x="37" y="50" name="Main flow">
    <elements href="assembly.xml#StartHere"/>
    <elements href="#//@swimlanes.4"/>
    <elements href="assembly.xml#CallGetReport"/>
    <elements href="assembly.xml#CallSendFileToAPI"/>
    <elements href="assembly.xml#CallSaveLogs"/>
</swimlanes>
```

### Unnamed vertical grouping (mediation + error handler pair)

```xml
<swimlanes x="172" y="108" name="" orientation="VERTICAL">
    <elements href="assembly.xml#GetAttributes"/>
    <elements href="assembly.xml#CatchGetAttributesError"/>
</swimlanes>
```

### Nested swimlane references

`<elements href="#//@swimlanes.4"/>` references another swimlane by index. This embeds that swimlane visually inside the current one.

---

## Swimlane Index System

Swimlanes use the same 0-based positional indexing as `@mixed`. The first `<swimlanes>` element in the file is index 0, the second is index 1, and so on.

### Why this matters

Swimlane cross-references use these positional indices:
- **Child elements**: `<elements href="#//@swimlanes.4"/>` — embeds swimlane 4 inside the current swimlane
- **Root swimlane**: `elements="//@swimlanes.7 //@swimlanes.19 ..."` — the root container lists its top-level children by index

When you **insert a new swimlane** between existing swimlanes, every index at or after the insertion point shifts by **+1**. When you **remove a swimlane**, they shift by **-1**.

**Every swimlane index reference in `assembly-diagram.xml` must be recalculated after inserting or removing swimlanes.**

### The root swimlane trap

The root swimlane is typically the **last** `<swimlanes>` element in the file. It uses the `elements` attribute (a space-separated string) instead of child `<elements>` tags. If you insert a new swimlane before it:

- The root swimlane's own index shifts by +1
- Any parent swimlane that references your new swimlane by index must use the **pre-root** index, not the root's new index
- Getting this wrong creates a **circular reference** (swimlane A embeds root, root embeds swimlane A's parent) that causes Studio to render only orphaned swimlanes — breaking the entire diagram

### Safe insertion pattern

1. **Count existing swimlanes** (0-based) to determine the index of the last swimlane (the root)
2. **Insert new swimlanes immediately before the root** — they take the old root index, root shifts +1
3. **Update all `#//@swimlanes.N` and `//@swimlanes.N` references** where N >= the insertion point
4. **Double-check the parent swimlane** that will embed your new swimlane uses the correct new index
5. **Verify the root swimlane's `elements` attribute** still references the correct child indices

### How to verify swimlane indices

Manually count from the first `<swimlanes>` element (index 0) to the last. Or use this PowerShell script:

```powershell
[xml]$diag = Get-Content "path/to/assembly-diagram.xml"
$ns = @{ wdnm = 'http://workday.com/studio/editors/notation' }
$lanes = $diag.SelectNodes('//wdnm:Diagram/wdnm:swimlanes', (New-Object System.Xml.XmlNamespaceManager($diag.NameTable)).tap{ $_.AddNamespace('wdnm','http://workday.com/studio/editors/notation') })
$i = 0
$diag.Diagram.swimlanes | ForEach-Object {
    $name = if ($_.name) { $_.name } else { '(unnamed)' }
    $isRoot = if ($_.elements -is [string]) { ' [ROOT]' } else { '' }
    Write-Output ("swimlanes.{0}: {1}{2}" -f $i, $name, $isRoot)
    $i++
}
```

---

## Checklist: Adding a New Component

When you add a component to `assembly.xml`:

1. **Add a `visualProperties` entry** with x/y coordinates that place it logically in the flow
2. **Add `connections` entries** for every `routes-to` and `routes-response-to` relationship involving the new component
3. **Add the component to the appropriate `swimlanes` element**
4. **Recalculate all `@mixed` indices** if the new component was inserted between existing assembly-level elements (not appended at the end)
5. **Recalculate all swimlane indices** if a new `<swimlanes>` element was inserted between existing swimlanes (see [Swimlane Index System](#swimlane-index-system))
6. **Verify** by opening in Workday Studio or using DOM parsing

## Checklist: Removing a Component

1. **Remove its `visualProperties` entry**
2. **Remove all `connections` where it appears as source or target**
3. **Remove it from any `swimlanes` elements**
4. **Recalculate all `@mixed` indices** if the removed component shifts positions of subsequent elements
5. **Recalculate all swimlane indices** if a `<swimlanes>` element was removed (see [Swimlane Index System](#swimlane-index-system))

## Checklist: Renaming a Component

1. **Update the `id` in `assembly.xml`**
2. **Update all `href` references in `assembly-diagram.xml`** — search for the old ID in visualProperties, connections (source and target), and swimlanes elements
3. **Update any `routes-to` or `routes-response-to` attributes** in `assembly.xml` that reference the old ID
4. **Update any `vm://` endpoint URIs** in `assembly.xml` that reference the old ID (only applies to `local-in` IDs)
