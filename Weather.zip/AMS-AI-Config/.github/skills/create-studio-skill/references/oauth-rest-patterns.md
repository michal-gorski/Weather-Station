# OAuth 2.0 & REST API Patterns for Workday Studio

Patterns for connecting to third-party REST APIs from Workday Studio, sourced from the `INT_Global_Time_Off_To_Outlook_Studio` integration (Microsoft Graph API / Outlook).

---

## OAuth 2.0 Client Credentials Flow

### Overview

The Client Credentials grant is used when the integration authenticates as an application (not a user). The flow:

1. **Build** a form-encoded token request body
2. **POST** to the token endpoint
3. **Parse** the JSON response to extract the access token
4. **Store** the token in a property for use in subsequent API calls

### Integration Attributes Required

```xml
<cloud:attribute name="Client ID">
    <cloud:type><cloud:simple-type>text</cloud:simple-type></cloud:type>
    <cloud:display-option>display-as-password</cloud:display-option>
    <cloud:display-option>required-for-launch</cloud:display-option>
</cloud:attribute>
<cloud:attribute name="Client Secret">
    <cloud:type><cloud:simple-type>text</cloud:simple-type></cloud:type>
    <cloud:display-option>display-as-password</cloud:display-option>
    <cloud:display-option>required-for-launch</cloud:display-option>
</cloud:attribute>
<cloud:attribute name="Scope">
    <cloud:type><cloud:simple-type>text</cloud:simple-type></cloud:type>
    <cloud:display-option>required-for-launch</cloud:display-option>
</cloud:attribute>
<cloud:attribute name="Token URL">
    <cloud:type><cloud:simple-type>text</cloud:simple-type></cloud:type>
    <cloud:display-option>required-for-launch</cloud:display-option>
</cloud:attribute>
```

Always use `display-as-password` for Client ID and Client Secret.

### Property Extraction (GetAttributes)

```xml
<cc:eval id="SetProps">
    <cc:expression>props['p.error.count'] = 0;
props['ia.client.id'] = intsys.getAttribute('Client ID');
props['ia.client.secret'] = intsys.getAttribute('Client Secret');
props['ia.scope'] = intsys.getAttribute('Scope');
props['ia.token.url'] = intsys.getAttribute('Token URL')</cc:expression>
</cc:eval>
```

### Token Request Sub-Assembly

Structure: `local-in` → build request → POST → extract token

```xml
<!-- Entry point -->
<cc:local-in id="GetToken" routes-to="BuildTokenRequest"/>

<!-- Build the form-encoded body and set headers -->
<cc:async-mediation id="BuildTokenRequest" routes-to="PostTokenRequest" handle-downstream-errors="true">
    <cc:steps>
        <cc:write id="WriteTokenBody" output-mimetype="application/x-www-form-urlencoded">
            <cc:message>
                <cc:text>grant_type=client_credentials&amp;client_id=@{props['ia.client.id']}&amp;client_secret=@{props['ia.client.secret']}&amp;scope=@{props['ia.scope']}</cc:text>
            </cc:message>
        </cc:write>
        <cc:set-headers id="SetTokenHeaders" output-mimetype="application/x-www-form-urlencoded">
            <cc:remove-headers/>
            <cc:add-headers>
                <cc:add-header name="Content-Type" value="application/x-www-form-urlencoded"/>
            </cc:add-headers>
        </cc:set-headers>
    </cc:steps>
    <cc:send-error id="SendErrorBuildTokenRequest" routes-to="CatchTokenError"/>
</cc:async-mediation>

<!-- POST to the token endpoint -->
<cc:http-out id="PostTokenRequest" routes-response-to="ExtractToken" endpoint="@{props['ia.token.url']}" http-method="POST"/>

<!-- Parse JSON response and extract the access_token -->
<cc:async-mediation id="ExtractToken" routes-to="LogTokenSuccess" handle-downstream-errors="true">
    <cc:steps>
        <cc:json-to-xml id="JsonToXml"/>
        <cc:eval id="ExtractAccessToken">
            <cc:expression>props['p.access.token'] = parts[0].xpath('/root/data/access_token')</cc:expression>
        </cc:eval>
    </cc:steps>
    <cc:send-error id="SendErrorExtractToken" routes-to="CatchTokenError"/>
</cc:async-mediation>

<!-- Log success -->
<cc:async-mediation id="LogTokenSuccess">
    <cc:steps>
        <cc:cloud-log id="LogToken" level="info" message="Successfully retrieved access token"/>
    </cc:steps>
</cc:async-mediation>
```

### Key Points

1. **`cc:write`** replaces the current message body with the form-encoded string. MVEL templates `@{...}` inject property values
2. **`output-mimetype`** on both `cc:write` and `cc:set-headers` sets the content type of the outgoing message
3. **`cc:json-to-xml`** converts the JSON token response into XML so `parts[0].xpath(...)` can extract values. The JSON `{ "access_token": "..." }` becomes `<root><data><access_token>...</access_token></data></root>`
4. **`handle-downstream-errors="true"`** on the mediations ensures transport errors from `http-out` are caught by the mediation's own `send-error`, not propagated upstream

---

## Using the Bearer Token

After the token is stored in `props['p.access.token']`, set the Authorization header on every subsequent API call:

```xml
<cc:set-headers id="SetAuthHeaders">
    <cc:remove-headers/>
    <cc:add-headers>
        <cc:add-header name="Authorization" value="Bearer @{props['p.access.token']}"/>
    </cc:add-headers>
</cc:set-headers>
```

This goes inside the `cc:steps` of the mediation that precedes each `cc:http-out` call. Every API call needs its own header setup because `cc:remove-headers` clears headers from the previous transport response.

### Bearer vs Basic Authentication

| Pattern | Header Value | When to Use |
|---------|-------------|-------------|
| Bearer (OAuth 2.0) | `Bearer @{props['p.access.token']}` | Token obtained via OAuth flow |
| Basic (static) | `Basic @{props['ia.base64.token']}` | Pre-encoded credentials in integration attributes |

---

## JSON Response Handling

### cc:json-to-xml Conversion Structure

JSON:
```json
{
  "value": [
    { "id": "abc123", "transactionId": "TX001" },
    { "id": "def456", "transactionId": "TX002" }
  ]
}
```

After `cc:json-to-xml`, becomes:
```xml
<root>
  <data>
    <value>
      <data>
        <id>abc123</id>
        <transactionId>TX001</transactionId>
      </data>
      <data>
        <id>def456</id>
        <transactionId>TX002</transactionId>
      </data>
    </value>
  </data>
</root>
```

### XPath to query converted JSON

```
// Simple value
parts[0].xpath('/root/data/access_token')

// Find by nested value (filter)
parts[0].xpath('/root/data/value/data[transactionId="TX001"]/id')
```

Note: When embedding quotes inside XPath within MVEL, use `&quot;` in XML or string concatenation:
```
parts[0].xpath('/root/data/value/data[transactionId=&quot;' + props['p.transaction.id'] + '&quot;]/id')
```

---

## Conditional Routing (CRUD Operations)

When an integration needs to Create, Update, or Delete records based on data conditions, use `cc:route` with `cc:mvel-strategy`:

```xml
<cc:route id="RouteByAction">
    <cc:mvel-strategy>
        <cc:choose-route expression="props['p.is.correction'] == false &amp;&amp; props['p.is.deletion'] == false" route="Create"/>
        <cc:choose-route expression="props['p.is.correction'] == true &amp;&amp; props['p.is.deletion'] == false" route="Update"/>
        <cc:choose-route expression="props['p.is.deletion'] == true" route="Delete"/>
        <cc:choose-route expression="true" route="Error"/>
    </cc:mvel-strategy>
    <cc:sub-route name="Create" routes-to="CreateRequest"/>
    <cc:sub-route name="Update" routes-to="UpdateRequest"/>
    <cc:sub-route name="Delete" routes-to="DeleteRequest"/>
    <cc:sub-route name="Error" routes-to="CatchRoutingError"/>
</cc:route>
```

### Pattern: Determine action before routing

Before the route, use a mediation to query the target system and set routing flags:

```xml
<!-- Check if record already exists in target system -->
<cc:async-mediation id="CheckExistence" routes-to="RouteByAction" handle-downstream-errors="true">
    <cc:steps>
        <cc:json-to-xml id="JsonToXml"/>
        <cc:eval id="SetRouteFlags">
            <cc:expression>props['p.existing.id'] = parts[0].xpath('/root/data/value/data[transactionId=&quot;' + props['p.transaction.id'] + '&quot;]/id')</cc:expression>
            <cc:expression>props['p.is.correction'] = props['p.existing.id'] != ''</cc:expression>
        </cc:eval>
    </cc:steps>
    <cc:send-error id="SendErrorCheckExistence" routes-to="CatchCheckError"/>
</cc:async-mediation>
```

---

## Splitter → Per-Record API Calls

When processing a report where each row needs an individual API call:

```
GetReport → XSLT preprocessing → Splitter → [per record: extract fields → set headers → API call → log result]
```

### Splitter Component

```xml
<cc:splitter id="SplitReportEntries" no-split-message-error="false">
    <cc:sub-route name="ProcessSingleEntry" routes-to="ExtractEntryFields"/>
    <cc:xml-stream-splitter xpath="wd:Report_Data/wd:Report_Entry"/>
</cc:splitter>
```

- `no-split-message-error="false"` — don't fail if the report has zero entries
- `cc:xml-stream-splitter` — streams the XML (memory efficient for large reports)
- Each split entry becomes the current message `parts[0]` in the target mediation

### Per-Record Processing Pattern

For each split entry:

1. **Extract fields** from the split XML into properties using `parts[0].xpath(...)`
2. **Set the Bearer token header** (must be set before each call — headers are reset between iterations)
3. **Call the target API** via `cc:http-out`
4. **Log the result** with per-record context (employee ID, date, etc.)
5. **On error** — increment count, log with context, continue to next record

```xml
<cc:async-mediation id="ExtractEntryFields" routes-to="CallTargetAPI" handle-downstream-errors="true">
    <cc:steps>
        <cc:eval id="ExtractFields">
            <cc:expression>props['p.employee.id'] = parts[0].xpath('/wd:Report_Entry/wd:Worker/wd:Employee_ID')</cc:expression>
            <cc:expression>props['p.date'] = parts[0].xpath('/wd:Report_Entry/wd:Date').substring(0, 10)</cc:expression>
        </cc:eval>
        <cc:set-headers id="SetAuthHeaders">
            <cc:remove-headers/>
            <cc:add-headers>
                <cc:add-header name="Authorization" value="Bearer @{props['p.access.token']}"/>
            </cc:add-headers>
        </cc:set-headers>
    </cc:steps>
    <cc:send-error id="SendErrorExtractFields" routes-to="CatchEntryError"/>
</cc:async-mediation>
```

### Error Handling in Splitter Loops

Each error handler in the splitter loop should include per-record context in the CloudLog message:

```xml
<cc:async-mediation id="CatchEntryError">
    <cc:steps>
        <cc:eval id="ExtractError">
            <cc:expression>props['p.error.message'] = util.cleanString(context.errorMessage)</cc:expression>
        </cc:eval>
        <cc:cloud-log id="CloudLog" level="error" message="Failure to process entry for @{props['p.employee.id']}" message-details="@{props['p.error.message']}"/>
        <cc:eval id="IncError">
            <cc:expression>props['p.error.count'] = props['p.error.count'] + 1</cc:expression>
        </cc:eval>
    </cc:steps>
</cc:async-mediation>
```

The `@{props['p.employee.id']}` in the `message` attribute gives the end user context about which record failed. This is critical for diagnosing issues without developer assistance.

---

## Constructing Dynamic API URLs

Build URLs from properties rather than inline `intsys.getAttribute()` calls:

```xml
<!-- Simple endpoint -->
<cc:http-out id="CreateEvent" endpoint="@{props['ia.api.url']}/@{props['p.username']}/events" http-method="POST"/>

<!-- Endpoint with query parameters -->
<cc:http-out id="GetEvents" endpoint="@{props['ia.api.url']}/@{props['p.username']}/calendarView?startDateTime=@{props['p.start']}T00:00:00&amp;endDateTime=@{props['p.end']}T00:00:00&amp;$select=id,transactionId" accept="application/json" http-method="GET"/>
```

Use `&amp;` for `&` in query strings (XML escaping). The `accept` attribute sets the `Accept` header on the request.

---

## URL Encoding

When embedding user data in URLs, encode it to handle special characters:

```
props['p.encoded.value'] = java.net.URLEncoder.encode(props['p.raw.value'], 'UTF-8').replace("+", "%20")
```

This is necessary when values might contain spaces, ampersands, or other URL-unsafe characters.
