# Assembly XML Element Catalog

Exact XML syntax for every component type used in Workday Studio `assembly.xml` files. All elements use the `cc:` namespace (`http://www.capeclear.com/assembly/10`). Integration services use the `cloud:` namespace (`urn:com.workday/esb/cloud/10.0`).

## Quick Reference

| Section | Elements |
|---------|----------|
| [Document Structure](#document-structure) | Assembly root, namespaces, version |
| [Input/Output Options](#inputoutput-options-reference) | `message`, `soapbody`, `rootpart`, `attachment`, `variable` |
| [Transports — Workday & HTTP](#transports--workday--http) | `workday-in`, `workday-out-soap`, `workday-out-rest`, `http-out`, `local-in`/`local-out` |
| [Transports — File Transfer & Email](#transports--file-transfer--email) | `ftp-out`, `sftp-out`, `ftps-out`, `email-out`, `xmpp-out`, `custom-out` |
| [Mediations](#mediations) | `async-mediation`, `sync-mediation`, `send-error`, `custom-mediation` |
| [Flow Control — Routing](#flow-control--routing) | `route` + strategies: `mvel`, `xpath`, `regex`, `loop`, `round-robin`, `failover`, `all`, `doc-iterator` |
| [Flow Control — Splitting & Aggregation](#flow-control--splitting--aggregation) | `splitter` + strategies: `xml-stream`, `xpath`, `json`, `standard`, `unzip`, `mtable`, `custom`; `aggregator` |
| [Steps — Core](#steps--core) | `eval`, `copy`, `write`, `set-headers`, `validation`, `cloud-log`, `store` |
| [Steps — Transform](#steps--transform) | `xslt`, `xslt-plus`, `json-to-xml`, `xml-to-json`, `xml-to-csv`, `csv-to-xml`, `fop`, `text-excel`, `textschema`, `javascript`, and more |
| [Steps — Server Logging](#steps--server-logging) | `log` (Log4j server logs) |
| [Steps — Validation](#steps--validation) | `validate`, `validate-exp`, `validate-xpath` |
| [Steps — Encoding & Compression](#steps--encoding--compression) | `pgp-encrypt`/`decrypt`, `base64-encode`/`decode`, `zip`/`unzip`, `compress`/`decompress` |
| [Steps — Other](#steps--other) | `custom`, `set-dynamic-endpoint`, `retrieve`, `xmldiff`, `enqueue-message` |
| [Integration System Configuration](#integration-system-configuration) | Attributes, reports, sequences, launch parameters, integration services |
| [Routing Patterns](#routing-patterns) | `routes-to` vs `routes-response-to`, sub-assembly calls, `vm://` URIs |
| [Common Components](#common-components-prepackaged-subassemblies) | `PutIntegrationMessage`, `PagedGet`, `Ftp`, `PdfPrintStep`, and more |

---

## Document Structure

Every assembly.xml follows this wrapper structure:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans
     xmlns="http://www.springframework.org/schema/beans"
     xmlns:beans="http://www.springframework.org/schema/beans"
     xmlns:atom="http://www.w3.org/2005/Atom"
     xmlns:cc="http://www.capeclear.com/assembly/10"
     xmlns:cloud="urn:com.workday/esb/cloud/10.0"
     xmlns:env="http://schemas.xmlsoap.org/soap/envelope/"
     xmlns:pi="urn:com.workday/picof"
     xmlns:wd="urn:com.workday/bsvc"
     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">

    <cc:assembly id="WorkdayAssembly" version="YYYY.RR">
        <!-- All components go here -->
    </cc:assembly>

</beans>
```

- `version` on `cc:assembly` is the Workday release version — default `2025.21` for new integrations
- `audit-log` attribute: `true` (store all logs), `false` (disable), `on-error` (store only error logs)
- All `cc:` elements are direct children of `cc:assembly` or nested inside mediations
- Whitespace between elements matters — it creates text nodes in the DOM (relevant for `@mixed` indexing in `assembly-diagram.xml`)

---

## Input/Output Options Reference

Most steps and transports accept these values for `input` and `output` attributes:

| Value | Description |
|-------|-------------|
| `message` | Entire message including rootpart and attachments. For output: creates new message, removing attachments |
| `soapbody` | SOAP body content from rootpart. Only valid for SOAP messages |
| `rootpart` | Root part of MIME message. For output: preserves existing attachments |
| `attachment` | MIME attachment by index. Requires index attribute (e.g. `input-attachment-index="0"`) |
| `variable` | Named MediationContext variable. Requires variable name attribute |

---

## Transports — Workday & HTTP

### cc:workday-in

Entry point for the integration. Contains the integration system configuration. Exactly one per assembly.

```xml
<cc:workday-in id="StartHere" routes-to="FirstMediationId">
    <cc:integration-system name="Integration_System_Name">
        <!-- attribute-map-service, report-service, sequence-generator-service go here -->
    </cc:integration-system>
</cc:workday-in>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `routes-to` | Yes | ID of the first component to receive the message |

### cc:workday-out-soap

SOAP call to a Workday web service. The SOAP operation is determined by the request body content, not by an attribute on the transport.

```xml
<cc:workday-out-soap id="CallChangeOtherIDs" routes-response-to="NextStepId" application="Human_Resources" version="v46.0"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `routes-response-to` | No | ID of component to receive the response |
| `execute-when` | No | MVEL boolean — only executes if true |
| `application` | Yes | Workday web service application name (e.g. `Human_Resources`, `Staffing`, `Payroll`) |
| `version` | Yes | API version (e.g. `v46.0`). Note: version in the XSLT request takes precedence if specified |
| `failure-message` | No | Custom error text prepended to transport errors |
| `replace-with-soap-fault` | No | `true` to replace failed message with a SOAP fault containing faultcode/faultstring |

> **WARNING**: `cc:workday-out` is **NOT valid** and will cause XSD validation errors in Studio. Always use `cc:workday-out-soap` for Workday SOAP web service calls.

### cc:workday-out-rest

REST call to a Workday API (typically RaaS custom reports).

```xml
<cc:workday-out-rest id="CallCustomReport" routes-response-to="NextStepId" extra-path="@{intsys.reportService.getExtrapath('ReportAlias')}?format=csv"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `routes-response-to` | No | ID of component to receive the response |
| `execute-when` | No | MVEL boolean — only executes if true |
| `extra-path` | No | Appended to the tenant REST URL. Supports MVEL templates `@{...}` |
| `method` | No | REST method: `get`, `post`, `put`. Default varies by context |
| `failure-message` | No | Custom error text prepended to transport errors |

### cc:http-out

HTTP call to an external (non-Workday) endpoint.

```xml
<cc:http-out id="PostToVendor" routes-response-to="NextStepId" endpoint="@{props['ia.endpoint']}" http-method="POST">
    <cc:rest-binding/>
    <cc:http-basic-auth/>
</cc:http-out>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `routes-response-to` | No | ID of component to receive the response |
| `endpoint` | Yes | Target URL. Supports MVEL templates `@{...}` |
| `http-method` | No | `GET`, `POST`, `PUT`, `PATCH`, `DELETE`. Default `POST`. Note: `PATCH` requires `wd.http.client` property set to `apache` |
| `accept` | No | Sets `Accept` header (e.g. `application/json`) |
| `connect-timeout` | No | Connection timeout in ms. Default 300000 (5 min) |
| `response-timeout` | No | Response timeout in ms. Default 21600000 (6 hr) |
| `retries` | No | Number of retry attempts on transport exception |
| `retry-delay` | No | Delay between retries in ms. Workday also respects `Retry-After` / `RateLimit-Reset` headers on 429 responses |
| `error-as-response` | No | `true` to copy server error response to the message instead of throwing |
| `streaming` | No | Enable HTTP streaming for PUT/POST |
| `accept-gzip` | No | `true` to add accept-encoding=gzip header |
| `gzip-content` | No | `true` to gzip the outgoing request body |
| `close-connection` | No | `true` to add `Connection: close` header |

Child elements:
- `<cc:rest-binding/>` — treat body as raw content (no SOAP envelope)
- `<cc:http-basic-auth username="..." password="..."/>` — HTTP Basic authentication. Can also use `callback-handler-bean` instead of username/password
- `<cc:http-custom-auth username="..." password="..." authenticator-bean="..."/>` — custom authentication via Spring bean
- `<cc:https-properties/>` — HTTPS settings: `accept-hosts`, `key-file`, `key-password`, `keystore-password`, `truststore-file`, `truststore-password`, `proxy-host`, `proxy-port`

### cc:local-in / cc:local-out

Sub-assembly entry and exit points. Used in pairs to create isolated functional blocks.

```xml
<!-- Sub-assembly entry point -->
<cc:local-in id="GetReport" routes-to="FirstStepInSubAssembly"/>

<!-- Calling a sub-assembly -->
<cc:local-out id="CallGetReport" store-message="none" routes-response-to="NextAfterReturn" endpoint="vm://Integration_System_Name/GetReport"/>
```

**cc:local-in attributes:**

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique ID — this becomes the sub-assembly name |
| `routes-to` | Yes | First component inside the sub-assembly |
| `access` | No | `public` (visible in Palette Workspace Components) or `private`. Default `private` |
| `use-global-error-handlers` | No | `true` = errors handled by parent assembly's global handler. Default `false` (handled at subassembly level) |
| `icon` | No | Custom 24x24 PNG/GIF icon path |
| `tooltip` | No | Tooltip description for the subassembly |

**cc:local-in Parameters Tab** — define accepted properties:
```xml
<cc:local-in id="SubProcess" routes-to="FirstStep">
    <cc:param name="worker.wid" type="string" required="true" documentation="Worker WID to process"/>
    <cc:out-param name="result.status" documentation="Processing result"/>
</cc:local-in>
```
Parameter types: `string`, `integer`, `long`, `double`, `float`, `boolean`

**cc:local-out attributes:**

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `endpoint` | Yes | `vm://IntegrationSystemName/LocalInId` or `vm://wcc/PutIntegrationMessage` |
| `store-message` | No | `none` to skip storing the message on the event |
| `routes-response-to` | No | ID of next component after the sub-assembly returns |
| `execute-when` | No | MVEL boolean expression — only executes if true |
| `clone-request` | No | `true` to copy message before passing to subassembly (prevents modifications affecting caller) |
| `propagate-abort` | No | `true` = abort flag propagates from subassembly to calling assembly. Critical for `setAbort` patterns |
| `unset-properties` | No | `true` = reset all local-out properties after subassembly call |

**cc:local-out for PutIntegrationMessage** (special pattern):

```xml
<cc:local-out id="PIMError" endpoint="vm://wcc/PutIntegrationMessage">
    <cc:set name="is.message.severity" value="'ERROR'"/>
    <cc:set name="is.message.summary" value="'Error description here'"/>
</cc:local-out>
```

The `cc:set` children set properties on the PIM call:
- `is.message.severity` — `'CRITICAL'`, `'ERROR'`, `'WARNING'`, or `'INFO'`
- `is.message.summary` — the message text (MVEL expression or string literal)

> **See also:** [Transports — File Transfer & Email](#transports--file-transfer--email) for `ftp-out`, `sftp-out`, `ftps-out`, `email-out`, `xmpp-out`, and `custom-out`.

---

## Mediations

### cc:async-mediation

Asynchronous processing block. Most common mediation type.

```xml
<cc:async-mediation id="ProcessData" routes-to="NextComponentId">
    <cc:steps>
        <!-- Steps go here: eval, cloud-log, store, set-headers, xslt, etc. -->
    </cc:steps>
    <cc:send-error id="SendErrorProcessData" routes-to="CatchProcessDataError"/>
</cc:async-mediation>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `routes-to` | No | ID of next component after steps complete |
| `handle-downstream-errors` | No | `true` = also catches errors from downstream components/transports |

**Required children:**
- `<cc:steps>` — contains the processing steps (can be empty)
- `<cc:send-error>` — error handler routing (**must be present on every mediation**)

### cc:sync-mediation

Synchronous processing block. Same structure as async but processes synchronously.

```xml
<cc:sync-mediation id="ValidateInput" routes-to="NextComponentId">
    <cc:steps>
        <!-- Steps go here -->
    </cc:steps>
    <cc:send-error id="SendErrorValidateInput" routes-to="CatchValidationError"/>
</cc:sync-mediation>
```

### cc:send-error

Error handler routing element. Must be the **last child** of a mediation (after `cc:steps`).

```xml
<cc:send-error id="SendErrorComponentName" routes-to="ErrorHandlerMediationId"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique ID — convention: `SendError` + parent mediation purpose |
| `routes-to` | Yes | ID of the error handler mediation |

At the assembly root level (global error handler):

```xml
<cc:send-error id="SendError" routes-to="ExtractGlobalError"/>
```

---

## Steps — Core

These are the most commonly used step types within `cc:steps`. For transform, validation, encoding, and logging steps see the sections that follow.

### cc:eval

MVEL expression evaluation.

```xml
<cc:eval id="SetProps">
    <cc:expression>props['p.error.count'] = 0;
props['ia.endpoint'] = intsys.getAttribute('Endpoint')</cc:expression>
</cc:eval>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |

The `<cc:expression>` child contains the MVEL code. Multiple statements separated by semicolons. Final statement does not need a semicolon.

### cc:cloud-log

Write an entry to the CloudLog HTML document.

```xml
<cc:cloud-log id="LogSuccess" level="info" message="Short summary" message-details="@{props['p.detail']}" reference-id="@{props['p.worker.id']}"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `level` | Yes | `info`, `warn`, `error`, `debug`, `fatal`, or `custom` (with MVEL expression) |
| `message` | Yes | Short summary text (plain string) |
| `message-details` | No | Detailed text. Supports MVEL templates `@{...}` |
| `variable-name` | No | Variable storing the output file. Multiple cloud-log steps with the same variable name concatenate into one report. Different names produce separate files |
| `reference-id` | No | Workday object reference ID for troubleshooting |
| `condition` | No | MVEL boolean expression — only logs if true |
| `header` | No | Header text for the cloud-log file. First cloud-log in the flow wins |
| `output-file-type` | No | `HTML` (default), `CSV`, or `XLSX`. Max 256 MB — results truncated if exceeded |

**Extra Columns** (child elements):
```xml
<cc:cloud-log id="LogDetail" level="info" message="Processed worker">
    <cc:extra-column key="empId" label="Employee ID" value="@{props['p.employee.id']}"/>
    <cc:extra-column key="name" label="Worker Name" value="@{props['p.worker.name']}"/>
</cc:cloud-log>
```

### cc:store

Store a document or variable content to the Integration Event.

```xml
<cc:store id="StoreLogs" input="variable" input-variable="cloud-log-content" expiresIn="P30D" title="CloudLog.html"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `input` | Yes | `message`, `soapbody`, `rootpart`, `attachment` (with index), or `variable` |
| `input-variable` | When input=variable | Variable name to store |
| `output` | No | Where to direct output (same options as input) |
| `expiresIn` | No | ISO 8601 duration (e.g. `P30D` = 30 days) |
| `title` | No | Filename for the stored document |
| `summary` | No | Summary text visible in Workday tenant |
| `collection` | No | Collection name for document storage |
| `createDocumentReference` | No | `true` to auto-create a Workday document reference |
| `contentDisposition` | No | Content-disposition header (overrides title) |
| `immutable` | No | `true` = document cannot be modified after creation |
| `entryID` | No | Unique Entry ID. If existing and mutable, overwrites. Use PUT for predefined IDs, POST when null |
| `isAttachment` | No | `true` = document is an OMS attachment |

**Size limits:** 1 GB individual (compressed), 3 GB cumulative (compressed). Workday terminates integrations exceeding these limits.

### cc:set-headers

Set or remove HTTP headers on the outgoing message.

```xml
<cc:set-headers id="SetAuthHeaders">
    <cc:remove-headers/>
    <cc:add-headers>
        <cc:add-header name="Authorization" value="Basic @{props['ia.token']}"/>
        <cc:add-header name="Content-Type" value="application/json"/>
    </cc:add-headers>
</cc:set-headers>
```

- `<cc:remove-headers/>` — clears all existing headers (always include before adding)
- `<cc:add-header>` — `name` is the header name, `value` supports MVEL templates

### cc:xslt

Run an XSLT 2.0 transformation. Compatible with assembly versions up to 2017.05.

```xml
<cc:xslt id="TransformData" resource="INT_Transform.xsl"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `resource` | Yes | XSLT filename in `WSAR-INF/` |
| `input` | No | `message`, `soapbody`, `rootpart`, `attachment`, or `variable` |
| `output` | No | `message`, `soapbody`, `rootpart`, `attachment`, or `variable` |
| `execute-when` | No | MVEL condition |

> **XSLT 2.0 only.** For XSLT 3.0 (streaming), use `cc:xslt-plus`.

### cc:xslt-plus

Run an XSLT 3.0 transformation with streaming support. **Preferred step for all new Studio integrations.** Always uses file-backed managed data. A log warning is produced if the stylesheet is not configured for streaming.

> Non-streaming transforms may consume up to **10x the document's disk size in memory**. Design with streaming for large documents.

```xml
<cc:xslt-plus id="TransformData" url="INT_Transform.xsl"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `url` | Yes | XSLT filename in `WSAR-INF/`. Can reference a variable: `mctx:vars/varName` |
| `input` | No | `message`, `soapbody`, `rootpart`, `attachment`, or `variable` |
| `output` | No | `message`, `soapbody`, `rootpart`, `attachment`, or `variable` |
| `secure-processing` | No | `true` to limit XML constructs for security |
| `execute-when` | No | MVEL condition |
| `schema-validation-mode` | No | Validates inputs/outputs via Saxon. Values: `lax`, `strict`, `preserve`, `strip` (default: off) |
| `schema-url` | No | Relative URL to XSD within the assembly project. Supports a sequence of URLs |

**XSLT Parameters**: MediationContext properties of supported Java types are automatically passed as `xsl:param` (String, Integer, Float, Double, Boolean, StringList, Node). Properties with invalid XSLT parameter names are skipped with a log warning.

> **Disable the XSL Validator** in Studio preferences when developing XSLT 3.0 — the validator does not recognize XSLT 3/XPath 3 features and may incorrectly block deployment.

> Note: `cc:xslt` uses the attribute `resource`, while `cc:xslt-plus` uses `url`. Getting this wrong causes a validation error.

### cc:write

Construct a new message body. Used for building REST API request payloads.

**Form-encoded body:**

```xml
<cc:write id="BuildTokenRequest" output-mimetype="application/x-www-form-urlencoded">
    <cc:message>
        <cc:text>grant_type=client_credentials&amp;client_id=@{props['ia.client.id']}&amp;client_secret=@{props['ia.client.secret']}&amp;scope=@{props['ia.scope']}</cc:text>
    </cc:message>
</cc:write>
```

**JSON body:**

```xml
<cc:write id="BuildEventPayload" output-mimetype="application/json">
    <cc:message>
        <cc:text>{
  "subject": "@{props['p.subject']}",
  "start": {
      "dateTime": "@{props['p.start.date']}",
      "timeZone": "@{props['p.time.zone']}"
  },
  "end": {
      "dateTime": "@{props['p.end.date']}",
      "timeZone": "@{props['p.time.zone']}"
  }
}
</cc:text>
    </cc:message>
</cc:write>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `output-mimetype` | No | MIME type of the output message (e.g. `application/json`, `application/x-www-form-urlencoded`) |

The `<cc:text>` content supports MVEL template expressions `@{...}`. Use `&amp;` for literal `&` and `&#xD;` for carriage returns in JSON.

### cc:json-to-xml

Converts a JSON message to XML so it can be queried with XPath.

```xml
<cc:json-to-xml id="JsonToXml"/>
```

| Property | Default | Description |
|---|---|---|
| Root Element Name | `root` | Name of the root element for generated XML |
| Nested Array Name | `entry` | XML element name for unnamed JSON arrays |
| Nested Object Name | `data` | XML element name for unnamed JSON objects |

After conversion, access values via XPath:

```
props['p.access.token'] = parts[0].xpath('/root/data/access_token')
```

### cc:xml-to-json

Converts an XML message to JSON. An XSD schema can optionally define type mappings and array structures.

```xml
<cc:xml-to-json id="XmlToJson"/>
```

| Property | Default | Description |
|---|---|---|
| Schema | (optional) | XSD to define JSON types and arrays. If omitted, types are inferred: recurring elements → arrays, parseable numbers → numbers, parseable booleans → booleans, all others → strings |
| Ignore Attributes | `true` | Set to `false` to include XML attributes in JSON output |

### cc:json-transformer

Transforms a JSON message using JsonPath expressions. Supports most JsonPath syntax including dot/subscript notation, recursive matches, array slices, wildcards, and filter expressions with regex.

> **Performance note**: Filter tokens (`[?(...)]`) and negative array indices require multiple passes of the input stream — expect longer processing.

The **json MVEL helper** (`json.stringAtJsonPath()`, `json.numberAtJsonPath()`, etc.) can be used in mapping value expressions within the transformer.

### cc:copy

Copy the current message to a named variable, or restore from a variable.

```xml
<!-- Save current message to a variable -->
<cc:copy id="SaveRequest" output="variable" output-variable="v.http.request"/>

<!-- Restore message from a variable -->
<cc:copy id="RestoreRequest" input="variable" input-variable="v.http.request"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `output` | No | `variable` to save the message |
| `output-variable` | When output=variable | Variable name to save to |
| `input` | No | `variable` to restore from |
| `input-variable` | When input=variable | Variable name to restore from |
| `input-xpath` | No | XPath to extract a section of the input |
| `output-xpath` | No | XPath to replace a section in the output |
| `append-to-output-element` | No | `true` to append input XML to the output-xpath match instead of replacing |
| `namespaces` | No | Namespace overrides for XPath: `prefix namespace prefix2 namespace2` |
| `stream-xpath` | No | `true` for streaming support with simple XPath |

### cc:splitter

Split the current message into multiple parts for iterative processing. This is a top-level component (sibling of mediations), not a step inside `cc:steps`.

**XML stream splitter (preferred for large messages):**

```xml
<cc:splitter id="SplitWorkers" no-split-message-error="false">
    <cc:sub-route name="ProcessSingleWorker" routes-to="ProcessWorkerMediation"/>
    <cc:xml-stream-splitter xpath="wd:Report_Data/wd:Report_Entry"/>
</cc:splitter>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `no-split-message-error` | No | `false` = do not error if there are no entries to split (empty report) |

The `cc:sub-route name` is descriptive, `routes-to` points to the mediation processing each split entry.

### cc:route

Conditional routing based on MVEL expressions. Evaluates conditions in order; first match wins.

```xml
<cc:route id="RouteByAction">
    <cc:mvel-strategy>
        <cc:choose-route expression="props['p.action'] == 'create'" route="CreateRoute"/>
        <cc:choose-route expression="props['p.action'] == 'update'" route="UpdateRoute"/>
        <cc:choose-route expression="props['p.action'] == 'delete'" route="DeleteRoute"/>
        <cc:choose-route expression="true" route="DefaultRoute"/>
    </cc:mvel-strategy>
    <cc:sub-route name="CreateRoute" routes-to="CreateMediation"/>
    <cc:sub-route name="UpdateRoute" routes-to="UpdateMediation"/>
    <cc:sub-route name="DeleteRoute" routes-to="DeleteMediation"/>
    <cc:sub-route name="DefaultRoute" routes-to="ErrorMediation"/>
</cc:route>
```

- Each `cc:choose-route` `expression` is an MVEL boolean expression
- The `route` attribute must match a `cc:sub-route name`
- Use `expression="true"` as a catch-all default route
- Use `&amp;&amp;` for logical AND in XML (represents `&&`)

### cc:validation

MVEL expression that must evaluate to true, otherwise throws an error.

```xml
<cc:validation id="ValidateNotEmpty" message="Report returned no data">
    <cc:expression>parts[0].text != empty</cc:expression>
</cc:validation>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `message` | Yes | Error message shown when validation fails |

> **More steps:** [Server Logging](#steps--server-logging) | [Transform](#steps--transform) | [Validation](#steps--validation) | [Encoding & Compression](#steps--encoding--compression) | [Other](#steps--other)
>
> **Assembly-level components:** [Flow Control — Routing](#flow-control--routing) | [Flow Control — Splitting & Aggregation](#flow-control--splitting--aggregation)

---

## Integration System Configuration

Inside `cc:workday-in` > `cc:integration-system`:

### Integration Attributes (cloud:attribute-map-service)

```xml
<cloud:attribute-map-service name="INT_ServiceName">
    <cloud:attribute name="Attribute_Name">
        <cloud:type>
            <cloud:simple-type>text</cloud:simple-type>
        </cloud:type>
        <cloud:display-option>required-for-launch</cloud:display-option>
    </cloud:attribute>
</cloud:attribute-map-service>
```

**Simple types:** `text`, `boolean`, `date`, `date-time`, `numeric`

**Display options:**
- `required-for-launch` — must be filled before integration can run
- `display-as-password` — masks the value in the UI
- `hidden` — not shown in the UI

**Reference type attribute (single instance):**

```xml
<cloud:attribute name="Pay_Group">
    <cloud:type>
        <cloud:reference-type>Pay_Group</cloud:reference-type>
    </cloud:type>
</cloud:attribute>
```

**Reference type attribute (multi-instance):**

```xml
<cloud:attribute name="Companies">
    <cloud:type>
        <cloud:reference-type>Company</cloud:reference-type>
    </cloud:type>
    <cloud:display-option>multi-instance</cloud:display-option>
</cloud:attribute>
```

### Report Service (cloud:report-service)

```xml
<cloud:report-service name="INT_RS">
    <cloud:report-alias description="Report Description" name="ReportAlias">
        <cloud:report-reference description="Report Description" type="WID">hex_wid_value</cloud:report-reference>
    </cloud:report-alias>
</cloud:report-service>
```

Access in MVEL: `intsys.reportService.getExtrapath('ReportAlias')`

### Sequence Generator Service

```xml
<cloud:sequence-generator-service name="INT_SEQ">
    <cloud:sequence-generator description="File Sequence" name="FileSeq"/>
</cloud:sequence-generator-service>
```

Access in MVEL: `sequenceGenerator.getNextSequenceValue('FileSeq')`

### Launch Parameters (cloud:param)

```xml
<cloud:param name="Effective Date">
    <cloud:type>
        <cloud:simple-type>datetime</cloud:simple-type>
    </cloud:type>
    <cloud:default>
        <cloud:class-report-field description="As Of Entry DateTime of Last Completed or Completed with Warnings Integration Event" type="WID">5c28b2d34d1a10000d8191a1fe0b59b2</cloud:class-report-field>
    </cloud:default>
</cloud:param>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `name` | Yes | Prompt label shown at launch |

The `cloud:default` child provides a default value. `cloud:class-report-field` references a Workday calculated field by WID for dynamic defaults (e.g. "last successful run time").

Access in MVEL: `lp.getSimpleData('Effective Date')`

### Multiple workday-in Entry Points

A single assembly can contain multiple `cc:workday-in` elements, each with a different `cc:integration-system`. This allows one codebase to serve multiple integration system configurations (e.g. different companies or tenants). All entry points share the same assembly logic via `routes-to`.

```xml
<cc:workday-in id="CompanyA" routes-to="GetAttributes">
    <cc:integration-system name="INT_CompanyA_Studio">
        <!-- Company A attributes -->
    </cc:integration-system>
</cc:workday-in>
<cc:workday-in id="CompanyB" routes-to="GetAttributes">
    <cc:integration-system name="INT_CompanyB_Studio">
        <!-- Company B attributes -->
    </cc:integration-system>
</cc:workday-in>
```

---

## Routing Patterns

### routes-to vs routes-response-to

- `routes-to` — sends the **current message** to the target component (one-way or chain)
- `routes-response-to` — sends the **response** from a transport call to the target component

### Sub-assembly call pattern

```
MainFlow mediation
  routes-to → local-out (CallSubAssembly)
                endpoint = vm://IntName/SubAssemblyLocalIn
                routes-response-to → NextStepAfterReturn

local-in (SubAssemblyLocalIn)
  routes-to → first component in sub-assembly
  ... processing ...
  last component has no routes-to (returns to caller)
```

### PutIntegrationMessage endpoint

Always: `endpoint="vm://wcc/PutIntegrationMessage"`

This is a Workday system endpoint, not tied to your integration system name.

### vm:// URI format

- Sub-assembly calls: `vm://Integration_System_Name/LocalInId`
- PutIntegrationMessage: `vm://wcc/PutIntegrationMessage`

The integration system name must exactly match the `name` attribute on `cc:integration-system`.

---

## Transports — File Transfer & Email

### cc:ftp-out

Send files to an FTP server. Asynchronous (request only).

```xml
<cc:ftp-out id="SendFile" endpoint="ftp://ftpserver.example.org/outputDir" method="put" username="@{props['ia.ftp.user']}" password="@{props['ia.ftp.pass']}" output-file-pattern="@{props['p.filename']}" binary-file="true"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `endpoint` | Yes | `ftp://host/directory` — directory must exist |
| `method` | No | `put`, `get`, `list`, `delete`. Default `put` |
| `username` / `password` | Yes | FTP credentials |
| `output-file-pattern` | No | Filename pattern. Tokens: `${INFILE}`, `${UUID}`, `${EXT}` |
| `input-file-pattern` | No | Glob pattern for `get`/`list`/`delete` (e.g. `*.xml`) |
| `binary-file` | No | `true` for binary transfer |
| `execute-when` | No | MVEL condition |
| `routes-response-to` | No | Response destination |

### cc:sftp-out

Send files securely via SFTP (FTP over SSH). Asynchronous.

```xml
<cc:sftp-out id="SendSecure" endpoint="sftp://sftpserver.example.org/outputDir" method="put" username="@{props['ia.sftp.user']}" password="@{props['ia.sftp.pass']}" output-file-pattern="@{props['p.filename']}" binary-file="true"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `endpoint` | Yes | `sftp://host/directory` |
| `method` | No | `put`, `get`, `list`, `delete` |
| `username` / `password` | Yes | SFTP credentials |
| `host-key-fingerprint` | No | SSH host key fingerprint for verification |
| `dual-authentication` | No | `true` to require both key + password |
| `output-file-pattern` | No | Filename tokens: `${INFILE}`, `${UUID}`, `${EXT}` |
| `binary-file` | No | `true` for binary |
| `temp-file-name` | No | Upload as temp name, rename on completion |
| `execute-when` | No | MVEL condition |

Child elements:
- `<cc:private-key-properties passphrase="..." private-key="private_key.txt"/>` — key file in `WSAR-INF/` or `attachment:privatekey/@{WID}`
- `<cc:proxy-properties proxy-host="..." proxy-port="..." proxy-type="http"/>` — proxy settings

### cc:ftps-out

Send files via FTP over SSL (FTPS). Same attributes as `cc:ftp-out` plus:

| Attribute | Description |
|-----------|-------------|
| `explicit-ssl` | `true` for AUTH TLS (explicit), `false` for AUTH SSL (implicit) |

Child elements: `proxy-properties`, `firewall-properties`, `client-key-properties`, `server-key-properties`

### cc:email-out

Send email via SMTP. Asynchronous.

```xml
<cc:email-out id="SendEmail" to="mailto:recipient@example.com" subject="@{props['p.subject']}" from="sender@example.com" host="smtp.office365.com" port="587" starttls="true" user="@{props['ia.email.user']}" password="@{props['ia.email.pass']}"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `to` | Yes | `mailto:address`. Use empty `mailto:` for BCC-only |
| `subject` | Yes | Email subject line |
| `from` | Yes | Sender address |
| `host` | Yes | SMTP server (`smtp.office365.com`, `smtp.gmail.com`, or `localhost` for OAuth) |
| `port` | No | Default 25. SSL=465, STARTTLS=587 |
| `ssl` / `starttls` | No | Mutually exclusive. `true` to enable |
| `user` / `password` | No | SMTP credentials |
| `execute-when` | No | MVEL condition |
| `bcc` | No | Semicolon-separated BCC recipients |
| `cc` | No | Semicolon-separated CC recipients |
| `reply-to` | No | Reply-to address(es) |

OAuth tab supports Microsoft Outlook and Google Gmail OAuth authentication for Studio email delivery.

Attachment pattern: set message `input`/`output` to `message`, set `Output MIME Type` to `text/plain` for body, add attachment via `output=attachment`, index `0`. Use MVEL for filename: `parts[1].setHeader('Content-Disposition', 'attachment; filename=payload.txt')`

### cc:custom-out

Customizable out-transport backed by a Spring bean.

```xml
<cc:custom-out id="CustomSend" endpoint="..." spring-bean="myTransportBean" method-name="send"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `spring-bean` | Yes | Spring bean implementing the transport interface |
| `method-name` | Yes | Java method name |
| `input` / `output` | No | Message, soapbody, rootpart, attachment, or variable |
| `endpoint` | No | Target endpoint |
| `execute-when` | No | MVEL condition |

### cc:xmpp-out

Write instant messages to a Jabber/XMPP server. Asynchronous.

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `endpoint` | Yes | `xmpp:recipient@domain.com` |
| `domain` | Yes | XMPP domain (e.g. `gmail.com`) |
| `server` | Yes | XMPP server host/IP |
| `port` | No | Default 5222 |
| `username` / `password` | Yes | XMPP credentials |

---

### cc:custom-mediation

Customizable mediation backed by a Spring bean.

```xml
<cc:custom-mediation id="CustomProcess" routes-to="NextStep" ref="myCustomBean" request-method="processRequest" response-method="processResponse"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `ref` | Yes | Spring bean reference |
| `request-method` | Yes | Java method for request processing |
| `response-method` | No | Java method for response processing |
| `routes-to` | No | Next component |
| `routes-response-to` | No | Response destination |
| `execute-when` | No | MVEL condition |

---

## Flow Control — Routing

The `cc:route` component (see [Steps — Core](#steps--core)) supports these strategy child elements:

### cc:mvel-strategy (most common)

```xml
<cc:mvel-strategy>
    <cc:choose-route expression="props['p.action'] == 'create'" route="CreateRoute"/>
    <cc:choose-route expression="true" route="DefaultRoute"/>
</cc:mvel-strategy>
```

### cc:xpath-strategy

```xml
<cc:xpath-strategy xpath-version="2" namespaces="wd urn:com.workday/bsvc">
    <cc:choose-route expression="/wd:Report_Data/wd:Report_Entry" route="HasData"/>
    <cc:choose-route expression="true" route="NoData"/>
</cc:xpath-strategy>
```

### cc:regex-strategy

```xml
<cc:regex-strategy>
    <cc:choose-route expression=".*SUCCESS.*" route="SuccessRoute"/>
    <cc:choose-route expression=".*ERROR.*" route="ErrorRoute"/>
</cc:regex-strategy>
```

### cc:loop-strategy

```xml
<cc:loop-strategy condition="props['p.page'] &lt;= props['p.total.pages']" init="props['p.page'] = 1" increment="props['p.page'] = props['p.page'] + 1" repeat-limit="200000">
    <cc:sub-route name="PageLoop" routes-to="FetchPage"/>
</cc:loop-strategy>
```

| Attribute | Description |
|-----------|-------------|
| `condition` | MVEL boolean — loop runs while true |
| `init` | MVEL expression run once before first iteration |
| `increment` | MVEL expression run after each iteration |
| `repeat-limit` | Max iterations (up to 200,000 total across all calls to same strategy) |

### cc:round-robin-strategy

Distributes messages cyclically across sub-routes.

| Attribute | Description |
|-----------|-------------|
| `clone-request` | `true` to copy message for each sub-route |
| `failover` | `true` to skip failed sub-routes |
| `timeout` | Ms to exclude a failed sub-route |

### cc:failover-strategy

Attempts sub-routes in order; falls back to next on failure.

| Attribute | Description |
|-----------|-------------|
| `clear-fault` | `true` to clear exceptions from failed sub-routes |
| `clone-request` | `true` to copy message |

### cc:all-strategy

Sends to every sub-route in sequence.

| Attribute | Description |
|-----------|-------------|
| `clone-request` | `true` to copy message |
| `ignore-errors` | `true` to continue despite sub-route errors |

### cc:doc-iterator

Iterates over documents retrieved from Workday (via Retrieval Service).

```xml
<cc:doc-iterator variable-name="wd.retrieve.variable" sort-by="FILENAME_ASCENDING"/>
```

| Attribute | Description |
|-----------|-------------|
| `variable-name` | Variable storing each document (default: `wd.retrieve.variable`) |
| `labels` | Filter by document label(s) |
| `sort-by` | `FILENAME_ASCENDING`, `FILENAME_DESCENDING`, or `NONE` |

---

## Flow Control — Splitting & Aggregation

The `cc:splitter` component (see [Steps — Core](#steps--core)) supports these splitter strategy child elements:

### cc:xml-stream-splitter (preferred for large XML)

```xml
<cc:xml-stream-splitter xpath="wd:Report_Data/wd:Report_Entry" namespaces="wd urn:com.workday/bsvc"/>
```

Streams XML — only current node in memory. Use for large Workday reports.

### cc:xpath-splitter

```xml
<cc:xpath-splitter xpath="/root/record" namespaces="..." xpath-version="2"/>
```

DOM-based (loads full document). Use only for smaller messages.

### cc:json-splitter

```xml
<cc:json-splitter json-path="$.data[*]"/>
```

Splits JSON arrays by JSONPath expression.

### cc:standard-splitter

Splits delimited text files (CSV, fixed-width) into records.

```xml
<cc:standard-splitter output-mimetype="text/plain" line-token-delimiter-regexp="\n">
    <cc:header-fixed-lines lines-count="1"/>
    <cc:content-fixed-lines lines-count="1"/>
</cc:standard-splitter>
```

Child elements for structure detection:
- `<cc:header-fixed-lines lines-count="N"/>` or `<cc:header-ends-with regexp="..."/>`
- `<cc:content-fixed-lines lines-count="N"/>` or `<cc:content-starts-with regexp="..."/>` or `<cc:content-starts-ends start-regexp="..." end-regexp="..."/>`
- `<cc:footer-fixed-lines lines-count="N"/>` or `<cc:footer-starts-with regexp="..."/>`

### cc:unzip-splitter

Extracts files from ZIP/TAR archives, one message per file.

```xml
<cc:unzip-splitter file-pattern=".*\.csv" format="zip"/>
```

### cc:mtable-splitter

Splits mtable rows into individual messages.

```xml
<cc:mtable-splitter mtable-name="prop.name" row-name="row.prop" row-format="map"/>
```

| Attribute | Description |
|-----------|-------------|
| `row-format` | `array` or `map` |

### cc:custom-splitter

```xml
<cc:custom-splitter ref="myCustomSplitterBean"/>
```

### cc:aggregator

Concatenates split messages into batches for reassembly. Use after a `cc:splitter` to recombine split messages.

```xml
<cc:aggregator id="AggregateResults" routes-to="DeliverFile" force-batch-on-last-message="true">
    <cc:message-content-collater output="rootpart" separator="&#10;"/>
    <cc:size-batch-strategy batch-size="100"/>
</cc:aggregator>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique component ID |
| `routes-to` | No | Destination for batched output |
| `collate-when` | No | MVEL expression controlling collation |
| `force-batch-on-last-message` | No | `true` to force batch when splitter sends last message |
| `force-batch-when` | No | MVEL expression controlling batch trigger |

**Batch strategy child elements** (choose one):
- `<cc:size-batch-strategy batch-size="100"/>` — batch by count
- `<cc:time-batch-strategy time-period="60" time-unit="seconds"/>` — batch by time
- `<cc:custom-batch-strategy ref="myBatchBean"/>` — custom logic

**Collater child elements** (choose one):
- `<cc:message-content-collater output="rootpart" separator="&#10;" header-text="..." footer-text="..."/>` — concatenate text
- `<cc:xml-message-content-collater output="rootpart" xpath="..." namespaces="..."/>` — aggregate XML
- `<cc:json-collater output="rootpart"/>` — aggregate JSON
- `<cc:zip-file-collater output="rootpart" format="zip" message-entity-name="..."/>` — combine into ZIP/TAR
- `<cc:mtable-collater mtable-name="..." row-name="..." column-names="..." index-column="..."/>` — aggregate mtable rows
- `<cc:custom-collater ref="myCollaterBean" output="rootpart"/>` — custom logic

---

## Steps — Server Logging

> Note: For CloudLog (the HTML/CSV report file stored on the Integration Event), see `cc:cloud-log` in [Steps — Core](#steps--core). For storing documents, see `cc:store` in Steps — Core.

### cc:log

Write a Log4j message to Workday server logs (visible in Studio console, not in the Integration Event).

```xml
<cc:log id="LogDebug" level="info" input="rootpart"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `level` | Yes | `debug`, `info`, `warn`, `error`, `fatal` |
| `input` | No | Message source (default: message) |
| `category` | No | Logger category name. Default `DEFAULT` |
| `execute-when` | No | MVEL condition |

---

## Steps — Transform

### cc:fop

Generate PDF/RTF from XML using Apache FOP.

```xml
<cc:fop id="GeneratePDF" input="rootpart" output="rootpart" url="report_template.xsl"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `url` | Yes | FOP stylesheet in WSAR-INF |
| `input` / `output` | No | Standard I/O options |
| `title` | No | Document metadata title |
| `author` | No | Document metadata author |
| `user-password` | No | PDF password protection |
| `configuration-xml` | No | Path to Apache FOP config XML (for custom fonts) |

### cc:text-excel

Convert between Excel and CSV.

```xml
<cc:text-excel id="ExcelToCSV" style="XLSX/XLS to Text" input="rootpart" output="rootpart"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `style` | Yes | `XLSX/XLS to Text`, `Text to XLS`, or `Text to XLSX` |
| `excel-style` | No | `workbook` (entire workbook) or `sheet` (single sheet) |
| `excel-sheet-number` | No | Sheet number when style is `sheet` |
| `usevalues` | No | `true` to use underlying values instead of formatted display values |

### cc:textschema

Convert between text and XML using a Text Schema XSD.

```xml
<cc:textschema id="TextToXml" url="schema.xsd" style="text2xml" input="rootpart" output="rootpart"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `url` | Yes | Text schema XSD filename in WSAR-INF |
| `style` | Yes | `text2xml` or `xml2text` |
| `input` / `output` | No | Standard I/O options |

### cc:xml-to-csv

Stream-convert XML to CSV (low memory).

```xml
<cc:xml-to-csv id="XmlToCsv" input="rootpart" output="rootpart"/>
```

### cc:csv-to-xml

Stream-convert CSV to XML (low memory).

```xml
<cc:csv-to-xml id="CsvToXml" input="rootpart" output="rootpart"/>
```

### cc:xml-to-json

Convert XML document to JSON.

```xml
<cc:xml-to-json id="XmlToJson" input="rootpart" output="rootpart"/>
```

### cc:xml-to-java

Unmarshal XML to Java objects via JAXB.

```xml
<cc:xml-to-java id="Unmarshal" input="rootpart"/>
```

Extracts Java objects into MediationContext for use by custom Spring beans.

### cc:java-to-xml

Marshal Java objects to XML via JAXB.

```xml
<cc:java-to-xml id="Marshal" output="rootpart"/>
```

### cc:wrap-soap

Wrap XML message in a SOAP envelope for forwarding to SOAP web services.

```xml
<cc:wrap-soap id="WrapInSoap" input="rootpart" output="rootpart"/>
```

### cc:character-conversion

Perform character conversion on text content.

```xml
<cc:character-conversion id="ConvertEncoding" input="rootpart" output="rootpart"/>
```

### cc:javascript

Execute a JavaScript script or function.

```xml
<cc:javascript id="RunScript" script="transform.js" input="rootpart" output="rootpart"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `script` | XOR with function | JS script file in WSAR-INF |
| `function` | XOR with script | JS function file in WSAR-INF |
| `input` / `output` | No | Standard I/O options |

> Specify either `script` or `function`, **never both**. Deployment fails if both are set.

---

## Steps — Validation

### cc:validate

Validate XML against XSD, DTD, or well-formedness check.

```xml
<cc:validate id="ValidateXml" schema="schema.xsd" mode="schema" input="rootpart" failure-message="Input XML is invalid"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `mode` | No | `schema`, `dtd`, or `well-formed` |
| `schema` | When mode=schema | Schema file path |
| `dtd` | When mode=dtd | DTD file path |
| `xpath` | No | XPath to select elements for validation |
| `failure-message` | No | Custom error message on failure |
| `replace-message` | No | `true` to replace the entire error with failure-message |
| `filter` | No | `true` = discard message silently on failure; `false` (default) = raise error |

### cc:validate-exp

Validate using one or more MVEL expressions.

```xml
<cc:validate-exp id="ValidateData">
    <cc:exp expression="props['p.count'] > 0" failure-message="No records to process" error-number="20001"/>
    <cc:exp expression="props['ia.endpoint'] != empty" failure-message="Endpoint not configured" error-number="20002"/>
</cc:validate-exp>
```

| Attribute on `cc:exp` | Description |
|-----------|-------------|
| `expression` | MVEL boolean — must evaluate to true |
| `failure-message` | Error text when false |
| `error-number` | Numeric error code |
| `replace` | `true` to replace default error with failure-message |

> Note: The inline `cc:validation` step (in [Steps — Core](#steps--core)) is a simpler single-expression alternative.

### cc:validate-xpath

Validate using an XPath expression (true if non-empty result).

```xml
<cc:validate-xpath id="CheckData" xpath="/root/data" namespaces="..." input="rootpart"/>
```

---

## Steps — Encoding & Compression

### cc:pgp-encrypt

PGP encrypt data. Best practice: use Workday Delivery Service instead for Studio integrations.

```xml
<cc:pgp-encrypt id="Encrypt" input="rootpart" output="rootpart" certificate="attachment:certificate/@{intsys.getAttributeReferenceData('PGP Key', 'WID')}" ascii-armored="true"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `certificate` | Yes | Public key: `attachment:certificate/WID`, `mctx:vars/VarName`, or filename in WSAR-INF |
| `ascii-armored` | No | `true` for Base64-armored output |
| `containing-integrity-check` | No | `true` to generate message signature |
| `signing-private-key` | No | Private key for signing (file:// protocol) |
| `private-key-passphrase` | No | Passphrase for signing key |
| `textmode` | No | `true` for text data with CR/LF endings |
| `decrypted-filename` | No | Filename embedded in encrypted file for recipient |

### cc:pgp-decrypt

PGP decrypt data.

```xml
<cc:pgp-decrypt id="Decrypt" input="rootpart" output="rootpart" private-key="file://private_key.asc" passphrase="@{props['ia.pgp.passphrase']}"/>
```

| Attribute | Required | Description |
|-----------|----------|-------------|
| `id` | Yes | Unique step ID |
| `private-key` | Yes | Private key file (file:// protocol) |
| `passphrase` | Yes | Key passphrase |
| `decrypted-filename` | No | Fallback filename if none embedded |

### cc:base64-encode / cc:base64-decode

```xml
<cc:base64-encode id="Encode" input="rootpart" output="rootpart"/>
<cc:base64-decode id="Decode" input="rootpart" output="rootpart"/>
```

### cc:zip / cc:unzip

```xml
<cc:zip id="ZipOutput" input="message" output="rootpart"/>
<cc:unzip id="UnzipInput" input="rootpart" output="message"/>
```

The `zip` step transforms rootpart + attachments into a ZIP. The `unzip` step extracts: first file becomes rootpart, others become attachments.

### cc:compress / cc:decompress

Single-file GZIP or BZIP2 compression (no archiving).

```xml
<cc:compress id="GzipOutput" input="rootpart" output="rootpart"/>
<cc:decompress id="GunzipInput" input="rootpart" output="rootpart"/>
```

### cc:custom

Custom step backed by a Spring bean.

```xml
<cc:custom id="CustomStep" ref="myStepBean" method-name="process" input="rootpart" output="rootpart"/>
```

### cc:set-dynamic-endpoint

Configure WS-Addressing endpoint for a downstream out-transport.

```xml
<cc:set-dynamic-endpoint id="SetEndpoint" endpoint="@{props['p.dynamic.url']}"/>
```

### cc:retrieve

Retrieve a previously stored document.

```xml
<cc:retrieve id="GetStoredDoc" output="rootpart" collection="MyCollection" entry="@{props['p.entry.id']}"/>
```

### cc:xmldiff

Compare two XML documents. Access results via `xmldiff.isDifferent()` in MVEL.

```xml
<cc:xmldiff id="CompareXml" first-input="variable" first-input-variable="v.before" second-input="variable" second-input-variable="v.after" output="variable" output-variable="v.diff"/>
```

### cc:enqueue-message

Organize messages into a named queue.

```xml
<cc:enqueue-message id="Enqueue" queueName="processing.queue" input="rootpart" output="rootpart"/>
```

### cc:etv

Transform and validate XML elements based on attached attributes.

```xml
<cc:etv id="TransformValidate" input="rootpart" output="rootpart" url="etv_rules.xml"/>
```

### cc:xtt

Convert XML to text using XTT (XML Text Template) attributes.

```xml
<cc:xtt id="XmlToText" input="rootpart" output="rootpart"/>
```

### cc:mtable-builder

Create an in-memory table from CSV or JSON data.

```xml
<cc:mtable-builder id="BuildTable" input="rootpart">
    <cc:csv-mtable-reader/>
</cc:mtable-builder>
```

Child elements: `<cc:csv-mtable-reader/>` or `<cc:json-mtable-reader/>`

### cc:mtable-writer

Write an mtable to the message as CSV or JSON.

```xml
<cc:mtable-writer id="WriteTable" output="rootpart">
    <cc:csv-mtable-writer/>
</cc:mtable-writer>
```

Child elements: `<cc:csv-mtable-writer/>` or `<cc:json-mtable-writer/>`

---

## Integration Services

Inside `cc:workday-in` > `cc:integration-system`, alongside integration attributes:

### Delivery Service

```xml
<cloud:delivery-service name="INT_DS"/>
```

Delivers documents to a target endpoint (SFTP, etc.) from your Workday tenant. Configured in the tenant, not in the assembly.

### Retrieval Service

```xml
<cloud:retrieval-service name="INT_RS"/>
```

Retrieves documents from remote clients. Stores them in the integration event for processing.

### Listener Service

```xml
<cloud:listener-service name="INT_LS"/>
```

Enables the integration to receive launch messages from third-party clients through the Workday tenant.

### Transaction Log Service

```xml
<cloud:transaction-log-service name="INT_TLS"/>
```

Provides access to transaction log events the integration system has subscribed to.

### Custom Object Service

```xml
<cloud:custom-object-service name="INT_COS">
    <cloud:custom-object-alias name="ObjectAlias" description="Custom Object">
        <cloud:custom-object-reference type="WID">hex_wid_value</cloud:custom-object-reference>
    </cloud:custom-object-alias>
</cloud:custom-object-service>
```

### Service Reference

Reference a service configured on another workday-in transport within the same collection:

```xml
<cloud:service-reference name="SharedService"/>
```

---

## Common Components (Prepackaged Subassemblies)

Called via `cc:local-out` with `endpoint="vm://wcc/ComponentName"`:

| Component | Endpoint | Purpose |
|-----------|----------|---------|
| PutIntegrationMessage | `vm://wcc/PutIntegrationMessage` | Send status messages to Workday (max 500 calls; subsequent redirected to log) |
| PutIntegrationEvent | `vm://wcc/PutIntegrationEvent` | Update integration event status |
| GetIntegrationSystems | `vm://wcc/GetIntegrationSystems` | Retrieve and parse integration system config |
| GetEventConfigurations | `vm://wcc/GetEventConfigurations` | Retrieve service configurations for an event |
| GetEventDocuments | `vm://wcc/GetEventDocuments` | Retrieve documents attached to an event |
| GetIntegrationEvent | `vm://wcc/GetIntegrationEvent` | Retrieve an integration event by reference ID |
| PagedGet | `vm://wcc/PagedGet` | Page-by-page web service data retrieval |
| PagedGetLocalPaging | `vm://wcc/PagedGetLocalPaging` | Local paging (single query for all WIDs, then per-WID retrieval) |
| Ftp | `vm://wcc/Ftp` | Unified FTP/SFTP/FTPS transport (auto-detects protocol from `wd.ftp.endpoint`) |
| PdfPrintStep | `vm://wcc/PdfPrintStep` | Convert report data to PDF via BIRT |
| SalesforceConnector | `vm://wcc/SalesforceConnector` | Authenticated Salesforce messaging |
| PrismConnector | `vm://wcc/PrismConnector` | Send CSV data to Prism Analytics |

### PutIntegrationMessage Parameters

```xml
<cc:local-out id="PIMError" endpoint="vm://wcc/PutIntegrationMessage">
    <cc:set name="is.message.severity" value="'ERROR'"/>
    <cc:set name="is.message.summary" value="'Worker processing failed for ID: ' + props['p.worker.id']"/>
</cc:local-out>
```

| Parameter | Values |
|-----------|--------|
| `is.message.severity` | `'CRITICAL'`, `'ERROR'`, `'WARNING'`, `'INFO'` |
| `is.message.summary` | Message text (MVEL expression) |

### Ftp Subassembly Parameters

| Parameter | Description |
|-----------|-------------|
| `wd.ftp.endpoint` | Protocol detection: must start with `ftp://`, `sftp://`, or `ftps://` |
| `wd.ftp.username` / `wd.ftp.password` | Credentials |
| `wd.ftp.method` | `'put'`, `'get'`, `'list'`, `'delete'`, `'mget'`, `'mdelete'` |
| `wd.ftp.file.pattern` | File pattern for get/list/delete |
| `wd.ftp.passive.mode` | `true` for passive FTP |
| `wd.ftp.temp.file.name` | Temp filename for atomic put |
| `wd.ftp.directory` | Relative/absolute directory path |
| `wd.ftp.private.key` | SFTP private key: `attachment:privatekey/@{WID}` |
| `wd.ftp.timeout` | Timeout in ms |
| `wd.ftp.max.attempts` | Max connection attempts |

### PagedGet Parameters

| Parameter | Description |
|-----------|-------------|
| `is.paged.get.process.endpoint` | Sub-assembly endpoint for per-page processing |
| `is.paged.get.aggregate.header` | XML header for aggregated output |
| `is.paged.get.aggregate.footer` | XML footer for aggregated output |
| `is.paged.get.aggregate.xpath` | XPath to extract content from each page |

> For large result sets, use per-page processing (`is.paged.get.process.endpoint`) instead of aggregation.
