---
name: mvel-studio-skill
description: "Workday Studio MVEL expression language reference. Use when writing or debugging MVEL expressions, cc:eval blocks, property evaluations, conditional routing, string manipulation, date formatting, data transformations, launch parameters (lp), integration attributes (intsys), document accessor (da), XPath via parts[], MVEL template capable properties, splitter patterns, or HashMap/ArrayList operations in Workday Studio assembly.xml integrations."
argument-hint: "Describe the MVEL task or question"
---

# MVEL Expression Language — Workday Studio

MVEL is the expression language integrated into the Workday ESB Assembly framework. It manipulates assembly context variables, message parts, and Java objects within `cc:eval` steps, expression-capable properties, and webservice template fields.

## When to Use

- Writing or debugging `cc:eval` MVEL expressions in assembly.xml
- Accessing launch parameters (`lp`), integration attributes (`intsys`), or integration maps
- Manipulating message parts via `parts[]` or variables via `vars[]`
- Building conditional routing, splitter logic, or error counters
- Formatting dates, numbers, or strings in MVEL instead of XSLT
- Using MVEL template syntax (`@foreach{}`, `@if{}`) in webservice write components
- Working with HashMaps, ArrayLists, or property store (`props[]`)

## Procedure

1. Identify which MVEL context variable is relevant to your task (see Quick Reference below)
2. Consult the [full MVEL reference guide](./references/mvel-reference.md) for syntax, examples, and patterns
3. Follow the naming conventions: prefix properties with integration name, use `ia.` for integration attributes, `lp.` for launch parameters
4. Use descriptive, unabbreviated property names for readability

## Quick Reference — Key MVEL Variables

| Variable | Purpose | Example |
|----------|---------|---------|
| `props` | Property store (mediation context) | `props['my.property']` |
| `lp` | Launch parameters | `lp.getSimpleData('label')` |
| `intsys` | Integration system config & attributes | `intsys.getAttribute('username')` |
| `da` | Document accessor (retrieve files) | `da.toVar('file.txt', 'var1')` |
| `parts` | Message parts (root=0, attachments=1+) | `parts[0].xpath('/a/b')` |
| `vars` | Message context variables | `vars['myVar'].text` |
| `util` | Utility functions (40+ helpers) | `util.isLastMessageInBatch()` |
| `context` | Full MediationContext object | `context.getProperty('prop')` |
| `intsys.getMap` | Integration maps | `intsys.getMap('mapName').get('key')` |
| `sequenceGenerator` | Sequence generator service | `sequenceGenerator.getNextSequenceValue('name')` |
| `epg` | External pay groups | `epg.getStartDate('periodWid')` |
| `mtable` | In-memory table (MTable) | `mtable['prop'].get(0, 'Column')` |
| `env` | JVM system properties | `env['cc.hostname']` |
| `ftp` | FTP helper (protocol detection) | `ftp.isSftp('sftp://server/dir')` |
| `message` | MediationMessage interface | `message.rootPartAsText` |
| `spring` | Spring ApplicationContext | `spring.getBean('name').property` |
| `xmldiff` | XML diff step result | `xmldiff.isDifferent()` |

## Full Reference

See [mvel-reference.md](./references/mvel-reference.md) for the complete guide covering:
- Operators, assignments, and literals
- Launch parameters and integration attributes
- Document accessor and XPath evaluation
- String functions, date/number formatting, padding
- Control flow, ternary operators, HashMap/ArrayList patterns
- MVEL template syntax for webservice components
- Splitter patterns (batch detection, counters)
- Complete MVEL variable reference table
