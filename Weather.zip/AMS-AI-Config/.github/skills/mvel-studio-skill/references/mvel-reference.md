# MVEL Expression Language - Studio

> A reference guide for MVEL expressions in Workday Studio integration development.
> Workday uses **MVEL 1.3** (not MVEL 2.x).

-----

## Table of Contents

1. [MVEL Expressions](#1-mvel-expressions)
   - 1.1 [Naming Conventions](#11-naming-conventions)
   - 1.2 [MVEL Autocomplete](#12-mvel-autocomplete)
   - 1.3 [Expression Capable vs Template Capable](#13-expression-capable-vs-template-capable)
   - 1.4 [MVEL Comments](#14-mvel-comments)
2. [Operators](#2-operators)
   - 2.1 [Unary Operator](#21-unary-operator)
   - 2.2 [Comparison Operators](#22-comparison-operators)
   - 2.3 [Logical Operators](#23-logical-operators)
   - 2.4 [Arithmetic Operators](#24-arithmetic-operators)
   - 2.5 [Other Operators](#25-other-operators)
3. [Assignment](#3-assignment)
   - 3.1 [Literals](#31-literals)
   - 3.2 [Difference b/w Assignment and Equal](#32-difference-bw-assignment-and-equal)
4. [Launch Parameter](#4-launch-parameter)
   - 4.1 [Simple Type Parameter](#41-simple-type-parameter)
   - 4.2 [Reference Type Parameter](#42-reference-type-parameter)
   - 4.3 [Convert Array Values to String](#43-convert-array-values-to-string)
   - 4.4 [Date From Launch Parameter](#44-date-from-launch-parameter)
   - 4.5 [Sequenced Value from Launch Parameter](#45-sequenced-value-from-launch-parameter)
   - 4.6 [Parent Process WID](#46-parent-process-wid)
5. [Integration Attributes](#5-integration-attributes)
   - 5.1 [Simple Type Parameter](#51-simple-type-parameter)
   - 5.2 [Reference Type Parameter](#52-reference-type-parameter)
   - 5.3 [Convert Array Values to String](#53-convert-array-values-to-string)
   - 5.4 [Report Service Extra Path](#54-report-service-extra-path)
6. [Integration MAP](#6-integration-map)
7. [Sequence Generator](#7-sequence-generator)
8. [Da: Document Accessor](#8-da-document-accessor)
9. [Evaluate Xpath: parts[]](#9-evaluate-xpath-parts)
   - 9.1 [Format Date](#91-format-date)
   - 9.2 [Format Number](#92-format-number)
   - 9.3 [Right/Left Justification (Padding)](#93-rightleft-justification-padding)
10. [MVEL Functions](#10-mvel-functions)
11. [Control Flow](#11-control-flow)
12. [Ternary Operator](#12-ternary-operator)
13. [Hash Map and Array List](#13-hash-map-and-array-list)
14. [MVEL Template Capable Property](#14-mvel-template-capable-property)
15. [Before and After Splitter](#15-before-and-after-splitter)
16. [JSON Handling in MVEL](#16-json-handling-in-mvel)
17. [Custom Java in MVEL](#17-custom-java-in-mvel)
18. [Type Discovery and Casting](#18-type-discovery-and-casting)
19. [URI Encoding](#19-uri-encoding)
20. [Troubleshooting](#20-troubleshooting)
21. [Studio Specific MVEL Expression Table](#21-studio-specific-mvel-expression-table)
22. [MVEL Variable Reference](#22-mvel-variable-reference)

-----

## 1. MVEL Expressions

MVEL is an incredibly powerful expression language which is tightly integrated into the Workday ESB's Assembly framework. With MVEL it is possible to construct powerful and flexible expressions for manipulating Assembly context variables and associated Java objects, but as ever, with great power comes great responsibility!

### 1.1 Naming Conventions

A large number of properties are added to the mediation context by the ESB and some of the shared components. Prefixing the properties you declare within your integration name will make them easier to find when debugging the assembly and add a conceptual scope to the properties. For example:

```
props['payforce.company.name']
```

If you set properties to contain the values of integration attributes, use `ia` as the prefix. For example:

```
props['ia.include.job.code']
```

For Launch parameters:

```
props['lp.include.job.code']
```

Always ensure that your property names are meaningful. Do not be tempted to abbreviate property names. Descriptive and meaningful property names aid readability, and reduce the overall cost of maintaining the code over subsequent revision.

### 1.2 MVEL Autocomplete

Need help with the syntax of particular operations or with the names of elements in your flow? You can always access MVEL suggestions by pressing **Ctrl + Space Bar**.

### 1.3 Expression Capable vs Template Capable

MVEL properties in Studio come in two types, indicated by an icon in the properties view:

| Type | Icon | Syntax | Usage |
|---|---|---|---|
| **Expression Capable** | Green circle | Plain MVEL — do NOT wrap in `@{}` | Eval expressions, route conditions, validation expressions |
| **Template Capable** | Blue square | Must wrap MVEL in `@{}` delimiters | Transport URLs, extra paths, filenames, failure messages |

**Expression Capable** example (eval expression):

```
props['p.full.name'] = props['p.first.name'] # ' ' # props['p.last.name']
```

**Template Capable** example (transport Extra Path):

```
@{intsys.reportService.getExtrapath('MyReport')}?Company!WID=@{props['p.company.wid']}
```

> **Critical**: Do NOT use `@{}` in Expression fields or omit `@{}` in Template fields — the expression will silently fail or be treated as a literal string.

### 1.4 MVEL Comments

MVEL supports Java-style comments:

```
/* This is a block comment */
// This is a line comment
props['p.value'] = 'test' /* inline comment */
```

### 1.5 MVEL Expressions

MVEL expressions may consist of:

- Property expressions
- Boolean expressions
- Method invocations
- Variable expressions
- Function definitions

#### Property Expression

A utility adapter for gaining access to message properties using the `AssemblyUtils.PropertyMapAdapter` class.

The following expression gets the value of `myProperty` on the **MediationContext**:

```
context.getProperty('myProperty')
```

The following is equivalent but less verbose:

```
props.myProperty
```

The following expression returns the property value set by a custom Spring bean:

```
props['bean.property']
```

#### Multiple Statements

You may write scripts with an arbitrary number of statements using the semi-colon to denote the termination of a statement. This is required in all cases except where there is only one statement, or for the last statement in a script.

#### Variable Expression

Provides access to the **MessageContextVariables** interface as a Map. To access variables, use the following notation:

```
vars['myVariable']
```

-----

## 2. Operators

### 2.1 Unary Operator

#### `new`

Object instantiation — creates an instance of a class and allocates memory to the object.

### 2.2 Comparison Operators

|Operator |Name |Description |
|----------|------------------------|-------------------------------------------------------------------------------------------------|
|`==` |Equal |Checks if the **values** on both sides are **equal**. Unlike Java, this is not an identity check.|

> **BUG**: Always put a space between `==` and a negative number: `x == -1`. Writing `x ==-1` (no space) evaluates incorrectly because MVEL parses `==-` as a single token. This is a known MVEL 1.3 parser issue.
|`!=` |Not Equal |Checks if the **values** on both sides are **not equal**. |
|`>` |Greater Than |Checks if the value on the left is greater than the value on the right. |
|`<` |Less Than |Checks if the value on the left is less than the value on the right. |
|`>=` |Greater Than or Equal To|Checks if the value on the left is greater than or equal to the value on the right. |
|`<=` |Less Than or Equal To |Checks if the value on the left is less than or equal to the value on the right. |
|`contains`|Contains |Checks if the value on the left contains the value on the right. |

### 2.3 Logical Operators

|Operator |Name |Description |
|-----------|-----------|--------------------------------------------------------------------------------|
|`and`, `&&`|Logical AND|Checks that the values on both sides are true. |
|`||` |Logical OR |Checks if either the value on the left or the right is true. |
|`or` |Chained OR |Checks a sequence of values for emptiness and returns the first non-empty value.|

### 2.4 Arithmetic Operators

|Operator|Operation |
|--------|--------------|
|`+` |Addition |
|`-` |Subtraction |
|`/` |Division |
|`*` |Multiplication|
|`%` |Modulus |

### 2.5 Other Operators

|Operator|Name |Description |
|--------|---------------------|-----------------------------------------------------------|
|`+` |String Concatenation |Overloaded operator. **Use `#` instead** — `+` can cause unintended numeric addition.|
|`#` |String Concatenation |**Preferred.** Concatenates values as strings without risk of numeric addition.|
|`=` |Assignment |Assigns the value on the right to the variable on the left.|

-----

## 3. Assignment

MVEL allows you to assign variables in your expression, either for extraction from the runtime, or for use inside the expression.

### 3.1 Literals

A literal is used to represent a fixed value in the source of a particular script.

#### Strings

String literals are enclosed in single or double quotes:

```
'Hello World'
"Hello World"
```

#### Numerics

Numeric literals are plain numbers:

```
42
3.14
```

#### Boolean

Boolean literals are represented by the reserved keywords `true` and `false`.

#### Null or nil

The null literal is denoted by the reserved keywords `null` or `nil`, or `''` or `empty`.

### 3.2 Difference b/w Assignment and Equal

- `=` is the **assignment** operator — it assigns a value to a variable.
- `==` is the **equality** operator — it compares two values.

```
// Assignment
props['my.value'] = 'hello'

// Equality check
props['my.value'] == 'hello'
```

-----

## 4. Launch Parameter

**MVEL helper class is `lp`**: Provides access to the integration launch parameters. The `lp` variable is only applicable to Workday internal server and integration Cloud developers.

### 4.1 Simple Type Parameter

The MVEL helper class for launch parameters is `lp`. To get data from a simple type launch parameter use `getSimpleData('label')` where `label` is your prompt name (e.g. `"Tax Frequency Value"`).

Type `lp.` then press **CTRL + Space Bar** to get all related methods.

```
lp.getSimpleData('label')
```

To pass a simple type prompt property value to a RaaS Report prompt, convert it to a string and call this property in the RaaS call:

```
props['lp.tax.frequency'] = lp.getSimpleData('Tax Frequency Value')
```

RaaS Report MVEL Property example:

```
props['raas.prompt.value'] = lp.getSimpleData('Tax Frequency Value')
```

### 4.2 Reference Type Parameter

Reference Type Parameter is a prompt on your webservice fields. To use a **single instance** reference type prompt value, use the `getReferenceData('label', 'type')` method.

- **Label** is your prompt name (e.g. `Run Category Type`)
- **Type** can be: `Reference ID` or `WID`

```
lp.getReferenceData('Run Category Type', 'Employee_ID')
```

### 4.3 Convert Array Values to String

To convert an array list to a string (e.g. array of Workers converted to a string for use in a REST URL for RaaS):

To use a **multi-instance** reference type prompt value, use either:

```
props['lp.cc.wid'] = lp.getWIDs('label')
```

or:

```
props['lp.cc.wid'] = lp.getReferenceDataList('label', 'type')
```

**Output format (raw):**

```
[6cb77610a8a543aea2d6bc10457e35d4, bc33aa3152ec42d4995f4791a106ed09, 80938777cac5440fab50d729f9634969, c4f78be1a8f14da0ab49ce1162348a5e]
```

To convert to the format supported by RaaS reports (commas replaced by `!`):

```
props['get.cc.wid.prompt'] = props['lp.cc.wid'].toString().replace('[','').replace(']','').replace(', ','!')
```

**Output format (for RaaS):**

```
6cb77610a8a543aea2d6bc10457e35d4!bc33aa3152ec42d4995f4791a106ed09!80938777cac5440fab50d729f9634969!c4f78be1a8f14da0ab49ce1162348a5e
```

Pass `props['get.cc.wid.prompt']` to the RaaS Report. The commas are replaced by exclamation marks (`!`) as this is how you separate IDs in a REST URL for Workday RaaS endpoints.

**Background URL format for RaaS:**

```
customreport2/medtronic4/jthangaraj/MyCustomReport?CostCenters!WID=6cb77610a8a543aea2d6bc10457e35d4!bc33aa3152ec42d4995f4791a106ed09!80938777cac5440fab50d729f9634969!c4f78be1a8f14da0ab49ce1162348a5e
```

### 4.4 Date From Launch Parameter

#### To Find Current Effective Date:

```
lp.getSimpleData('Effective Date')
```

#### To Find Last Successful Date Time:

```
lp.getLastSuccessfulDateTime()
```

### 4.5 Sequenced Value from Launch Parameter

If your assembly needs only one sequenced value, configure a sequence service on the workday-in and get the value:

```
props['lp.seq.value'] = lp.getSequencedValue('Integration Sequencer Name')
```

For multiple sequenced values from the same generator, use the Get Sequenced Value sub-workflow module.

### 4.6 Parent Process WID

When a Studio integration is launched from a packaged integration's business process, get the parent event WID:

```
props['p.parent.process.wid'] = lp.getReferenceData("Parent Process", "WID")
```

Pass this to `PutIntegrationMessage` parameter `is.event.wid` to report messages on the parent event.

-----

## 5. Integration Attributes

**MVEL helper class is `intsys`**: Provides access to the integration system configuration for this assembly.

### 5.1 Simple Type Parameter

To access a simple type integration attribute prompt, use `intsys.getAttribute('label')`:

```
intsys.getAttribute('username')
```

### 5.2 Reference Type Parameter

To access a reference type single instance integration attribute prompt, use `intsys.getAttributeReferenceData('label', 'type')`:

```
intsys.getAttributeReferenceData('Run Category Type', 'Employee_ID')
```

### 5.3 Convert Array Values to String

To access a reference type multi-instance integration attribute prompt, use either:

```
intsys.getAttributeReferenceDataList('label', 'type')
```

or:

```
intsys.getWIDs('label')
```

#### Report URL:

```
@{intsys.reportService.getExtrapath('costcenterpromptvaluegiven')}?ledger account!WID=@{props['get.ledger.account.no.emp']}
```

### 5.4 Report Service Extra Path

To call a RaaS report **without prompts** (in a Template Capable Extra Path on workday-out-rest):

```
@{intsys.reportService.getExtrapath('MyReportAlias')}
```

To call a RaaS report **with prompts**, build the prompt string in a preceding eval:

```
companies = intsys.getAttributeReferenceDataList('Companies', 'WID');
String str = "?Company!WID=";
foreach (id : companies) { str += id # '!'; };
props['p.companiesPromptString'] = str.substring(0, str.length() - 1)
```

Then in the Extra Path:

```
@{intsys.reportService.getExtrapath('MyReportAlias')}@{props['p.companiesPromptString']}
```

#### How to get Integration Attribute or any MVEL Property to XSLT:

In XSLT or STX, first declare the `is` namespace in the stylesheet, then call the method from an XPath expression (note the alternative mechanism for passing attribute values into XSLT in the next paragraph).

-----

## 6. Integration MAP

How to access an Integration Map (text-to-text lookup):

```
intsys.getMap('mapName').get('key')
```

Alternative syntax for map lookup:

```
intsys.integrationMapLookup('Status', props['position.status'])
```

Reverse map lookup (text-to-business object):

```
intsys.integrationMapReverseLookup('map_name', 'key').get(0).getReferenceData('REF_ID_TYPE_TO_RETURN')
```

How to access Integration Map in XSLT or STX: first declare the `is` namespace in the stylesheet, then call the method from an XPath expression (note the alternative mechanism for passing attribute values into XSLT).

-----

## 7. Sequence Generator

You can use a sequence generator to generate unique, sequenced file names. If your integration system needs to create a different file name each time it runs, you can associate a sequence generator service with your Workday-in transport to generate the file name. You define the service with one or more named sequencers in Studio, then configure the sequencers in Workday.

```
sequenceGenerator.getNextSequenceValue('sequenceName')
```

-----

## 8. Da: Document Accessor (To Retrieve Input File)

Within a Workday Studio integration, you can use the Document Accessor (`da`) variable within an eval step's MVEL expression to access a document or input file from the tenant or some SFTP server.

```
da.toVar('eib_transform_output.txt', 'var1')
```

The above example gets a document from the Integration Event with filename `eib_transform_output.txt` and adds it as a variable named `var1`.

-----

## 9. Evaluate Xpath: parts[]

`parts[]` provides array-based access to message parts using the **MessageAdapter** interface. The root part is part 0, the first attachment is part 1.

To get the content of part 0 (the root part):

```
parts[0].text
```

To get the content of the second attachment:

```
parts[1].text
```

### 9.1 Format Date

To format a date using MVEL (converting `yyyy-MM-dd` to `MM/dd/yyyy`):

```
def sdf1 = new java.text.SimpleDateFormat('yyyy-MM-dd');
def sdf2 = new java.text.SimpleDateFormat('MM/dd/yyyy');
props['formatted.date'] = sdf2.format(sdf1.parse(parts[0].xpath('/root/date')));
```

For UTC/Zulu time formatting, use `DateFormatUtils.formatUTC`:

```
props['p.timestamp'] = org.apache.commons.lang.time.DateFormatUtils.formatUTC(new java.util.Date(), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
```

#### SimpleDateFormat Pattern Reference

| Letter | Component | Example |
|---|---|---|
| `y` | Year | `yyyy` → 2026, `yy` → 26 |
| `M` | Month | `MM` → 04, `MMM` → Apr, `MMMM` → April |
| `d` | Day of month | `dd` → 11 |
| `H` | Hour (0-23) | `HH` → 14 |
| `h` | Hour (1-12) | `hh` → 02 |
| `m` | Minute | `mm` → 30 |
| `s` | Second | `ss` → 45 |
| `S` | Millisecond | `SSS` → 123 |
| `a` | AM/PM | `a` → PM |
| `E` | Day of week | `EEE` → Mon, `EEEE` → Monday |
| `z` | Time zone | `z` → PST |
| `Z` | Time zone (RFC 822) | `Z` → -0800 |

### 9.2 Format Number

To format a number using MVEL instead of XSLT (converting `##0.0000` to `##0.00`):

```
def nf = new java.text.DecimalFormat('##0.00');
props['formatted.number'] = nf.format(Double.parseDouble(parts[0].xpath('/root/amount')));
```

### 9.3 Right/Left Justification (Padding)

To justify, or pad, a value using MVEL:

```
// Right-justify / left-pad with spaces to width 10
String.format('%10s', props['my.value'])

// Left-justify / right-pad with spaces to width 10
String.format('%-10s', props['my.value'])

// Left-pad with zeros to width 10
String.format('%010d', Integer.parseInt(props['my.value']))
```

#### Using Apache StringUtils (recommended for fixed-width files):

```
// Left-pad to 10 characters with spaces
org.apache.commons.lang.StringUtils.leftPad(props['my.value'], 10)

// Right-pad to 10 characters with zeros
org.apache.commons.lang.StringUtils.rightPad(props['my.value'], 10, '0')

// Left-pad with a specific character
org.apache.commons.lang.StringUtils.leftPad(props['my.value'], 10, '0')
```

-----

## 10. MVEL Functions

### 10.1 Substring

Returns the substring from the start position to the specified length. **Index of the first character is 1 here.** If length is omitted, it returns the substring from the start position to the end.

```
substring('Beatles', 1, 4)
// Result: 'Beat'
```

### 10.2 Index of

Returns the positions within the sequence of items that are equal to the search item argument. **Index starts with 0 here.**

```
index-of('12-10', '-')
// Result: 2
```

### 10.3 Substring-before

Returns the part of the string before the first occurrence of the delimiter:

```
substring-before('12-10', '-')
// Result: '12'
```

### 10.4 Substring-after

Returns the part of the string after the first occurrence of the delimiter:

```
substring-after('12-10', '-')
// Result: '10'
```

### 10.5 Replace or Translate

Replace all occurrences of a string. **Note**: Call `.toString()` first if the value may not be a String type:

```
props['my.value'].toString().replaceAll('old', 'new')
```

#### Replace all non-numeric characters:

```
props['my.value'].toString().replaceAll('[^0-9]', '')
```

### 10.6 Contains

```
props['my.value'].contains('search string')
// Returns: true or false
```

### 10.7 Normalize Space

Removes leading and trailing spaces from the specified string, and replaces all internal sequences of white space with one space. If there is no string argument, it does the same on the current node.

```
props['my.value'].trim().replaceAll('\\s+', ' ')
```

### 10.8 Length

```
props['my.value'].length()
```

### 10.9 Concat

Use `#` for string concatenation (not `+`, which can cause unintended numeric addition):

```
props['my.value'] = props['p.first'] # ' ' # props['p.last']
```

### 10.10 Substring and Contains

```
props['my.value'].substring(0, 5).contains('abc')
```

### 10.11 Equal Ignore Case

```
props['my.value'].equalsIgnoreCase('CompareValue')
// Returns: true or false
```

### 10.12 Aggregate Function

#### Sum

Do sum of salary of all employees on an XML message:

```
def total = 0;
for (emp : props['employees']) {
total += Double.parseDouble(emp.salary);
}
props['total.salary'] = total;
```

#### Count

Count the number of nodes:

```
props['employee.count'] = parts[0].xpath('count(/root/employee)')
```

### 10.13 Lowercase

```
props['my.value'].toLowerCase()
```

### 10.14 UpperCase

```
props['my.value'].toUpperCase()
```

### 10.15 Starts With

```
props['my.value'].startsWith('prefix')
// Returns: true or false
```

### 10.16 Ends With

```
props['my.value'].endsWith('suffix')
// Returns: true or false
```

-----

## 11. Control Flow

### 11.1 If-Else (Expression Capable)

In Expression Capable MVEL, use standard Java-style if/else:

```
if (props['p.status'] == 'Active') {
    props['p.result'] = 'Process';
} else if (props['p.status'] == 'Leave') {
    props['p.result'] = 'Skip';
} else {
    props['p.result'] = 'Error';
}
```

### 11.2 If-Else (Template Capable)

In Template Capable MVEL, use `@if{}` / `@else{}` syntax:

```
@if{props['p.status'] == 'Active'}Process@else{}Skip@end{}
```

**On web service write components:**

```xml
<root>
@if{props['p.is.boolean']}
<ee>Do Something</ee>
@elseif{props['p.numeric.value'] == 1}
<ee>Do Something Else</ee>
@else{}
<ee>Default</ee>
@end{}
</root>
```

> **Warning**: Do NOT use `xpath` or `xpathB` inside `@if{}` conditions — parsing large documents as DOM has severe performance overhead.

### 11.3 Foreach (Template Capable)

In Template Capable MVEL, use `@foreach{}`. The `@end{}` parameter is the separator between iterations.

```
@foreach{item : props['p.list']}@{item}@end{','}
```

**On web service write components (looping workers):**

```xml
@foreach{props['Workers'] as emp}
<wd:Worker_Reference>
<wd:ID wd:type="Employee_ID">@{emp}</wd:ID>
</wd:Worker_Reference>
@end{}
```

-----

## 12. Ternary Operator

The ternary operator provides a concise conditional expression:

```
props['p.result'] = (props['p.value'] != empty) ? props['p.value'] : 'default'
```

Use the `empty` literal to check for null, 0-length string, whitespace-only string, or false boolean:

```
props['p.name'] = props['p.first.name'] != empty ? props['p.first.name'] : null
```

### Nested Ternary

```
props['p.result'] = (props['p.value'] == 'A') ? 'Value is A' :
    (props['p.value'] == 'B') ? 'Value is B' :
    'Value is something else'
```

-----

## 13. Hash Map and Array List

### 13.1 HashMap

```
// Create a HashMap
props['p.map'] = new java.util.HashMap();

// Put a value
props['p.map'].put('key1', 'value1');

// Get a value
props['p.result'] = props['p.map'].get('key1');

// Check if key exists
props['p.exists'] = props['p.map'].containsKey('key1');

// Clean up
props['p.map'].clear();
props.remove('p.map');
```

### 13.2 Array to HashMap (Organization Filter Pattern)

A common use case: filter employees to only those in certain organizations. Convert a multi-value launch parameter to a HashMap for O(1) lookup:

```
def orgMap = new java.util.HashMap();
for (wid : lp.getWIDs('Organizations')) {
    orgMap.put(wid, '1');
}
props['p.org.map'] = orgMap;

// Then in a splitter loop, check membership:
props['p.org.map'].get(props['p.current.org.wid']) == '1'
```

### 13.3 ArrayList

```
// Create and populate
props['p.list'] = new java.util.ArrayList();
props['p.list'].add('item1');
props['p.list'].add('item2');

// Iterate
for (item : props['p.list']) {
    // process item
}

// Add only if not duplicate
if (!props['p.list'].contains(props['p.new.value'])) {
    props['p.list'].add(props['p.new.value']);
}

// Remove duplicates
props['p.unique'] = new java.util.ArrayList(new java.util.LinkedHashSet(props['p.list']));
```

> **Warning**: Do not store excessive data in HashMaps or ArrayLists in memory. For large data sets, use XSLT 3.0 maps or streaming approaches instead.

-----

## 14. MVEL Template Capable Property

Template Capable MVEL is used on transport properties like URLs, Extra Paths, filenames, and failure messages. All MVEL must be wrapped in `@{}` delimiters. Text outside the delimiters is treated as literal output.

### Examples

**Workday-out-rest Extra Path:**

```
@{intsys.reportService.getExtrapath('MyReport')}
```

**Dynamic filename:**

```
Workers_@{new java.text.SimpleDateFormat('yyyyMMdd').format(new java.util.Date())}.csv
```

**Failure message (Workday-out transport):**

```
An error occurred while processing employee @{props['p.employee.id']}. Details:
```

The original error message is automatically appended to the failure message text.

-----

## 15. Before and After Splitter

### Splitter Context Properties

Inside a splitter loop, the following properties are available:

| Property | Description |
|---|---|
| `props['cc.splitter.current.index']` | Current iteration index (0-based) |
| `props['cc.splitter.total.count']` | Total number of items being split |
| `util.currentFilename` | Filename of the current file (for unzip strategy) |
| `util.isLastMessageInBatch()` | Returns true on the last iteration |

### Tracking Success/Error Counts

```
// Increment success counter
props['p.success.count'] = props['p.success.count'] == null ? 1 : props['p.success.count'] + 1

// Increment error counter
props['p.error.count'] = props['p.error.count'] == null ? 1 : props['p.error.count'] + 1
```

### Convert Array to String for REST URLs

Use `util.listToCommaDelimString()` to convert a list of WIDs to a delimited string:

```
props['p.wid.list'] = util.listToCommaDelimString(lp.getWIDs('Workers'), '!')
```

This produces a string like `wid1!wid2!wid3` suitable for REST URL parameters.

-----

## 16. JSON Handling in MVEL

### Small JSON Messages

For small JSON messages only (large messages cause memory issues with `message.rootPartAsText`):

```
// Parse JSON to an object
props['json.msg'] = new org.json.JSONObject(message.rootPartAsText)

// Access a value
props['p.name'] = props['json.msg'].getString('firstName')

// Convert JSON to XML
message.setRootPartAsText(org.json.XML.toString(props['json.msg'], 'root'), 'text/xml')
```

> **Prefer JSON Studio components** (JSON-to-XML, XML-to-JSON) or XSLT 3.0 `json-to-xml()` / `xml-to-json()` functions for large messages.

### JSON MVEL Helper (json.)

The `json` helper can read values from JSON in message parts or variables:

```
json.stringAtJsonPath('$.field1', parts[0])          // Returns: "val1"
json.numberAtJsonPath('$.field2', parts[0])           // Returns: 2
json.booleanAtJsonPath('$.field3', parts[0])          // Returns: true
json.isValueAtJsonPath('$.field1', parts[0])          // Returns: true/false
json.countItemsAtJsonPath('$.array', parts[0])        // Returns: count
json.isNullAtJsonPath('$.field', parts[0])            // Returns: true/false
```

With defaults:

```
json.stringAtJsonPathWithDefault('$.field', parts[0], 'fallback')
json.numberAtJsonPathWithDefault('$.field', parts[0], 0)
json.booleanAtJsonPathWithDefault('$.field', parts[0], false)
```

For arrays/objects (returns DataHandlerSource):

```
json.arrayAtJsonPath('$.items', parts[0])
json.objectAtJsonPath('$.profile', parts[0])
```

-----

## 17. Custom Java in MVEL

### Calling Static Methods

Call any static Java method available on the classpath:

```
props['p.padded'] = org.apache.commons.lang.StringUtils.leftPad(props['p.value'], 10, '0')
```

### Deploying Custom JARs

Place custom JAR files in the `WSAR-INF/lib` directory of your Studio project. Classes from those JARs become available for calling in MVEL expressions.

### Thread Sleep (QPS Throttling)

To introduce a delay between API calls for rate limiting:

```
Thread.currentThread().sleep(50)
```

> Use sparingly — only when required for external API QPS limits.

-----

## 18. Type Discovery and Casting

### Discover Property Types

Use the Studio scratchpad or an eval expression to discover the runtime type of a value:

```
props['p.type'] = props['p.value'].getClass().getName()
```

### Explicit Casting

Cast a value to a specific type when needed:

```
props['p.amount'] = (double) props['p.raw.value']
```

Format with DecimalFormat:

```
props['p.formatted'] = new java.text.DecimalFormat('#,##0.00').format((double) props['p.amount'])
```

-----

## 19. URI Encoding

Encode URL parameters when calling REST-enabled custom reports with special characters:

```
props['p.encoded.url'] = java.net.URLEncoder.encode(props['p.report.parameters'], "UTF-8")
```

Example input: `Full_Name=Nick Fernandez`
Example output: `Full_Name=Nick%20Fernandez`

-----

## 20. Troubleshooting

### Stale Message Headers

If you get I/O errors or unexpected `400`/`403` responses calling Workday web services after an external HTTP call, stale headers from the prior call may be forwarded. Clear them:

```
message.removeAllHeaders()
```

Or use a `set-headers` component to explicitly remove problematic headers before invoking Workday web services.

### 400/403 Errors to External Endpoints

Some servers block the default Java User-Agent. Set it explicitly:

```
message.setHeader('User-Agent', 'Workday/2025')
```

### TLS Protocol Configuration

To force specific TLS versions for an endpoint (set before the http-out transport):

```
props['wd.esb.use.specified.tls.protocols'] = "TLSv1.1,TLSv1.2"
```

-----

## 21. Studio Specific MVEL Expression Table

| Expression | Description |
|---|---|
| `props['name']` | Get/set a mediation context property |
| `vars['name']` | Get/set a message variable |
| `parts[0].text` | Root message part as text (1M char limit) |
| `parts[0].xpath('expr')` | Evaluate XPath on root part (DOM — avoid on large messages) |
| `message.rootPartAsText` | Root part as text (memory — avoid on large messages) |
| `message.setRootPartAsText(text, mimetype)` | Set root part content |
| `message.removeAllHeaders()` | Remove all message headers |
| `message.setHeader(name, value)` | Set a message header |
| `context.setError(msg, code)` | Throw an error |
| `context.setAbort(true)` | Terminate processing |
| `context.errorMessage` | Get current error message (in error handlers) |
| `util.cleanString(value)` | Remove invalid XML characters |
| `util.listToCommaDelimString(list, sep)` | Convert list to delimited string |
| `util.currentFilename` | Current filename in splitter context |
| `lp.getSimpleData('label')` | Get simple launch parameter |
| `lp.getReferenceData('label', 'type')` | Get reference launch parameter |
| `lp.getWIDs('label')` | Get multi-instance WIDs |
| `lp.getLastSuccessfulDateTime()` | Last successful run date/time |
| `lp.getSequencedValue('name')` | Get next sequence value |
| `intsys.getAttribute('label')` | Get simple integration attribute |
| `intsys.getAttributeAsBoolean('label')` | Get boolean integration attribute |
| `intsys.getAttributeReferenceData('label', 'type')` | Get reference attribute |
| `intsys.getAttributeReferenceDataList('label', 'type')` | Get multi-instance reference attribute |
| `intsys.integrationMapLookup('map', 'key')` | Map lookup (text-to-text) |
| `intsys.integrationMapReverseLookup('map', 'key')` | Reverse map lookup |
| `intsys.reportService.getExtrapath('alias')` | Get RaaS report path |
| `da.toVar('filename', 'varName')` | Load document to variable |
| `sequenceGenerator.getNextSequenceValue('name')` | Get next sequence value |
| `json.stringAtJsonPath('$.path', parts[0])` | Read JSON string by path |
| `json.numberAtJsonPath('$.path', parts[0])` | Read JSON number by path |

-----

## 22. MVEL Variable Reference

| Variable | Description |
|---|---|
| `context` | MediationContext — main context object. Contains MediationMessage, variables, properties, error flags, assembly audit, customer ID, dynamic endpoint |
| `da` | Document Accessor — access documents from integration events: `da.toVar('filename', 'varName')` |
| `env` | JVM system properties: `env['cc.hostname']` |
| `epg` | External Paygroups helper — for payroll integrations using `Get_External_Paygroups` |
| `ftp` | FTP helper — test URI schemes: `ftp.isSftp('sftp://...')`, `ftp.isExplicitSSL('ftpse://...')` |
| `intsys` | Integration system configuration — attributes, maps, report services |
| `json` | JSON MVEL helper — read values by JsonPath from message parts or variables |
| `lp` | Launch parameters helper — access launch parameter values, dates, references |
| `message` | MediationMessage — root part, headers, attachments |
| `mtable` | MTable adapter — in-memory table: `mtable['prop'].set(row, col, val)` |
| `parts` | Message parts array — `parts[0]` is root, `parts[1]+` are attachments. Supports `.text`, `.xpath()`, `.xpathB()`, `.xpathF()`, `.mimeType`, `.getHeader()` |
| `props` | Property map adapter — shorthand for `context.getProperty()` |
| `spring` | Spring ApplicationContext — access beans: `spring.getBean('name')` |
| `util` | Utility helper — 40+ functions for dates, XML testing, batching: `util.isLastMessageInBatch()`, `util.cleanString()`, `util.listToCommaDelimString()` |
| `vars` | Message variables map — `vars['name'].text`, `.xpath()`, `.xpathB()`, `.xpathF()` |
| `xmldiff` | XMLDiff result — `xmldiff.isDifferent()` |

### 10.17 Clear and Remove

To clear a property:

```
props.remove('my.property')
```

To clear a map:

```
myMap.clear()
```

### 10.18 Append

To append to a string property (prefer `#` operator):

```
props['my.value'] = props['my.value'] # ' appended text'
```
