<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:map="http://www.w3.org/2005/xpath-functions/map" xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:wd="urn:com.workday/bsvc" xmlns:tdf="urn:com.workday/tdf" expand-text="yes" exclude-result-prefixes="#all" xmlns:mf="urn:mf">
	<xsl:output method="xml" indent="no"/>
	<xsl:strip-space elements="*"/>
	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

	<!-- Skip element in streamable mode -->
	<xsl:template match="tdf:Payments"/>

	<!-- Skip element in in-memory mode -->
	<xsl:template match="tdf:Payments" mode="in-memory"/>

	<xsl:accumulator name="customerPaymentIDMap" as="map(xs:string, xs:string)" initial-value="map {}" streamable="yes">

		<!-- temporary Payment_Amount variable -->
		<xsl:accumulator-rule match="tdf:Payments/tdf:Customer_Payments_Data/tdf:Payment_Amount/text()" select="map:put($value, 'lastAmount', string(.))"/>

		<!-- temporary Direct_Debit_Reference variable -->
		<xsl:accumulator-rule match="tdf:Payments/tdf:Customer_Payments_Data/tdf:Direct_Debit_Reference/text()" select="map:put($value, 'lastRef', string(.))"/>

		<!-- creation of map with use of temporary variables -->
		<xsl:accumulator-rule match="tdf:Payments/tdf:Customer_Payments_Data/tdf:Customer_Payment_ID/text()">
			<xsl:variable name="key" select="map:get($value, 'lastRef') || '_' || map:get($value, 'lastAmount')"/>
			<xsl:variable name="val" select="string(.)"/>
			<xsl:sequence select="map:put($value, $key, $val)"/>
		</xsl:accumulator-rule>

	</xsl:accumulator>

	<xsl:accumulator name="customerPaymentReturnDateMap" as="map(xs:string, xs:string)" initial-value="map {}" streamable="yes">

		<!-- temporary Payment_Amount variable -->
		<xsl:accumulator-rule match="tdf:Payments/tdf:Customer_Payments_Data/tdf:Payment_Amount/text()" select="map:put($value, 'lastAmount', string(.))"/>

		<!-- temporary Direct_Debit_Reference variable -->
		<xsl:accumulator-rule match="tdf:Payments/tdf:Customer_Payments_Data/tdf:Direct_Debit_Reference/text()" select="map:put($value, 'lastRef', string(.))"/>

		<!-- creation of map with use of temporary variables -->
		<xsl:accumulator-rule match="tdf:Payments/tdf:Customer_Payments_Data/tdf:Estimated_Return_Date/text()">
			<xsl:variable name="key" select="map:get($value, 'lastRef') || '_' || map:get($value, 'lastAmount')"/>
			<xsl:variable name="val" select="string(.)"/>
			<xsl:sequence select="map:put($value, $key, $val)"/>
		</xsl:accumulator-rule>

	</xsl:accumulator>

	
	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>

	<xsl:template match="Merged_data">
		<Transactions>
			<!-- Copy-of copies everything from source XML, to avoid printing Customers add empty template in in-memory mode -->
			<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
		</Transactions>
	</xsl:template>

	<xsl:template match="Element[@name = 'ReturnedDebitItem']" mode="in-memory">

		<xsl:variable name="lookupKey" select="Element[@name = 'PayerAccount']/Attribute[@name = 'ref']/@value || '_' || Attribute[@name = 'valueOf']/@value"/>

		<xsl:variable name="customerPaymentID" select="map:get(accumulator-after('customerPaymentIDMap'), $lookupKey)"/>

		<xsl:variable name="customerPaymentReturnDate" select="map:get(accumulator-after('customerPaymentReturnDateMap'), $lookupKey)"/>

		<PaymentReturn>

			<CustomerPaymentID>
				<xsl:value-of select="$customerPaymentID"/>
			</CustomerPaymentID>
			<DirectDebitRefID>
				<xsl:value-of select="Attribute[@name = 'ref']/@value"/>
			</DirectDebitRefID>
			<CustomerPaymentReturnDate>
				<xsl:value-of select="$customerPaymentReturnDate"/>
			</CustomerPaymentReturnDate>
			<Amount>
				<xsl:value-of select="Attribute[@name = 'valueOf']/@value"/>
			</Amount>
			
		</PaymentReturn>

	</xsl:template>

</xsl:stylesheet>
