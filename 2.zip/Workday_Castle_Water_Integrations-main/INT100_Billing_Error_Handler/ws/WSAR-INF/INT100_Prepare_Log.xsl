<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map"
	xmlns:env="http://schemas.xmlsoap.org/soap/envelope/"
	xmlns:wd="urn:com.workday/bsvc"
	xmlns:xs="http://www.w3.org/2001/XMLSchema">
	<xsl:output method="xml" indent="1"/>

	<!-- Declare streaming mode -->
	<xsl:mode streamable="no" on-no-match="shallow-skip"/>

	
	<xsl:template match="/">
		<logEntries>
		<xsl:apply-templates/>
		</logEntries>
	</xsl:template>
	
	<xsl:template match="wd:Import_Process_Message">
		<logEntry>
			<severity><xsl:value-of select="wd:Import_Process_Message_Data/wd:Severity"/></severity>
			<message><xsl:value-of select="wd:Import_Process_Message_Data/wd:Message_Summary"/></message>
			<xsl:variable name="position" select="xs:integer(wd:Import_Process_Message_Data/wd:Line_Number)"/>
			<position><xsl:value-of select="$position"/></position>
			<xsl:variable name="webService" select="/env:Envelope/env:Body/wd:Bulk_Import_Customer_Invoice_Request/wd:Submit_Customer_Invoice_Request[$position]" />
			<invoiceID><xsl:value-of select="$webService/wd:Customer_Invoice_Data/wd:Customer_Invoice_ID"/></invoiceID>
			
			<customer><xsl:value-of select="$webService/wd:Customer_Invoice_Data/wd:Customer_Reference/wd:ID"/></customer>
			<webService>
				<xsl:copy-of select="$webService"/>
				
			</webService>
		</logEntry>
	</xsl:template>
</xsl:stylesheet>
