<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc">
	<xsl:output method="xml" indent="1"/>
	
	<!-- Declare streaming mode -->
	<xsl:mode streamable="no" on-no-match="shallow-skip"/>
	
	
	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>
	
	
	
	<xsl:template match="wd:Event_Documents">
		<documents>
			<xsl:apply-templates  />
		</documents>
	</xsl:template>
	
	
	
	<xsl:template match="wd:Repository_Document" >
		<xsl:if test="wd:Repository_Document_Data/wd:Document_Tag_Reference/@wd:Descriptor = 'INT_Webservice_File'">
		<document>
			<fileName><xsl:value-of select="wd:Repository_Document_Data/@wd:File_Name"/></fileName>
			<collection><xsl:value-of select="wd:Repository_Document_Data/@wd:Document_ID => substring-before('/')"/></collection>
			<id><xsl:value-of select="wd:Repository_Document_Data/@wd:Document_ID => substring-after('/')"/></id>
		</document>
		</xsl:if>
	</xsl:template>
	
	
</xsl:stylesheet>
