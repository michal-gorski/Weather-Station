<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map" xmlns:this="this.stylesheet"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc"
	xmlns:tdf="urn:com.workday/tdf">

	<xsl:output method="html" indent="1"/>


	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

	<xsl:template match="/">
		<html>
			<head>
				<title>CastleWater Invoices</title>
				<style><![CDATA[
					body {
					    font-family: Arial, sans-serif;
					    background-color: #f4f9f9;
					    color: #003366;
					}
					table {
					    border-collapse: collapse;
					    width: 100%;
					    margin-top: 20px;
					}
					th,
					td {
					    border: 1px solid #003366;
					    padding: 8px;
					    text-align: left;
					}
					th {
					    background-color: #0055a5;
					    color: white;
					}
					input[type = "text"] {
					    width: 90%;
					    padding: 5px;
					    margin-bottom: 5px;
					}
					.popup {
					    display: none;
					    position: fixed;
					    top: 20%;
					    left: 30%;
					    width: 40%;
					    background-color: white;
					    border: 2px solid #003366;
					    padding: 20px;
					    z-index: 1000;
					    overflow: auto;
					    max-height: 60%;
					}
					.popup-close {
					    float: right;
					    cursor: pointer;
					    color: red;
					    font-weight: bold;
					}
					.overlay {
					    display: none;
					    position: fixed;
					    top: 0;
					    left: 0;
					    width: 100%;
					    height: 100%;
					    background-color: rgba(0, 0, 0, 0.5);
					    z-index: 999;
					}
					
					.table {
					    display: table;
					    width: 100%;
					    border-collapse: collapse;
					}
					.table-header {
					    display: table-header-group;
					    font-weight: bold;
					}
					.table-body {
					    display: table-row-group;
					}
					.table-row {
					    display: table-row;
					}
					.table-cell {
					    display: table-cell;
					    padding: 8px;
					    border: 1px solid #ccc;
					}]]>
				</style>
			</head>
			<body>
				<br/>
				<h2>CastleWater Invoice Table</h2>
				<table id="invoiceTable">
					<thead>
						<tr>
							<th>Customer ID<br/><input type="text" id="customerFilter"
									onkeyup="filterTable()" placeholder="Filter by Customer ID"
								/></th>
							<th>Invoice ID<br/><input type="text" id="invoiceFilter"
									onkeyup="filterTable()" placeholder="Filter by Invoice ID"
								/></th>
							<th>New Charge Date</th>
														
							<th>LPI Charge</th>
							<th>LPC Charge</th>
							<th>MDC Charge</th>
							
							
							<th>Billed LPI</th>
							<th>Billed LPC</th>
							<th>Billed MDC</th>							
						
						</tr>
					</thead>
					<tbody>
						<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
					</tbody>
				</table>
				<div class="overlay" id="overlay" onclick="closeAllPopups()"/>
				<script><![CDATA[
					 function filterTable() {
			            var customerInput = document.getElementById("customerFilter").value.toUpperCase();
			            var invoiceInput = document.getElementById("invoiceFilter").value.toUpperCase();
			            var table = document.getElementById("invoiceTable");
			            var tr = table.getElementsByTagName("tr");
			            for (var i = 1; i < tr.length; i++) {
			                var tdCustomer = tr[i].getElementsByTagName("td")[0];
			                var tdInvoice = tr[i].getElementsByTagName("td")[1];
			                if (tdCustomer && tdInvoice) {
			                    var customerText = tdCustomer.textContent || tdCustomer.innerText;
			                    var invoiceText = tdInvoice.textContent || tdInvoice.innerText;
			                    if (customerText.toUpperCase().indexOf(customerInput) > -1 &&
			                        invoiceText.toUpperCase().indexOf(invoiceInput) > -1) {
			                        tr[i].style.display = "";
			                    } else {
			                        tr[i].style.display = "none";
			                    }
			                }
			            }
			        }
			
			        function showPopup(id) {
			            document.getElementById(id).style.display = "block";
			            document.getElementById("overlay").style.display = "block";
			        }
			
			        function closePopup(id) {
			            document.getElementById(id).style.display = "none";
			            document.getElementById("overlay").style.display = "none";
			        }
			
			        function closeAllPopups() {
			            var popups = document.getElementsByClassName("popup");
			            for (var i = 0; i < popups.length; i++) {
			                popups[i].style.display = "none";
			            }
			            document.getElementById("overlay").style.display = "none";
			        } ]]>
				</script>
			</body>
		</html>
	</xsl:template>

	<xsl:template match="invoice" mode="in-memory">
		<tr>
			<td>
				<xsl:value-of select="customerID"/>
			</td>
			<td>
				<xsl:value-of select="invoiceID"/>
			</td>
			<td>
				<xsl:value-of select="newChargeDate => substring(1, 10)"/>
			</td>
			<td>
				<xsl:value-of select="charges/LPICharge"/>
			</td>
			<td>
				<xsl:value-of select="charges/LPCCharge"/>
			</td>
			<td>
				<xsl:value-of select="charges/MDCCharge"/>
			</td>

			<td>
				<xsl:value-of select="charges/billedAmountLPI"/>
			</td>
			<td>
				<xsl:value-of select="charges/billedAmountLPC"/>
			</td>
			
			<td>
				<xsl:value-of select="charges/billedAmountMDC"/>
			</td>
				
		</tr>	

		
	</xsl:template>
</xsl:stylesheet>
