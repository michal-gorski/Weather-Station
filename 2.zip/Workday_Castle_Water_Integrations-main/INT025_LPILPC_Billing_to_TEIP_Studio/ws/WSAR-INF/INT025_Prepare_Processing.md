# INT025_Prepare_Processing.xsl

**Integration:** INT025 – LPI/LPC Billing to TEIP Studio

---

## Purpose

Transforms raw LPI invoice data retrieved from the Workday DIS report (_INT025 LPI Invoices to be Billed DIS_) into a normalised intermediate XML structure (`preparedInvoices`) that downstream stylesheets and the REST call step can consume directly.

---

## Integration Flow Context

This stylesheet is invoked by the `PrepareProcessing` XSLT-plus step inside the `Prepare_Processing` async-mediation in `assembly.xml`. It runs after the DIS invoice payload has been assembled into the `DIS_Invoices` variable and the `INT025_Charge_Frequency_Days` attribute has been resolved from the integration system attribute map.

```
DIS Report (tdf:LPI_Invoices)
    └─► INT025_Prepare_Processing.xsl
            └─► preparedInvoices/invoice ─► INT025_PrepareCSV.xsl
                                          ─► INT025_PrepareHTML.xsl
                                          ─► INT025_LPI_Charge_Date_Body.xsl
                                                  └─► REST POST /customObjects/lpiAndLpcChargeDate/
```

---

## Parameters

| Parameter | Type | Required | Description |
|---|---|---|---|
| `INT025_Charge_Frequency_Days` | Integer-compatible string | Yes | Number of days added to today's date to produce the next charge date. Sourced from the _Charge Frequency Days_ integration system attribute (set in the `PrepareParams` eval step in `assembly.xml`). |

---

## Input

XML document rooted at `tdf:LPI_Invoices` (namespace `urn:com.workday/tdf`) containing one or more `tdf:LPI_Invoice` children.

### Consumed input fields per invoice

| Field | Description |
|---|---|
| `tdf:Invoice_WID` | Workday internal WID of the invoice |
| `tdf:Invoice_ID` | Business invoice ID |
| `tdf:Customer_ID` | Workday customer reference |
| `tdf:Customer_Invoice/tdf:Chargeable_Balance_LPI` | Current LPI chargeable balance |
| `tdf:Customer_Invoice/tdf:Chargeable_Balance_LPC` | Current LPC chargeable balance |
| `tdf:Customer_Invoice/tdf:Chargeable_Balance_MDC` | Current MDC chargeable balance |
| `tdf:Customer_Invoice/tdf:Billed_Amount_LPI` | Previously billed LPI amount |
| `tdf:Customer_Invoice/tdf:Billed_Amount_LPC` | Previously billed LPC amount |
| `tdf:Customer_Invoice/tdf:Billed_Amount_MDC` | Previously billed MDC amount |

---

## Output

XML document with the following structure:

```xml
<preparedInvoices>
  <invoice>
    <invoiceWID>…</invoiceWID>
    <invoiceID>…</invoiceID>
    <customerID>…</customerID>
    <newChargeDate>…</newChargeDate>
    <charges>
      <LPICharge>…</LPICharge>
      <LPCCharge>…</LPCCharge>
      <MDCCharge>…</MDCCharge>
      <LPIBalance>0</LPIBalance>
      <LPCBalance>0</LPCBalance>
      <MDCBalance>0</MDCBalance>
      <billedAmountLPI>…</billedAmountLPI>
      <billedAmountLPC>…</billedAmountLPC>
      <billedAmountMDC>…</billedAmountMDC>
    </charges>
  </invoice>
  …
</preparedInvoices>
```

### Output field reference

| Field | Description |
|---|---|
| `invoiceWID` | Workday internal WID of the invoice |
| `invoiceID` | Business invoice ID |
| `customerID` | Workday customer ID |
| `newChargeDate` | ISO date: today + `INT025_Charge_Frequency_Days` days |
| `LPICharge` | LPI chargeable balance copied from the DIS report |
| `LPCCharge` | LPC chargeable balance copied from the DIS report |
| `MDCCharge` | MDC chargeable balance copied from the DIS report |
| `LPIBalance` | Outstanding LPI balance — initialised to `0` at this stage |
| `LPCBalance` | Outstanding LPC balance — initialised to `0` at this stage |
| `MDCBalance` | Outstanding MDC balance — initialised to `0` at this stage |
| `billedAmountLPI` | Previously billed LPI amount; defaults to `0` if absent or non-numeric |
| `billedAmountLPC` | Previously billed LPC amount; defaults to `0` if absent or non-numeric |
| `billedAmountMDC` | Previously billed MDC amount; defaults to `0` if absent or non-numeric |

---

## Key Implementation Notes

### Streaming

The stylesheet root mode is declared `streamable="yes"` to allow the XSLT engine to process large DIS payloads without loading the entire document into memory.

The `tdf:LPI_Invoices` template immediately materialises each invoice via `copy-of()` before delegating to the `in-memory` mode. This is required because child templates need random-access (multi-directional) navigation such as `tdf:Customer_Invoice/tdf:Billed_Amount_LPI`, which is not permitted in streaming mode.

### Charge date calculation

The next charge date is computed at transform time:

```xpath
current-date() + xs:dayTimeDuration('P' || $INT025_Charge_Frequency_Days || 'D')
```

For example, with `INT025_Charge_Frequency_Days = 30` and today being 2026-02-25, `newChargeDate` would be `2026-03-27`.

### Numeric fallback guard

`billedAmount*` fields use a castability check before outputting the source value:

```xpath
if (tdf:Customer_Invoice/tdf:Billed_Amount_LPI castable as xs:decimal)
  then tdf:Customer_Invoice/tdf:Billed_Amount_LPI
  else 0
```

This prevents a type error when the element is absent or contains an empty/non-numeric string.

### Balance initialisation

`LPIBalance`, `LPCBalance`, and `MDCBalance` are hardcoded to `0` in this stylesheet. They represent running balances that are intended to be updated by subsequent processing steps (e.g. the REST response handling in `INT025_LPI_Charge_Date_Body.xsl`).

---

## Acronyms

| Acronym | Meaning |
|---|---|
| LPI | Late Payment Interest |
| LPC | Late Payment Charge |
| MDC | Meter Data Charge |
| DIS | Data Integration Service (Workday) |
| TEIP | Third-party billing platform receiving the output |
| TDF | Workday Touchless Data Feed namespace (`urn:com.workday/tdf`) |
| WID | Workday Internal Identifier |
