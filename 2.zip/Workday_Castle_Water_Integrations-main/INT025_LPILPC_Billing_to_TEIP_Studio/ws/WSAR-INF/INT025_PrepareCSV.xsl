<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map" xmlns:this="this.stylesheet"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc"
	xmlns:tdf="urn:com.workday/tdf">
	<xsl:output method="text" indent="0"/>
	<xsl:strip-space elements="*"/>

	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

	<xsl:template match="/">
		<xsl:text>UniqueId,AccountNumber,InvoicePeriodStart,InvoicePeriodEnd,NonPrimaryChargeTypeCode,NonPrimaryChargePriceCode,Price,Vatable,Description&#10;</xsl:text>

		<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
	</xsl:template>

	<xsl:template match="invoice" mode="in-memory">
		<!-- LPI -->
		<xsl:if test="charges/LPICharge castable as xs:decimal and charges/LPICharge &gt; 0">
			<xsl:value-of
				select="'LPI' || xs:string(current-date()) => substring(1, 10) => replace('-', '')"/>
			<xsl:text>,</xsl:text>
			<xsl:value-of select="customerID"/>
			<xsl:text>,,,</xsl:text>
			<xsl:text>LPI</xsl:text>
			<xsl:text>,</xsl:text>
			<xsl:text>UD</xsl:text>
			<xsl:text>,</xsl:text>
			<xsl:value-of select="charges/LPICharge => format-number('0.00')"/>
			<xsl:text>,</xsl:text>
			<xsl:text>0</xsl:text>
			<xsl:text>,</xsl:text>
			<xsl:text>Late Payment Interest</xsl:text>
			<xsl:text>&#10;</xsl:text>
		</xsl:if>

		<!-- LPC + MDC -->
		<xsl:if test="(charges/LPCCharge castable as xs:decimal and charges/LPCCharge &gt; 0) 
			or (charges/MDCCharge castable as xs:decimal and charges/MDCCharge &gt; 0)">
			<xsl:value-of
				select="'LPC' || xs:string(current-date()) => substring(1, 10) => replace('-', '') || invoiceID"/>
			<xsl:text>,</xsl:text>
			<xsl:value-of select="customerID"/>
			<xsl:text>,,,</xsl:text>
			<xsl:text>LPC</xsl:text>
			<xsl:text>,</xsl:text>
			<xsl:text>UD</xsl:text>
			<xsl:text>,</xsl:text>
						
			
			<xsl:value-of select="(
				(if (string(charges/LPCCharge)) then xs:decimal(charges/LPCCharge) else 0) + 
				(if (string(charges/MDCCharge)) then xs:decimal(charges/MDCCharge) else 0)
				) => format-number('0.00')"/>
			<xsl:text>,</xsl:text>
			<xsl:text>0</xsl:text>
			<xsl:text>,</xsl:text>
			<xsl:text>Late Payment Charge</xsl:text>
			<xsl:text>&#10;</xsl:text>
		</xsl:if>
		
	</xsl:template>
</xsl:stylesheet>
