<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:this="this.stylesheet" xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:wd="urn:com.workday/bsvc" xmlns:tdf="urn:com.workday/tdf"
	xmlns:xf="http://www.w3.org/2005/xpath-functions" expand-text="yes">
	<xsl:output method="text" indent="1"/>
	
	<!-- Declare streaming mode -->
	<xsl:mode streamable="no" on-no-match="shallow-skip" use-accumulators="#all"/>
	
	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>
	
	<xsl:template match="invoice">
		<xsl:variable name="invoiceRequest" as="node()">
			<xf:map key="">
				<!-- LPI balances -->
				<xf:map key="billedAmountGbp">
					<xf:string key="currency">GBP</xf:string>
					<xsl:variable name="LPICharge" select="if (charges/LPICharge castable as xs:decimal) then charges/LPICharge else 0"/>
					<xf:number key="value">
						<xsl:value-of select="xs:decimal($LPICharge) + xs:decimal(charges/billedAmountLPI)"/>
					</xf:number>
				</xf:map>	
				
				<xf:map key="chargeableBalanceGbp">
					<xf:string key="currency">GBP</xf:string>
					<xf:number key="value">
						<xsl:value-of select="charges/LPIBalance"/>
					</xf:number>
				</xf:map>	
				
				
				<!-- LPC Balances -->
				<xf:map key="billedAmountLpc">
					<xf:string key="currency">GBP</xf:string>
					
					<xsl:variable name="LPCCharge" select="if (charges/LPCCharge castable as xs:decimal) then charges/LPCCharge else 0"/>
					
					<xf:number key="value">
						<xsl:value-of select="xs:decimal($LPCCharge) + xs:decimal(charges/billedAmountLPC)"/>
					</xf:number>
				</xf:map>	
				
				<xf:map key="chargeableBalanceLpc">
					<xf:string key="currency">GBP</xf:string>
					<xf:number key="value">
						<xsl:value-of select="charges/LPCBalance"/>
					</xf:number>
				</xf:map>	
				
				
				<!-- MDC balances -->
				<xsl:variable name="MDCCharge" select="if (charges/MDCCharge castable as xs:decimal) then charges/MDCCharge else 0"/>
				<xf:number key="billedAmountMdc"><xsl:value-of select="xs:decimal($MDCCharge) + xs:decimal(charges/billedAmountMDC)"/></xf:number>
				<xf:number key="chargeableBalanceMdc"><xsl:value-of select="charges/MDCBalance"/></xf:number>
				
				
				<xf:string key="lpiAndLpcChargeDate2"><xsl:value-of select="newChargeDate => substring(1,10)"/></xf:string>
				<xf:number key="lpiAndLpcChargeDateDays">
					<xsl:value-of select="if (normalize-space(LPILPCChargeDays) != '') then LPILPCChargeDays else 0"/>
				</xf:number>
				<xf:map key="customerInvoice">
					<xf:string key="id">
						<xsl:value-of select="invoiceWID"/>
					</xf:string>
				</xf:map>
			</xf:map>
		</xsl:variable>
		
		
		
		
		
	<xsl:value-of select="xml-to-json($invoiceRequest, map {'indent': true()})"/>
	</xsl:template>
	
</xsl:stylesheet>

