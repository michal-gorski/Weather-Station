<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map" xmlns:this="this.stylesheet"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc"
	xmlns:tdf="urn:com.workday/tdf">
	<xsl:output method="xml" indent="1"/>

	<!-- Number of days from today to compute the next LPI/LPC charge date.
	     Supplied by the integration system attribute "Charge Frequency Days". -->
	<xsl:param name="INT025_Charge_Frequency_Days"/>

	<!-- Declare streaming mode: allows processing of large DIS payloads without
	     loading the full document into memory. on-no-match="shallow-skip" silently
	     ignores unmatched nodes. -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

	<!-- Root template: wraps all processed invoices in a single <preparedInvoices>
	     container. copy-of() materialises the streamed node into an in-memory tree
	     so that child templates can perform multi-directional navigation. -->
	<xsl:template match="tdf:LPI_Invoices">
		<preparedInvoices>
			<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
		</preparedInvoices>
	</xsl:template>

	<!-- Per-invoice template: flattens each tdf:LPI_Invoice into a simplified
	     <invoice> element with normalised field names and safe numeric defaults. -->
	<xsl:template match="tdf:LPI_Invoice" mode="in-memory">
		<invoice>
			<!-- Invoice identifiers -->
			<invoiceWID>
				<xsl:value-of select="tdf:Invoice_WID"/>
			</invoiceWID>
			<invoiceID>
				<xsl:value-of select="tdf:Invoice_ID"/>
			</invoiceID>

			<!-- Customer reference -->
			<customerID>
				<xsl:value-of select="tdf:Customer_ID"/>
			</customerID>

			<!-- Next charge date = today + INT025_Charge_Frequency_Days days.
			     The duration string is built dynamically, e.g. 'P30D' for 30 days. -->
			<newChargeDate>
				<xsl:value-of select="current-date() + xs:dayTimeDuration('P' || $INT025_Charge_Frequency_Days || 'D')"/>
			</newChargeDate>

			<charges>
				<!-- Chargeable balances sourced from the DIS report as-is -->
				<LPICharge><xsl:value-of select="tdf:Customer_Invoice/tdf:Chargeable_Balance_LPI"/></LPICharge>
				<LPCCharge><xsl:value-of select="tdf:Customer_Invoice/tdf:Chargeable_Balance_LPC"/></LPCCharge>
				<MDCCharge><xsl:value-of select="tdf:Customer_Invoice/tdf:Chargeable_Balance_MDC"/></MDCCharge>

				<!-- Outstanding balances set to 0; noting that all has been billed -->
				<LPIBalance>0</LPIBalance>
				<LPCBalance>0</LPCBalance>
				<MDCBalance>0</MDCBalance>

				<!-- Previously billed amounts; default to 0 when absent or non-numeric -->
				<billedAmountLPI><xsl:value-of select="if (tdf:Customer_Invoice/tdf:Billed_Amount_LPI castable as xs:decimal) then tdf:Customer_Invoice/tdf:Billed_Amount_LPI else 0"/></billedAmountLPI>
				<billedAmountLPC><xsl:value-of select="if (tdf:Customer_Invoice/tdf:Billed_Amount_LPC castable as xs:decimal) then tdf:Customer_Invoice/tdf:Billed_Amount_LPC else 0"/></billedAmountLPC>
				<billedAmountMDC><xsl:value-of select="if (tdf:Customer_Invoice/tdf:Billed_Amount_MDC castable as xs:decimal) then tdf:Customer_Invoice/tdf:Billed_Amount_MDC else 0"/></billedAmountMDC>
			</charges>
		</invoice>
	</xsl:template>

</xsl:stylesheet>
