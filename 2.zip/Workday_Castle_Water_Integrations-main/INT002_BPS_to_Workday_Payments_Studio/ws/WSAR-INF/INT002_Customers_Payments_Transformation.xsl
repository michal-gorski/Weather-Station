<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:map="http://www.w3.org/2005/xpath-functions/map" xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:wd="urn:com.workday/bsvc" xmlns:tdf="urn:com.workday/tdf" expand-text="yes" exclude-result-prefixes="#all" xmlns:mf="urn:mf">
	<xsl:output method="xml" indent="no"/>
	<xsl:strip-space elements="*"/>
	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

	<!-- Skip element in streamable mode -->
	<xsl:template match="tdf:Customers"/>

	<!-- Skip element in in-memory mode -->
	<xsl:template match="tdf:Customers" mode="in-memory"/>


	<xsl:accumulator name="customerNameMap" as="map(xs:string, xs:string)" initial-value="map {}" streamable="yes">

		<!-- Remember current customer name text -->
		<xsl:accumulator-rule match="tdf:Customer_Data/tdf:Customer_Name/text()" select="map:put($value, '_currentName', string(.))"/>

		<!-- Map each DD_Ref to that name, using '' if no name seen yet -->
		<xsl:accumulator-rule match="tdf:Customer_Data/tdf:Direct_Debit_Reference/text()" select="
				let $name := (if (map:contains($value, '_currentName')) then
					map:get($value, '_currentName')
				else
					'')
				return
					map:put($value, string(.), $name)"/>
	</xsl:accumulator>


	<xsl:accumulator name="customerIDMap" as="map(xs:string, xs:string)" initial-value="map {}" streamable="yes">

		<!-- Remember current customer ID text -->
		<xsl:accumulator-rule match="tdf:Customer_Data/tdf:Customer_ID/text()" select="map:put($value, '_currentID', string(.))"/>

		<!-- Map each DD_Ref to that ID, using '' if no ID seen yet -->
		<xsl:accumulator-rule match="tdf:Customer_Data/tdf:Direct_Debit_Reference/text()" select="
				let $id := (if (map:contains($value, '_currentID')) then
					map:get($value, '_currentID')
				else
					'')
				return
					map:put($value, string(.), $id)"/>
	</xsl:accumulator>

	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>

	<xsl:template match="Merged_data">
		<Transactions>
			<!-- Copy-of copies everything from source XML, to avoid printing Customers add empty template in in-memory mode -->
			<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
		</Transactions>
	</xsl:template>

	<xsl:template match="Payment" mode="in-memory">
		<Payment>

			<xsl:variable name="customerName" select="map:get(accumulator-after('customerNameMap'), PayerReference)"/>

			<xsl:variable name="customerID" select="map:get(accumulator-after('customerIDMap'), PayerReference)"/>

			<PayerName>
				<xsl:value-of select="PayerName"/>
			</PayerName>
			<CustomerName>
				<xsl:value-of select="$customerName"/>
			</CustomerName>
			<PayerReference>
				<xsl:value-of select="PayerReference"/>
			</PayerReference>
			<CustomerID>
				<xsl:value-of select="$customerID"/>
			</CustomerID>
			<Amount>
				<xsl:value-of select="Amount"/>
			</Amount>
			<Status>
				<xsl:value-of select="Status"/>
			</Status>
			<PaymentDate>
				<xsl:value-of select="CollectionDate"/>
			</PaymentDate>
			<PayerAccountNumber>
				<xsl:value-of select="PayerAccountNumber"/>
			</PayerAccountNumber>
		</Payment>
	</xsl:template>

	<xsl:template match="Element[@name = 'ReturnedDebitItem']" mode="in-memory">
	</xsl:template>

</xsl:stylesheet>
