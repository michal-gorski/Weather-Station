<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:v3="https://www.emandates.co.uk/v3/" exclude-result-prefixes="soap v3">


    <xsl:output method="xml" indent="yes"/>

    <!--<xsl:template match="/">

        <xsl:copy-of select="//v3:Payments"/>

    </xsl:template>-->
    
    
    <!-- Processing root of document -->
    <xsl:template match="/">
        <xsl:apply-templates select="//v3:Payments"/>
    </xsl:template>
    
    <!-- Processing v3:Payments without namespaces -->
    <xsl:template match="v3:Payments">
        <xsl:element name="Payments">
            <xsl:apply-templates select="v3:PaymentAPI"/>
        </xsl:element>
    </xsl:template>
    
    <!-- Processing v3:PaymentAPI without namespaces -->
    <xsl:template match="v3:PaymentAPI">
        <xsl:element name="Payment">
            <xsl:apply-templates select="@* | node()"/>
        </xsl:element>
    </xsl:template>
    
    
    <xsl:template match="v3:*">
        <xsl:element name="{local-name()}">
            <xsl:apply-templates select="@* | node()"/>
        </xsl:element>
    </xsl:template>
    
    
    <!-- Attributes without namespaces -->
    <xsl:template match="@*">
        <xsl:attribute name="{local-name()}">
            <xsl:value-of select="."/>
        </xsl:attribute>
    </xsl:template>

    <xsl:template match="text()">
        <xsl:value-of select="."/>
    </xsl:template>
    

</xsl:stylesheet>
