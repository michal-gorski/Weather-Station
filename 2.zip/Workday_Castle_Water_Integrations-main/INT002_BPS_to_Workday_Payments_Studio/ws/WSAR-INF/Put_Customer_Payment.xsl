<?xml version="1.0" encoding="UTF-8"?>
<env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema"
    xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wd="urn:com.workday/bsvc">
    <env:Header>
        <wsse:Security env:mustUnderstand="1">
            <wsse:UsernameToken>
                <wsse:Username>@{props['p.username']}</wsse:Username>
                <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">@{props['p.password']}</wsse:Password>
            </wsse:UsernameToken>
        </wsse:Security>
    </env:Header>
    <env:Body>
        <wd:Put_Customer_Payment_Request xmlns:wd="urn:com.workday/bsvc" wd:Add_Only="true" wd:version="v44.1">

            <wd:Customer_Payment_Data>
                <wd:Locked_in_Workday>false</wd:Locked_in_Workday>
                <wd:Company_Reference>
                    <wd:ID wd:type="Company_Reference_ID">@{props['p.companyRefID']}</wd:ID>
                </wd:Company_Reference>
                <wd:Payment_Currency_Reference>
                    <wd:ID wd:type="Currency_ID">@{props['p.currency']}</wd:ID>
                </wd:Payment_Currency_Reference>
                <wd:Payment_Date>@{props['p.formattedDate']}</wd:Payment_Date>
                <wd:Payment_Type_Reference>
                    <wd:ID wd:type="Payment_Type_ID">Wire</wd:ID>
                </wd:Payment_Type_Reference>
                <wd:Payment_Status/>
                <wd:Cancel_Accounting_Date/>
                <wd:Payment_Application_Status/>
                <wd:Payment_Number/>
                <wd:Payment_Amount>@{props['p.amount']}</wd:Payment_Amount>
                <wd:Remit-from_Customer_Reference>
                    <wd:ID wd:type="Customer_ID">@{props['p.customerID']}</wd:ID>
                </wd:Remit-from_Customer_Reference>
                <wd:Check_Number/>
                <wd:Document_Link/>
                <wd:Payment_Memo/>
                <wd:Ready_to_Auto-Apply>true</wd:Ready_to_Auto-Apply>
                <wd:Invoice_Currency_Reference>
                    <wd:ID wd:type="Currency_ID">@{props['p.currency']}</wd:ID>
                </wd:Invoice_Currency_Reference>

            </wd:Customer_Payment_Data>
        </wd:Put_Customer_Payment_Request>
    </env:Body>
</env:Envelope>
