<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    exclude-result-prefixes="soap xsi">
    
    <xsl:output method="xml" indent="yes"/>
    
    <!-- Start at root -->
    <xsl:template match="/">
        <Attributes>
            <xsl:apply-templates select="*"/>
        </Attributes>
    </xsl:template>
    
    <!-- Match any element -->
    <xsl:template match="*">
        <Element name="{name()}">
            <!-- List attributes -->
            <xsl:for-each select="@*">
                <Attribute name="{name()}" value="{normalize-space(.)}"/>
            </xsl:for-each>
            <!-- Recurse into children -->
            <xsl:apply-templates select="*"/>
        </Element>
    </xsl:template>
</xsl:stylesheet>