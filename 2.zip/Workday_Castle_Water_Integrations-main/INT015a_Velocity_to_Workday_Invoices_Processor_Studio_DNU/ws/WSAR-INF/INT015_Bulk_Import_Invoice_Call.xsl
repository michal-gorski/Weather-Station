<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc">
	<xsl:output method="xml" indent="1"/>
	
	<xsl:template match="invoice">
		      <xsl:variable name="dateDay" select="substring(invoice_date,1,2)"/>
	    <xsl:variable name="dateMonth" select="substring(invoice_date,4,2)"/>
	    <xsl:variable name="dateYear" select="substring(invoice_date,7,4)"/>
	    
	    <xsl:variable name="invoiceDate" select="$dateYear || '-' || $dateMonth || '-' || $dateDay" />
	    
            <wd:Submit_Customer_Invoice_Request wd:Add_Only="true">
                
                <wd:Business_Process_Parameters>
                    <wd:Auto_Complete>true</wd:Auto_Complete>
                    <wd:Comment_Data>
                        <wd:Comment>Imported from Velocity integration</wd:Comment>
                     
                    </wd:Comment_Data>
                </wd:Business_Process_Parameters>
                <wd:Customer_Invoice_Data>
                	<wd:Customer_Invoice_ID><xsl:value-of select="invoice_id"/></wd:Customer_Invoice_ID>
                    <wd:Submit>true</wd:Submit>
                    
                    <wd:Company_Reference>
                    	<wd:ID wd:type="Company_Reference_ID">CWL</wd:ID>
                    </wd:Company_Reference>
                    
                    
                    <wd:Currency_Reference>
                        <wd:ID wd:type="Currency_ID">GBP</wd:ID>
                    </wd:Currency_Reference>
                	
                    <wd:Customer_Reference>
                    	<wd:ID wd:type="Customer_ID"><xsl:value-of select="customer"/></wd:ID>
                    </wd:Customer_Reference>
                   
                                     
                	<wd:Invoice_Number><xsl:value-of select="invoice_id"/></wd:Invoice_Number>
                	
                    
                	<wd:Invoice_Date><xsl:value-of select="$invoiceDate"/></wd:Invoice_Date>
                	<wd:Accounting_Date><xsl:value-of select="$invoiceDate"/></wd:Accounting_Date>
                 
                	<wd:Control_Amount_Total><xsl:value-of select="sum(lines/line/amount)"/></wd:Control_Amount_Total>
                  
                    <wd:Customer_Invoice_Type_Reference>
                    	<wd:ID wd:type="Customer_Invoice_Type_ID">Standard</wd:ID>
                    </wd:Customer_Invoice_Type_Reference>
                	                
                    
                    <!--<wd:Memo>Test Memo</wd:Memo>-->
                    
                    <xsl:for-each select="lines/line">
                    
                    <wd:Customer_Invoice_Line_Replacement_Data>
                    	
                    	<wd:Line_Order><xsl:value-of select="position()"/></wd:Line_Order>
                       
                                          	
                        <wd:Revenue_Category_Reference>
                        	<wd:ID wd:type="Revenue_Category_ID"><xsl:value-of select="revenue_category"/></wd:ID>
                        </wd:Revenue_Category_Reference>
                    	
                    	<wd:Line_Item_Description><xsl:value-of select="description"/></wd:Line_Item_Description>
                        
                    
                        <wd:Tax_Applicability_Reference>
                        	<wd:ID wd:type="Tax_Applicability_ID">GBR_Domestic_Sale_of_Goods_and_Services</wd:ID>
                        </wd:Tax_Applicability_Reference>
                        <xsl:choose>
                    	<xsl:when test="tax_amount and tax_amount != 0">
	                    	<wd:Tax_Code_Reference>
	                    		<wd:ID wd:type="Tax_Code_ID">GBR_Standard</wd:ID>
	                        </wd:Tax_Code_Reference>
                                                                 
                        	<wd:Calculated_Tax_Amount><xsl:value-of select="tax_amount"/></wd:Calculated_Tax_Amount>
                        </xsl:when>
                        	<xsl:otherwise>
                        		<wd:Tax_Code_Reference>
                        			<wd:ID wd:type="Tax_Code_ID">GBR_Exempt</wd:ID>
                        		</wd:Tax_Code_Reference>
                        		
                        		<wd:Calculated_Tax_Amount>0</wd:Calculated_Tax_Amount>
                        	</xsl:otherwise>
                        </xsl:choose>
                    	
                    	<wd:Extended_Amount><xsl:value-of select="amount"/></wd:Extended_Amount>
                    	<wd:Transaction_Date><xsl:value-of select="../../$invoiceDate"/></wd:Transaction_Date>
                      
                        <!--<wd:Memo>test line memo</wd:Memo>-->
                    	<wd:Analytical_Amount><xsl:value-of select="amount"/></wd:Analytical_Amount>
                    	
                        <wd:Worktags_Reference>
                        	<wd:ID wd:type="Cost_Center_ID"><xsl:value-of select="cost_center"/></wd:ID>
                        </wd:Worktags_Reference>
                    	
                        
                  
                        
                       
                    </wd:Customer_Invoice_Line_Replacement_Data>                  
                
                    </xsl:for-each>
                </wd:Customer_Invoice_Data>
            </wd:Submit_Customer_Invoice_Request>
        
	</xsl:template>
</xsl:stylesheet>