<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:wd="urn:com.workday/bsvc" exclude-result-prefixes="wd">

	<xsl:output method="text" encoding="UTF-8"/>

	<xsl:template match="/">
		<xsl:for-each select="//wd:File">
			<xsl:value-of select="."/>
			<xsl:text>&#10;</xsl:text>

		</xsl:for-each>
	</xsl:template>
</xsl:stylesheet>
