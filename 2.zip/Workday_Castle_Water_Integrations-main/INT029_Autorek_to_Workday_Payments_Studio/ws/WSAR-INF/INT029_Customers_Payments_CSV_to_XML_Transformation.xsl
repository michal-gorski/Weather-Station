<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

	<xsl:template match="/root">
		<Transactions>
			<xsl:for-each select="row[position() > 1]">
				<Record>
					<xsl:for-each select="*[starts-with(name(), 'col')]">
						<xsl:variable name="pos" select="position()" />
						<xsl:variable name="header" select="/root/row[1]/*[position()=$pos]" />
						<xsl:element name="{translate($header, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')}">
							<xsl:value-of select="replace(., &quot;'&quot;, '#')" />
						</xsl:element>
					</xsl:for-each>
				</Record>
			</xsl:for-each>
		</Transactions>
	</xsl:template>
	
</xsl:stylesheet>
