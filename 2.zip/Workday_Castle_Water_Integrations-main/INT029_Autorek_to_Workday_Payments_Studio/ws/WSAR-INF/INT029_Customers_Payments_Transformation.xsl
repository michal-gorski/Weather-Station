<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:map="http://www.w3.org/2005/xpath-functions/map"
	xmlns:wd="urn:com.workday/bsvc" xmlns:tdf="urn:com.workday/tdf" expand-text="yes" exclude-result-prefixes="#all">

	<xsl:output method="xml" indent="no"/>
	<xsl:strip-space elements="*"/>

	<!-- streamable mode + accumulators -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

	<!--creation of map: TEIP_Legacy_Account -> Customer_ID  -->
	<xsl:accumulator name="legacyMap" as="map(xs:string, xs:string)" initial-value="map {}" streamable="yes">
		<!-- When encounter this node -> uses this rule -->
		<!-- Creates map {'legacyNum' : '123'} -->
		<xsl:accumulator-rule match="tdf:Customer_Data/tdf:TEIP_Legacy_Account/text()" select="map:put($value, 'legacyNum', upper-case(normalize-space(.)))"/>
		
		
		<xsl:accumulator-rule match="tdf:Customer_Data/tdf:Customer_ID/text()">
			<!-- $key = '123' -->
			<xsl:variable name="key" select="map:get($value, 'legacyNum')"/>
			<!-- val = value form Customer_ID/text() -->
			<xsl:variable name="val" select="upper-case(normalize-space(.))"/>
			<!-- if $key is not empty -> clear map -> map {} and return new map {'123' : 'customer_ID_val'} -->
			<!-- if there's no $key, returns WHOLE MAP, without new changes-->
			<xsl:sequence select="
					if ($key) then
					map:put(map:remove($value, 'legacyNum'), $key, $val)
					else
						$value"/>
		</xsl:accumulator-rule>
	</xsl:accumulator>

	<!-- Account_Number -> Customer_ID (clearing) -->
	<xsl:accumulator name="accountMap" as="map(xs:string, xs:string)" initial-value="map {}" streamable="yes">
		<xsl:accumulator-rule match="tdf:Customer_Data/tdf:Account_Number/text()" select="map:put($value, 'accountNum', upper-case(normalize-space(.)))"/>
		<xsl:accumulator-rule match="tdf:Customer_Data/tdf:Customer_ID/text()">
			<xsl:variable name="key" select="map:get($value, 'accountNum')"/>
			<xsl:variable name="val" select="upper-case(normalize-space(.))"/>
			<xsl:sequence select="
					if ($key) then
					map:put(map:remove($value, 'accountNum'), $key, $val)
					else
						$value"/>
		</xsl:accumulator-rule>
	</xsl:accumulator>

	<!-- Bank_Account_Number -> Bank_Account_WID (clearing) -->
	<xsl:accumulator name="bankWIDMap" as="map(xs:string, xs:string)" initial-value="map {}" streamable="yes">
		<xsl:accumulator-rule match="tdf:Bank_Accounts/tdf:Bank_Account_Data/tdf:Bank_Account_Number/text()" select="map:put($value, 'k', normalize-space(.))"/>
		<xsl:accumulator-rule match="tdf:Bank_Accounts/tdf:Bank_Account_Data/tdf:Bank_Account_WID/text()">
			<xsl:variable name="k" select="map:get($value, 'k')"/>
			<xsl:sequence select="
					if ($k) then
						map:put(map:remove($value, 'k'), $k, normalize-space(.))
					else
						$value"/>
		</xsl:accumulator-rule>
	</xsl:accumulator>

	<!-- Entering: emit the container and process the records (without copy-of) -->
	<xsl:template match="/">
		<Transactions>
			<xsl:apply-templates select="/*/Transactions/Record"/>
		</Transactions>
	</xsl:template>

	<!-- Record: first ONE copy of the entire Record, then work on it -->
	<xsl:template match="Record">
		<!-- Grounding (one allowed consumption of the current node) -->
		<xsl:variable name="rec" as="element(Record)" select="copy-of(.)"/>

		<!-- Fields from the copy (not streamable) -->
		<xsl:variable name="acct" select="upper-case(normalize-space(string($rec/account_number)))"/>
		<xsl:variable name="transactionType" select="normalize-space(string($rec/transaction_type))"/>
		<xsl:variable name="amount" select="string($rec/transaction_value)"/>
		<xsl:variable name="payDate" select="string($rec/group_by_date)"/>
		<xsl:variable name="payerAcc" select="string($rec/account_number)"/>
		<xsl:variable name="refText" select="string($rec/reference)"/>
		<xsl:variable name="refNum" select="normalize-space(tokenize($refText, ':')[last()])"/>
		<xsl:variable name="depositRef" select="translate(normalize-space(string($rec/bank_statement_line_ref)), ' &amp;', '_+')"/>
		<xsl:variable name="depositDate" select="string($rec/bank_statement_date)"/>
		<xsl:variable name="bankWID" select="map:get(accumulator-after('bankWIDMap'), normalize-space(string($rec/bank_account_number)))"/>

		<!-- Mapping of CustomerID: first legacy account number, then account number-->
		<xsl:variable name="legacy" select="map:get(accumulator-after('legacyMap'), $acct)"/>
		<xsl:variable name="cust" select="map:get(accumulator-after('accountMap'), $acct)"/>
		<xsl:variable name="custID" select="($legacy, $cust)[. != ''][1]"/>

		<xsl:choose>
			<xsl:when test="$transactionType = '1'">
				<Credit>
					<PaymentReference>{$refText}</PaymentReference>
					<PaymentReferenceNumber>{$refNum}</PaymentReferenceNumber>
					<CustomerID>{$custID}</CustomerID>
					<Amount>{$amount}</Amount>
					<PaymentDate>{$payDate}</PaymentDate>
					<PayerAccountNumber>{$payerAcc}</PayerAccountNumber>
					<TransactionType>{$transactionType}</TransactionType>
					<DepositReference>{$depositRef}</DepositReference>
					<PaymentDepositDate>{$depositDate}</PaymentDepositDate>
					<BankAccountWID>{$bankWID}</BankAccountWID>
				</Credit>
			</xsl:when>
			<xsl:otherwise>
				<Debit>
					<PaymentReference>{$refText}</PaymentReference>
					<PaymentReferenceNumber>{$refNum}</PaymentReferenceNumber>
					<CustomerID>{$custID}</CustomerID>
					<Amount>{$amount}</Amount>
					<PaymentDate>{$payDate}</PaymentDate>
					<PayerAccountNumber>{$payerAcc}</PayerAccountNumber>
					<TransactionType>{$transactionType}</TransactionType>
					<AdHocBankTransactionReference>{$depositRef}</AdHocBankTransactionReference>
					<PaymentDepositDate>{$depositDate}</PaymentDepositDate>
					<BankAccountWID>{$bankWID}</BankAccountWID>
				</Debit>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

</xsl:stylesheet>
