<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map"
	xmlns:xs="http://www.w3.org/2001/XMLSchema">
	<xsl:output method="xml" indent="1"/>
	
	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip"/>
	
	<!-- Root template to process transactions -->
	<xsl:template match="root">
		<root>
			<!--stream iterate over all row elements -->
			<xsl:iterate select="row">
				<!-- Initialize an empty map as a parameter -->
				<xsl:param name="itemMap" as="map(xs:string, node())" select="map{}"/>
				
				<!--after all iterations output map -->
				<xsl:on-completion>
					<xsl:for-each select="map:keys($itemMap)">                                       
						<xsl:copy-of select="$itemMap(.)"/>
					</xsl:for-each>                             
				</xsl:on-completion>				
				
				<!--copy current row element to variable to ensure no streaming issues -->
				<xsl:variable name="iter" select="./copy-of()"/>
				
				<!-- get existing item from map -->
				<xsl:variable name="existing" select="map:get($itemMap,$iter/REFERENCE)"/>
				
				<!-- build groupped content -->
				<xsl:variable name="groupped">
					<invoice>
						<xsl:attribute name="InvoiceID" select="$iter/REFERENCE"/>
						<xsl:copy-of select="$existing/invoice/*"/> 
						<xsl:copy-of select="$iter"/>
					</invoice>
					
				</xsl:variable>
				
				
				<!--add current item to map -->
				<xsl:variable name="newItemMap" as="map(xs:string, node())"
					select="map:put(
					$itemMap,
					xs:string($iter/REFERENCE/text()),
					$groupped)"/>
				
				<!-- Pass the updated map to the next iteration -->
				<xsl:next-iteration>
					<xsl:with-param name="itemMap" select="$newItemMap"/>
				</xsl:next-iteration>
			</xsl:iterate>
		</root>
		
		
	</xsl:template>
</xsl:stylesheet>
