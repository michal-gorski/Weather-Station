<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc"
	xmlns:etv="urn:com.workday/etv" xmlns:err="http://www.w3.org/2005/xqt-errors">
	<xsl:output method="xml" indent="1"/>

	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

	<xsl:accumulator name="revCatKey" as="xs:string" initial-value="''" streamable="yes">
		<xsl:accumulator-rule match="revenueCatMap/mapValue/key/text()" select="string(.)"/>
	</xsl:accumulator>

	<xsl:accumulator name="revenueCategoryMap" as="map(xs:string,xs:string)" initial-value="map {}"
		streamable="yes">
		<xsl:accumulator-rule match="revenueCatMap/mapValue/value/text()"
			select="map:put($value, accumulator-before('revCatKey'), string(.))"/>
	</xsl:accumulator>


	<xsl:accumulator name="taxApplicabilityKey" as="xs:string" initial-value="''" streamable="yes">
		<xsl:accumulator-rule match="taxApplicabilityMap/mapValue/key/text()" select="string(.)"/>
	</xsl:accumulator>

	<xsl:accumulator name="taxApplicabilityMap" as="map(xs:string,xs:string)" initial-value="map {}"
		streamable="yes">
		<xsl:accumulator-rule match="taxApplicabilityMap/mapValue/value/text()"
			select="map:put($value, accumulator-before('taxApplicabilityKey'), string(.))"/>
	</xsl:accumulator>

	<xsl:variable name="CREDIT_NOTE_ID" select="'5'"/>

	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>

	<xsl:template match="root">
		<invoices>
			<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
		</invoices>
	</xsl:template>


	<xsl:template match="invoice" mode="in-memory">
		<xsl:variable name="current_id" select="row[1]/REFERENCE" />
		<xsl:try>
			<xsl:variable name="invoice_or_adjustment">
				<invoice>
					<invoice_id>
						<xsl:value-of select="row[1]/REFERENCE"/>
					</invoice_id>
					<customer>
						<xsl:value-of select="row[1]/ACCOUNT_NUMBER"/>
					</customer>
					<invoice_date>
						<xsl:value-of select="row[1]/TRANSACTION_DATE => replace('/', '-')"/>
					</invoice_date>

					<accounting_date>
						<xsl:value-of select="row[1]/TRANSACTION_DATE => replace('/', '-')"/>
					</accounting_date>


					<company>CWL</company>

					<xsl:variable name="lines">

						<xsl:for-each select="row">
							<line>
								<xsl:variable name="nominalAccount">
									<xsl:value-of select="replace(NOMINAL_ACCOUNT, '^0+', '')"/>
								</xsl:variable>

								<xsl:variable name="revenueCategory">
									<xsl:value-of
										select="map:get(accumulator-after('revenueCategoryMap'), $nominalAccount)"/>

								</xsl:variable>

								<xsl:variable name="taxApplicability">
									<xsl:value-of
										select="map:get(accumulator-after('taxApplicabilityMap'), $nominalAccount)"
									/>
								</xsl:variable>

								<xsl:variable name="creditNoteNegation" select="
										if (TRANSACTION_TYPE = $CREDIT_NOTE_ID)
										then
											-1
										else
											1"/>

								<amount>
									<xsl:value-of select="NOMINAL_AMOUNT * $creditNoteNegation"/>
								</amount>

								<tax_amount>
									<xsl:value-of select="TAX_VALUE * $creditNoteNegation"/>
								</tax_amount>

								<tax_applicability>
									<xsl:value-of select="$taxApplicability"/>
								</tax_applicability>

								<tax_code>
									<xsl:choose>
										<xsl:when test="TAX_VALUE = 0">GBR_Zero_Rated</xsl:when>
										<xsl:when test="TAX_CODE = '1'">GBR_Standard</xsl:when>
										<xsl:when test="TAX_CODE = '9'">GBR_Out_of_Scope</xsl:when>
										<xsl:when test="TAX_CODE = '12'">GBR_Zero_Rated</xsl:when>
										<xsl:otherwise>GBR_Standard</xsl:otherwise>
									</xsl:choose>
								</tax_code>

								<xsl:if test="$revenueCategory != 'RVC002'">
									<cost_center>
										<xsl:value-of select="NOMINAL_CC"/>
									</cost_center>
								</xsl:if>
								<revenue_category>
									<xsl:value-of select="$revenueCategory"/>
								</revenue_category>


								<description>
									<xsl:value-of select="REFERENCE"/>
								</description>
								<memo>
									<xsl:value-of select="Other-Description"/>
								</memo>

							</line>
						</xsl:for-each>

					</xsl:variable>

					<lines>
						<xsl:for-each-group select="$lines/line" group-by="revenue_category">
							<line>
								<amount>
									<xsl:value-of select="sum(current-group()/amount)"/>
								</amount>

								<tax_amount>
									<xsl:value-of select="sum(current-group()/tax_amount)"/>
								</tax_amount>

								<total_amount>
									<xsl:value-of
										select="sum(current-group()/amount) + sum(current-group()/tax_amount)"
									/>
								</total_amount>

								<tax_applicability>
									<xsl:value-of select="current-group()[1]/tax_applicability"/>
								</tax_applicability>

								<tax_code>
									<xsl:value-of select="current-group()[1]/tax_code"/>
								</tax_code>


								<cost_center>
									<xsl:value-of select="current-group()[1]/cost_center"/>
								</cost_center>
								<revenue_category>
									<xsl:value-of select="current-grouping-key()"/>
								</revenue_category>


								<description>
									<xsl:value-of select="current-group()[1]/description"/>
								</description>
								<memo>
									<xsl:value-of select="current-group()[1]/memo"/>
								</memo>


							</line>

						</xsl:for-each-group>
					</lines>
				</invoice>
			</xsl:variable>



			<!--
				Sum total_amount across all lines to decide invoice vs adjustment.
				All lines are always included; the sign of the total determines the document type.
			-->
			<xsl:variable name="linesAmount"
				select="sum($invoice_or_adjustment/invoice/lines/line/total_amount)"/>

			<!-- total >= 0: emit a normal invoice containing all lines -->
			<xsl:if test="$linesAmount &gt;= 0">
				<invoice>

					<xsl:copy-of
						select="$invoice_or_adjustment/invoice/child::*[local-name() != 'lines']"/>

					<lines>
						<xsl:for-each
							select="$invoice_or_adjustment/invoice/lines/line">
							<xsl:copy-of select="."/>
						</xsl:for-each>
					</lines>

				</invoice>
			</xsl:if>

			<!-- total < 0: emit an adjustment containing all lines with amounts negated -->
			<xsl:if test="$linesAmount &lt; 0">
				<invoice-adjustment>

					<xsl:copy-of
						select="$invoice_or_adjustment/invoice/child::*[local-name() != 'lines']"/>

					<lines>
						<xsl:for-each
							select="$invoice_or_adjustment/invoice/lines/line">
							<line>
								<xsl:copy-of
									select="./child::*[local-name() != 'amount' and local-name() != 'tax_amount']"/>
								<tax_amount>
									<xsl:value-of select="./tax_amount * -1"/>
								</tax_amount>
								<amount>
									<xsl:value-of select="./amount * -1"/>
								</amount>
							</line>

						</xsl:for-each>
					</lines>
				</invoice-adjustment>
			</xsl:if>

			<xsl:catch>
				<etv:message etv:severity="error" etv:target="{$current_id}">
					<xsl:value-of
						select="'XSLT error occured for invoice: ' || $current_id || '; ' || $err:description || ' line: ' || $err:line-number"/>
				</etv:message>
			</xsl:catch>
		</xsl:try>
	</xsl:template>


</xsl:stylesheet>
