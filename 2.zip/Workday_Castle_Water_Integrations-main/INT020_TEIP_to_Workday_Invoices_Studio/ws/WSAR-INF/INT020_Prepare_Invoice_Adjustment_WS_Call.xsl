<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc">
	<xsl:output method="xml" indent="1"/>
<xsl:param name="INT_FileName"/>
	<xsl:template match="invoice-adjustment">
		<xsl:variable name="dateDay" select="substring(invoice_date, 1, 2)"/>
		<xsl:variable name="dateMonth" select="substring(invoice_date, 4, 2)"/>
		<xsl:variable name="dateYear" select="substring(invoice_date, 7, 4)"/>

		<xsl:variable name="invoiceDate" select="$dateYear || '-' || $dateMonth || '-' || $dateDay"/>
		
		<xsl:variable name="accountingDateDay" select="substring(accounting_date, 1, 2)"/>
		<xsl:variable name="accountingDateMonth" select="substring(accounting_date, 4, 2)"/>
		<xsl:variable name="accountingDateYear" select="substring(accounting_date, 7, 4)"/>
		
		<xsl:variable name="accountingDate" select="$dateYear || '-' || $dateMonth || '-' || $dateDay"/>
		
		<env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/"
			xmlns:xsd="http://www.w3.org/2001/XMLSchema"
			xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
			xmlns:wd="urn:com.workday/bsvc">

			<env:Body>
				<wd:Submit_Customer_Invoice_Adjustment_Request xmlns:wd="urn:com.workday/bsvc"
					wd:Add_Only="true" wd:version="v44.2">

					<wd:Business_Process_Parameters>
						<wd:Auto_Complete>true</wd:Auto_Complete>
						<wd:Comment_Data>
							<wd:Comment>Imported from Scotland integration</wd:Comment>

						</wd:Comment_Data>
					</wd:Business_Process_Parameters>

					<wd:Customer_Invoice_Adjustment_Data>
						<wd:Customer_Invoice_Adjustment_ID>
							<xsl:value-of select="invoice_id"/>
						</wd:Customer_Invoice_Adjustment_ID>
						<wd:Submit>true</wd:Submit>

						<wd:Invoice_Number>
							<xsl:value-of select="invoice_id"/>
						</wd:Invoice_Number>

						<wd:Company_Reference>
							<wd:ID wd:type="Company_Reference_ID">
								<xsl:value-of select="company"/>
							</wd:ID>
						</wd:Company_Reference>



						<wd:Customer_Reference>
							<wd:ID wd:type="Customer_ID">
								<xsl:value-of select="customer"/>
							</wd:ID>
						</wd:Customer_Reference>

						<!-- <wd:Sold_To_Customer_Reference>
                    <wd:ID wd:type="Customer_ID">abcdef</wd:ID>
                </wd:Sold_To_Customer_Reference>-->

						<wd:Populate_with_Default_Bill_To_Contacts>true</wd:Populate_with_Default_Bill_To_Contacts>


						<wd:Adjustment_Reason_Reference>
							<wd:ID wd:type="Adjustment_Reason_ID">Credit_Note</wd:ID>
						</wd:Adjustment_Reason_Reference>
						<!-- <wd:Increase_Amount_Due>true</wd:Increase_Amount_Due>-->
						<!-- <wd:Original_Customer_Invoice_Reference>
                    <wd:ID wd:type="Customer_Invoice_Reference_ID">abcdef</wd:ID>
                </wd:Original_Customer_Invoice_Reference>-->

						<wd:Auto-Apply_Adjustment_to_Invoice>false</wd:Auto-Apply_Adjustment_to_Invoice>
						<wd:Currency_Reference>
							<wd:ID wd:type="Currency_ID">GBP</wd:ID>
						</wd:Currency_Reference>

						<wd:Adjustment_Date>
							<xsl:value-of select="$invoiceDate"/>
						</wd:Adjustment_Date>
						<!--<wd:Accounting_Date>
							<xsl:value-of select="$accountingDate"/>
						</wd:Accounting_Date>-->
						<xsl:if test="due_date_override">
							<wd:Due_Date_Override>
								<xsl:value-of select="due_date_override"/>
							</wd:Due_Date_Override>
						</xsl:if>
						<wd:Control_Amount_Total>
							<xsl:value-of select="sum(lines/line/amount)"/>
						</wd:Control_Amount_Total>
						<!-- <wd:Payment_Terms_Reference>
                    <wd:ID wd:type="Payment_Terms_ID">abcdef</wd:ID>
                </wd:Payment_Terms_Reference>
                <wd:Payment_Status>abcdef</wd:Payment_Status>-->

						<wd:Customer_Invoice_Type_Reference>
							<wd:ID wd:type="Customer_Invoice_Type_ID">Standard</wd:ID>
						</wd:Customer_Invoice_Type_Reference>

						<!--<wd:Tax_Code_Reference>
                    <wd:ID wd:type="Tax_Code_ID">abcdef</wd:ID>
                </wd:Tax_Code_Reference>-->

						<wd:Memo>
							<xsl:value-of select="memo"/>
						</wd:Memo>
						<wd:Customer_PO_Number><xsl:value-of select="$INT_FileName"/></wd:Customer_PO_Number>
						<xsl:for-each select="lines/line">

							<wd:Customer_Invoice_Line_Replacement_Data>
								<!--<wd:Customer_Invoice_Line_Reference>
							<wd:ID wd:type="Customer_Invoice_Line_Reference_ID">abcdef</wd:ID>
						</wd:Customer_Invoice_Line_Reference>-->
								<!--<wd:Customer_Invoice_Line_Reference_ID>abcdef</wd:Customer_Invoice_Line_Reference_ID>-->
								<wd:Line_Order>
									<xsl:value-of select="position()"/>
								</wd:Line_Order>
								<!--
						<wd:Sales_Item_Reference>
							<wd:ID wd:type="Sales_Item_ID">abcdef</wd:ID>
						</wd:Sales_Item_Reference>-->

								<wd:Revenue_Category_Reference>
									<wd:ID wd:type="Revenue_Category_ID">
										<xsl:value-of select="revenue_category"/>
									</wd:ID>
								</wd:Revenue_Category_Reference>


								<wd:Line_Item_Description><xsl:value-of select="description"/></wd:Line_Item_Description>

								<wd:Tax_Applicability_Reference>
									<wd:ID wd:type="Tax_Applicability_ID">
										<xsl:value-of select="tax_applicability"/>
									</wd:ID>
								</wd:Tax_Applicability_Reference>
								<wd:Tax_Code_Reference>
									<wd:ID wd:type="Tax_Code_ID">
										<xsl:value-of select="tax_code"/>
									</wd:ID>
								</wd:Tax_Code_Reference>



								<!--<wd:Quantity>12678967.54</wd:Quantity>
						<wd:Unit_of_Measure_Reference>
							<wd:ID wd:type="UN_CEFACT_Common_Code_ID">abcdef</wd:ID>
						</wd:Unit_of_Measure_Reference>

						<wd:Unit_Cost>12678967.54</wd:Unit_Cost>
						<wd:Amount_Retained>12678967.54</wd:Amount_Retained>
						<wd:Amount_Released>12678967.54</wd:Amount_Released>-->
								<wd:Extended_Amount>
									<xsl:value-of select="amount"/>
								</wd:Extended_Amount>
								<wd:Transaction_Date>
									<xsl:value-of select="../../$invoiceDate"/>
								</wd:Transaction_Date>
								<!--<wd:From_Date>2025-09-16</wd:From_Date>
						<wd:To_Date>2025-09-16</wd:To_Date>
-->
								<!--<wd:Memo>abcdef</wd:Memo>-->
								<wd:Analytical_Amount>
									<xsl:value-of select="amount"/>
								</wd:Analytical_Amount>
								<xsl:if test="cost_center and cost_center != ''">
									<wd:Worktags_Reference>
										<wd:ID wd:type="Organization_Reference_ID">
											<xsl:value-of select="cost_center"/>
										</wd:ID>
									</wd:Worktags_Reference>
								</xsl:if>
								<!--<wd:Calculated_Tax_Amount>12678967.54</wd:Calculated_Tax_Amount>-->

							</wd:Customer_Invoice_Line_Replacement_Data>
						</xsl:for-each>


						<xsl:variable name="vatLines" select="lines/line[tax_amount != 0]"/>

						<xsl:if test="$vatLines">
							<wd:Tax_Code_Data>
								<wd:Tax_Applicability_Reference>
									<wd:ID wd:type="Tax_Applicability_ID">
										<xsl:value-of select="$vatLines[1]/tax_applicability"/>
									</wd:ID>
								</wd:Tax_Applicability_Reference>
								<wd:Tax_Code_Reference>
									<wd:ID wd:type="Tax_Code_ID">
										<xsl:value-of select="$vatLines[1]/tax_code"/>
									</wd:ID>
								</wd:Tax_Code_Reference>
								<wd:Tax_Amount>
									<xsl:value-of select="sum($vatLines/tax_amount)"/>
								</wd:Tax_Amount>
								
								<wd:Tax_Rate_Data>
									<wd:Tax_Rate_Reference>
										<wd:ID wd:type="Tax_Rate_ID">GBR_Standard</wd:ID>
									</wd:Tax_Rate_Reference>
									<wd:Tax_Amount> <xsl:value-of select="sum($vatLines/tax_amount)"/></wd:Tax_Amount>
									
									<wd:Tax_Recoverability_Reference>
										<wd:ID wd:type="Tax_Recoverability_Object_ID">Fully_Recoverable</wd:ID>
									</wd:Tax_Recoverability_Reference>                            
									
								</wd:Tax_Rate_Data>
							</wd:Tax_Code_Data>                 
						</xsl:if>


					</wd:Customer_Invoice_Adjustment_Data>
				</wd:Submit_Customer_Invoice_Adjustment_Request>
			</env:Body>
		</env:Envelope>
	</xsl:template>
</xsl:stylesheet>
