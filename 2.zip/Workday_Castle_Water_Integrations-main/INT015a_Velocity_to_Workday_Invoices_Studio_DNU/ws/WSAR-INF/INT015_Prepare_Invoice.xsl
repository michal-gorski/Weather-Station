<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map" xmlns:this="this.stylesheet"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc">
	<xsl:output method="xml" indent="1"/>

	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>


	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>

	<xsl:template match="root">
		<invoices>
			<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
		</invoices>
	</xsl:template>

	<xsl:template match="invoice" mode="in-memory">
		<invoice>
			<invoice_id>
				<xsl:value-of select="row[1]/Statement-ID"/>
			</invoice_id>
			<customer>
				<xsl:value-of select="row[1]/Transaction-Key"/>
			</customer>
			<invoice_date>
				<xsl:value-of select="row[1]/Statement-Date"/>
			</invoice_date>

			<lines>

				<!--<!-\-\-\->	
				<xsl:variable name="rowsWithTax">
					<line>
						<amount>
							<xsl:value-of select="Credit-Amount - Debit-Amount"/>
						</amount>
						<cost_center>
							<xsl:value-of select="$costCenter"/>
						</cost_center>
						<revenue_category><xsl:value-of select="$revenueCategory"/></revenue_category>
						
						<quantity>
							<xsl:value-of select="sum(current-group()/Transaction-Units)"/>
						</quantity>
						<description>
							<xsl:value-of select="current-group()[1]/Description"/>
						</description>
						<memo>
							<xsl:value-of select="current-group()[1]/Other-Description"/>
						</memo>
						
						
						
						
						
					</line>
					
				</xsl:variable>-->


				<!--Map the nominal account in each row using complex logic stored in function -->
				<xsl:variable name="mappedRows">
					<xsl:for-each
						select="row[Transaction-GL != 'GL_Debtors_Glob' and Transaction-GL != 'GL_TAX']">
						<row>
							<xsl:copy-of select="./*"/>
							
							
							<NominalAccount>
								<xsl:value-of
									select="this:mapNominalAccount(Transaction-GL, Transaction-Type, Wholesaler)"
								/>
							</NominalAccount>

							<xsl:variable name="transactionDebtID" select="Transaction-Debt-ID"/>


							<!-- find line with corresponding Transaction Debt ID and with Transaction-GL = GL_TAX -->
							<xsl:if
								test="../row[Transaction-GL = 'GL_TAX'][Transaction-Debt-ID = $transactionDebtID]">
								<TaxAmount>
									<xsl:value-of
										select="../row[Transaction-GL = 'GL_TAX'][Transaction-Debt-ID = $transactionDebtID][1]/Credit-Amount"
									/>
								</TaxAmount>
							</xsl:if>
						</row>
					</xsl:for-each>
				</xsl:variable>

				<xsl:copy-of select="$mappedRows"/>


				<!-- group invoice rows by nominal account, summarising the amounts on groupped rows -->

				<!--<xsl:for-each-group select="$mappedRows" group-by="NominalAccount">
					
					
					<!-\-<category>
						<xsl:value-of select="current-grouping-key()" />
						<xsl:for-each select="current-group()">
							<xsl:value-of select="name" />
							<xsl:text>, </xsl:text>
						</xsl:for-each>
					</category>-\->
				</xsl:for-each-group>-->

			</lines>
		</invoice>
	</xsl:template>

	<xsl:function name="this:mapNominalAccount" as="xs:string">
		<xsl:param name="Transaction_GL" as="xs:string?"/>
		<xsl:param name="Transaction_Type" as="xs:string?"/>
		<xsl:param name="Wholesaler" as="xs:string?"/>

		<xsl:choose>

			<!-- Portsmouth -->
			<xsl:when test="
					$Transaction_Type = ('W-ENGRET-SC', 'W-ENGRET-SC-VAT', 'W-ENGWHO-SC', 'W-ENGWHO-SC-VAT',
					'S-ENGRET-SC', 'S-ENGWHO-SC', 'S-SCORET-SC', 'S-SCOWHO-SC',
					'MAN_LKG_CHG_VAT', 'MAN_LKG_CHG_NON_VAT',
					'OPEN_INV', 'OPEN_INV_VAT', 'W-RETMINUS', 'S-RETMINUS')
					and $Wholesaler = 'OW-PORTSMOUTH-W'">
				<xsl:text>00015</xsl:text>
			</xsl:when>

			<!-- Southeast -->
			<xsl:when test="
					$Transaction_Type = ('W-ENGRET-SC', 'W-ENGRET-SC-VAT', 'W-ENGWHO-SC', 'W-ENGWHO-SC-VAT',
					'S-ENGRET-SC', 'S-ENGWHO-SC', 'S-SCORET-SC', 'S-SCOWHO-SC',
					'MAN_LKG_CHG_VAT', 'MAN_LKG_CHG_NON_VAT',
					'OPEN_INV', 'OPEN_INV_VAT', 'W-RETMINUS', 'S-RETMINUS')
					and $Wholesaler = 'OW-SOUTHEAST-W'">
				<xsl:text>00050</xsl:text>
			</xsl:when>

			<!-- Scottish -->
			<xsl:when test="
					$Transaction_Type = ('W-SCORET-SC', 'W-SCORET-SC-VAT', 'W-SCOWHO-SC', 'W-SCOWHO-SC-VAT',
					'OPEN_INV', 'OPEN_INV_VAT', 'W-RETMINUS')
					and $Wholesaler = 'OW-SCOTTISH-W'">
				<xsl:text>00010</xsl:text>
			</xsl:when>

			<!-- All other wholesalers -->
			<xsl:when test="
					$Transaction_Type = ('W-ENGRET-SC', 'W-ENGRET-SC-VAT', 'W-ENGWHO-SC', 'W-ENGWHO-SC-VAT',
					'S-ENGRET-SC', 'S-ENGWHO-SC', 'S-SCORET-SC', 'S-SCOWHO-SC',
					'MAN_LKG_CHG_VAT', 'MAN_LKG_CHG_NON_VAT',
					'OPEN_INV', 'OPEN_INV_VAT', 'W-RETMINUS', 'S-RETMINUS')
					and not($Wholesaler = ('OW-SOUTHEAST-W', 'OW-PORTSMOUTH-W', 'OW-SCOTTISH-W'))
					and string($Wholesaler) != ''">
				<xsl:text>00005</xsl:text>
			</xsl:when>

			<!-- GL = W-ENGRET-SC -->
			<xsl:when test="
					$Transaction_GL = 'W-ENGRET-SC'
					and $Transaction_Type = ('INV_ADJ_VAT', 'INV_ADJ_NONVAT')">
				<xsl:text>00005</xsl:text>
			</xsl:when>

			<!-- Special Transaction_Types -->
			<xsl:when test="
					$Transaction_Type = ('ALLOTMENT', 'TROUGH', 'CESSPOOL', 'STUDY', 'GARAGE', 'HYDRANT',
					'METER_INSTALL', 'TE_SAMPLE', 'TE_LICENCE', 'TE_CONSENT_SHORT',
					'TE_CONSENT_APPLICATION', 'METER_SIZE_MODEL', 'METER_LOC_CHG',
					'DEREG_BILATERAL', 'WATERAUDIT', 'METER_ACC_TEST',
					'METER_VERIFICATION', 'METER_REP', 'SUPPLY_VERIFICATION',
					'AMR_INSTALL', 'AMR_RENT', 'METER_DATA', 'ADHOC_READ',
					'ADMIN_FEE_VAT')">
				<xsl:text>00035</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = 'LATEPAYMENT'">
				<xsl:text>12000</xsl:text>
			</xsl:when>

			<xsl:when test="
					$Transaction_Type = ('RECONNECT', 'DCARECOV_AGENT', 'DISCONNECT_CANCEL', 'DISCON-FEE',
					'VISIT', 'DCARECOV', 'CLAMP_DAMAGE')">
				<xsl:text>23506</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = 'RECONNECT-ILLEGAL'">
				<xsl:text>23509</xsl:text>
			</xsl:when>

			<xsl:when
				test="$Transaction_Type = ('LGLRECOV', 'LGLRECOV_AGENT_VAT', 'LGL_SET_INTEREST')">
				<xsl:text>23006</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = ('CUST_DENIED_ACCESS', 'MAINT_MTR_ACCESS')">
				<xsl:text>23007</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = 'LEGAL_LBA_CHG'">
				<xsl:text>23008</xsl:text>
			</xsl:when>

			<xsl:when test="
					$Transaction_Type = ('LEGAL_IPC_CHG', 'LEGAL_JUDG_CHG', 'LEGAL_ENF_FEE',
					'LEGAL_ADD_COSTS', 'LEGAL_ICP_OOSVAT')">
				<xsl:text>23009</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = 'INT'">
				<xsl:text>12011</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_GL = 'O-GSS-WHO'">
				<xsl:text>40320</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = ('LEAKALLOW_NONVAT', 'LEAKALLOW_VAT')">
				<xsl:text>00005</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_GL = 'GL_EXGRATIA'">
				<xsl:text>00085</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_GL = 'O-GSS-RET'">
				<xsl:text>00080</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = 'O-DD-REJECTION-FEE'">
				<xsl:text>12012</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = 'DEPOSIT'">
				<xsl:text>50303</xsl:text>
			</xsl:when>

			<!-- Default -->
			<xsl:otherwise>
				<xsl:text>null</xsl:text>
			</xsl:otherwise>

		</xsl:choose>

	</xsl:function>

</xsl:stylesheet>
