<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:map="http://www.w3.org/2005/xpath-functions/map" xmlns:this="this.stylesheet"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xmlns:wd="urn:com.workday.report/INT028_Autorek_Invoices_and_Adjustments_Outbound"
    xmlns:tdf="urn:com.workday/tdf" xmlns:my="urn:csv">
    <xsl:output method="text" indent="0"/>
    <xsl:strip-space elements="*"/>

    <!-- Declare streaming mode -->
    <xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

    <xsl:template match="/">
        <xsl:text>CustomerAccountNumber,CustomerAccountName,Region,Thames Water Account Number,Sensitive Site,Key Acc Managed,Payment Method,Payment Frequency,Payment Date,Supply Name,Supply Add 1,Supply Add 2,Supply postcode,Bank Name,Bank Sortcode,Bank Acc Number,Thames Water Account,Inflight debt stage,DateOfLastTransaction,SalesName,TransactionReference,UniqueReferenceNumber,SecondReference,Usernumber,TransactionDate,DueDate,PostedDate,TaxValue,DiscountValue,Supply Add 3,Invoice Amount,Allocated Amount,AccountBalance,Outstanding Amount&#13;&#10;</xsl:text>
        <xsl:apply-templates select="./copy-of()" mode="in-memory"/>
    </xsl:template>

    <xsl:template match="wd:Report_Entry" mode="in-memory">


        <xsl:variable name="csvLine">
            <csvLine>
                <CustomerAccountNumber/>
                <CustomerAccountName>
                    <xsl:value-of
                        select="wd:Customer_group/wd:Customer_Name => replace('&amp;amp;','&amp;')"
                    />
                </CustomerAccountName>
                <Region/>
                <Thames_Water_Account_Number>
                    <xsl:choose>
                        <xsl:when test="wd:Customer_group/wd:Teip_Legacy_ID != ''">
                            <xsl:value-of select="wd:Customer_group/wd:Teip_Legacy_ID"/>
                        </xsl:when>
                        <xsl:when test="wd:Customer_group/wd:Velocity_Legacy_ID != ''">
                            <xsl:value-of select="wd:Customer_group/wd:Velocity_Legacy_ID"/>
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="wd:Customer_group/wd:Customer_ID"/>
                        </xsl:otherwise>

                    </xsl:choose>
                </Thames_Water_Account_Number>
                <Sensitive_Site/>
                <Key_Acc_Managed/>
                <Payment_Method/>
                <Payment_Frequency/>
                <Payment_Date/>
                <Supply_Name/>
                <Supply_Add_1/>
                <Supply_Add_2/>
                <Supply_postcode/>
                <Bank_Name/>
                <Bank_Sortcode/>
                <Bank_Acc_Number/>
                <Thames_Water_Account>
                    <xsl:value-of select="wd:Customer_group/wd:Customer_ID"/>
                </Thames_Water_Account>
                <Inflight_debt_stage/>
                <DateOfLastTransaction>
                    <xsl:value-of select="wd:Invoice_Date => substring(1, 10)"/>
                </DateOfLastTransaction>
                <SalesName>
                    <xsl:value-of select="wd:Transaction_Type"/>
                </SalesName>
                <TransactionReference>
                    <xsl:value-of select="wd:referenceID"/>
                </TransactionReference>
                <UniqueReferenceNumber>
                    <xsl:value-of select="wd:Short_ID/wd:ID[@wd:type = 'WID']"/>
                </UniqueReferenceNumber>
                <SecondReference>
                    <xsl:value-of select="wd:Memo => replace('&quot;', '&quot;&quot;')"/>
                </SecondReference>
                <Usernumber/>
                <TransactionDate>
                    <xsl:value-of select="wd:Invoice_Date => substring(1, 10)"/>
                </TransactionDate>
                <DueDate>
                    <xsl:value-of select="wd:Due_Date => substring(1, 10)"/>
                </DueDate>
                <PostedDate>
                    <xsl:value-of select="wd:Accounting_Date => substring(1, 10)"/>
                </PostedDate>
                <TaxValue>
                    <xsl:value-of select="wd:Tax_Amount"/>
                </TaxValue>
                <DiscountValue>0</DiscountValue>
                <Supply_Add_3/>
                <Invoice_Amount>
                    <xsl:value-of select="wd:Total_Invoice_Amount"/>
                </Invoice_Amount>
                <Allocated_Amount>0</Allocated_Amount>
                <AccountBalance><xsl:value-of select="wd:Customer_group/wd:Total_Balance"/></AccountBalance>
                <Outstanding_Amount>
                    <xsl:value-of select="wd:Total_Invoice_Amount"/>
                </Outstanding_Amount>
            </csvLine>
        </xsl:variable>



        <xsl:value-of select="my:element-to-csv-line($csvLine/csvLine)"/>
        <xsl:text>&#13;&#10;</xsl:text>

    </xsl:template>


    <xsl:function name="my:element-to-csv-line" as="xs:string">
        <xsl:param name="parentNode" as="element()"/>

        <xsl:variable name="processedFields" as="xs:string*">
            <xsl:for-each select="$parentNode/*">
                <xsl:sequence select="my:escape-csv-field(string(.))"/>
            </xsl:for-each>
        </xsl:variable>

        <xsl:value-of select="string-join($processedFields, ',')"/>
    </xsl:function>

    <xsl:function name="my:escape-csv-field" as="xs:string">
        <xsl:param name="fieldValue" as="xs:string?"/>

        <xsl:variable name="rawValue" select="
                if (exists($fieldValue)) then
                    $fieldValue
                else
                    ''"/>

        <xsl:variable name="cleanedValue" select="translate($rawValue, '&#13;&#10;', '')"/>

        <xsl:variable name="escapedQuotes" select="replace($cleanedValue, '&#34;', '&#34;&#34;')"/>
        <xsl:value-of select="concat('&#34;', $escapedQuotes, '&#34;')"/>


    </xsl:function>

</xsl:stylesheet>
