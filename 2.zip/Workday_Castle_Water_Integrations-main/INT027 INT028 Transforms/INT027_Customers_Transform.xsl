<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:map="http://www.w3.org/2005/xpath-functions/map" xmlns:this="this.stylesheet"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xmlns:wd="urn:com.workday.report/INT027_Customer_Change" xmlns:tdf="urn:com.workday/tdf">
    <xsl:output method="text" indent="0"/>
    <xsl:strip-space elements="*"/>

    <!-- Declare streaming mode -->
    <xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

    <xsl:template match="/">
        <xsl:text>Customer Account Number,Region,Thames Water Account,Thames Water Account Number,CustomerAccountName,Account Balance,Payment Method,Payment Frequency,Payment Date,Bank Name,Bank Sortcode,Bank Acc Number,Supply Add 1,Supply Add 2,Supply Add 3,Supply Postcode,Account Opened,DateOfLastTransaction&#13;&#10;</xsl:text>

        <xsl:apply-templates select="./copy-of()" mode="in-memory"/>
    </xsl:template>

    <xsl:template match="wd:Report_Entry" mode="in-memory">
        <xsl:text>,</xsl:text>
        <xsl:text>,</xsl:text>

        <xsl:value-of select="wd:Customer_ID"/>
        <xsl:text>,</xsl:text>

        <xsl:choose>
            <xsl:when test="wd:Teip_Legacy_ID != ''">
                <xsl:value-of select="wd:Teip_Legacy_ID"/>
            </xsl:when>
            <xsl:when test="wd:Velocity_Legacy_ID != ''">
                <xsl:value-of select="wd:Velocity_Legacy_ID"/>
            </xsl:when>

        </xsl:choose>
        <xsl:text>,</xsl:text>
        <xsl:value-of select="'&quot;' || wd:Customer_Name => replace('&amp;amp;','&amp;') =>replace('&quot;','&quot;&quot;') || '&quot;'"/>
    
        <xsl:text>,</xsl:text>
        <xsl:value-of select="wd:Current_Balance"/>
        <xsl:text>,</xsl:text>
        <xsl:text>,,,,,,,,,,</xsl:text>
        <xsl:value-of select="wd:Date_Opened => substring(1, 10)"/>
        <xsl:text>,</xsl:text>
        <xsl:value-of select="wd:Last_Invoice_Date => substring(1, 10)"/>

        <xsl:text>&#13;&#10;</xsl:text>

    </xsl:template>
</xsl:stylesheet>
