<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc">
	<xsl:output method="xml" indent="1"/>

	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

	<xsl:accumulator name="revCatKey" as="xs:string" initial-value="''" streamable="yes">
		<xsl:accumulator-rule match="revenueCatMap/mapValue/key/text()" select="string(.)"/>
	</xsl:accumulator>

	<xsl:accumulator name="revenueCategoryMap" as="map(xs:string,xs:string)" initial-value="map {}"
		streamable="yes">
		<xsl:accumulator-rule match="revenueCatMap/mapValue/value/text()"
			select="map:put($value, accumulator-before('revCatKey'), string(.))"/>
	</xsl:accumulator>


	<xsl:accumulator name="taxApplicabilityKey" as="xs:string" initial-value="''" streamable="yes">
		<xsl:accumulator-rule match="taxApplicabilityMap/mapValue/key/text()" select="string(.)"/>
	</xsl:accumulator>

	<xsl:accumulator name="taxApplicabilityMap" as="map(xs:string,xs:string)" initial-value="map {}"
		streamable="yes">
		<xsl:accumulator-rule match="taxApplicabilityMap/mapValue/value/text()"
			select="map:put($value, accumulator-before('taxApplicabilityKey'), string(.))"/>
	</xsl:accumulator>

	<xsl:accumulator name="taxCodeKey" as="xs:string" initial-value="''" streamable="yes">
		<xsl:accumulator-rule match="taxCodeMap/mapValue/key/text()" select="string(.)"/>
	</xsl:accumulator>

	<xsl:accumulator name="taxCodeMap" as="map(xs:string,xs:string)" initial-value="map {}"
		streamable="yes">
		<xsl:accumulator-rule match="taxCodeMap/mapValue/value/text()"
			select="map:put($value, accumulator-before('taxCodeKey'), string(.))"/>
	</xsl:accumulator>

	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>

	<xsl:template match="root">
		<invoices>
			<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
		</invoices>
	</xsl:template>

	<xsl:variable name="CREDIT_NOTE_ID" select="'5'"/>

	<xsl:template match="invoice" mode="in-memory">
		<xsl:if test="./row[1]/SYSTRADERTRANTYPE = $CREDIT_NOTE_ID and ./row[1]/COMPANY != ''">
			<invoice>

				<invoice_id>
					<xsl:value-of select="./row[1]/TRANSACTIONREFERENCE"/>
				</invoice_id>
				<customer>
					<xsl:value-of select="./row[1]/ACCOUNTNUMBER"/>
				</customer>

				<invoice_date>
					<xsl:value-of select="./row[1]/TRANSACTIONDATE => replace('/', '-')"/>
				</invoice_date>

				<accounting_date>
					<xsl:value-of select="./row[1]/POSTEDDATE => replace('/', '-')"/>
				</accounting_date>

				<due_date_override>
					<xsl:value-of select="./row[1]/DUEDATE => replace('/', '-')"/>
				</due_date_override>


				<company>
					<xsl:value-of select="./row[1]/COMPANY"/>
				</company>

				<memo>
					<xsl:value-of select="./row[1]/SECONDREFERENCE"/>
				</memo>

				<lines>
					<xsl:for-each select="./row">
						<line>
							<xsl:variable name="nominalAccount">
								<xsl:value-of
									select="replace(NOMINALANALYSISNOMINALACCOUNTNUMBER-1, '^0+', '')"
								/>
							</xsl:variable>

							<xsl:variable name="revenueCategory">
								<xsl:value-of
									select="map:get(accumulator-after('revenueCategoryMap'), $nominalAccount)"/>

							</xsl:variable>

							<xsl:variable name="taxApplicability">
								<xsl:value-of
									select="map:get(accumulator-after('taxApplicabilityMap'), $nominalAccount)"/>

							</xsl:variable>

							<xsl:variable name="taxCode">
								<xsl:value-of
									select="map:get(accumulator-after('taxCodeMap'), $nominalAccount)"/>

							</xsl:variable>

							<amount>
								<xsl:value-of
									select="xs:decimal(NOMINALANALYSISTRANSACTIONVALUE-1 => replace(',', '.'))"
								/>
							</amount>

							<xsl:variable name="taxAmount">
								<xsl:value-of select="
										xs:decimal(TAXANALYSISTAXONGOODSVALUE-1 => replace(',', '.')) +
										xs:decimal(TAXANALYSISTAXONGOODSVALUE-2 => replace(',', '.'))"
								/>
							</xsl:variable>

							<tax_amount>
								<xsl:choose>
									<xsl:when test="MIXEDSIGN = 'Y'">
										<xsl:value-of select="$taxAmount * -1"/>
									</xsl:when>
									<xsl:otherwise>
										<xsl:value-of select="$taxAmount"/>
									</xsl:otherwise>
								</xsl:choose>
							</tax_amount>

							<tax_applicability>
								<xsl:value-of select="$taxApplicability"/>
							</tax_applicability>

							<tax_code>
								<xsl:choose>
									<xsl:when test="$taxAmount = 0">GBR_Zero_Rated</xsl:when>
									<xsl:when test="$taxCode = '1'">GBR_Standard</xsl:when>
									<xsl:when test="$taxCode = '9'">GBR_Out_of_Scope</xsl:when>
									<xsl:when test="$taxCode = '12'">GBR_Zero_Rated</xsl:when>
									<xsl:when test="$taxCode = '0'">GBR_Zero_Rated</xsl:when>
									<xsl:when test="$taxCode = '2' and COMPANY = 'CWSC2'"
										>GBR_Zero_Rated</xsl:when>
									<xsl:otherwise>GBR_Standard</xsl:otherwise>
								</xsl:choose>
							</tax_code>

							<cost_center>
								<xsl:value-of select="NOMINALANALYSISNOMINALCOSTCENTRE-1"/>
							</cost_center>
							<revenue_category>
								<xsl:value-of select="$revenueCategory"/>
							</revenue_category>


							<description>
								<xsl:value-of select="SECONDREFERENCE"/>
							</description>

							<!--	<memo>
							<xsl:value-of select="Other-Description"/>
						</memo>
						-->
						</line>
					</xsl:for-each>
				</lines>
			</invoice>
		</xsl:if>
	</xsl:template>


</xsl:stylesheet>
