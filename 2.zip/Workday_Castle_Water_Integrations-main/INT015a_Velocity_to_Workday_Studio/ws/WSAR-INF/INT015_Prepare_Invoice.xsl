<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map" xmlns:this="this.stylesheet"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc"
	xmlns:etv="urn:com.workday/etv"
	xmlns:err="http://www.w3.org/2005/xqt-errors">
	<xsl:output method="xml" indent="1"/>

	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

	<xsl:accumulator name="revCatKey" as="xs:string" initial-value="''" streamable="yes">
		<xsl:accumulator-rule match="revenueCatMap/mapValue/key/text()" select="string(.)"/>
	</xsl:accumulator>

	<xsl:accumulator name="revenueCategoryMap" as="map(xs:string,xs:string)" initial-value="map {}"
		streamable="yes">
		<xsl:accumulator-rule match="revenueCatMap/mapValue/value/text()"
			select="map:put($value, accumulator-before('revCatKey'), string(.))"/>
	</xsl:accumulator>


	<xsl:accumulator name="taxApplicabilityKey" as="xs:string" initial-value="''" streamable="yes">
		<xsl:accumulator-rule match="taxApplicabilityMap/mapValue/key/text()" select="string(.)"/>
	</xsl:accumulator>

	<xsl:accumulator name="taxApplicabilityMap" as="map(xs:string,xs:string)" initial-value="map {}"
		streamable="yes">
		<xsl:accumulator-rule match="taxApplicabilityMap/mapValue/value/text()"
			select="map:put($value, accumulator-before('taxApplicabilityKey'), string(.))"/>
	</xsl:accumulator>

	<xsl:accumulator name="costCenterKey" as="xs:string" initial-value="''" streamable="yes">
		<xsl:accumulator-rule match="costCenterMap/mapValue/key/text()" select="string(.)"/>
	</xsl:accumulator>

	<xsl:accumulator name="costCenterMap" as="map(xs:string,xs:string)" initial-value="map {}"
		streamable="yes">
		<xsl:accumulator-rule match="costCenterMap/mapValue/value/text()"
			select="map:put($value, accumulator-before('costCenterKey'), string(.))"/>
	</xsl:accumulator>

	<xsl:accumulator name="taxCodeKey" as="xs:string" initial-value="''" streamable="yes">
		<xsl:accumulator-rule match="taxCodeMap/mapValue/key/text()" select="string(.)"/>
	</xsl:accumulator>

	<xsl:accumulator name="taxCodeMap" as="map(xs:string,xs:string)" initial-value="map {}"
		streamable="yes">
		<xsl:accumulator-rule match="taxCodeMap/mapValue/value/text()"
			select="map:put($value, accumulator-before('taxCodeKey'), string(.))"/>
	</xsl:accumulator>

	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>

	<xsl:template match="root">
		<invoices>
			<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
		</invoices>
	</xsl:template>

	<xsl:template match="invoice" mode="in-memory">
<xsl:try>
		<xsl:variable name="invoiceAndAdjustment">
			<invoice>
				<invoice_id>
					<xsl:value-of select="row[1]/Statement-ID"/>
				</invoice_id>
				<customer>
					<xsl:value-of select="row[1]/Transaction-Key"/>
				</customer>

				<invoice_date>
					<xsl:value-of select="row[1]/Statement-Date => replace('/', '-')"/>
				</invoice_date>

				<accounting_date>
					<xsl:value-of select="row[1]/Statement-Date => replace('/', '-')"/>
				</accounting_date>

				<company>CWL</company>

				<lines>
					
					<xsl:variable name="revCatMap" select="accumulator-after('revenueCategoryMap')"/>
					<xsl:variable name="taxApplicabilityMap"
						select="accumulator-after('taxApplicabilityMap')"/>
					<xsl:variable name="costCenterMap" select="accumulator-after('costCenterMap')"/>
					<xsl:variable name="taxCodeMap" select="accumulator-after('taxCodeMap')"/>
					
					<!--
				1. Copy the lines without change, just populate the tax from corresponding line and add the nominal account mapping
				2. group by nominal account and output final line
				-->

					<!-- Map the nominal account in each row using complex logic stored in function + populate tax from separate line -->
					<xsl:variable name="mappedRows">
						<xsl:for-each
							select="row[Transaction-GL != 'GL_DEBTORS_GLOB' 
							and Transaction-GL != 'GL_TAX' 
							and Transaction-Type != 'BALANCE_MOVED'  
							and Transaction-Type != 'BALANCE_PAYOFF' 
							and Transaction-Type != 'CSH' 
							and Transaction-Type != 'O-DD-PAYMENT' 
							and Transaction-Type != 'O-DD-REJECTION']">
							
							<row>								
								<xsl:copy-of select="./*"/>
								<xsl:variable name="nominalAccount" select="this:mapNominalAccount(Transaction-GL, Transaction-Type, Wholesaler)"/>
								<Nominal-Account>
									<xsl:value-of select="$nominalAccount"/>
								</Nominal-Account>
									
								<xsl:variable name="revenueCategory">
									<xsl:value-of select="map:get($revCatMap, $nominalAccount)"/>
								</xsl:variable>
								
								<xsl:variable name="taxApplicability">
									<xsl:value-of
										select="map:get($taxApplicabilityMap, $nominalAccount)"/>
								</xsl:variable>
								
								<xsl:variable name="costCenter">
									<xsl:value-of
										select="map:get($costCenterMap, $nominalAccount)"/>
								</xsl:variable>
								
								<xsl:variable name="taxCode">
									<xsl:value-of select="map:get($taxCodeMap, $nominalAccount)"
									/>
								</xsl:variable>
								
								<Revenue-Category><xsl:value-of select="$revenueCategory"/></Revenue-Category>
								<Tax-Code><xsl:value-of select="$taxCode"/></Tax-Code>
								<Cost-Center><xsl:value-of select="$costCenter"/></Cost-Center>
								<Tax-Applicability><xsl:value-of select="$taxApplicability"/></Tax-Applicability>

								<xsl:variable name="transactionDebtID" select="Transaction-Debt-ID"/>

								<xsl:variable name="taxAmount">
									<!-- find line with corresponding Transaction Debt ID and with Transaction-GL = GL_TAX -->
									<!-- then tax amount in credit amount field is negative, in debit amount field is positive -->
									<xsl:choose>
										<xsl:when
											test="../row[Transaction-GL = 'GL_TAX'][Transaction-Debt-ID = $transactionDebtID]">

											<xsl:value-of
												select="xs:decimal(../row[Transaction-GL = 'GL_TAX'][Transaction-Debt-ID = $transactionDebtID][1]/Debit-Amount => replace(',', '.')) - xs:decimal(../row[Transaction-GL = 'GL_TAX'][Transaction-Debt-ID = $transactionDebtID][1]/Credit-Amount => replace(',', '.'))"
											/>
										</xsl:when>
										<xsl:otherwise>0</xsl:otherwise>
									</xsl:choose>
								</xsl:variable>
								<Tax-Amount>
									<xsl:value-of select="$taxAmount"/>
								</Tax-Amount>

							</row>
						</xsl:for-each>
					</xsl:variable>
					
					<!-- group invoice rows by nominal account, summarising the amounts on groupped rows -->

					<xsl:for-each-group select="$mappedRows/row" group-by="Revenue-Category||Tax-Applicability||Tax-Code">

						<line>
							<nominal_account>
								<xsl:value-of select="Nominal-Account"/>
							</nominal_account>

							<xsl:variable name="creditAmount"
								select="sum(current-group()/xs:decimal(Credit-Amount => replace(',', '.')))"/>
							<xsl:variable name="debitAmount"
								select="sum(current-group()/xs:decimal(Debit-Amount => replace(',', '.')))"/>

							<credit_amount>
								<xsl:value-of select="$creditAmount"/>
							</credit_amount>

							<debit_amount>
								<xsl:value-of select="$debitAmount"/>
							</debit_amount>

							<amount>
								<xsl:value-of select="$debitAmount - $creditAmount"/>
							</amount>

							<xsl:variable name="taxAmount"
								select="sum(current-group()/xs:decimal(Tax-Amount => replace(',', '.')))"/>

							<tax_amount>
								<xsl:value-of select="$taxAmount"/>
							</tax_amount>
							
							<total_amount><xsl:value-of select="($debitAmount - $creditAmount) + $taxAmount"/></total_amount>

							<tax_applicability>
								<xsl:value-of select="Tax-Applicability"/>
							</tax_applicability>

							<tax_code>
								<xsl:choose>
									<xsl:when test="Tax-Code = 'GBR_Standard' and $taxAmount = 0"
										>GBR_Zero_Rated</xsl:when>

									<xsl:otherwise>
										<xsl:value-of select="Tax-Code"/>
									</xsl:otherwise>
								</xsl:choose>
							</tax_code>

							<xsl:if test="Revenue-Category != 'RVC002'">
								<cost_center>
									<xsl:value-of select="Cost-Center"/>
								</cost_center>
							</xsl:if>

							<revenue_category>
								<xsl:value-of select="Revenue-Category"/>
							</revenue_category>

							<quantity>
								<xsl:value-of select="
										sum(
										for $t in current-group()/Transaction-Units
										return
											if (normalize-space($t) != '')
											then
												xs:decimal(replace($t, ',', '.'))
											else
												0
										)"/>
							</quantity>
							<description>
								<xsl:value-of select="current-group()[1]/Description"/>
							</description>
							<memo>
								<xsl:value-of select="current-group()[1]/Other-Description"/>
							</memo>
						</line>
					</xsl:for-each-group>

				</lines>
			</invoice>
		</xsl:variable>
		
		<!-- debug-->
	

		<!-- sum all line amounts to determine invoice type -->
		<xsl:variable name="totalAmount" select="sum($invoiceAndAdjustment/invoice/lines/line/total_amount)"/>

		<!-- if total amount is positive (or zero), create invoice from all lines -->
		<xsl:if test="$totalAmount &gt;= 0">
			<invoice>

				<xsl:copy-of
					select="$invoiceAndAdjustment/invoice/child::*[local-name() != 'lines']"/>

				<lines>
					<xsl:for-each select="$invoiceAndAdjustment/invoice/lines/line">
						<xsl:copy-of select="."/>
					</xsl:for-each>
				</lines>

			</invoice>
		</xsl:if>

		<!-- if total amount is negative, create invoice adjustment from all lines -->
		<xsl:if test="$totalAmount &lt; 0">
			<invoice-adjustment>

				<xsl:copy-of
					select="$invoiceAndAdjustment/invoice/child::*[local-name() != 'lines']"/>

				<lines>
					<xsl:for-each select="$invoiceAndAdjustment/invoice/lines/line">
						<line>
							<xsl:copy-of
								select="./child::*[local-name() != 'amount' and local-name() != 'tax_amount']"/>
							<tax_amount>
								<xsl:value-of select="./tax_amount * -1"/>
							</tax_amount>
							<amount>
								<xsl:value-of select="./amount * -1"/>
							</amount>
						</line>

					</xsl:for-each>
				</lines>
			</invoice-adjustment>
		</xsl:if>
			<xsl:catch>
					<etv:message etv:severity="error"  etv:target="{row[1]/Statement-ID}">
						<xsl:value-of
							select="'XSLT error occured for invoice: ' || row[1]/Statement-ID || '; ' || $err:description || ' line: ' || $err:line-number "
						/>
						
					</etv:message>
				</xsl:catch>
</xsl:try>
	</xsl:template>

	<xsl:function name="this:mapNominalAccount" as="xs:string">
		<xsl:param name="Transaction_GL" as="xs:string?"/>
		<xsl:param name="Transaction_Type" as="xs:string?"/>
		<xsl:param name="Wholesaler" as="xs:string?"/>

		<xsl:choose>

			<!-- OTHER -->
			<xsl:when test="$Transaction_Type = 'OTHER'">
				<xsl:text>OTHER</xsl:text>
			</xsl:when>
			<!-- Portsmouth -->
			<xsl:when test="
					$Transaction_Type = ('W-ENGRET-SC', 'W-ENGRET-SC-VAT', 'W-ENGWHO-SC', 'W-ENGWHO-SC-VAT',
					'S-ENGRET-SC', 'S-ENGWHO-SC', 'S-SCORET-SC', 'S-SCOWHO-SC',
					'MAN_LKG_CHG_VAT', 'MAN_LKG_CHG_NON_VAT',
					'OPEN_INV', 'OPEN_INV_VAT', 'W-RETMINUS', 'S-RETMINUS')
					and $Wholesaler = 'OW-PORTSMOUTH-W'">
				<xsl:text>00015</xsl:text>
			</xsl:when>
			
					<!-- Southeast -->
			<xsl:when test="
					$Transaction_Type = ('W-ENGRET-SC', 'W-ENGRET-SC-VAT', 'W-ENGWHO-SC', 'W-ENGWHO-SC-VAT',
					'S-ENGRET-SC', 'S-ENGWHO-SC', 'S-SCORET-SC', 'S-SCOWHO-SC',
					'MAN_LKG_CHG_VAT', 'MAN_LKG_CHG_NON_VAT',
					'OPEN_INV', 'OPEN_INV_VAT', 'W-RETMINUS', 'S-RETMINUS')
					and $Wholesaler = 'OW-SOUTHEAST-W'">
				<xsl:text>00050</xsl:text>
			</xsl:when>

			<!-- Scottish -->
			<xsl:when test="
					$Transaction_Type = ('W-SCORET-SC', 'W-SCORET-SC-VAT', 'W-SCOWHO-SC', 'W-SCOWHO-SC-VAT',
					'OPEN_INV', 'OPEN_INV_VAT', 'W-RETMINUS')
					and $Wholesaler = 'OW-SCOTTISH-W'">
				<xsl:text>00010</xsl:text>
			</xsl:when>

			<!-- All other wholesalers -->
			<xsl:when test="
					$Transaction_Type = ('W-ENGRET-SC', 'W-ENGRET-SC-VAT', 'W-ENGWHO-SC', 'W-ENGWHO-SC-VAT',
					'S-ENGRET-SC', 'S-ENGWHO-SC', 'S-SCORET-SC', 'S-SCOWHO-SC',
					'MAN_LKG_CHG_VAT', 'MAN_LKG_CHG_NON_VAT',
					'OPEN_INV', 'OPEN_INV_VAT', 'W-RETMINUS', 'S-RETMINUS')
					and not($Wholesaler = ('OW-SOUTHEAST-W', 'OW-PORTSMOUTH-W', 'OW-SCOTTISH-W'))
					and string($Wholesaler) != ''">
				<xsl:text>00005</xsl:text>
			</xsl:when>

			<!-- GL = W-ENGRET-SC -->
			<xsl:when test="
					$Transaction_GL = 'W-ENGRET-SC'
					and $Transaction_Type = ('INV_ADJ_VAT', 'INV_ADJ_NONVAT')">
				<xsl:text>00005</xsl:text>
			</xsl:when>

			<!-- Special Transaction_Types -->
			<xsl:when test="
					$Transaction_Type = ('ALLOTMENT', 'TROUGH', 'CESSPOOL', 'STUDY', 'GARAGE', 'HYDRANT',
					'METER_INSTALL', 'TE_SAMPLE', 'TE_LICENCE', 'TE_CONSENT_SHORT',
					'TE_CONSENT_APPLICATION', 'METER_SIZE_MODEL', 'METER_LOC_CHG',
					'DEREG_BILATERAL', 'WATERAUDIT', 'METER_ACC_TEST',
					'METER_VERIFICATION', 'METER_REP', 'SUPPLY_VERIFICATION',
					'AMR_INSTALL', 'AMR_RENT', 'METER_DATA', 'ADHOC_READ',
					'ADMIN_FEE_VAT')">
				<xsl:text>00035</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = 'LATEPAYMENT'">
				<xsl:text>12000</xsl:text>
			</xsl:when>

			<xsl:when test="
					$Transaction_Type = ('RECONNECT', 'DCARECOV_AGENT', 'DISCONNECT_CANCEL', 'DISCON-FEE',
					'VISIT', 'DCARECOV', 'CLAMP_DAMAGE')">
				<xsl:text>23506</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = 'RECONNECT-ILLEGAL'">
				<xsl:text>23509</xsl:text>
			</xsl:when>

			<xsl:when
				test="$Transaction_Type = ('LGLRECOV', 'LGLRECOV_AGENT_VAT', 'LGL_SET_INTEREST')">
				<xsl:text>23006</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = ('CUST_DENIED_ACCESS', 'MAINT_MTR_ACCESS')">
				<xsl:text>23007</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = 'LEGAL_LBA_CHG'">
				<xsl:text>23008</xsl:text>
			</xsl:when>

			<xsl:when test="
					$Transaction_Type = ('LEGAL_IPC_CHG', 'LEGAL_JUDG_CHG', 'LEGAL_ENF_FEE',
					'LEGAL_ADD_COSTS', 'LEGAL_ICP_OOSVAT')">
				<xsl:text>23009</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = 'INT'">
				<xsl:text>12011</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_GL = 'O-GSS-WHO'">
				<xsl:text>40320</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = ('LEAKALLOW_NONVAT', 'LEAKALLOW_VAT')">
				<xsl:text>00005</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_GL = 'GL_EXGRATIA'">
				<xsl:text>00085</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_GL = 'O-GSS-RET'">
				<xsl:text>00080</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = 'O-DD-REJECTION-FEE'">
				<xsl:text>12012</xsl:text>
			</xsl:when>

			<xsl:when test="$Transaction_Type = 'DEPOSIT'">
				<xsl:text>50303</xsl:text>
			</xsl:when>
			
			

			<!-- Default -->
			<xsl:otherwise>
				<xsl:text>OTHER</xsl:text>
			</xsl:otherwise>

		</xsl:choose>

	</xsl:function>

</xsl:stylesheet>
