<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map" exclude-result-prefixes="#all">
	<xsl:output method="xml" indent="1"/>

	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip"/>

	<!-- Root template to process transactions -->
	<xsl:template match="Exclusions">
		<invoices>
			<!--stream iterate over all row elements -->
			<xsl:iterate select="./child::*">
				<!-- Initialize an empty map as a parameter -->
				<xsl:param name="exclusionMap" as="map(xs:string, xs:string)" select="map {}"/>

				<xsl:choose>
					<xsl:when test="local-name() = 'Exclusion'">
						<!--copy current row element to variable to ensure no streaming issues -->
						<xsl:variable name="iter" select="./copy-of()"/>


						<!--add current item to map -->
						<xsl:variable name="newExclusionMap" as="map(xs:string, xs:string)" select="
								map:put(
								$exclusionMap,
								xs:string($iter/text()),
								xs:string($iter/text()))"/>

						<!-- Pass the updated map to the next iteration -->
						<xsl:next-iteration>
							<xsl:with-param name="exclusionMap" select="$newExclusionMap"/>
						</xsl:next-iteration>

					</xsl:when>
					<xsl:when test="local-name()='invoices'"> 
						<xsl:iterate select="invoice">
							<xsl:variable name="invoice" select="copy-of(.)"/>
							<xsl:variable name="invoiceID" select="$invoice/invoice_id"/>
							<xsl:variable name="invoiceExclusion" select="map:get($exclusionMap,$invoiceID)"/>
							<xsl:if test="not(exists($invoiceExclusion))">
								<xsl:copy-of select="$invoice"/>
							</xsl:if>
						</xsl:iterate>
					</xsl:when>
				</xsl:choose>
			</xsl:iterate>
		</invoices>
	</xsl:template>


</xsl:stylesheet>
