<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:wd="urn:com.workday/bsvc">
	<xsl:output method="xml" indent="1"/>
	
	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>
	
	<xsl:accumulator name="revCatKey" as="xs:string" initial-value="''" streamable="yes">
		<xsl:accumulator-rule match="revenueCatMap/mapValue/key/text()" select="string(.)"/>
	</xsl:accumulator>
	
	<xsl:accumulator name="revenueCategoryMap" as="map(xs:string,xs:string)" initial-value="map{}" streamable="yes">
		<xsl:accumulator-rule match="revenueCatMap/mapValue/value/text()" select="map:put($value, accumulator-before('revCatKey'),string(.))"/>
	</xsl:accumulator>
	
	
	<xsl:accumulator name="taxApplicabilityKey" as="xs:string" initial-value="''" streamable="yes">
		<xsl:accumulator-rule match="taxApplicabilityMap/mapValue/key/text()" select="string(.)"/>
	</xsl:accumulator>
	
	<xsl:accumulator name="taxApplicabilityMap" as="map(xs:string,xs:string)" initial-value="map{}" streamable="yes">
		<xsl:accumulator-rule match="taxApplicabilityMap/mapValue/value/text()" select="map:put($value, accumulator-before('taxApplicabilityKey'),string(.))"/>
	</xsl:accumulator>
	
	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>
	
	<xsl:template match="root">
		<invoices>			
			<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
		</invoices>
	</xsl:template>
	
	<xsl:variable name="CREDIT_NOTE_ID" select="'5'"/>
	
	<xsl:template match="row" mode="in-memory">
		<xsl:if test="TRANSACTION_TYPE = $CREDIT_NOTE_ID">
			<invoice>
				
				<invoice_id>
					<xsl:value-of select="REFERENCE"/>
				</invoice_id>
				<customer>
					<xsl:value-of select="SAGE_ACCOUNT_NUMBER"/>
				</customer>
				<invoice_date>
					<xsl:value-of select="TRANSACTION_DATE => replace('/','-')"/>
				</invoice_date>
				
				<accounting_date>
					<xsl:value-of select="TRANSACTION_DATE => replace('/','-')"/>
				</accounting_date>
				
					<due_date_override><xsl:value-of select="DUE_DATE_OVERRIDE"/></due_date_override>
				
				
				<company><xsl:value-of select="COMPANY"/></company>
				
				<memo><xsl:value-of select="SECOND_REFERENCE"/></memo>
				
				<lines>
					
					<line>
						
						<xsl:variable name="revenueCategory">
							<xsl:value-of select="map:get(accumulator-after('revenueCategoryMap'),NOMINAL_ACCOUNT)"/>
							
						</xsl:variable>
						
						<xsl:variable name="taxApplicability">
							<xsl:value-of select="map:get(accumulator-after('taxApplicabilityMap'),NOMINAL_ACCOUNT)"/>
							
						</xsl:variable>
						
						
						<amount>
							<xsl:value-of select="NOMINAL_AMOUNT"/>
						</amount>
						<tax_amount>
							<xsl:value-of select="TAX_VALUE"/>
						</tax_amount>
						
						<tax_applicability>
							<xsl:value-of select="$taxApplicability"/>
						</tax_applicability>
						
						<tax_code>
							<xsl:choose>
								<xsl:when test="TAX_CODE = '1'">GBR_Standard</xsl:when>
								<xsl:when test="TAX_CODE = '9'">GBR_Out_of_Scope</xsl:when>
								<xsl:when test="TAX_CODE = '12'">GBR_Zero_Rated</xsl:when>
								<xsl:when test="TAX_CODE = '0'">GBR_Zero_Rated</xsl:when>
								<xsl:when test="TAX_CODE = '2' and COMPANY = 'CWSC2'">GBR_Zero_Rated</xsl:when>
								<xsl:otherwise>GBR_Standard</xsl:otherwise>
							</xsl:choose>
						</tax_code>
						
						<cost_center>
							<xsl:value-of select="NOMINAL_CC"/>
						</cost_center>
						<revenue_category><xsl:value-of select="$revenueCategory"/></revenue_category>
						
						
						<description>
							<xsl:value-of select="SECOND_REFERENCE"/>
						</description>
						<memo>
							<xsl:value-of select="Other-Description"/>
						</memo>
						
					</line>
				</lines>
			</invoice>
		</xsl:if>
	</xsl:template>
	
	
</xsl:stylesheet>
