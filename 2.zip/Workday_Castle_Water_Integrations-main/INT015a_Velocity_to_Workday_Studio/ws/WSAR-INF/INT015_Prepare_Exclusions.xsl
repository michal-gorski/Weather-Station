<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map" exclude-result-prefixes="#all">
	<xsl:output method="xml" indent="1" />

	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip"/>

	<!-- Root template to process transactions -->
	<xsl:template match="root">
		<Exclusions>
			<!--stream iterate over all row elements -->
			<xsl:iterate select="row">
				<!-- Initialize an empty map as a parameter -->
				<xsl:param name="itemMap" as="map(xs:string, xs:string)" select="map {}"/>

				<!--after all iterations output map -->
				<xsl:on-completion>
					<xsl:for-each select="map:keys($itemMap)">
						<xsl:if test="$itemMap(.) ne ''">
						<Exclusion>
							<xsl:copy-of select="."/>
						</Exclusion>
						</xsl:if>
					</xsl:for-each>
				</xsl:on-completion>

				<!--copy current row element to variable to ensure no streaming issues -->
				<xsl:variable name="iter" select="./copy-of()"/>
				
				
						<!--add current item to map -->
						<xsl:variable name="newItemMap" as="map(xs:string, xs:string)" select="
								map:put(
								$itemMap,
								xs:string($iter/Statement_Num/text()),
								xs:string($iter/Transaction_Key))"/>
					
				<!-- Pass the updated map to the next iteration -->
				<xsl:next-iteration>
					<xsl:with-param name="itemMap" select="$newItemMap"/>
				</xsl:next-iteration>
			</xsl:iterate>
		</Exclusions>
	</xsl:template>


</xsl:stylesheet>
