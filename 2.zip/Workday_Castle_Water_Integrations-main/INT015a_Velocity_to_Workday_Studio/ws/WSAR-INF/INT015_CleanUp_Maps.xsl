<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc">
	<xsl:output method="xml" indent="1"/>

	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip"/>


	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>



	<xsl:template match="wd:Integration_Maps_Data">
		<maps>
			<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
		</maps>
	</xsl:template>

	<xsl:template match="wd:Integration_Map_Provider_Reference" mode="in-memory"/>

	<xsl:template match="wd:Integration_Map_Data" mode="in-memory">
		<xsl:variable name="mapNodeName">
			<xsl:choose>
				<xsl:when test="wd:Integration_Map_Name = 'Revenue Category Map'"
					>revenueCatMap</xsl:when>
				<xsl:when test="wd:Integration_Map_Name = 'Tax Applicability Map'"
					>taxApplicabilityMap</xsl:when>
				<xsl:when test="wd:Integration_Map_Name = 'Cost Center Map'"
					>costCenterMap</xsl:when>
				<xsl:when test="wd:Integration_Map_Name = 'Tax Code Map'">taxCodeMap</xsl:when>
			</xsl:choose>
		</xsl:variable>

		<xsl:element name="{$mapNodeName}">

			<xsl:iterate select="wd:Integration_Map_Value_Data">
				<mapValue>
					<key>
						<xsl:value-of select="wd:External_Value_Data/wd:Text"/>
					</key>
					<value>
						<xsl:value-of
							select="wd:Internal_Value_Data/wd:Instance_Reference/wd:ID[last()]"/>
					</value>
				</mapValue>
			</xsl:iterate>

		</xsl:element>

	</xsl:template>


</xsl:stylesheet>
