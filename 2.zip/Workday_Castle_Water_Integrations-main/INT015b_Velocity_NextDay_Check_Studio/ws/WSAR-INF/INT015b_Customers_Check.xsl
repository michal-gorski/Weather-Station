<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc" xmlns:tdf="urn:com.workday/tdf">
	<xsl:output method="xml" indent="1"/>
	
	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>
	
	<xsl:accumulator name="customerKey" as="xs:string" initial-value="''" streamable="yes">
		<xsl:accumulator-rule match="tdf:Customer/tdf:Customer_ID/text()" select="string(.)"/>
	</xsl:accumulator>
	
	<xsl:accumulator name="customerMap" as="map(xs:string,xs:string)" initial-value="map {}"
		streamable="yes">
		<xsl:accumulator-rule match="tdf:Customer/tdf:Customer_Name/text()"
			select="map:put($value, accumulator-before('customerKey'), string(.))"/>
	</xsl:accumulator>
		
	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>
	
	
	<xsl:template match="root">
		<invoices>
			<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
		</invoices>
	</xsl:template>
	
	<xsl:template match="row" mode="in-memory">
		<xsl:variable name="WDCustomer" 
			select="map:get(accumulator-after('customerMap'), xs:string(Transaction-Key))"/>
		
		<invoice>
			<xsl:copy-of select="./child::*"/>
			<WD_Customer><xsl:value-of select="$WDCustomer"/></WD_Customer>
		</invoice>
		
	</xsl:template>
</xsl:stylesheet>