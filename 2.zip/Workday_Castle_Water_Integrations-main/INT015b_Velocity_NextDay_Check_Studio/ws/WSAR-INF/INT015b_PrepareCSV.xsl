<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:my="this.stylesheet"
    xmlns:xs="http://www.w3.org/2001/XMLSchema">
	<xsl:output method="text" indent="0"/>
	<xsl:strip-space elements="*"/>

	<!-- Declare streaming mode -->
	<xsl:mode streamable="no" on-no-match="shallow-skip" />

	<xsl:template match="invoice">
	
	  <xsl:value-of select="my:element-to-csv-line(copy-of(.))"/>
	  <xsl:text>&#13;&#10;</xsl:text>

    </xsl:template>
	
	 <xsl:function name="my:element-to-csv-line" as="xs:string">
        <xsl:param name="parentNode" as="element()"/>

        <xsl:variable name="processedFields" as="xs:string*">
            <xsl:for-each select="$parentNode/*">
                <xsl:sequence select="my:escape-csv-field(string(.))"/>
            </xsl:for-each>
        </xsl:variable>

        <xsl:value-of select="string-join($processedFields, ',')"/>
    </xsl:function>

    <xsl:function name="my:escape-csv-field" as="xs:string">
        <xsl:param name="fieldValue" as="xs:string?"/>

        <xsl:variable name="rawValue" select="
                if (exists($fieldValue)) then
                    $fieldValue
                else
                    ''"/>

        <xsl:variable name="cleanedValue" select="translate($rawValue, '&#13;&#10;', '')"/>

        <xsl:variable name="escapedQuotes" select="replace($cleanedValue, '&#34;', '&#34;&#34;')"/>
        <xsl:value-of select="concat('&#34;', $escapedQuotes, '&#34;')"/>


    </xsl:function>
	
</xsl:stylesheet>
