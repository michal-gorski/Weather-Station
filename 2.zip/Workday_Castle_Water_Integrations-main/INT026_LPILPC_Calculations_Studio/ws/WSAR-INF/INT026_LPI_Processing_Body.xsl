<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:this="this.stylesheet" xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:wd="urn:com.workday/bsvc" xmlns:tdf="urn:com.workday/tdf"
	xmlns:xf="http://www.w3.org/2005/xpath-functions" expand-text="yes">
	<xsl:output method="text" indent="1"/>

	<!-- Declare streaming mode -->
	<xsl:mode streamable="no" on-no-match="shallow-skip" use-accumulators="#all"/>

	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>

	<xsl:template match="invoice">
		<xsl:variable name="invoiceRequest" as="node()">
			<xf:array key="">
				<xsl:for-each select="newLPIEntries/LPIEntry">
					<!-- precaution for testing, max items is 100, this will not occur in real life -->
					<xsl:if test="position() &lt; 100">
						<xf:map>
							<xf:number key="c">
								<xsl:value-of select="LPIAmount"/>
							</xf:number>
							<xf:number key="lpiRate">
								<xsl:value-of select="(xs:decimal(LPIRate) * 100) => format-number('##.##')"/>
							</xf:number>
							
							<xsl:if test="../../newLPC != 0 and xs:date(date) eq xs:date(../../dueDatePlusGrace)">
								<xf:number key="mdcChargeInGbp">
									<xsl:value-of select="../../newMDC"/>
								</xf:number>
								<xf:number key="lpcChargeInGbp">
									<xsl:value-of select="../../newLPC"/>
								</xf:number>
							
							</xsl:if>
							
							<xf:string key="date">
								<xsl:value-of select="date => substring(1, 10)"/>
							</xf:string>
							<xf:map key="customerInvoice">
								<xf:string key="id">
									<xsl:value-of select="../../invoiceWID"/>
								</xf:string>
							</xf:map>
						</xf:map>
					</xsl:if>
				</xsl:for-each>
			</xf:array>
		</xsl:variable>

	



	  <xsl:value-of select="xml-to-json($invoiceRequest, map {'indent': true()})"/>
	</xsl:template>

</xsl:stylesheet>
