<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map" xmlns:this="this.stylesheet"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc"
	xmlns:tdf="urn:com.workday/tdf">

	<xsl:output method="html" indent="1"/>


	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

	<xsl:template match="/">
		<html>
			<head>
				<title>CastleWater Invoices</title>
				<style><![CDATA[
					body {
					    font-family: Arial, sans-serif;
					    background-color: #f4f9f9;
					    color: #003366;
					}
					table {
					    border-collapse: collapse;
					    width: 100%;
					    margin-top: 20px;
					}
					th,
					td {
					    border: 1px solid #003366;
					    padding: 8px;
					    text-align: left;
					}
					th {
					    background-color: #0055a5;
					    color: white;
					}
					input[type = "text"] {
					    width: 90%;
					    padding: 5px;
					    margin-bottom: 5px;
					}
					.popup {
					    display: none;
					    position: fixed;
					    top: 20%;
					    left: 30%;
					    width: 40%;
					    background-color: white;
					    border: 2px solid #003366;
					    padding: 20px;
					    z-index: 1000;
					    overflow: auto;
					    max-height: 60%;
					}
					.popup-close {
					    float: right;
					    cursor: pointer;
					    color: red;
					    font-weight: bold;
					}
					.overlay {
					    display: none;
					    position: fixed;
					    top: 0;
					    left: 0;
					    width: 100%;
					    height: 100%;
					    background-color: rgba(0, 0, 0, 0.5);
					    z-index: 999;
					}
					
					.table {
					    display: table;
					    width: 100%;
					    border-collapse: collapse;
					}
					.table-header {
					    display: table-header-group;
					    font-weight: bold;
					}
					.table-body {
					    display: table-row-group;
					}
					.table-row {
					    display: table-row;
					}
					.table-cell {
					    display: table-cell;
					    padding: 8px;
					    border: 1px solid #ccc;
					}]]>
				</style>
			</head>
			<body>
				<br/>
				<h2>CastleWater Invoice Table</h2>
				<table id="invoiceTable">
					<thead>
						<tr>
							<th>Customer ID<br/><input type="text" id="customerFilter"
									onkeyup="filterTable()" placeholder="Filter by Customer ID"
								/></th>
							<th>Invoice ID<br/><input type="text" id="invoiceFilter"
									onkeyup="filterTable()" placeholder="Filter by Invoice ID"
								/></th>
							<th>Invoice Date</th>
							
							<th>Invoice Amount</th>
							<th>Due Date</th>
							<th>Grace Reached</th>
							<th>Paused</th>
							<th>Billed LPI</th>
							<th>Balance LPI</th>
							
							<th>Billed LPC</th>
							<th>Balance LPC</th>
							
							<th>Billed MDC</th>
							<th>Balance MDC</th>
							
							<th>New LPI Entries</th>
							
							
							
							<th>Existing LPI</th>
							<th>New LPI Entries</th>
						</tr>
					</thead>
					<tbody>
						<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
					</tbody>
				</table>
				<div class="overlay" id="overlay" onclick="closeAllPopups()"/>
				<script><![CDATA[
					 function filterTable() {
			            var customerInput = document.getElementById("customerFilter").value.toUpperCase();
			            var invoiceInput = document.getElementById("invoiceFilter").value.toUpperCase();
			           			            
			            
			            var table = document.getElementById("invoiceTable");
			            var tr = table.getElementsByTagName("tr");
			            for (var i = 1; i < tr.length; i++) {
			                var tdCustomer = tr[i].getElementsByTagName("td")[0];
			                var tdInvoice = tr[i].getElementsByTagName("td")[1];
			                
			                if (tdCustomer && tdInvoice) {
			                    var customerText = tdCustomer.textContent || tdCustomer.innerText;
			                    var invoiceText = tdInvoice.textContent || tdInvoice.innerText;
			                    if (customerText.toUpperCase().indexOf(customerInput) > -1 &&
			                        invoiceText.toUpperCase().indexOf(invoiceInput) > -1) {
			                        tr[i].style.display = "";
			                    } else {
			                        tr[i].style.display = "none";
			                    }
			                }
			            }
			        }
			
			        function showPopup(id) {
			            document.getElementById(id).style.display = "block";
			            document.getElementById("overlay").style.display = "block";
			        }
			
			        function closePopup(id) {
			            document.getElementById(id).style.display = "none";
			            document.getElementById("overlay").style.display = "none";
			        }
			
			        function closeAllPopups() {
			            var popups = document.getElementsByClassName("popup");
			            for (var i = 0; i < popups.length; i++) {
			                popups[i].style.display = "none";
			            }
			            document.getElementById("overlay").style.display = "none";
			        } ]]>
				</script>
			</body>
		</html>
	</xsl:template>

	<xsl:template match="invoice" mode="in-memory">
		<tr>
			<td>
				<xsl:value-of select="customer/customerID"/>
			</td>
			<td>
				<xsl:value-of select="invoiceID"/>
			</td>
			
			<td><xsl:value-of select="invoiceDate => substring(1, 10)"/></td>
			
			<td><xsl:value-of select="invoiceAmount"/></td>
			
			<td>
				<xsl:value-of select="dueDate => substring(1, 10)"/>
			</td>
			<td>
				<xsl:value-of select="graceReached => substring(1, 10)"/>
			</td>
			<td>
				<xsl:value-of select="currentlyPaused"/>
			</td>
			<td>
				<xsl:value-of select="billedAmountLPI"/>
			</td>
			<td>
				<xsl:value-of select="chargeableBalanceLPI"/>
			</td>

			<td>
				<xsl:value-of select="billedAmountLPC"/>
			</td>
			<td>
				<xsl:value-of select="chargeableBalanceLPC"/>
			</td>
			
			<td>
				<xsl:value-of select="billedAmountMDC"/>
			</td>
			<td>
				<xsl:value-of select="chargeableBalanceMDC"/>
			</td>
			
			<td><xsl:value-of select="count(newLPIEntries/LPIEntry)"/></td>


			<td>
				<xsl:element name="button">
					<xsl:attribute name="onclick">
						<xsl:value-of select="'showPopup(''existing' || invoiceID || ''')'"/>
					</xsl:attribute>View</xsl:element>
			</td>
			<td>
				<xsl:element name="button">
					<xsl:attribute name="onclick">
						<xsl:value-of select="'showPopup(''new' || invoiceID || ''')'"/>
					</xsl:attribute>View</xsl:element>
			</td>
		</tr>
		<div class="popup">
			<xsl:attribute name="id">
				<xsl:value-of select="'existing' || invoiceID"/>
			</xsl:attribute>
			<span class="popup-close">
				<xsl:attribute name="onclick">
					<xsl:value-of select="'closePopup(''existing' || invoiceID || ''')'"/>
				</xsl:attribute>
				<xsl:text>x</xsl:text>
			</span>
			<h3>Existing LPI Invoice: 
			<xsl:value-of select="invoiceID"/>
			</h3>

			<div class="table">
				<div class="table-header">
					<div class="table-row">
						<div class="table-cell">LPI Date</div>
						<div class="table-cell">MDC Charge</div>
						<div class="table-cell">LPC Charge</div>
						<div class="table-cell">LPI Charge</div>
					</div>
				</div>
				<div class="table-body">
					<xsl:for-each select="existing_LPI/lpiEntry">
						<div class="table-row">
							<div class="table-cell">
								<xsl:value-of select="LPIDate => substring(1, 10)"/>
							</div>
							<div class="table-cell"/>
							<div class="table-cell"/>
							<div class="table-cell">
								<xsl:value-of select="dailyLPICharge"/>
							</div>
						</div>
					</xsl:for-each>
				</div>
			</div>
		</div>

		<div class="popup">
			<xsl:attribute name="id">
				<xsl:value-of select="'new' || invoiceID"/>
			</xsl:attribute>
			<span class="popup-close">
				<xsl:attribute name="onclick">
					<xsl:value-of select="'closePopup(''new' || invoiceID || ''')'"/>
				</xsl:attribute>
				<xsl:text>x</xsl:text>
			</span>
			<h3>New LPI Entries: 
				<xsl:value-of select="invoiceID"/>
			</h3>
			
			<div class="table">
				<div class="table-header">
					<div class="table-row">
						<div class="table-cell">LPI Date</div>
						<div class="table-cell">LPI Rate</div>
						<div class="table-cell">LPI Charge</div>
					</div>
				</div>
				<div class="table-body">
					<xsl:for-each select="newLPIEntries/LPIEntry">
						<div class="table-row">
							<div class="table-cell">
								<xsl:value-of select="date => substring(1, 10)"/>
							</div>
							<div class="table-cell"><xsl:value-of select="LPIRate"/></div>
							
							<div class="table-cell">
								<xsl:value-of select="LPIAmount"/>
							</div>
						</div>
					</xsl:for-each>
				</div>
			</div>
			
		</div>
	</xsl:template>
</xsl:stylesheet>
