<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:this="this.stylesheet" xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:wd="urn:com.workday/bsvc" xmlns:tdf="urn:com.workday/tdf"
	xmlns:xf="http://www.w3.org/2005/xpath-functions" expand-text="yes">
	<xsl:output method="text" indent="1"/>
	
	<!-- Declare streaming mode -->
	<xsl:mode streamable="no" on-no-match="shallow-skip" use-accumulators="#all"/>
	
	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>
	
	<xsl:template match="invoice">
		<xsl:variable name="invoiceRequest" as="node()">
			<xf:map key="">
				
				<!-- LPI balances -->
					<xf:map key="billedAmountGbp">
						<xf:string key="currency">GBP</xf:string>
						<xf:number key="value">
							<xsl:value-of select="if (normalize-space(billedAmountLPI) != '') then billedAmountLPI else 0"/>
						</xf:number>
					</xf:map>	
				
				<xf:map key="chargeableBalanceGbp">
					<xf:string key="currency">GBP</xf:string>
					<xf:number key="value">
						<xsl:value-of select="if (normalize-space(newChargeableBalanceLPI) != '') then newChargeableBalanceLPI else 0"/>
					</xf:number>
				</xf:map>	
				
				
				<!-- LPC Balances -->
				<xf:map key="billedAmountLpc">
					<xf:string key="currency">GBP</xf:string>
					<xf:number key="value">
						<xsl:value-of select="if (normalize-space(billedAmountLPC) != '') then billedAmountLPC else 0"/>
					</xf:number>
				</xf:map>	
				
				<xf:map key="chargeableBalanceLpc">
					<xf:string key="currency">GBP</xf:string>
					<xf:number key="value">
						<xsl:value-of select="if (normalize-space(newChargeableBalanceLPC) != '') then newChargeableBalanceLPC else 0"/>
					</xf:number>
				</xf:map>	
				
				<xf:boolean key="gracePeriod">
					<xsl:value-of select="not(xs:boolean(graceReached))"/>					
				</xf:boolean>
				
				
				<!-- MDC balances -->
				<xf:number key="billedAmountMdc"><xsl:value-of select="if (normalize-space(billedAmountMDC) != '') then billedAmountMDC else 0"/></xf:number>
				<xf:number key="chargeableBalanceMdc"><xsl:value-of select="if (normalize-space(newChargeableBalanceMDC) != '') then newChargeableBalanceMDC else 0"/></xf:number>
				<xf:number key="lpiAndLpcChargeDateDays">0</xf:number>
				
				
				<xf:string key="lpiAndLpcChargeDate2">
						<xsl:choose>
							<xsl:when test="exists(chargeDate) and chargeDate ne '' and xf:year-from-date(chargeDate) = 2100">								
								<xsl:value-of select="dueDatePlusGrace => substring(1,10)"/>
							</xsl:when>
							
							<xsl:when test="exists(chargeDate) and chargeDate ne ''"><xsl:value-of select="chargeDate => substring(1,10)"/></xsl:when>
							
							<xsl:otherwise><xsl:value-of select="dueDatePlusGrace => substring(1,10)"/></xsl:otherwise>
						</xsl:choose>					
							
				</xf:string>
				
				
				
				<!--  <xf:number key="lpiAndLpcChargeDateDays"><xsl:value-of select="if (normalize-space(LPILPCChargeDays) != '') then LPILPCChargeDays else 0"/></xf:number>-->
				<xf:map key="customerInvoice">
					<xf:string key="id">
						<xsl:value-of select="invoiceWID"/>
					</xf:string>
				</xf:map>
			</xf:map>
		</xsl:variable>
		
		
		
		
		
		<xsl:value-of select="xml-to-json($invoiceRequest, map {'indent': true()})"/>
	</xsl:template>
	
</xsl:stylesheet>

