<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map" xmlns:this="this.stylesheet"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc"
	xmlns:tdf="urn:com.workday/tdf">

	<xsl:output method="text" indent="no" omit-xml-declaration="yes"/>
	
	<xsl:strip-space elements="*"/>
	


	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

	<xsl:template match="/">
		<xsl:variable name="header">
			<header>
				<rowNumber>Row Number</rowNumber>
				<Invoice_ID>Invoice ID</Invoice_ID>
				<Invoice_Date>Invoice Date</Invoice_Date>
				<Due_Date>Due Date</Due_Date>
				<Paused>Paused</Paused>
				<Billed_LPI>Billed LPI</Billed_LPI>
				<Balance_LPI>Balance LPI</Balance_LPI>
				<Billed_LPC>Billed LPC</Billed_LPC>
				<Balance_LPC>Balance LPC</Balance_LPC>
				<Billed_MDC>Billed MDC</Billed_MDC>
				<Balance_MDC>Balance MDC</Balance_MDC>
				<Existing_LPI_Date>Existing LPI Date</Existing_LPI_Date>
				<Existing_MDC_Charge>Existing MDC Charge</Existing_MDC_Charge>
				<Existing_LPC_Charge>Existing LPC Charge</Existing_LPC_Charge>
				<Existing_LPI_Charge>Existing LPI Charge</Existing_LPI_Charge>
				<New_LPI_Date>New LPI Date</New_LPI_Date>
				<New_LPI_Rate>New LPI Rate</New_LPI_Rate>
				<New_LPI_Charge>New LPI Charge</New_LPI_Charge>

			</header>
		</xsl:variable>
		<xsl:value-of select="this:element-to-csv-line($header/header)"/>
		<xsl:text>&#13;&#10;</xsl:text>

		<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
	</xsl:template>

	<xsl:template match="invoice" mode="in-memory">

		<xsl:variable name="rowCount" select="
				max((
				count(existing_LPI/lpiEntry),
				count(newLPIEntries/lpiEntry)
				))"/>

		<xsl:variable name="invoice" select="."/>
		<xsl:for-each select="1 to $rowCount">
			<xsl:variable name="rowNumber" as="xs:integer" select="."/>
			<xsl:variable name="existingCount" as="xs:integer" select="count($invoice/existing_LPI/lpiEntry)"/>
			<xsl:variable name="newCount" as="xs:integer" select="count($invoice/newLPIEntries/LPIEntry)"/>
			<xsl:variable name="row">
				
				<row>
					<rowNumber>
						<xsl:value-of select="$rowNumber"/>
					</rowNumber>
					<Invoice_ID><xsl:value-of select="$invoice/invoiceID"/></Invoice_ID>
					<Invoice_Date><xsl:value-of select="$invoice/invoiceDate => substring(1,10)"/></Invoice_Date>
					<Due_Date><xsl:value-of select="$invoice/dueDate => substring(1,10)"/></Due_Date>
					<Paused><xsl:value-of select="$invoice/currentlyPaused"/></Paused>
					<Billed_LPI><xsl:value-of select="$invoice/billedAmountLPI"/></Billed_LPI>
					<Balance_LPI><xsl:value-of select="$invoice/chargeableBalanceLPI"/></Balance_LPI>
					<Billed_LPC><xsl:value-of select="$invoice/billedAmountLPC"/></Billed_LPC>
					<Balance_LPC><xsl:value-of select="$invoice/chargeableBalanceLPC"/></Balance_LPC>
					<Billed_MDC><xsl:value-of select="$invoice/billedAmountMDC"/></Billed_MDC>
					<Balance_MDC><xsl:value-of select="$invoice/chargeableBalanceMDC"/></Balance_MDC>
					<xsl:choose>
					<xsl:when test="$rowNumber &lt;= $existingCount">
						<Existing_LPI_Date><xsl:value-of select="$invoice/existing_LPI/lpiEntry[$rowNumber]/LPIDate => substring(1,10)"/></Existing_LPI_Date>
						<Existing_MDC_Charge><xsl:value-of select="$invoice/existing_LPI/lpiEntry[$rowNumber]/mdcCharge"/></Existing_MDC_Charge>
						<Existing_LPC_Charge><xsl:value-of select="$invoice/existing_LPI/lpiEntry[$rowNumber]/LPCCharge"/></Existing_LPC_Charge>
						<Existing_LPI_Charge><xsl:value-of select="$invoice/existing_LPI/lpiEntry[$rowNumber]/dailyLPICharge"/></Existing_LPI_Charge>
					</xsl:when>
						<xsl:otherwise><Existing_LPI_Date></Existing_LPI_Date>
							<Existing_MDC_Charge></Existing_MDC_Charge>
							<Existing_LPC_Charge></Existing_LPC_Charge>
							<Existing_LPI_Charge></Existing_LPI_Charge></xsl:otherwise>
					</xsl:choose>
					<xsl:choose>
					<xsl:when test="$rowNumber &lt;= $newCount">
						<New_LPI_Date><xsl:value-of select="$invoice/newLPIEntries/LPIEntry[$rowNumber]/date => substring(1,10)"/></New_LPI_Date>
						<New_LPI_Rate><xsl:value-of select="$invoice/newLPIEntries/LPIEntry[$rowNumber]/LPIRate"/></New_LPI_Rate>
						<New_LPI_Charge><xsl:value-of select="$invoice/newLPIEntries/LPIEntry[$rowNumber]/LPIAmount"/></New_LPI_Charge>
					</xsl:when>
						<xsl:otherwise><New_LPI_Date></New_LPI_Date>
							<New_LPI_Rate></New_LPI_Rate>
							<New_LPI_Charge></New_LPI_Charge></xsl:otherwise>
					</xsl:choose>
				</row>
			</xsl:variable>
			<xsl:value-of select="this:element-to-csv-line($row/row)"/>
			<xsl:text>&#13;&#10;</xsl:text>
		</xsl:for-each>


		
	</xsl:template>



	<xsl:function name="this:element-to-csv-line" as="xs:string">
		<xsl:param name="parentNode" as="element()"/>

		<xsl:variable name="processedFields" as="xs:string*">
			<xsl:for-each select="$parentNode/*">
				<xsl:sequence select="this:escape-csv-field(string(.))"/>
			</xsl:for-each>
		</xsl:variable>

		<xsl:value-of select="string-join($processedFields, ',')"/>
	</xsl:function>

	<xsl:function name="this:escape-csv-field" as="xs:string">
		<xsl:param name="fieldValue" as="xs:string?"/>

		<xsl:variable name="rawValue" select="
				if (exists($fieldValue)) then
					$fieldValue
				else
					''"/>

		<xsl:variable name="cleanedValue" select="translate($rawValue, '&#13;&#10;', '')"/>

		<xsl:variable name="escapedQuotes" select="replace($cleanedValue, '&#34;', '&#34;&#34;')"/>
		<xsl:value-of select="concat('&#34;', $escapedQuotes, '&#34;')"/>


	</xsl:function>
</xsl:stylesheet>
