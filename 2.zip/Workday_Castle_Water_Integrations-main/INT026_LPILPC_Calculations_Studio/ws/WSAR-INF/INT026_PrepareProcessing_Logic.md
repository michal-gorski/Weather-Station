# INT026_PrepareProcessing.xsl — Logic Description

## Purpose

This stylesheet is the **preparation stage** of the INT026 LPI/LPC/MDC calculation pipeline.
It receives a stream of `tdf:LPI_Invoice` records from Workday and, for each invoice, computes
all intermediate values needed by the downstream calculation step:

- date arithmetic (grace period, effective grace end date)
- pause / suspension detection
- LPI interest accrual entries (one per chargeable day not yet processed)
- LPC and MDC one-time charge amounts
- updated chargeable balances for LPI, LPC, and MDC

The output is a `<preparedInvoices>` XML document containing one `<invoice>` element per valid
input invoice.

---

## Stylesheet Parameters

| Parameter | Default | Purpose |
|---|---|---|
| `INT026_Grace_Days` | `33` | Number of calendar days after the due date before LPI/LPC charging is confirmed |
| `INT026_BoE_Rate` | *(required)* | Bank of England base rate (percentage, e.g. `5.25`) |
| `INT026_Standard_Offset` | *(required)* | Default spread added to BoE rate for customers without a specific offset |
| `INT026_MDC_Amount` | *(required)* | Fixed Meter Data Collection charge amount (£) |
| `INT026_LPC_Statutory_1/2/3` | *(required)* | Statutory LPC charge for balance bands 1, 2, 3 |
| `INT026_LPC_Standard_1/2/3` | *(required)* | Standard LPC charge for balance bands 1, 2, 3 |

---

## Streaming Architecture

The stylesheet declares `streamable="yes"` on its default mode, which allows it to process large
Workday report payloads without buffering the whole document in memory.

Because streaming does not permit re-reading nodes, the root template materialises each
`tdf:LPI_Invoice` into an in-memory copy via `copy-of()` before applying the `in-memory` mode
template. All computation then happens in memory on that single invoice node.

---

## Per-Invoice Processing (`tdf:LPI_Invoice` template, mode `in-memory`)

### 1. Due Date Validation

The first action is to verify that `tdf:Due_Date` is castable to `xs:date`.

- **Valid** → an `<invoice>` element is produced and all subsequent logic runs.
- **Invalid** → an `etv:severity="ERROR"` message is emitted with the invoice ID and the raw
  field value; no `<invoice>` element is written.

---

### 2. Basic Invoice Fields Copied to Output

The following fields are passed through unchanged:

| Output element | Source field |
|---|---|
| `<invoiceWID>` | `tdf:Invoice_WID` |
| `<invoiceID>` | `tdf:Invoice_ID` |
| `<invoiceDate>` | `tdf:Invoice_Date` |
| `<invoiceAmount>` | `tdf:Invoice_Amount` |

---

### 3. Current Pause Detection (`$currentlyPaused`)

A boolean flag is set to `true` if **any** of three conditions is met:

1. A customer-level `tdf:LPI_Pause` record exists whose `To_Date` is **on or after today**.
2. An invoice-level `tdf:LPI_Pause_Invoice` record exists whose `To_Date` is **on or after today**.
3. The customer node contains a `tdf:Credit_Suspension_Expiry` that is **on or after today**.

In all comparisons, `adjust-date-to-timezone(..., ())` strips any timezone offset from the stored
date so that comparisons are made consistently against a no-timezone `current-date()`.

The result is written to the `<currentlyPaused>` output element. Downstream stylesheets use this
flag to suppress daily LPI accrual on the current day.

---

### 4. Customer Attributes Copied to Output

The `<customer>` block copies:

| Output element | Source |
|---|---|
| `<customerID>` | `tdf:Customer_ID` |
| `<customerUseStatutoryRate>` | `tdf:Customer/tdf:Statutory_Rate` |
| `<customerMDCFlagOff>` | `tdf:Customer/tdf:MDC_Flag_Off` |
| `<specificOffset>` | `tdf:Customer/tdf:Specific_Offset` |

---

### 5. Grace Period Date Arithmetic

Three date variables are computed from `tdf:Due_Date`:

| Variable | Value |
|---|---|
| `$dueDate` | The due date cast to `xs:date` |
| `$dueDatePlusGrace` | `$dueDate + INT026_Grace_Days` days (base grace end date) |
| `$dueDatePlusDay` | `$dueDate + 1 day` (the first day on which LPI can accrue) |

---

### 6. Pause Days Within the Grace Window

If any pause overlapped the grace window `[$dueDate, $dueDatePlusGrace]`, the effective grace end
date is extended by the number of days paused during that window. Three sources are evaluated
independently:

#### `$pauseDaysCustomer`
Iterates over every `tdf:Customer/tdf:LPI_Pause` record that has valid `From_Date` and `To_Date`
fields. For each record the overlap with the grace window is:

```
overlap_start = max(pause.From_Date, $dueDate)
overlap_end   = min(pause.To_Date,   $dueDatePlusGrace)
overlap_days  = if overlap_start ≤ overlap_end
                then (overlap_end − overlap_start) + 1
                else 0
```

The results are summed across all customer pauses.

#### `$pauseDaysInvoice`
Identical logic but iterates over `tdf:Customer_Invoice/tdf:LPI_Pause_Invoice` records.

#### `$creditSuspensionTo` / `$pauseDaysSuspension`
`$creditSuspensionTo` resolves to the `tdf:Credit_Suspension_Expiry` date (timezone-stripped) if
the field is castable, otherwise to an empty sequence.

`$pauseDaysSuspension` is the number of days from `$dueDate` to
`min($creditSuspensionTo, $dueDatePlusGrace)` inclusive, or 0 if there is no suspension or it does
not reach the due date. The credit suspension has no stored start date; the calculation assumes the
suspension began at or before the due date.

#### `$pauseDaysInGrace`
`max($pauseDaysCustomer, $pauseDaysInvoice, $pauseDaysSuspension)`

The `max` (rather than `sum`) is used because the three pause sources may represent overlapping
real-world intervals; taking the maximum avoids double-counting.

#### `$effectiveDueDatePlusGrace`
`$dueDatePlusGrace + $pauseDaysInGrace days`

This is the actual grace deadline used in all subsequent logic.

Output elements written: `<pauseDaysInGrace>`, `<dueDate>`, `<dueDatePlusGrace>` (effective),
`<chargeDate>`.

---

### 7. Grace Reached Flag (`$graceReached`)

```
$graceReached = current-date() >= $effectiveDueDatePlusGrace
```

`true` means the invoice has passed its full grace period (including any pause extension) and is
eligible for confirmed LPI/LPC/MDC charging. When `false`, LPI entries are still generated but
LPC and MDC are suppressed, and chargeable balances for a fully-paid invoice are forced to zero.

Written to `<graceReached>`.

---

### 8. Existing Processing Data Passed Through

The following existing Workday data is copied unchanged so downstream stylesheets have the full
picture:

- `<existing_LPI>` — each `tdf:LPI_LPC_Processing` row, with `LPIDate`, `mdcCharge`,
  `dailyLPICharge`, `LPCCharge`.
- `<billedAmountLPI>`, `<chargeableBalanceLPI>`
- `<billedAmountLPC>`, `<chargeableBalanceLPC>`
- `<billedAmountMDC>`, `<chargeableBalanceMDC>`

---

### 9. Amount Calculations

#### `$amountPaid`
```
amountPaid = Invoice_Amount − Amount_Due
```
`Amount_Due` is treated as 0 if the field is absent or blank (`$safeAmountDue` guard).

#### `$LPIAmount`
Sum of `tdf:Line_Amount` across all invoice lines where `tdf:LPI_Eligible = '1'`. Lines such as
VAT or credit notes that are not flagged eligible are excluded from the interest base.

#### `$LPIAmountDue`
```
LPIAmountDue = round(max(LPIAmount − amountPaid, 0) × 100) ÷ 100
```
The `max(..., 0)` floor prevents a negative base when payment exceeds the eligible portion. The
`× 100 / ÷ 100` pattern rounds to exactly 2 decimal places using integer arithmetic to avoid
floating-point drift.

Output elements written: `<Paid_Amount>`, `<LPI_Amount_Due>`, `<invoiceLines>`.

---

### 10. Interest Rate Offset (`$offset`)

If the customer node carries a `tdf:Specific_Offset` that is castable to `xs:decimal`, that value
is used. Otherwise the stylesheet parameter `INT026_Standard_Offset` applies. The offset is added
to the BoE base rate to produce the annual LPI rate.

---

### 11. Daily LPI Entry Generation (`$newLPIEntries`)

A set of new LPI entries is produced for every calendar day from `$dueDatePlusDay` (due date + 1)
up to **yesterday** (the day before `current-date()`), inclusive.

**Deduplication**: dates already present in `tdf:LPI_LPC_Processing/tdf:LPI_Date` are skipped
using a pre-built sequence `$existingDates`. Timezone is stripped from stored dates for consistent
comparison.

For each new date that passes the deduplication check:

```
dailyLPIRate = (INT026_BoE_Rate + $offset) × 0.01 ÷ daysInYear(date)
dailyLPICharge = dailyLPIRate × LPIAmountDue
```

`daysInYear` returns 366 for leap years, 365 otherwise (see helper function below), ensuring the
daily rate is proportionally correct across year boundaries.

Each entry is written as an `<LPIEntry>` with child elements `<date>`, `<LPIRate>` (4 d.p.),
`<LPIAmount>` (2 d.p.).

---

### 12. LPC (Late Payment Charge) Calculation

LPC is a **one-time** flat charge per invoice, not a daily accrual.

#### Guard conditions — LPC is forced to 0 when **any** of:
- `$LPC_MDC_Already_Calculated` is `true` (an existing `LPI_LPC_Processing` row already has
  `LPC_Charge_GBP > 0`, meaning the charge was posted in a previous run).
- `$LPIAmountDue <= 0` (no outstanding eligible balance).
- `not($graceReached)` (the grace period has not yet fully elapsed).

#### Band determination (`this:lpc-band`)
| Band | Outstanding balance |
|---|---|
| 1 | < £1,000 |
| 2 | £1,000 – £9,999.99 |
| 3 | ≥ £10,000 |

#### Tariff look-up (`this:lpc-amount`)
If `tdf:Customer/tdf:Statutory_Rate` normalises to `"true"` or `"1"`, the statutory tariff
parameters (`INT026_LPC_Statutory_1/2/3`) are used. Otherwise the standard tariff parameters
(`INT026_LPC_Standard_1/2/3`) apply. The band integer is used as a sequence index.

Output element: `<newLPC>`.

---

### 13. MDC (Meter Data Collection) Charge Calculation

MDC is also a **one-time** charge per invoice.

Guard conditions — MDC is 0 when **any** of:
- Same combined guard as LPC (`$LPC_MDC_Already_Calculated or $LPIAmountDue <= 0 or not($graceReached)`).
- `tdf:Customer/tdf:MDC_Flag_Off = "1"` (MDC charging is disabled for this customer).

Otherwise the fixed `INT026_MDC_Amount` parameter is returned.

Output element: `<newMDC>`.

---

### 14. New Chargeable Balances

Three running balances are updated: `<newChargeableBalanceLPI>`, `<newChargeableBalanceLPC>`,
`<newChargeableBalanceMDC>`.

**Special case — paid during grace period**: if `$LPIAmountDue <= 0` **and**
`$graceReached = false()` (invoice fully paid before the grace deadline), all three balances are
forced to `0`. This prevents provisional LPI entries that were calculated speculatively from being
carried forward.

**Otherwise**:

```
newChargeableBalanceLPI = oldChargeableBalanceLPI + sum(new LPIEntry amounts)   [2 d.p.]
newChargeableBalanceLPC = oldChargeableBalanceLPC + newLPC                      [3 d.p.]
newChargeableBalanceMDC = oldChargeableBalanceMDC + newMDC                      [3 d.p.]
```

Old balances default to `0` when the source field is absent or non-numeric.

---

## Helper Functions

### `this:daysInYear(date) → xs:integer`

Returns `366` if the year of the supplied date is a leap year, `365` otherwise.

Leap year rule: `(year mod 4 = 0 and year mod 100 ≠ 0) or (year mod 400 = 0)`.

Used as the denominator when converting the annual LPI rate to a daily rate.

---

### `this:lpc-band(amount) → xs:integer`

Maps an outstanding balance to a tariff band integer (1, 2, or 3). See §12 above.

---

### `this:lpc-amount(band, statutory) → xs:decimal`

Selects the correct LPC tariff amount from the stylesheet parameters using the band integer as a
sequence index. Returns the statutory tariff when `statutory = true()`, standard otherwise.

---

### `this:mdc-amount(mdcFlagOff, alreadyCalculated) → xs:decimal`

Returns `0` if `alreadyCalculated` is `true` or if `mdcFlagOff = "1"`. Otherwise returns
`INT026_MDC_Amount`.

---

## Output Structure Summary

```xml
<preparedInvoices>
  <invoice>                          <!-- one per valid input invoice -->
    <invoiceWID/>
    <invoiceID/>
    <invoiceDate/>
    <invoiceAmount/>
    <currentlyPaused/>               <!-- boolean: is charging paused today -->
    <customer>
      <customerID/>
      <customerUseStatutoryRate/>
      <customerMDCFlagOff/>
      <specificOffset/>
    </customer>
    <pauseDaysInGrace/>              <!-- integer: pause days counted inside grace window -->
    <dueDate/>
    <dueDatePlusGrace/>              <!-- effective grace end date (extended by pauses) -->
    <chargeDate/>
    <graceReached/>                  <!-- boolean: grace period fully elapsed -->
    <existing_LPI>
      <lpiEntry>…</lpiEntry>         <!-- existing processed rows from Workday -->
    </existing_LPI>
    <billedAmountLPI/>
    <chargeableBalanceLPI/>
    <billedAmountLPC/>
    <chargeableBalanceLPC/>
    <billedAmountMDC/>
    <chargeableBalanceMDC/>
    <Paid_Amount/>
    <LPI_Amount_Due/>
    <invoiceLines>
      <invoiceLine>…</invoiceLine>
    </invoiceLines>
    <newLPIEntries>
      <LPIEntry>                     <!-- one per new chargeable day -->
        <date/>
        <LPIRate/>
        <LPIAmount/>
      </LPIEntry>
    </newLPIEntries>
    <newLPC/>
    <newMDC/>
    <newChargeableBalanceLPI/>
    <newChargeableBalanceLPC/>
    <newChargeableBalanceMDC/>
  </invoice>
</preparedInvoices>
```
