<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map" xmlns:this="this.stylesheet"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc"
	xmlns:tdf="urn:com.workday/tdf" xmlns:etv="urn:com.workday/etv">
	<xsl:output method="xml" indent="1"/>
	<xsl:param name="INT026_Grace_Days"/>
	<xsl:param name="INT026_BoE_Rate" />
	<xsl:param name="INT026_Standard_Offset" />
	<xsl:param name="INT026_MDC_Amount" />

	<xsl:param name="INT026_LPC_Statutory_1" />
	<xsl:param name="INT026_LPC_Statutory_2"/>
	<xsl:param name="INT026_LPC_Statutory_3"/>

	<xsl:param name="INT026_LPC_Standard_1"/>
	<xsl:param name="INT026_LPC_Standard_2"/>
	<xsl:param name="INT026_LPC_Standard_3"/>
	
	<xsl:param name="INT026_Golive_Cutoff_Date" />

	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip" use-accumulators="#all"/>

	<xsl:template match="tdf:LPI_Invoices">
		<preparedInvoices>
			<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
		</preparedInvoices>
	</xsl:template>

	<xsl:template match="tdf:LPI_Invoice" mode="in-memory">

		<!-- Check castability to xs:date -->
		<xsl:variable name="dueDateOk" as="xs:boolean" select="tdf:Due_Date castable as xs:date"/>

		<xsl:choose>
			<xsl:when test="$dueDateOk">
				<invoice>

					<!-- copy invoice info to output -->
					<invoiceWID>
						<xsl:value-of select="tdf:Invoice_WID"/>
					</invoiceWID>
					<invoiceID>
						<xsl:value-of select="tdf:Invoice_ID"/>
					</invoiceID>
					<invoiceDate>
						<xsl:value-of select="tdf:Invoice_Date"/>
					</invoiceDate>

					<invoiceAmount>
						<xsl:value-of select="tdf:Invoice_Amount"/>
					</invoiceAmount>

					<!--
						Determine whether LPI/LPC charging is currently paused for this invoice.
						Three independent conditions each suppress charges when true:
						  1. A customer-level pause record whose To_Date has not yet elapsed.
						  2. An invoice-level pause record whose To_Date has not yet elapsed.
						  3. The customer has an active credit suspension (Credit_Suspension_Expiry >= today).
						adjust-date-to-timezone(..., ()) strips any embedded timezone offset so that
						the xs:date comparisons are always made against a no-timezone current-date().
					-->
					<xsl:variable name="currentlyPaused" as="xs:boolean">
						<xsl:value-of select="
								exists(tdf:Customer/tdf:LPI_Pause[
								adjust-date-to-timezone(xs:date(tdf:To_Date), ()) >= current-date()
								])
								or
								exists(tdf:Customer_Invoice/tdf:LPI_Pause_Invoice[
								adjust-date-to-timezone(xs:date(tdf:To_Date), ()) >= current-date()
								])
								or
								exists(tdf:Customer[
								adjust-date-to-timezone(xs:date(tdf:Credit_Suspension_Expiry), ()) >= current-date()
								])
								"/>
					</xsl:variable>

					<currentlyPaused>
						<xsl:value-of select="$currentlyPaused"/>
					</currentlyPaused>

					<!-- copy customer info to output -->
					<customer>
						<customerID>
							<xsl:value-of select="tdf:Customer_ID"/>
						</customerID>
						<customerUseStatutoryRate>
							<xsl:value-of select="tdf:Customer/tdf:Statutory_Rate"/>
						</customerUseStatutoryRate>
						<customerMDCFlag>
							<xsl:value-of select="tdf:Customer/tdf:MDC_Flag"/>
						</customerMDCFlag>
						<specificOffset>
							<xsl:value-of select="tdf:Customer/tdf:Specific_Offset"/>
						</specificOffset>
					</customer>

					
					
					<!-- LPI calculation should start 33 days after due date. We calculate LPI nevertheless, but until 33 days is reached it's provisional only -->
					<xsl:variable name="dueDatePlusGrace" as="xs:date">
						<xsl:value-of
							select="xs:date(tdf:Due_Date) + xs:dayTimeDuration('P' || $INT026_Grace_Days || 'D')"
						/>
					</xsl:variable>

					<xsl:variable name="dueDate" as="xs:date">
						<xsl:value-of select="xs:date(tdf:Due_Date)"/>
					</xsl:variable>

					<xsl:variable name="dueDatePlusDay" as="xs:date">
						<xsl:value-of select="$dueDate + xs:dayTimeDuration('P1D')"/>
					</xsl:variable>

									
					<dueDate>
						<xsl:value-of select="$dueDate"/>
					</dueDate>

					<dueDatePlusGrace>
						<xsl:value-of select="$dueDatePlusGrace"/>
					</dueDatePlusGrace>

					<chargeDate>
						<xsl:value-of select="tdf:Customer_Invoice/tdf:LPI_LPC_Charge_Date"/>
					</chargeDate>

					<!--
						True when today has reached or passed the due date + grace period,
						meaning the invoice is eligible for confirmed (non-provisional) LPI/LPC charging.
					-->
					<xsl:variable name="graceReached" as="xs:boolean"
						select="current-date() &gt;= $dueDatePlusGrace"/>

					<graceReached>
						<xsl:value-of select="$graceReached"/>
					</graceReached>

					<!-- copy to output existing data -->
					<existing_LPI>
						<xsl:for-each select="tdf:Customer_Invoice/tdf:LPI_LPC_Processing">
							<lpiEntry>
								<LPIDate>
									<xsl:value-of select="./tdf:LPI_Date"/>
								</LPIDate>
								<mdcCharge>
									<xsl:value-of select="./tdf:MDC_Charge_GBP"/>
								</mdcCharge>
								<dailyLPICharge>
									<xsl:value-of select="tdf:Daily_LPI_Charge_GBP"/>
								</dailyLPICharge>
								<LPCCharge>
									<xsl:value-of select="tdf:LPC_Charge_GBP"/>
								</LPCCharge>
							</lpiEntry>
						</xsl:for-each>
					</existing_LPI>

					<billedAmountLPI>
						<xsl:value-of select="tdf:Customer_Invoice/tdf:Billed_Amount_LPI"/>
					</billedAmountLPI>

					<chargeableBalanceLPI>
						<xsl:value-of select="tdf:Customer_Invoice/tdf:Chargeable_Balance_LPI"/>
					</chargeableBalanceLPI>

					<billedAmountLPC>
						<xsl:value-of select="tdf:Customer_Invoice/tdf:Billed_Amount_LPC"/>
					</billedAmountLPC>

					<chargeableBalanceLPC>
						<xsl:value-of select="tdf:Customer_Invoice/tdf:Chargeable_Balance_LPC"/>
					</chargeableBalanceLPC>

					<billedAmountMDC>
						<xsl:value-of select="tdf:Customer_Invoice/tdf:Billed_Amount_MDC"/>
					</billedAmountMDC>

					<chargeableBalanceMDC>
						<xsl:value-of select="tdf:Customer_Invoice/tdf:Chargeable_Balance_MDC"/>
					</chargeableBalanceMDC>


					<!-- for each day between due date and yesterday -->
					<xsl:variable name="customerInvoice" select="./tdf:Customer_Invoice"/>
					<xsl:variable name="customerSpecificOffset"
						select="tdf:Customer/tdf:Specific_Offset"/>
					
					

					<!-- Amount already paid = Invoice_Amount minus the remaining Amount_Due. -->
					<xsl:variable name="safeAmountDue" as="xs:decimal" 
						select="if (tdf:Amount_Due and normalize-space(tdf:Amount_Due) != '') 
						then xs:decimal(tdf:Amount_Due) 
						else 0"/>
					
					<xsl:variable name="amountPaid" as="xs:decimal"
						select="xs:decimal(tdf:Invoice_Amount) - $safeAmountDue"/>
					
					<!--
						Sum only lines flagged as LPI-eligible (LPI_Eligible = '1').
						Non-eligible line types (e.g. VAT, credit notes) are excluded from the interest base.
					-->
					<xsl:variable name="LPIAmount"
						select="xs:decimal(sum(tdf:Invoice_Lines[tdf:LPI_Eligible = '1']/tdf:Line_Amount))"
						as="xs:decimal"/>

					<!--
						LPIAmountDue = eligible amount minus what has already been paid, floored at 0
						(max prevents a negative base when a partial payment covers more than the eligible portion).
						The * 100 / div 100 pattern rounds to exactly 2 decimal places using integer arithmetic
						to avoid floating-point drift before multiplying by the daily rate.
					-->
					<xsl:variable name="LPIAmountDue"
						select="round(max((xs:decimal($LPIAmount - $amountPaid), 0)) * 100) div 100"
						as="xs:decimal"/>



					<Paid_Amount>
						<xsl:value-of select="$amountPaid"/>
					</Paid_Amount>

					<LPI_Amount_Due>
						<xsl:value-of select="$LPIAmountDue"/>
					</LPI_Amount_Due>

					<invoiceLines>
						<xsl:for-each select="tdf:Invoice_Lines">
							<invoiceLine>
								<amount>
									<xsl:value-of select="tdf:Line_Amount"/>
								</amount>
								<revenueCategory>
									<xsl:value-of select="tdf:Revenue_Category/@tdf:Descriptor"/>
								</revenueCategory>
							</invoiceLine>
						</xsl:for-each>

					</invoiceLines>

					<!--
						Use customer-specific offset when one is defined (castable as xs:decimal),
						otherwise fall back to the stylesheet parameter INT026_Standard_Offset.
						The offset is added to the BoE base rate before computing the daily LPI rate.
					-->

					<xsl:variable name="offset" as="xs:decimal" select="
							if ($customerSpecificOffset castable as xs:decimal)
							then
								xs:decimal($customerSpecificOffset)
							else
								$INT026_Standard_Offset
							"/>


					<!--
						LPC and MDC are one-time charges per invoice, not daily.
						If any existing LPI_LPC_Processing row already carries a non-zero LPC_Charge_GBP,
						the charges have already been applied and must not be duplicated.
					-->
					<xsl:variable name="LPC_MDC_Already_Calculated" as="xs:boolean">
						<xsl:value-of
							select="exists($customerInvoice/tdf:LPI_LPC_Processing[tdf:LPC_Charge_GBP &gt; 0])"
						/>
					</xsl:variable>

					<xsl:variable name="newLPIEntries">
						<newLPIEntries>

							<!--
								Build a sequence of already-processed dates so that the inner loop can
								skip them with a simple sequence-membership test ($existingDates = $candidateDate).
								The ! operator pipes each node through normalize-space -> xs:date -> strip-timezone,
								ensuring apples-to-apples comparison with candidate dates below.
							-->
							<xsl:variable name="existingDates" as="xs:date*" select="
									$customerInvoice/tdf:LPI_LPC_Processing/tdf:LPI_Date
									! xs:date(normalize-space(.))
									! adjust-date-to-timezone(., ())
									"/>

							<!--
								Generate one xs:date per day from dueDatePlusDay (due date + 1 day) up to
								yesterday (current-date() is today, so the range ends before today).
								days-from-duration(current-date() - $dueDatePlusDay) gives the total count;
								the for expression produces an integer sequence 0..N and each value is
								added as a dayTimeDuration to the start date to yield the actual date.
							-->
							<xsl:for-each select="
									for $i in 0 to days-from-duration(current-date() - $dueDatePlusDay)
									
									return
										$dueDatePlusDay + ($i * xs:dayTimeDuration('P1D'))">


								<xsl:variable name="candidateDate"
									select="adjust-date-to-timezone(., ())"/>


								<!-- check if entry not already exists in LPI Processing of invoice -->
								<xsl:if test="not($existingDates = $candidateDate)">
									
									<!-- check if date not before golive date -->
									<xsl:if test="$candidateDate ge xs:date($INT026_Golive_Cutoff_Date)">
									
									<xsl:variable name="daysInYear" select="this:daysInYear(.)"
										as="xs:integer"/>
									<LPIEntry>
										<date>
											<xsl:value-of select="."/>
										</date>
										<!--
											Annual LPI rate = (Bank of England base rate + spread offset) expressed as a
											decimal fraction (e.g. 5.5% -> 0.055). Dividing by days-in-year below
											converts to a daily rate, correctly handling leap years.
										-->
										<xsl:variable name="LPIRate"
											select="($INT026_BoE_Rate + $offset) * 0.01"/>

										<LPIRate>
											<xsl:value-of
												select="$LPIRate => format-number('#.####')"/>
										</LPIRate>
										<LPIAmount>
											<xsl:variable name="LPIAmount"
												select="$LPIRate * $LPIAmountDue div $daysInYear"/>
											<xsl:value-of
												select="$LPIAmount => format-number('#.##')"/>
										</LPIAmount>
									</LPIEntry>
									</xsl:if>
								</xsl:if>

							</xsl:for-each>

						</newLPIEntries>
					</xsl:variable>
					<xsl:copy-of select="$newLPIEntries"/>
					<!-- if LPC MDC not already calculated, calculate it -->



					<!-- determine LPC band -->
					<xsl:variable name="LPCBand" select="this:lpc-band($LPIAmountDue)"/>


					<!-- determine LPC amount -->


					<!--
						Normalise the Statutory_Rate field to xs:boolean.
						Workday may deliver this as the string "true" or the integer "1"; both are
						treated as true so that the LPC look-up uses the statutory tariff table.
					-->
					<xsl:variable name="customerStatutoryRate" as="xs:boolean" select="
							let $v := normalize-space(tdf:Customer/tdf:Statutory_Rate)
							return
								if ($v = ('true', '1')) then
									true()
								else
									false()
							"/>



					<!--
						LPC is zero when either guard condition is true:
						  - LPC_MDC_Already_Calculated: the one-time charge was applied in a previous run.
						  - LPIAmountDue <= 0: no outstanding eligible balance, so no LPC is owed.
						Otherwise the LPC amount is looked up from the correct tariff table
						(statutory or standard) for the band determined by the outstanding balance.
					-->
					<xsl:variable name="LPC" as="xs:decimal" select="
							if ($LPC_MDC_Already_Calculated or $LPIAmountDue &lt;= 0 or not($graceReached) or (xs:date($INT026_Golive_Cutoff_Date) gt $dueDatePlusGrace)) then
								0
							else
								this:lpc-amount($LPCBand, $customerStatutoryRate)"/>

					<newLPC>
						<xsl:value-of select="$LPC"/>
					</newLPC>

					<!-- calculate MDC, look at MDC flag off field -->
					<xsl:variable name="MDC" as="xs:decimal"
						select="this:mdc-amount(tdf:Customer/tdf:MDC_Flag, ($LPC_MDC_Already_Calculated or $LPIAmountDue &lt;= 0 or not($graceReached) or (xs:date($INT026_Golive_Cutoff_Date) gt $dueDatePlusGrace)))"/>

					<newMDC>
						<xsl:value-of select="$MDC"/>
					</newMDC>

					<xsl:variable name="oldChargeableBalanceLPI" as="xs:decimal" select="
							if ($customerInvoice/tdf:Chargeable_Balance_LPI castable as xs:decimal) then
								$customerInvoice/tdf:Chargeable_Balance_LPI
							else
								0"/>

					<xsl:variable name="oldChargeableBalanceLPC" as="xs:decimal" select="
							if ($customerInvoice/tdf:Chargeable_Balance_LPC castable as xs:decimal) then
								$customerInvoice/tdf:Chargeable_Balance_LPC
							else
								0"/>

					<xsl:variable name="oldChargeableBalanceMDC" as="xs:decimal" select="
							if ($customerInvoice/tdf:Chargeable_Balance_MDC castable as xs:decimal) then
								$customerInvoice/tdf:Chargeable_Balance_MDC
							else
								0"/>


					<!-- new balance = sum of old balance, new LPC, new MDC and sum of all new LPI -->
					<!-- if invoice paid during grace period, set to 0 all balances -->
					<newChargeableBalanceLPI>
						<xsl:choose>
							<xsl:when test="$LPIAmountDue &lt;= 0 and $graceReached eq false()"
								>0</xsl:when>
							<xsl:otherwise>
								<xsl:value-of
									select="($oldChargeableBalanceLPI + sum($newLPIEntries/newLPIEntries/LPIEntry/LPIAmount)) => format-number('0.00')"
								/>
							</xsl:otherwise>
						</xsl:choose>
					</newChargeableBalanceLPI>

					<newChargeableBalanceLPC>
						<xsl:choose>
							<xsl:when test="$LPIAmountDue &lt;= 0 and $graceReached eq false()"
								>0</xsl:when>
							<xsl:otherwise>
								<xsl:value-of
									select="($oldChargeableBalanceLPC + $LPC) => format-number('0.000')"
								/>
							</xsl:otherwise>
						</xsl:choose>

					</newChargeableBalanceLPC>

					<newChargeableBalanceMDC>
						<xsl:choose>
							<xsl:when test="$LPIAmountDue &lt;= 0 and $graceReached eq false()"
								>0</xsl:when>
							<xsl:otherwise>
								<xsl:value-of
									select="($oldChargeableBalanceMDC + $MDC) => format-number('0.000')"
								/>
							</xsl:otherwise>
						</xsl:choose>

					</newChargeableBalanceMDC>
					
					<paidDuringGrace><xsl:value-of select="$LPIAmountDue &lt;= 0 and $graceReached eq false()"/></paidDuringGrace>

				</invoice>
			</xsl:when>
			<xsl:otherwise>

				<xsl:message etv:severity="ERROR" etv:target="tdf:Invoice_ID">
					<xsl:value-of select="
							'Due_Date not castable to xs:date for Invoice '
							|| normalize-space(tdf:Invoice_ID)
							|| ' (value: ' || tdf:Due_Date || ')'"/>

				</xsl:message>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>


	<!--
		Return the number of days in the year of the supplied date (365 or 366).
		Leap-year rule: divisible by 4 AND (not divisible by 100 OR divisible by 400).
		This is used as the denominator when converting the annual LPI rate to a daily rate,
		ensuring that interest accrual is proportionally correct in leap years.
	-->
	<xsl:function name="this:daysInYear" as="xs:integer">

		<xsl:param name="inputDate" as="xs:date"/>

		<xsl:variable name="year" select="year-from-date($inputDate)"/>

		<xsl:choose>
			<xsl:when test="($year mod 4 = 0 and $year mod 100 != 0) or ($year mod 400 = 0)"
				>366</xsl:when>
			<xsl:otherwise>365</xsl:otherwise>
		</xsl:choose>

	</xsl:function>


	<!--
		Map the outstanding LPI-eligible balance to one of three LPC tariff bands:
		  Band 1: balance < £1,000
		  Band 2: £1,000 <= balance < £10,000
		  Band 3: balance >= £10,000
		The returned integer is used as an XPath sequence index in this:lpc-amount().
	-->
	<xsl:function name="this:lpc-band" as="xs:integer">
		<xsl:param name="amount" as="xs:decimal"/>
		<xsl:sequence select="
				if ($amount lt 1000) then
					1
				else
					if ($amount lt 10000) then
						2
					else
						3
				"/>
	</xsl:function>

	<!--
		Look up the LPC charge for the given band from the correct parameter set.
		XPath sequence indexing [$band] selects the Nth item from the comma-separated
		sequence literal, making the band-to-amount mapping a single expression without
		a nested choose/when structure.
	-->
	<xsl:function name="this:lpc-amount" as="xs:decimal">
		<xsl:param name="band" as="xs:integer"/>
		<xsl:param name="statutory" as="xs:boolean"/>
		<xsl:sequence select="
				if ($statutory) then
					($INT026_LPC_Statutory_1, $INT026_LPC_Statutory_2, $INT026_LPC_Statutory_3)[$band]
				else
					($INT026_LPC_Standard_1, $INT026_LPC_Standard_2, $INT026_LPC_Standard_3)[$band]
				"/>
	</xsl:function>

	<!--
		Return the Meter Data Collection (MDC) charge for this invoice.
		MDC is also a one-time charge, suppressed when:
		  - alreadyCalculated is true (LPC/MDC were posted in a prior run), or
		  - MDC_Flag_Off = "1" (the customer has MDC charging disabled).
	-->
	<xsl:function name="this:mdc-amount" as="xs:decimal">
		<xsl:param name="mdcFlag" as="xs:string?"/>
		<xsl:param name="alreadyCalculated" as="xs:boolean"/>
		<xsl:sequence select="
				if ($alreadyCalculated) then
					0
				else
					if (normalize-space($mdcFlag) != '1') then
						0
					else
						$INT026_MDC_Amount
				"/>
	</xsl:function>


</xsl:stylesheet>
