<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:map="http://www.w3.org/2005/xpath-functions/map"
	xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:wd="urn:com.workday/bsvc"
	exclude-result-prefixes="#all">
	<xsl:output method="xml" indent="1"/>

	<!-- Declare streaming mode -->
	<xsl:mode streamable="yes" on-no-match="shallow-skip"/>


	<xsl:template match="/">
		<xsl:apply-templates/>
	</xsl:template>



	<xsl:template match="wd:Integration_Maps_Data">
		<xsl:variable name="maps">
			<xsl:apply-templates select="./copy-of()" mode="in-memory"/>
		</xsl:variable>
		<AttributeValues>
			<MDC>
				<xsl:value-of
					select="$maps/MDC_Amount_Map/mapValue[xs:date(value) &lt; current-date()][last()]/key"
				/>
			</MDC>
			<BoE_Rate>
				<xsl:value-of
					select="$maps/BoE_Rate_Map/mapValue[xs:date(value) &lt; current-date()][last()]/key"
				/>
			</BoE_Rate>
			<Standard_Offset>
				<xsl:value-of
					select="$maps/Standard_Offset_Map/mapValue[xs:date(value) &lt; current-date()][last()]/key"
				/>
			</Standard_Offset>
			<LPC_Statutory_Band1>
				<xsl:value-of
					select="$maps/LPC_Statutory_Band1_Map/mapValue[xs:date(value) &lt; current-date()][last()]/key"
				/>
			</LPC_Statutory_Band1>
			<LPC_Statutory_Band2>
				<xsl:value-of
					select="$maps/LPC_Statutory_Band2_Map/mapValue[xs:date(value) &lt; current-date()][last()]/key"
				/>
			</LPC_Statutory_Band2>
			<LPC_Statutory_Band3>
				<xsl:value-of
					select="$maps/LPC_Statutory_Band3_Map/mapValue[xs:date(value) &lt; current-date()][last()]/key"
				/>
			</LPC_Statutory_Band3>
			<LPC_Standard_Band1>
				<xsl:value-of
					select="$maps/LPC_Standard_Band1_Map/mapValue[xs:date(value) &lt; current-date()][last()]/key"
				/>
			</LPC_Standard_Band1>
			<LPC_Standard_Band2>
				<xsl:value-of
					select="$maps/LPC_Standard_Band2_Map/mapValue[xs:date(value) &lt; current-date()][last()]/key"
				/>
			</LPC_Standard_Band2>
			<LPC_Standard_Band3>
				<xsl:value-of
					select="$maps/LPC_Standard_Band3_Map/mapValue[xs:date(value) &lt; current-date()][last()]/key"
				/>
			</LPC_Standard_Band3>
		</AttributeValues>
	</xsl:template>

	<xsl:template match="wd:Integration_Map_Provider_Reference" mode="in-memory"/>

	<xsl:template match="wd:Integration_Map_Data" mode="in-memory">



		<xsl:element name="{wd:Integration_Map_Name}">
			<xsl:for-each select="wd:Integration_Map_Value_Data">
				<xsl:sort select="xs:date(wd:Internal_Value_Data/wd:Text)" data-type="text"
					order="ascending"/>
				<mapValue>
					<key>
						<xsl:value-of select="wd:External_Value_Data/wd:Text"/>
					</key>
					<value>
						<xsl:value-of select="wd:Internal_Value_Data/wd:Date"/>
					</value>
				</mapValue>
			</xsl:for-each>
		</xsl:element>




	</xsl:template>


</xsl:stylesheet>
